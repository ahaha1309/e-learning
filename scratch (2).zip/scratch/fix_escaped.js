const mongoose = require('mongoose');
const QuestionBank = require('../models/QuestionBank');
const Question = require('../models/Question');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

function unescapeHtml(text) {
  if (!text) return text;
  return text
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#x2F;/g, '/')
    .replace(/&amp;/g, '&');
}

async function run() {
  await mongoose.connect(process.env.MONGO_URL);
  
  let fixedQb = 0;
  const qbs = await QuestionBank.find({});
  for (const qb of qbs) {
    if (qb.content && qb.content.includes('&lt;')) {
      qb.content = unescapeHtml(qb.content);
      await qb.save();
      fixedQb++;
    }
  }

  let fixedQ = 0;
  const qs = await Question.find({});
  for (const q of qs) {
    if (q.content && q.content.includes('&lt;')) {
      q.content = unescapeHtml(q.content);
      await q.save();
      fixedQ++;
    }
  }

  console.log(`Fixed ${fixedQb} QuestionBank items and ${fixedQ} Question items.`);
  process.exit(0);
}

run();
