/**
 * Script hoàn thiện tạo tài liệu Huong_dan_ve_bieu_do.docx
 * Tổng hợp toàn bộ 15 biểu đồ với ma trận kết nối A -> B, nhãn mũi tên, mã Mermaid và Code Mapping.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel,
  AlignmentType, PageBreak, ShadingType, Table, TableRow, TableCell,
  WidthType, BorderStyle,
  titleDoc, subTitleDoc, h1, h2, h3, p, callout, codeBlock, createTable
} = require('./diagram_helpers');

const part1 = require('./diagrams_data_part1');
const part2 = require('./diagrams_data_part2');
const part3 = require('./diagrams_data_part3');

const allDiagrams = [...part1, ...part2, ...part3];

console.log(`Đã nạp thành công ${allDiagrams.length} biểu đồ.`);

const docChildren = [];

// ─── TRANG TIÊU ĐỀ & PHẦN MỞ ĐẦU ─────────────────────────────────────────────
docChildren.push(
  new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun({
        text: 'BỘ GIÁO DỤC VÀ ĐÀO TẠO — TRƯỜNG ĐẠI HỌC MỎ - ĐỊA CHẤT',
        bold: true,
        size: 22,
        font: 'Times New Roman',
        color: '4B5563',
      }),
    ],
    spacing: { after: 60 },
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun({
        text: 'KHOA CÔNG NGHỆ THÔNG TIN — BỘ MÔN CÔNG NGHỆ PHẦN MỀM',
        bold: true,
        size: 24,
        font: 'Times New Roman',
        color: '1E3A8A',
      }),
    ],
    spacing: { after: 200 },
  }),
  titleDoc('TÀI LIỆU HƯỚNG DẪN TỰ VẼ VÀ TÁI TẠO TOÀN BỘ 15 BIỂU ĐỒ BÁO CÁO ĐỒ ÁN TỐT NGHIỆP'),
  subTitleDoc('Đề tài: Xây dựng hệ thống quản lý học tập trực tuyến tích hợp trí tuệ nhân tạo và lớp học ảo (E-Learning LMS)'),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun({
        text: '★ ĐẶC TẢ CHI TIẾT MA TRẬN KẾT NỐI (A → B) — NHÃN CHỮ TRÊN MŨI TÊN — MÃ MERMAID 1-CLICK TỰ ĐỘNG SINH HÌNH ★',
        bold: true,
        size: 20,
        color: 'DC2626',
        font: 'Times New Roman',
      }),
    ],
    spacing: { after: 300 },
  })
);

// Callout hướng dẫn chung
docChildren.push(
  callout('LƯU Ý QUAN TRỌNG KHI SỬ DỤNG TÀI LIỆU NÀY:', [
    '1. Tài liệu này cung cấp đầy đủ thông tin để bạn vẽ lại 100% chính xác toàn bộ 15 biểu đồ bằng công cụ Draw.io (diagrams.net), StarUML hoặc Visual Paradigm.',
    '2. Để bạn dễ hiểu và vẽ theo nhanh nhất, MỖI BIỂU ĐỒ ĐỀU CÓ "BẢNG ĐẶC TẢ MŨI TÊN (A → B)" chỉ rõ: Phần tử nguồn nối tới phần tử đích nào, loại mũi tên gì, trên mũi tên ghi chính xác chữ gì và hành động nghiệp vụ thực tế là gì.',
    '3. TÍNH NĂNG 1-CLICK DRAW.IO: Cuối mỗi biểu đồ có sẵn đoạn mã Mermaid. Bạn chỉ cần mở Draw.io -> Vào menu [Arrange] -> [Insert] -> [Advanced] -> [Mermaid] -> Dán đoạn mã vào -> Bấm [Insert] là Draw.io tự động vẽ ra toàn bộ biểu đồ với đầy đủ các khối và mũi tên chuẩn xác 100%!',
    '4. Toàn bộ các phần tử và mũi tên đều được đối chiếu trực tiếp với mã nguồn thực tế của dự án e-learning (file code, controller, service, routes).',
  ]),
  p(' ')
);

// ─── BẢNG TỔNG HỢP 15 BIỂU ĐỒ ───────────────────────────────────────────────
docChildren.push(
  h1('DANH MỤC TỔNG HỢP 15 BIỂU ĐỒ VÀ VỊ TRÍ TRONG BÁO CÁO'),
  p('Dưới đây là danh mục toàn bộ 15 biểu đồ theo đúng thứ tự xuất hiện trong Báo cáo Đồ án tốt nghiệp:'),
  createTable(
    ['STT', 'Mã hình', 'Tên biểu đồ', 'Loại biểu đồ UML / Kiến trúc', 'Vị trí trong báo cáo'],
    allDiagrams.map((d, idx) => [
      idx + 1,
      d.id,
      d.title,
      d.diagramType,
      d.chapterLocation,
    ]),
    [8, 12, 38, 22, 20]
  ),
  p(' '),
  new Paragraph({ children: [new PageBreak()] })
);

// ─── CHI TIẾT TỪNG BIỂU ĐỒ TRONG SỐ 15 BIỂU ĐỒ ──────────────────────────────
allDiagrams.forEach((d, idx) => {
  console.log(`Đang sinh biểu đồ ${idx + 1}/${allDiagrams.length}: ${d.id} - ${d.title}`);

  // Heading biểu đồ
  docChildren.push(
    h1(`${d.id}: ${d.title}`),
    callout(`THÔNG TIN ĐẶC TẢ — [${d.status}]`, [
      `• Vị trí đề xuất trong báo cáo: ${d.chapterLocation}`,
      `• Loại biểu đồ: ${d.diagramType}`,
      `• Mục đích & Ý nghĩa: ${d.purpose}`,
    ]),
    p(' ')
  );

  // 1. Danh sách phần tử và hình khối
  docChildren.push(
    h2('1. Danh sách phần tử và hình khối cần vẽ (Node Inventory)'),
    p('Trước khi vẽ các đường nối, bạn hãy kéo thả các hình khối tương ứng với các phần tử dưới đây lên trang vẽ Draw.io:'),
    createTable(
      ['Mã Node', 'Tên phần tử trên hình', 'Hình khối trong Draw.io', 'Màu sắc gợi ý', 'Vai trò / Ý nghĩa kỹ thuật'],
      d.nodes.map((n) => [n[0], n[1], n[2], n[3], n[4]]),
      [10, 24, 22, 18, 26]
    ),
    p(' ')
  );

  // 2. BẢNG ĐẶC TẢ CHI TIẾT TỪNG MŨI TÊN KẾT NỐI (A -> B)
  docChildren.push(
    h2('2. Bảng đặc tả chi tiết từng mũi tên kết nối (Ma trận A → B)'),
    p('Đây là phần quan trọng nhất: Hãy nối từng mũi tên từ phần tử nguồn tới phần tử đích, ghi chính xác nhãn text trên mũi tên theo bảng dưới:'),
    createTable(
      ['STT', 'Từ phần tử (Source A)', 'Đến phần tử (Target B)', 'Kiểu đường nối', 'Nhãn chữ ghi trên mũi tên (Label)', 'Hành động nghiệp vụ thực tế'],
      d.connections.map((c) => [c[0], c[1], c[2], c[3], c[4], c[5]]),
      [6, 18, 18, 18, 22, 18]
    ),
    p(' ')
  );

  // 3. Sơ đồ dòng chảy tóm tắt (Text Flow)
  docChildren.push(
    h2('3. Sơ đồ dòng chảy trực quan (Text-Flow Summary)'),
    p('Cấu trúc luồng đi tuần tự từ đầu đến cuối giúp bạn nhìn nhanh toàn cảnh mà không bị rối mắt:'),
    codeBlock(d.textFlow),
    p(' ')
  );

  // 4. Mã nguồn Mermaid (1-Click Draw.io Import)
  docChildren.push(
    h2('4. Mã nguồn Mermaid (Copy & Paste vào Draw.io để vẽ tự động)'),
    callout('HƯỚNG DẪN 1-CLICK TỰ ĐỘNG VẼ TRÊN DRAW.IO:', [
      'Bước 1: Mở trình duyệt truy cập app.diagrams.net (Draw.io).',
      'Bước 2: Trên thanh menu, chọn [Arrange] -> [Insert] -> [Advanced] -> [Mermaid].',
      'Bước 3: Sao chép toàn bộ đoạn mã trong khung dưới đây và dán vào cửa sổ nhập.',
      'Bước 4: Bấm nút [Insert]. Toàn bộ biểu đồ sẽ được tự động vẽ ra với đầy đủ các khối và mũi tên!',
      'Bước 5: Kéo thả căn chỉnh vị trí cho đẹp mắt, sau đó xuất ra file ảnh PNG độ phân giải cao để chèn vào Word.',
    ]),
    p(' '),
    codeBlock(d.mermaidCode),
    p(' ')
  );

  // 5. Bảng ánh xạ đối chiếu mã nguồn thực tế
  docChildren.push(
    h2('5. Bảng ánh xạ đối chiếu với mã nguồn thực tế (Code Mapping)'),
    p('Mỗi thành phần và liên kết trên biểu đồ tương ứng với các file mã nguồn cụ thể sau trong dự án:'),
    createTable(
      ['Thành phần biểu đồ', 'File mã nguồn thực tế trong dự án', 'Hàm / Class / Route thực thi'],
      d.codeMapping.map((m) => [m[0], m[1], m[2]]),
      [25, 45, 30]
    ),
    p(' ')
  );

  // Ngắt trang giữa các biểu đồ (trừ biểu đồ cuối)
  if (idx < allDiagrams.length - 1) {
    docChildren.push(new Paragraph({ children: [new PageBreak()] }));
  }
});

// ─── TẠO VÀ XUẤT FILE DOCX ──────────────────────────────────────────────────
console.log('Đang đóng gói tài liệu Word...');

const doc = new Document({
  styles: {
    default: {
      document: {
        run: {
          font: 'Times New Roman',
          size: 24, // 12pt
          color: '1F2937',
        },
        paragraph: {
          spacing: { line: 280, before: 60, after: 60 },
        },
      },
    },
  },
  sections: [
    {
      properties: {
        page: {
          margin: {
            top: 1134, // ~2cm
            bottom: 1134,
            left: 1417, // ~2.5cm
            right: 1134,
          },
        },
      },
      children: docChildren,
    },
  ],
});

Packer.toBuffer(doc)
  .then((buffer) => {
    const outputPath = path.resolve(__dirname, '..', 'Huong_dan_ve_bieu_do.docx');
    fs.writeFileSync(outputPath, buffer);
    console.log(`\n================================================================`);
    console.log(`✓ ĐÃ TẠO THÀNH CÔNG TÀI LIỆU: ${outputPath}`);
    console.log(`✓ Dung lượng tệp: ${(buffer.length / 1024).toFixed(2)} KB`);
    console.log(`✓ Tổng số biểu đồ hoàn thiện: ${allDiagrams.length}/15 biểu đồ`);
    console.log(`================================================================\n`);
  })
  .catch((err) => {
    console.error('Lỗi khi đóng gói file Word:', err);
    process.exit(1);
  });
