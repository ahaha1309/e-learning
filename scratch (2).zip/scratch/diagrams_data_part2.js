/**
 * Dữ liệu chi tiết cho 5 biểu đồ tiếp theo (Hình 2-3 -> Hình 2-7)
 * Bao gồm Nodes, Ma trận kết nối A -> B, Text Flow, Mermaid Code, Code Mapping
 */
module.exports = [
  // ─── HÌNH 2-3 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-3',
    title: 'Biểu đồ Ca sử dụng phân rã phân hệ Sinh viên',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.4: Đặc tả phân rã chức năng phân hệ Sinh viên (Student Subsystem)',
    purpose: 'Mô tả chi tiết toàn bộ các chức năng và tương tác học tập của sinh viên: tham gia lớp bằng mã PIN, học bài giảng số, nộp bài tập, tham gia lớp học ảo, làm bài kiểm tra trực tuyến có camera giám sát và theo dõi sổ điểm.',
    diagramType: 'Biểu đồ Ca sử dụng phân rã (Subsystem Use Case Diagram)',
    nodes: [
      ['ACT1', 'Sinh viên (Student)', 'Actor (Hình người)', '#DCFCE7', 'Người học chính trong hệ thống thực hiện các tác vụ học tập'],
      ['PKG1', 'Gói: Quản lý Khóa học & Lớp học', 'Gói Package UML', '#F1F5F9', 'Ghi danh, xem tiến độ và thông tin lớp'],
      ['UC_S01', 'Tham gia lớp học bằng mã PIN 6 số', 'Hình Oval', '#FFFFFF', 'Nhập mã PIN giáo viên cung cấp để trở thành ClassroomMember'],
      ['UC_S02', 'Xem Danh sách lớp học & Tiến độ cá nhân', 'Hình Oval', '#FFFFFF', 'Theo dõi phần trăm hoàn thành bài học, hạn nộp bài tập sắp tới'],
      ['PKG2', 'Gói: Học tập & Tương tác', 'Gói Package UML', '#F1F5F9', 'Học bài giảng, nộp bài và tương tác thảo luận'],
      ['UC_S03', 'Xem Nội dung Bài giảng & Tải tài liệu', 'Hình Oval', '#FFFFFF', 'Đọc nội dung văn bản, xem video nhúng và tải tệp PDF đính kèm'],
      ['UC_S04', 'Nộp Bài tập về nhà (Upload file / Soạn text)', 'Hình Oval', '#FFFFFF', 'Tải tệp bài giải hoặc soạn thảo câu trả lời trước deadline'],
      ['UC_S05', 'Tham gia Diễn đàn Thảo luận & Đặt câu hỏi', 'Hình Oval', '#FFFFFF', 'Tạo chủ đề thảo luận trong bài học, bình luận phản hồi bạn học'],
      ['PKG3', 'Gói: Lớp học ảo & Điểm danh', 'Gói Package UML', '#F1F5F9', 'Phòng học trực tuyến WebRTC và điểm danh'],
      ['UC_S06', 'Vào Phòng chờ Lớp học ảo (Waiting Room)', 'Hình Oval', '#FFFFFF', 'Chờ giảng viên duyệt cấp quyền truy cập vào phòng học trực tuyến'],
      ['UC_S07', 'Tương tác trong Lớp học ảo (Mic/Cam/Chat/Giơ tay)', 'Hình Oval', '#FFFFFF', 'Bật/tắt micro, webcam, giơ tay xin phát biểu, nhắn tin trong phòng'],
      ['UC_S08', 'Điểm danh tự động & Check-in Webcam', 'Hình Oval', '#FFFFFF', 'Ghi nhận thời gian có mặt và chụp ảnh kiểm chứng tham dự'],
      ['PKG4', 'Gói: Kiểm tra & Khảo thí', 'Gói Package UML', '#F1F5F9', 'Làm bài thi trực tuyến và xem kết quả'],
      ['UC_S09', 'Làm bài thi trực tuyến (Online Exam)', 'Hình Oval', '#FFFFFF', 'Làm bài kiểm tra trắc nghiệm trong môi trường bảo vệ toàn màn hình'],
      ['UC_S10', 'Chấp hành Giám sát Vi phạm (Anti-cheat)', 'Hình Oval', '#FEE2E2', 'Hiển thị cảnh báo khi rời tab, chuyển màn hình, tự động nộp bài khi quá giới hạn'],
      ['UC_S11', 'Xem Kết quả, Điểm số & Đáp án chi tiết', 'Hình Oval', '#FFFFFF', 'Xem điểm đạt được, tỷ lệ đúng/sai và lời giải thích chi tiết của từng câu'],
    ],
    connections: [
      ['1', 'ACT1 (Sinh viên)', 'UC_S01 (Tham gia lớp mã PIN)', 'Đường nối liền nét (──)', 'Ghi danh vào lớp', 'Gửi request POST /student/classrooms/join kèm mã PIN'],
      ['2', 'ACT1 (Sinh viên)', 'UC_S02 (Xem danh sách lớp)', 'Đường nối liền nét (──)', 'Theo dõi học tập', 'Truy cập Dashboard sinh viên'],
      ['3', 'ACT1 (Sinh viên)', 'UC_S03 (Xem bài giảng)', 'Đường nối liền nét (──)', 'Tiếp cận học liệu', 'Xem bài học, ghi nhận tiến độ progress'],
      ['4', 'ACT1 (Sinh viên)', 'UC_S04 (Nộp bài tập)', 'Đường nối liền nét (──)', 'Nộp bài trước hạn', 'Upload file giải bài lên Cloudinary'],
      ['5', 'ACT1 (Sinh viên)', 'UC_S05 (Thảo luận diễn đàn)', 'Đường nối liền nét (──)', 'Trao đổi hỏi đáp', 'Gửi bình luận socket thời gian thực'],
      ['6', 'ACT1 (Sinh viên)', 'UC_S06 (Vào phòng chờ)', 'Đường nối liền nét (──)', 'Yêu cầu vào học', 'Gửi sự kiện socket "request-entry"'],
      ['7', 'UC_S06 (Vào phòng chờ)', 'UC_S07 (Tương tác phòng học)', 'Mũi tên nét đứt có chữ <<include>> (⇢)', '<<include>> (Sau khi được duyệt)', 'Được giảng viên duyệt sẽ kết nối thẳng WebRTC'],
      ['8', 'UC_S07 (Tương tác phòng học)', 'UC_S08 (Điểm danh tự động)', 'Mũi tên nét đứt có chữ <<include>> (⇢)', '<<include>> (Tự động ghi nhận)', 'Hệ thống tự động lưu attendance record'],
      ['9', 'ACT1 (Sinh viên)', 'UC_S09 (Làm bài thi online)', 'Đường nối liền nét (──)', 'Thực hiện bài kiểm tra', 'Mở giao diện phòng thi take-exam.pug'],
      ['10', 'UC_S09 (Làm bài thi online)', 'UC_S10 (Giám sát vi phạm)', 'Mũi tên nét đứt có chữ <<include>> (⇢)', '<<include>> (Bắt buộc kích hoạt)', 'Module client-monitor tự động khóa phím, chặn đổi tab'],
      ['11', 'UC_S09 (Làm bài thi online)', 'UC_S11 (Xem kết quả điểm)', 'Mũi tên nét đứt có chữ <<extend>> (⇢)', '<<extend>> (Sau khi nộp bài)', 'Hiển thị phổ điểm sau khi hoàn thành hoặc có sự cho phép'],
    ],
    textFlow: `[Sinh viên]
  ├──> [Ghi danh & Lớp học]: Nhập mã PIN tham gia ── Xem tiến độ
  ├──> [Học tập]: Xem bài giảng & Tải tài liệu ── Nộp bài tập ── Thảo luận
  ├──> [Lớp học ảo]: Vào phòng chờ ──<<include>>──> Tương tác phòng học ──<<include>>──> Điểm danh tự động
  └──> [Khảo thí]: Làm bài thi trực tuyến
                      ├──<<include>>──> Chấp hành Giám sát Vi phạm (Anti-cheat)
                      └──<<extend>>───> Xem Kết quả, Điểm số & Đáp án`,
    mermaidCode: `graph TD
  Student(("Sinh viên"))

  subgraph ClassSub ["Phân hệ Lớp học & Tiến độ"]
    UC_S01(["Tham gia lớp bằng mã PIN"])
    UC_S02(["Xem danh sách lớp & Tiến độ"])
  end

  subgraph LearnSub ["Phân hệ Học tập & Thảo luận"]
    UC_S03(["Xem bài giảng & Tải tài liệu"])
    UC_S04(["Nộp bài tập về nhà"])
    UC_S05(["Thảo luận diễn đàn"])
  end

  subgraph LiveSub ["Phân hệ Lớp học ảo & Điểm danh"]
    UC_S06(["Vào phòng chờ (Waiting Room)"])
    UC_S07(["Tương tác phòng học (Cam/Mic/Chat)"])
    UC_S08(["Điểm danh tự động"])
  end

  subgraph ExamSub ["Phân hệ Khảo thí Trực tuyến"]
    UC_S09(["Làm bài thi trực tuyến"])
    UC_S10(["Giám sát vi phạm (Anti-cheat)"])
    UC_S11(["Xem kết quả điểm & Lời giải"])
  end

  Student --- UC_S01
  Student --- UC_S02
  Student --- UC_S03
  Student --- UC_S04
  Student --- UC_S05
  Student --- UC_S06
  UC_S06 -.->|"<<include>>"| UC_S07
  UC_S07 -.->|"<<include>>"| UC_S08

  Student --- UC_S09
  UC_S09 -.->|"<<include>>"| UC_S10
  UC_S09 -.->|"<<extend>>"| UC_S11`,
    codeMapping: [
      ['Ghi danh & Lớp học', 'controller/student/classroom.controller.js', 'joinClassroomByPin(), getMyClassrooms()'],
      ['Học bài giảng', 'controller/student/lecture.controller.js', 'getLectureDetail(), markComplete()'],
      ['Nộp bài tập', 'controller/student/assignment.controller.js', 'submitAssignment()'],
      ['Lớp học ảo', 'views/student/classrooms/live.pug, public/js/classroom-live.js', 'Sự kiện socket waiting room'],
      ['Thi trực tuyến & Giám sát', 'controller/student/exam.controller.js, public/js/take-exam.js', 'takeExam(), logViolation(), submitExam()'],
    ]
  },

  // ─── HÌNH 2-4 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-4',
    title: 'Biểu đồ Ca sử dụng phân rã phân hệ Quản trị viên (Admin)',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.5: Đặc tả phân rã chức năng phân hệ Quản trị viên (Admin Subsystem)',
    purpose: 'Mô tả chi tiết quyền hạn tối cao của Quản trị viên: Quản trị tài khoản, phê duyệt giảng viên, giám sát số liệu vận hành thời gian thực, quản lý danh mục và cấu hình bảo mật hệ thống.',
    diagramType: 'Biểu đồ Ca sử dụng phân rã (Subsystem Use Case Diagram)',
    nodes: [
      ['ACT1', 'Quản trị viên (Admin)', 'Actor (Hình người)', '#FEE2E2', 'Quản trị viên hệ thống có toàn quyền giám sát và thiết lập'],
      ['PKG1', 'Gói: Quản trị Người dùng & Phân quyền', 'Gói Package UML', '#F1F5F9', 'Quản lý tài khoản toàn hệ thống'],
      ['UC_A01', 'Xem Danh sách & Lọc Người dùng', 'Hình Oval', '#FFFFFF', 'Lọc theo vai trò (Teacher, Student, Admin), trạng thái hoạt động'],
      ['UC_A02', 'Khóa / Kích hoạt Tài khoản', 'Hình Oval', '#FFFFFF', 'Vô hiệu hóa tài khoản vi phạm chính sách hoặc mở lại'],
      ['UC_A03', 'Phê duyệt Hồ sơ Giảng viên', 'Hình Oval', '#FFFFFF', 'Xét duyệt minh chứng bằng cấp và kích hoạt quyền tạo lớp'],
      ['UC_A04', 'Đặt lại Mật khẩu & Gán Vai trò', 'Hình Oval', '#FFFFFF', 'Cấp lại quyền truy cập khi người dùng gặp sự cố'],
      ['PKG2', 'Gói: Báo cáo Thống kê & Giám sát KPI', 'Gói Package UML', '#F1F5F9', 'Số liệu vận hành và hiệu năng'],
      ['UC_A05', 'Xem Dashboard Thống kê Tổng thể', 'Hình Oval', '#FFFFFF', 'Số lượng người dùng mới, lớp học đang hoạt động, bài thi hoàn thành'],
      ['UC_A06', 'Biểu đồ Tăng trưởng & Xu hướng', 'Hình Oval', '#FFFFFF', 'Biểu đồ 30 ngày tăng trưởng người dùng, tỷ lệ hoàn thành khóa học'],
      ['UC_A07', 'Giám sát Tài nguyên & Sức khỏe Hệ thống', 'Hình Oval', '#FFFFFF', 'Theo dõi thời gian phản hồi, trạng thái kết nối MongoDB, uptime'],
      ['PKG3', 'Gói: Quản trị Danh mục & Cấu hình Hệ thống', 'Gói Package UML', '#F1F5F9', 'Thông số hệ thống và nhật ký bảo mật'],
      ['UC_A08', 'Quản lý Khoa / Bộ môn & Chuyên ngành', 'Hình Oval', '#FFFFFF', 'Tổ chức cây phân cấp quản lý đào tạo'],
      ['UC_A09', 'Cấu hình Tham số Hệ thống (SMTP, API Keys)', 'Hình Oval', '#FFFFFF', 'Cập nhật API Key Gemini AI, Cloudinary credentials, mail server'],
      ['UC_A10', 'Tra cứu Nhật ký An ninh (Audit Logs)', 'Hình Oval', '#FFFFFF', 'Xem vết IP, thời gian, hành vi xóa/sửa dữ liệu quan trọng'],
    ],
    connections: [
      ['1', 'ACT1 (Quản trị viên)', 'UC_A01 (Xem & Lọc người dùng)', 'Đường nối liền nét (──)', 'Quản trị danh sách người dùng', 'GET /admin/users'],
      ['2', 'ACT1 (Quản trị viên)', 'UC_A02 (Khóa/Mở tài khoản)', 'Đường nối liền nét (──)', 'Kiểm soát truy cập', 'POST /admin/users/:id/toggle-status'],
      ['3', 'ACT1 (Quản trị viên)', 'UC_A03 (Duyệt giảng viên)', 'Đường nối liền nét (──)', 'Xác minh hồ sơ giáo viên', 'POST /admin/teachers/:id/approve'],
      ['4', 'ACT1 (Quản trị viên)', 'UC_A04 (Gán vai trò & reset pass)', 'Đường nối liền nét (──)', 'Thay đổi thẩm quyền', 'POST /admin/users/:id/role'],
      ['5', 'ACT1 (Quản trị viên)', 'UC_A05 (Xem Dashboard KPI)', 'Đường nối liền nét (──)', 'Tổng quan điều hành', 'GET /admin/dashboard'],
      ['6', 'UC_A05 (Xem Dashboard)', 'UC_A06 (Biểu đồ tăng trưởng)', 'Mũi tên nét đứt có chữ <<include>> (⇢)', '<<include>> (Hiển thị biểu đồ)', 'Tự động tính toán chart data từ MongoDB'],
      ['7', 'ACT1 (Quản trị viên)', 'UC_A07 (Giám sát tài nguyên)', 'Đường nối liền nét (──)', 'Kiểm tra sức khỏe server', 'GET /admin/health'],
      ['8', 'ACT1 (Quản trị viên)', 'UC_A08 (Quản lý khoa/bộ môn)', 'Đường nối liền nét (──)', 'Cấu trúc đào tạo', 'CRUD /admin/categories'],
      ['9', 'ACT1 (Quản trị viên)', 'UC_A09 (Cấu hình hệ thống)', 'Đường nối liền nét (──)', 'Thiết lập tham số môi trường', 'POST /admin/settings'],
      ['10', 'ACT1 (Quản trị viên)', 'UC_A10 (Tra cứu Audit Logs)', 'Đường nối liền nét (──)', 'Kiểm toán an ninh', 'GET /admin/audit-logs'],
    ],
    textFlow: `[Quản trị viên]
  ├──> [Quản trị Người dùng]: Xem danh sách ── Khóa/Mở tài khoản ── Duyệt giảng viên ── Phân vai trò
  ├──> [Thống kê & Giám sát]: Dashboard KPI ──<<include>>──> Biểu đồ tăng trưởng ── Sức khỏe hệ thống
  └──> [Hệ thống & Cấu hình]: Quản lý khoa/bộ môn ── Cấu hình SMTP/API Keys ── Tra cứu Audit Logs`,
    mermaidCode: `graph TD
  Admin(("Quản trị viên (Admin)"))

  subgraph UserMgmt ["Quản trị Người dùng & Phân quyền"]
    UC_A01(["Xem & Lọc người dùng"])
    UC_A02(["Khóa / Mở tài khoản"])
    UC_A03(["Phê duyệt giảng viên"])
    UC_A04(["Gán vai trò & Reset mật khẩu"])
  end

  subgraph Analytics ["Thống kê KPI & Giám sát"]
    UC_A05(["Dashboard KPI tổng thể"])
    UC_A06(["Biểu đồ tăng trưởng"])
    UC_A07(["Giám sát sức khỏe hệ thống"])
  end

  subgraph SystemConf ["Quản trị Danh mục & Cấu hình"]
    UC_A08(["Quản lý Khoa / Bộ môn"])
    UC_A09(["Cấu hình SMTP & API Keys"])
    UC_A10(["Tra cứu Audit Logs"])
  end

  Admin --- UC_A01
  Admin --- UC_A02
  Admin --- UC_A03
  Admin --- UC_A04

  Admin --- UC_A05
  UC_A05 -.->|"<<include>>"| UC_A06
  Admin --- UC_A07

  Admin --- UC_A08
  Admin --- UC_A09
  Admin --- UC_A10`,
    codeMapping: [
      ['Dashboard & Thống kê', 'controller/admin/dashboard.controller.js', 'getDashboardStats(), getGrowthChartData()'],
      ['Quản lý Người dùng', 'controller/admin/user.controller.js', 'getUsers(), toggleUserStatus(), updateUserRole()'],
      ['Phê duyệt giảng viên', 'controller/admin/user.controller.js', 'approveTeacher()'],
      ['Cấu hình hệ thống', 'controller/admin/setting.controller.js, views/admin/settings.pug', 'getSettings(), updateSettings()'],
      ['Audit Logs', 'models/AuditLog.js, controller/admin/auditLog.controller.js', 'getLogs()'],
    ]
  },

  // ─── HÌNH 2-5 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-5',
    title: 'Biểu đồ Hoạt động quy trình trích xuất tài liệu và sinh câu hỏi bằng AI Gemini',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.6: Phân tích quy trình nghiệp vụ tự động sinh đề thi bằng Trí tuệ nhân tạo',
    purpose: 'Đặc tả chi tiết từng bước chuyển giao dữ liệu từ khi Giảng viên tải tệp tài liệu học tập, qua các bước xử lý parser, validate, gọi Gemini 3.8 Flash, làm sạch JSON, cho đến khi xem trước và lưu vào CSDL.',
    diagramType: 'Biểu đồ Hoạt động phân làn (Activity Diagram with Swimlanes)',
    nodes: [
      ['START', 'Nút khởi đầu (Initial State)', 'Hình tròn đen đặc (●)', '#000000', 'Bắt đầu quy trình'],
      ['LANE1', 'Làn Giảng viên (Teacher)', 'Làn bơi (Swimlane Trái)', '#EFF6FF', 'Thao tác của người dùng trên giao diện'],
      ['LANE2', 'Làn LMS Server (Node.js)', 'Làn bơi (Swimlane Giữa)', '#F0FDF4', 'Hệ thống tiếp nhận, xử lý tệp, validate'],
      ['LANE3', 'Làn Google Gemini API', 'Làn bơi (Swimlane Phải)', '#FAF5FF', 'Dịch vụ AI phân tích ngữ nghĩa và sinh câu hỏi'],
      ['ACT_1', 'Giảng viên chọn tệp (PDF/DOCX/TXT) & cấu hình tham số', 'Hình chữ nhật bo góc', '#FFFFFF', 'Chọn số lượng câu (5-30), độ khó (Dễ/TB/Khó), chủ đề trọng tâm'],
      ['ACT_2', 'Nhấn nút "Sinh câu hỏi bằng AI"', 'Hình chữ nhật bo góc', '#FFFFFF', 'Gửi request FormData qua AJAX tới endpoint máy chủ'],
      ['ACT_3', 'Multer Middleware tiếp nhận tệp & kiểm tra hợp lệ', 'Hình chữ nhật bo góc', '#FFFFFF', 'Kiểm tra MIME-type và kích thước tệp (< 10MB)'],
      ['DEC_1', 'Kiểm tra định dạng & kích thước có hợp lệ?', 'Hình thoi quyết định (◇)', '#FEF3C7', 'Điều kiện rẽ nhánh kiểm tra tệp'],
      ['ACT_4', 'Trả thông báo lỗi tệp không hợp lệ', 'Hình chữ nhật bo góc', '#FEE2E2', 'Thông báo định dạng không hỗ trợ hoặc file quá lớn'],
      ['ACT_5', 'Text Extractor giải mã nội dung văn bản thuần', 'Hình chữ nhật bo góc', '#FFFFFF', 'Dùng pdf-parse (với PDF) hoặc mammoth (với DOCX) trích xuất chuỗi text'],
      ['DEC_2', 'Văn bản có đủ độ dài tối thiểu (> 50 từ)?', 'Hình thoi quyết định (◇)', '#FEF3C7', 'Kiểm tra xem file có nội dung thực chất không'],
      ['ACT_6', 'Báo lỗi tài liệu quá ngắn/rỗng', 'Hình chữ nhật bo góc', '#FEE2E2', 'Yêu cầu tải tài liệu có dung lượng nội dung phong phú hơn'],
      ['ACT_7', 'Chuẩn hóa System Prompt & Schema JSON', 'Hình chữ nhật bo góc', '#FFFFFF', 'Ghép nội dung văn bản vào mẫu prompt chuẩn hóa cấu trúc output JSON'],
      ['ACT_8', 'Gửi HTTPS Request tới Google Gemini API', 'Hình chữ nhật bo góc', '#FFFFFF', 'Gọi endpoint models/gemini-3.8-flash:generateContent'],
      ['ACT_9', 'Gemini AI phân tích ngữ nghĩa & sinh mảng câu hỏi', 'Hình chữ nhật bo góc', '#F3E8FF', 'Mô hình AI suy luận, trích xuất kiến thức trọng tâm và tạo câu hỏi'],
      ['ACT_10', 'Trả về JSON Payload chứa danh sách câu hỏi', 'Hình chữ nhật bo góc', '#F3E8FF', 'Gemini trả về chuỗi JSON chứa các object câu hỏi'],
      ['ACT_11', 'LMS JSON Parser làm sạch chuỗi & Parse Object', 'Hình chữ nhật bo góc', '#FFFFFF', 'Cắt bỏ markdown ticks ```json, kiểm tra hợp lệ cấu trúc'],
      ['DEC_3', 'JSON có hợp lệ và đầy đủ trường bắt buộc?', 'Hình thoi quyết định (◇)', '#FEF3C7', 'Kiểm tra question, options, correctAnswer, explanation'],
      ['ACT_12', 'Kích hoạt cơ chế Fallback Regex trích xuất', 'Hình chữ nhật bo góc', '#FEF3C7', 'Tự động quét mẫu regex cứu các câu hỏi nếu JSON bị lệch chuẩn nhẹ'],
      ['ACT_13', 'Render Modal xem trước danh sách câu hỏi', 'Hình chữ nhật bo góc', '#FFFFFF', 'Hiển thị bảng câu hỏi trực quan trên giao diện cho giáo viên kiểm tra'],
      ['ACT_14', 'Giảng viên duyệt, sửa nội dung/đáp án các câu hỏi', 'Hình chữ nhật bo góc', '#FFFFFF', 'Cho phép sửa câu chữ, đổi đáp án đúng trước khi lưu'],
      ['ACT_15', 'Nhấn "Lưu vào Đề thi / Ngân hàng câu hỏi"', 'Hình chữ nhật bo góc', '#FFFFFF', 'Gửi POST lưu dữ liệu vào CSDL'],
      ['ACT_16', 'Mongoose lưu Question Documents vào MongoDB', 'Hình chữ nhật bo góc', '#FFFFFF', 'Thực thi Question.insertMany() và gắn ID vào Exam'],
      ['ACT_17', 'Thông báo thành công & Tải lại giao diện', 'Hình chữ nhật bo góc', '#DCFCE7', 'Hiển thị thông báo Toast xanh và cập nhật danh sách câu hỏi'],
      ['END', 'Nút kết thúc (Final State)', 'Vòng tròn mắt bò (◉)', '#000000', 'Kết thúc hoàn tất quy trình'],
    ],
    connections: [
      ['1', 'START (Bắt đầu)', 'ACT_1 (Chọn tệp & tham số)', 'Mũi tên liền nét (──>)', 'Bắt đầu quy trình', 'Giảng viên mở trang tạo đề thi và click nút AI Generate'],
      ['2', 'ACT_1 (Chọn tệp & tham số)', 'ACT_2 (Nhấn nút sinh)', 'Mũi tên liền nét (──>)', 'Hoàn tất chọn tệp', 'Giảng viên chọn xong tệp tài liệu bài giảng'],
      ['3', 'ACT_2 (Nhấn nút sinh)', 'ACT_3 (Multer tiếp nhận)', 'Mũi tên liền nét vắt qua làn (──>)', 'HTTP POST multipart/form-data', 'Trình duyệt bắn request sang Server'],
      ['4', 'ACT_3 (Multer tiếp nhận)', 'DEC_1 (Kiểm tra tệp)', 'Mũi tên liền nét (──>)', 'Kiểm tra file filter', 'Chuyển dữ liệu sang khối quyết định'],
      ['5', 'DEC_1 (Kiểm tra tệp)', 'ACT_4 (Báo lỗi tệp)', 'Mũi tên liền nét (──>)', '[Không hợp lệ] (Sai đuôi / Quá dung lượng)', 'Tệp không phải PDF/DOCX hoặc > 10MB'],
      ['6', 'ACT_4 (Báo lỗi tệp)', 'ACT_1 (Chọn tệp & tham số)', 'Mũi tên vòng phản hồi (──>)', 'Yêu cầu chọn lại', 'Giảng viên nhận thông báo và chọn file khác'],
      ['7', 'DEC_1 (Kiểm tra tệp)', 'ACT_5 (Trích xuất văn bản)', 'Mũi tên liền nét (──>)', '[Hợp lệ] (Đúng định dạng)', 'Multer ghi đệm và chuyển buffer sang parser'],
      ['8', 'ACT_5 (Trích xuất văn bản)', 'DEC_2 (Kiểm tra độ dài text)', 'Mũi tên liền nét (──>)', 'Kiểm tra số lượng từ', 'Đánh giá chất lượng nội dung văn bản thô'],
      ['9', 'DEC_2 (Kiểm tra độ dài text)', 'ACT_6 (Báo lỗi text rỗng)', 'Mũi tên liền nét (──>)', '[< 50 từ] (Tài liệu scan rỗng)', 'Tệp là file ảnh scan không có text layer'],
      ['10', 'ACT_6 (Báo lỗi text rỗng)', 'END (Kết thúc)', 'Mũi tên liền nét (──>)', 'Hủy quy trình', 'Dừng tiến trình và hướng dẫn người dùng'],
      ['11', 'DEC_2 (Kiểm tra độ dài text)', 'ACT_7 (Tạo Prompt & Schema)', 'Mũi tên liền nét (──>)', '[Đủ nội dung]', 'Ghép văn bản vào khuôn System Instruction'],
      ['12', 'ACT_7 (Tạo Prompt & Schema)', 'ACT_8 (Gửi request AI)', 'Mũi tên liền nét (──>)', 'Chuẩn bị payload', 'Tạo gói tin REST request'],
      ['13', 'ACT_8 (Gửi request AI)', 'ACT_9 (Gemini phân tích)', 'Mũi tên liền nét vắt qua làn (──>)', 'HTTPS POST /v1beta/models/gemini-3.8-flash', 'Bắn request qua máy chủ Google AI'],
      ['14', 'ACT_9 (Gemini phân tích)', 'ACT_10 (Trả JSON payload)', 'Mũi tên liền nét (──>)', 'Hoàn tất suy luận AI', 'Sinh chuỗi định dạng JSON thuần'],
      ['15', 'ACT_10 (Trả JSON payload)', 'ACT_11 (Parse JSON)', 'Mũi tên liền nét vắt ngược làn (──>)', 'HTTP Response 200 OK', 'Server LMS nhận dữ liệu trả về'],
      ['16', 'ACT_11 (Parse JSON)', 'DEC_3 (Kiểm tra JSON Schema)', 'Mũi tên liền nét (──>)', 'Validate cấu trúc', 'Kiểm tra các key bắt buộc trong mảng câu hỏi'],
      ['17', 'DEC_3 (Kiểm tra JSON Schema)', 'ACT_12 (Kích hoạt Fallback Regex)', 'Mũi tên liền nét (──>)', '[JSON lỗi cú pháp nhẹ]', 'Dùng regex cứu các câu hỏi hợp lệ còn lại'],
      ['18', 'ACT_12 (Kích hoạt Fallback Regex)', 'ACT_13 (Hiển thị xem trước)', 'Mũi tên liền nét (──>)', 'Chuyển dữ liệu đã cứu', 'Đưa danh sách câu hỏi sang modal'],
      ['19', 'DEC_3 (Kiểm tra JSON Schema)', 'ACT_13 (Hiển thị xem trước)', 'Mũi tên liền nét (──>)', '[JSON chuẩn xác 100%]', 'Trả dữ liệu về trình duyệt hiển thị'],
      ['20', 'ACT_13 (Hiển thị xem trước)', 'ACT_14 (Giảng viên duyệt & sửa)', 'Mũi tên liền nét vắt qua làn (──>)', 'Hiển thị giao diện duyệt', 'Giảng viên trực tiếp xem lại từng câu hỏi'],
      ['21', 'ACT_14 (Giảng viên duyệt & sửa)', 'ACT_15 (Nhấn Lưu câu hỏi)', 'Mũi tên liền nét (──>)', 'Xác nhận danh sách', 'Giảng viên hài lòng với các câu hỏi'],
      ['22', 'ACT_15 (Nhấn Lưu câu hỏi)', 'ACT_16 (Mongoose lưu CSDL)', 'Mũi tên liền nét vắt qua làn (──>)', 'POST /teacher/exams/save-ai-questions', 'Server ghi dữ liệu vào MongoDB'],
      ['23', 'ACT_16 (Mongoose lưu CSDL)', 'ACT_17 (Thông báo thành công)', 'Mũi tên liền nét (──>)', 'Lưu thành công', 'Phản hồi thông báo toast thành công'],
      ['24', 'ACT_17 (Thông báo thành công)', 'END (Kết thúc)', 'Mũi tên liền nét (──>)', 'Hoàn tất quy trình', 'Kết thúc trọn vẹn luồng sinh đề AI'],
    ],
    textFlow: `[START] ──> Giảng viên chọn file & tham số ──> Nhấn Sinh câu hỏi 
   ──> Multer kiểm tra file ──[Hợp lệ]──> Trích xuất text (pdf-parse/mammoth) 
   ──> Kiểm tra độ dài ──[Đủ text]──> Tạo Prompt chuẩn ──> Gửi Google Gemini 3.8 Flash
   ──> Gemini suy luận ──> Trả JSON ──> LMS Parser làm sạch & Validate 
   ──> Render Modal Preview ──> Giảng viên duyệt & sửa câu hỏi ──> Nhấn Lưu 
   ──> Mongoose lưu Question & gắn vào Exam ──> Thông báo thành công ──> [END]`,
    mermaidCode: `flowchart TD
  START((●)) --> A1["1. Giảng viên chọn tệp & cấu hình tham số"]
  A1 --> A2["2. Nhấn nút 'Sinh câu hỏi bằng AI'"]
  A2 --> A3["3. Multer kiểm tra định dạng & dung lượng"]
  A3 --> D1{"Tệp hợp lệ?"}
  D1 -- "Không" --> E1["Báo lỗi tệp không hợp lệ"] --> A1
  D1 -- "Có (PDF/DOCX)" --> A4["4. Text Extractor giải mã nội dung văn bản"]
  A4 --> D2{"Nội dung > 50 từ?"}
  D2 -- "Không" --> E2["Báo lỗi tài liệu rỗng/không đủ chữ"] --> END((◉))
  D2 -- "Có" --> A5["5. Chuẩn hóa System Prompt & JSON Schema"]
  A5 --> A6["6. Gửi HTTPS Request tới Google Gemini 3.8 Flash"]
  A6 --> A7["7. Gemini phân tích ngữ nghĩa & sinh mảng câu hỏi"]
  A7 --> A8["8. Trả về JSON Response"]
  A8 --> A9["9. Server làm sạch Markdown & Parse JSON"]
  A9 --> D3{"JSON đúng chuẩn?"}
  D3 -- "Sai nhẹ" --> A10["Dùng Fallback Regex cứu câu hỏi"] --> A11
  D3 -- "Chuẩn" --> A11["10. Hiển thị Modal Preview danh sách câu hỏi"]
  A11 --> A12["11. Giảng viên duyệt, sửa nội dung/đáp án"]
  A12 --> A13["12. Nhấn 'Lưu vào đề thi'"]
  A13 --> A14["13. Mongoose lưu Question documents vào MongoDB"]
  A14 --> A15["14. Thông báo thành công & Tải lại giao diện"]
  A15 --> END`,
    codeMapping: [
      ['Upload & Parser', 'middleware/aiDocUpload.js', 'multer memoryStorage, fileFilter (.pdf, .docx, .txt)'],
      ['Text Extractor', 'services/aiQuestionGen.service.js', 'extractTextFromBuffer(), pdf-parse, mammoth'],
      ['Gọi Gemini API', 'services/aiQuestionGen.service.js', 'GoogleGenAI, gemini-3.8-flash, generateContent()'],
      ['Validate & Fallback', 'services/aiQuestionGen.service.js', 'cleanAndParseJSON(), fallbackExtractQuestions()'],
      ['Lưu vào CSDL', 'controller/teacher/aiQuestionGen.controller.js', 'Question.insertMany(), Exam.findByIdAndUpdate()'],
    ]
  },

  // ─── HÌNH 2-6 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-6',
    title: 'Biểu đồ Hoạt động quy trình làm bài thi trực tuyến và giám sát chống gian lận',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.7: Phân tích cơ chế giám sát vi phạm và thi cử an toàn thời gian thực',
    purpose: 'Đặc tả chi tiết các giai đoạn làm bài thi của thí sinh: xác thực vào phòng, kích hoạt chế độ toàn màn hình (Fullscreen), bắt sự kiện đổi tab (visibilitychange/blur), đếm số lần vi phạm và cưỡng chế thu bài khi vượt ngưỡng.',
    diagramType: 'Biểu đồ Hoạt động phân làn (Activity Diagram with Swimlanes)',
    nodes: [
      ['START', 'Bắt đầu làm bài (Initial State)', 'Hình tròn đen đặc (●)', '#000000', 'Sinh viên click vào thi'],
      ['LANE1', 'Làn Thí sinh (Student)', 'Làn bơi Trái', '#EFF6FF', 'Thao tác trả lời, thao tác chuyển ứng dụng'],
      ['LANE2', 'Làn Client Monitor Sandbox', 'Làn bơi Giữa', '#FEF3C7', 'Javascript giám sát trên trình duyệt: Fullscreen, key block, tab change'],
      ['LANE3', 'Làn LMS Server & Database', 'Làn bơi Phải', '#F0FDF4', 'Ghi nhận vết vi phạm, tính điểm và lưu bài nộp'],
      ['ACT_1', 'Sinh viên nhập Mật khẩu đề thi & Xem quy chế', 'Hình chữ nhật bo góc', '#FFFFFF', 'Đọc kỹ giới hạn thời gian, quy định chống đổi tab'],
      ['ACT_2', 'Nhấn nút "Bắt đầu làm bài"', 'Hình chữ nhật bo góc', '#FFFFFF', 'Xác nhận bắt đầu tính giờ'],
      ['ACT_3', 'Kích hoạt Fullscreen API & Khóa phím tắt', 'Hình chữ nhật bo góc', '#FEF3C7', 'Khóa F12, Ctrl+C, Ctrl+V, Alt+Tab, chuột phải'],
      ['ACT_4', 'Khởi tạo Submission & Đếm lùi thời gian', 'Hình chữ nhật bo góc', '#FFFFFF', 'Tạo ExamSubmission trạng thái "in_progress", lưu startTime'],
      ['ACT_5', 'Thí sinh đọc đề & chọn đáp án các câu hỏi', 'Hình chữ nhật bo góc', '#FFFFFF', 'Giao diện tự động lưu tạm câu trả lời vào LocalStorage'],
      ['DEC_1', 'Phát hiện sự kiện rời màn hình (Tab switch / Blur)?', 'Hình thoi quyết định (◇)', '#FEE2E2', 'Bắt window.onblur hoặc document.visibilitychange === "hidden"'],
      ['ACT_6', 'Tăng biến đếm vi phạm: violationCount++', 'Hình chữ nhật bo góc', '#FEE2E2', 'Tăng bộ đếm và chụp lại thời điểm vi phạm'],
      ['ACT_7', 'Gửi cảnh báo Socket vi phạm về máy chủ', 'Hình chữ nhật bo góc', '#FFFFFF', 'Socket.emit("exam-violation", { studentId, violationType })'],
      ['ACT_8', 'Lưu nhật ký vi phạm vào ExamSubmission & Thông báo Giám thị', 'Hình chữ nhật bo góc', '#FFFFFF', 'Thêm phần tử vào mảng violations và gửi alert lên màn hình giảng viên'],
      ['DEC_2', 'violationCount >= tabSwitchLimit cho phép?', 'Hình thoi quyết định (◇)', '#FEE2E2', 'So sánh với số lần đổi tab tối đa giáo viên cấu hình'],
      ['ACT_9', 'Hiển thị Modal cảnh báo toàn màn hình', 'Hình chữ nhật bo góc', '#FEF3C7', 'Cảnh báo đỏ: "Bạn đã rời khỏi màn hình thi! Còn lại X lần vi phạm!"'],
      ['DEC_3', 'Hết giờ làm bài HOẶC thí sinh bấm "Nộp bài"?', 'Hình thoi quyết định (◇)', '#FEF3C7', 'Kiểm tra điều kiện kết thúc thi'],
      ['ACT_10', 'Cưỡng chế nộp bài tự động (Force Auto-Submit)', 'Hình chữ nhật bo góc', '#FEE2E2', 'Khóa toàn bộ form, tự động gom đáp án và gửi nộp ngay lập tức'],
      ['ACT_11', 'LMS Engine chấm điểm trắc nghiệm tự động', 'Hình chữ nhật bo góc', '#FFFFFF', 'So khớp mảng đáp án với Question.correctAnswer, tính tổng điểm'],
      ['ACT_12', 'Cập nhật ExamSubmission trạng thái "submitted"', 'Hình chữ nhật bo góc', '#FFFFFF', 'Lưu điểm số, thời gian kết thúc (submittedAt), lý do nộp'],
      ['ACT_13', 'Hiển thị trang thông báo kết quả thi', 'Hình chữ nhật bo góc', '#DCFCE7', 'Hiện điểm số, số lần vi phạm và lời nhắn của hệ thống'],
      ['END', 'Kết thúc kỳ thi (Final State)', 'Vòng tròn mắt bò (◉)', '#000000', 'Đóng phiên làm bài'],
    ],
    connections: [
      ['1', 'START (Bắt đầu)', 'ACT_1 (Nhập mật khẩu thi)', 'Mũi tên liền nét (──>)', 'Bắt đầu truy cập kỳ thi', 'Sinh viên vào trang /student/exams/:id/take'],
      ['2', 'ACT_1 (Nhập mật khẩu thi)', 'ACT_2 (Nhấn Bắt đầu)', 'Mũi tên liền nét (──>)', 'Đồng ý quy chế', 'Xác nhận chấp hành giám sát'],
      ['3', 'ACT_2 (Nhấn Bắt đầu)', 'ACT_3 (Kích hoạt Fullscreen)', 'Mũi tên liền nét vắt qua làn (──>)', 'Bật chế độ thi an toàn', 'Trình duyệt chuyển sang toàn màn hình'],
      ['4', 'ACT_3 (Kích hoạt Fullscreen)', 'ACT_4 (Khởi tạo Submission)', 'Mũi tên liền nét vắt qua làn (──>)', 'Ghi nhận bắt đầu', 'Server lưu mốc thời gian startTime vào CSDL'],
      ['5', 'ACT_4 (Khởi tạo Submission)', 'ACT_5 (Làm bài trắc nghiệm)', 'Mũi tên liền nét vắt ngược làn (──>)', 'Hiển thị bộ đề', 'Thí sinh bắt đầu chọn đáp án A, B, C, D'],
      ['6', 'ACT_5 (Làm bài trắc nghiệm)', 'DEC_1 (Phát hiện đổi tab?)', 'Mũi tên liền nét (──>)', 'Lắng nghe sự kiện nền', 'Trình duyệt liên tục theo dõi cửa sổ'],
      ['7', 'DEC_1 (Phát hiện đổi tab?)', 'ACT_6 (Tăng violationCount)', 'Mũi tên liền nét (──>)', '[Có sự kiện rời màn hình]', 'Thí sinh Alt+Tab hoặc click chuột ra ngoài'],
      ['8', 'ACT_6 (Tăng violationCount)', 'ACT_7 (Gửi cảnh báo Socket)', 'Mũi tên liền nét vắt qua làn (──>)', 'Bắn tín hiệu thời gian thực', 'Gửi sự kiện vi phạm về Server'],
      ['9', 'ACT_7 (Gửi cảnh báo Socket)', 'ACT_8 (Lưu nhật ký vi phạm)', 'Mũi tên liền nét (──>)', 'Ghi vết dữ liệu', 'Ghi vào MongoDB và đẩy notification cho giám thị'],
      ['10', 'ACT_8 (Lưu nhật ký vi phạm)', 'DEC_2 (Quá giới hạn cho phép?)', 'Mũi tên liền nét vắt qua làn (──>)', 'Đánh giá mức độ vi phạm', 'Kiểm tra violationCount >= limit'],
      ['11', 'DEC_2 (Quá giới hạn cho phép?)', 'ACT_10 (Cưỡng chế nộp bài)', 'Mũi tên liền nét (──>)', '[Vượt quá giới hạn] (Gian lận)', 'Cưỡng bức thu bài ngay lập tức'],
      ['12', 'DEC_2 (Quá giới hạn cho phép?)', 'ACT_9 (Hiện Modal cảnh báo)', 'Mũi tên liền nét (──>)', '[Còn trong giới hạn]', 'Cảnh báo nghiêm khắc và bắt buộc bấm quay lại'],
      ['13', 'ACT_9 (Hiện Modal cảnh báo)', 'ACT_5 (Tiếp tục làm bài)', 'Mũi tên liền nét (──>)', 'Quay lại làm bài', 'Thí sinh tiếp tục trả lời các câu còn lại'],
      ['14', 'DEC_1 (Phát hiện đổi tab?)', 'DEC_3 (Hết giờ hoặc Bấm nộp?)', 'Mũi tên liền nét (──>)', '[Không vi phạm]', 'Quá trình làm bài diễn ra bình thường'],
      ['15', 'DEC_3 (Hết giờ hoặc Bấm nộp?)', 'ACT_5 (Tiếp tục làm bài)', 'Mũi tên liền nét (──>)', '[Chưa hết giờ]', 'Thí sinh tiếp tục làm bài'],
      ['16', 'DEC_3 (Hết giờ hoặc Bấm nộp?)', 'ACT_11 (Chấm điểm tự động)', 'Mũi tên liền nét vắt qua làn (──>)', '[Hết giờ HOẶC Bấm Nộp]', 'Chuyển bài thi sang module chấm điểm'],
      ['17', 'ACT_10 (Cưỡng chế nộp bài)', 'ACT_11 (Chấm điểm tự động)', 'Mũi tên liền nét (──>)', 'Nộp bài bắt buộc', 'Đưa vào hàng đợi chấm bài tự động'],
      ['18', 'ACT_11 (Chấm điểm tự động)', 'ACT_12 (Cập nhật CSDL)', 'Mũi tên liền nét (──>)', 'Lưu kết quả điểm', 'Ghi điểm số và mốc thời gian hoàn tất'],
      ['19', 'ACT_12 (Cập nhật CSDL)', 'ACT_13 (Hiển thị kết quả)', 'Mũi tên liền nét vắt qua làn (──>)', 'Chuyển hướng màn hình', 'Hiển thị trang tổng kết điểm số'],
      ['20', 'ACT_13 (Hiển thị kết quả)', 'END (Kết thúc)', 'Mũi tên liền nét (──>)', 'Hoàn tất kỳ thi', 'Đóng phiên thi an toàn'],
    ],
    textFlow: `[START] ──> Nhập mật khẩu & Bắt đầu ──> Kích hoạt Fullscreen & Khóa phím 
   ──> Thí sinh làm bài thi ──[Đổi Tab / Rời màn hình]──> Tăng violationCount ──> Bắn Socket về Server
   ──> Kiểm tra ngưỡng:
         ├── Nếu vi phạm >= Giới hạn ──> CƯỠNG CHẾ NỘP BÀI TỰ ĐỘNG
         └── Nếu vi phạm < Giới hạn  ──> Cảnh báo đỏ toàn màn hình ──> Tiếp tục làm
   ──[Hết giờ / Bấm Nộp]──> Chấm điểm trắc nghiệm tự động ──> Lưu ExamSubmission ──> Hiện kết quả ──> [END]`,
    mermaidCode: `flowchart TD
  START((●)) --> B1["1. Nhập mật khẩu thi & Xác nhận quy chế"]
  B1 --> B2["2. Kích hoạt Fullscreen API & Khóa phím tắt"]
  B2 --> B3["3. Khởi tạo Submission & Bắt đầu tính giờ"]
  B3 --> B4["4. Thí sinh làm bài thi trắc nghiệm"]
  B4 --> D1{"Đổi Tab / Blur màn hình?"}
  D1 -- "Có" --> V1["5. violationCount++ & Chụp timestamp"]
  V1 --> V2["6. Bắn sự kiện Socket 'exam-violation' về Server"]
  V2 --> V3["7. Lưu nhật ký vi phạm & Báo Giám thị"]
  V3 --> D2{"violationCount >= Limit?"}
  D2 -- "Vượt quá" --> AUTO["8. CƯỠNG CHẾ NỘP BÀI TỰ ĐỘNG"]
  D2 -- "Chưa quá" --> WARN["9. Hiện Modal Cảnh báo đỏ Fullscreen"] --> B4
  D1 -- "Không" --> D3{"Hết giờ HOẶC Bấm Nộp?"}
  D3 -- "Chưa" --> B4
  D3 -- "Đã nộp" --> GRADE["10. Chấm điểm trắc nghiệm tự động"]
  AUTO --> GRADE
  GRADE --> SAVE["11. Cập nhật ExamSubmission: submitted"]
  SAVE --> RESULT["12. Hiển thị trang kết quả & điểm số"]
  RESULT --> END((◉))`,
    codeMapping: [
      ['Client Monitor', 'public/js/take-exam.js', 'requestFullscreen(), visibilitychange, blur, keydown (F12, Ctrl+C)'],
      ['Ghi nhận vi phạm', 'controller/student/exam.controller.js, services/examIntegrity.service.js', 'logViolation(), calculateTabSwitch()'],
      ['Chấm điểm tự động', 'services/exam.service.js', 'autoGradeSubmission(), compareAnswers()'],
      ['Lưu trữ kết quả', 'models/ExamSubmission.js', 'score, totalQuestions, violations, isForceSubmitted'],
    ]
  },

  // ─── HÌNH 2-7 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-7',
    title: 'Biểu đồ Hoạt động quy trình tham gia phòng học ảo và duyệt phòng chờ',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.8: Phân tích cơ chế kiểm soát lớp học ảo và điểm danh tự động',
    purpose: 'Mô tả quy trình kiểm soát học sinh vào lớp học trực tuyến: sinh viên xếp hàng tại phòng chờ (Waiting Room), giảng viên nhận thông báo và phê duyệt (Admit) hoặc từ chối (Deny), sau đó kích hoạt WebRTC và tự động ghi nhận điểm danh.',
    diagramType: 'Biểu đồ Hoạt động phân làn (Activity Diagram with Swimlanes)',
    nodes: [
      ['START', 'Bắt đầu vào lớp (Initial State)', 'Hình tròn đen đặc (●)', '#000000', 'Sinh viên bấm tham gia lớp học ảo'],
      ['LANE1', 'Làn Sinh viên (Student)', 'Làn bơi Trái', '#EFF6FF', 'Thao tác yêu cầu vào lớp và học tập'],
      ['LANE2', 'Làn LMS Waiting Room Server', 'Làn bơi Giữa', '#FEF3C7', 'Quản lý hàng đợi phòng chờ bằng Socket.IO'],
      ['LANE3', 'Làn Giảng viên / Host (Teacher)', 'Làn bơi Phải', '#F0FDF4', 'Quyết định duyệt hoặc từ chối học sinh'],
      ['ACT_1', 'Sinh viên click "Tham gia Lớp học trực tuyến"', 'Hình chữ nhật bo góc', '#FFFFFF', 'Truy cập route phòng học ảo'],
      ['ACT_2', 'Kiểm tra quyền thành viên trong lớp học', 'Hình chữ nhật bo góc', '#FFFFFF', 'Xác thực userId có thuộc ClassroomMember hay không'],
      ['DEC_1', 'Có phải thành viên hợp lệ của lớp?', 'Hình thoi quyết định (◇)', '#FEE2E2', 'Ngăn chặn người lạ xâm nhập lớp học'],
      ['ACT_3', 'Báo lỗi không có quyền truy cập', 'Hình chữ nhật bo góc', '#FEE2E2', 'Thông báo 403 Forbidden và chuyển về trang chủ'],
      ['ACT_4', 'Đưa sinh viên vào màn hình Phòng chờ (Waiting Room)', 'Hình chữ nhật bo góc', '#FEF3C7', 'Hiển thị thông báo: "Vui lòng chờ giáo viên duyệt bạn vào lớp..."'],
      ['ACT_5', 'Socket.emit("request-entry", { studentInfo })', 'Hình chữ nhật bo góc', '#FFFFFF', 'Gửi thông tin sinh viên kèm ảnh đại diện vào hàng đợi phòng chờ'],
      ['ACT_6', 'Hiển thị Toast / Popup yêu cầu vào lớp trên màn hình Host', 'Hình chữ nhật bo góc', '#FFFFFF', 'Giảng viên nhìn thấy tên học sinh xin vào'],
      ['DEC_2', 'Giảng viên duyệt (Admit) hay từ chối (Deny)?', 'Hình thoi quyết định (◇)', '#FEF3C7', 'Thầy cô click nút tương ứng'],
      ['ACT_7', 'Socket.emit("entry-denied")', 'Hình chữ nhật bo góc', '#FEE2E2', 'Gửi lệnh từ chối về trình duyệt sinh viên'],
      ['ACT_8', 'Hiển thị thông báo: "Yêu cầu vào lớp bị từ chối"', 'Hình chữ nhật bo góc', '#FEE2E2', 'Rời phòng học ảo'],
      ['ACT_9', 'Socket.emit("entry-approved") & Gửi thông tin SDP/ICE', 'Hình chữ nhật bo góc', '#DCFCE7', 'Cho phép kết nối WebRTC Media Stream'],
      ['ACT_10', 'Sinh viên kết nối trực tiếp P2P vào lớp học', 'Hình chữ nhật bo góc', '#FFFFFF', 'Bật camera, micro và xem video bài giảng'],
      ['ACT_11', 'Tự động tạo bản ghi Attendance (Điểm danh có mặt)', 'Hình chữ nhật bo góc', '#FFFFFF', 'Lưu joinTime, studentId, status: "present" vào MongoDB'],
      ['ACT_12', 'Cập nhật danh sách học viên trực tuyến thời gian thực', 'Hình chữ nhật bo góc', '#DCFCE7', 'Hiển thị badge xanh online trên thanh công cụ của lớp'],
      ['END', 'Tham gia lớp thành công (Final State)', 'Vòng tròn mắt bò (◉)', '#000000', 'Hoàn tất kết nối vào lớp học ảo'],
    ],
    connections: [
      ['1', 'START (Bắt đầu)', 'ACT_1 (Click tham gia)', 'Mũi tên liền nét (──>)', 'Bắt đầu truy cập', 'Sinh viên click nút Join Live Class'],
      ['2', 'ACT_1 (Click tham gia)', 'ACT_2 (Kiểm tra thành viên)', 'Mũi tên liền nét vắt qua làn (──>)', 'Xác thực phân quyền', 'LMS Server kiểm tra ClassroomMember'],
      ['3', 'ACT_2 (Kiểm tra thành viên)', 'DEC_1 (Hợp lệ?)', 'Mũi tên liền nét (──>)', 'Phân nhánh hợp lệ', 'Kiểm tra xem sinh viên có trong danh sách'],
      ['4', 'DEC_1 (Hợp lệ?)', 'ACT_3 (Báo lỗi 403)', 'Mũi tên liền nét (──>)', '[Không hợp lệ]', 'Chặn người ngoài lớp'],
      ['5', 'ACT_3 (Báo lỗi 403)', 'END (Kết thúc)', 'Mũi tên liền nét (──>)', 'Chấm dứt truy cập', 'Dừng phiên'],
      ['6', 'DEC_1 (Hợp lệ?)', 'ACT_4 (Đưa vào Phòng chờ)', 'Mũi tên liền nét (──>)', '[Hợp lệ]', 'Mở giao diện phòng chờ'],
      ['7', 'ACT_4 (Đưa vào Phòng chờ)', 'ACT_5 (Gửi request-entry)', 'Mũi tên liền nét vắt qua làn (──>)', 'Bắn sự kiện socket', 'Đẩy vào waitingQueue của Server'],
      ['8', 'ACT_5 (Gửi request-entry)', 'ACT_6 (Hiện Popup xin vào)', 'Mũi tên liền nét vắt qua làn (──>)', 'Thông báo cho Host', 'Màn hình giáo viên nhấp nháy thông báo'],
      ['9', 'ACT_6 (Hiện Popup xin vào)', 'DEC_2 (Giáo viên duyệt?)', 'Mũi tên liền nét (──>)', 'Thầy cô ra quyết định', 'Lựa chọn Admit hoặc Deny'],
      ['10', 'DEC_2 (Giáo viên duyệt?)', 'ACT_7 (Bắn entry-denied)', 'Mũi tên liền nét vắt qua làn (──>)', '[Từ chối (Deny)]', 'Giảng viên không cho vào'],
      ['11', 'ACT_7 (Bắn entry-denied)', 'ACT_8 (Báo bị từ chối)', 'Mũi tên liền nét vắt qua làn (──>)', 'Báo về máy sinh viên', 'Hiện thông báo từ chối'],
      ['12', 'ACT_8 (Báo bị từ chối)', 'END (Kết thúc)', 'Mũi tên liền nét (──>)', 'Rời phòng', 'Kết thúc'],
      ['13', 'DEC_2 (Giáo viên duyệt?)', 'ACT_9 (Bắn entry-approved)', 'Mũi tên liền nét vắt qua làn (──>)', '[Chấp nhận (Admit)]', 'Giảng viên cấp quyền vào lớp'],
      ['14', 'ACT_9 (Bắn entry-approved)', 'ACT_10 (Kết nối P2P WebRTC)', 'Mũi tên liền nét vắt qua làn (──>)', 'Thiết lập Media Stream', 'Sinh viên nhận tín hiệu video trực tiếp'],
      ['15', 'ACT_10 (Kết nối P2P WebRTC)', 'ACT_11 (Tự động điểm danh)', 'Mũi tên liền nét vắt qua làn (──>)', 'Ghi vết tham dự', 'LMS lưu mốc giờ vào Attendance'],
      ['16', 'ACT_11 (Tự động điểm danh)', 'ACT_12 (Cập nhật online list)', 'Mũi tên liền nét (──>)', 'Đồng bộ danh sách', 'Cập nhật UI tất cả mọi người trong phòng'],
      ['17', 'ACT_12 (Cập nhật online list)', 'END (Kết thúc)', 'Mũi tên liền nét (──>)', 'Hoàn tất vào lớp', 'Học tập và tương tác bình thường'],
    ],
    textFlow: `[START] ──> Sinh viên click tham gia lớp học ──> Kiểm tra thành viên
   ├── [Không hợp lệ] ──> Báo lỗi 403 ──> [END]
   └── [Hợp lệ] ──> Đưa vào Phòng chờ (Waiting Room) ──> Gửi request-entry
        ──> Màn hình Giảng viên hiện Popup xin vào
        ├── [Giảng viên Từ chối] ──> Bắn entry-denied ──> Sinh viên bị chặn ──> [END]
        └── [Giảng viên Duyệt]   ──> Bắn entry-approved ──> Kết nối WebRTC Media P2P
             ──> Tự động ghi nhận Điểm danh (Attendance) ──> Cập nhật danh sách Online ──> [END]`,
    mermaidCode: `flowchart TD
  START((●)) --> C1["1. Sinh viên click 'Tham gia lớp học ảo'"]
  C1 --> C2["2. Server kiểm tra quyền thành viên (ClassroomMember)"]
  C2 --> D1{"Thành viên hợp lệ?"}
  D1 -- "Không" --> ERR["Báo lỗi 403: Không có quyền truy cập"] --> END((◉))
  D1 -- "Có" --> C3["3. Đưa sinh viên vào màn hình Phòng chờ"]
  C3 --> C4["4. Socket.emit('request-entry', studentData)"]
  C4 --> C5["5. Hiển thị Popup xin vào lớp trên màn hình Giảng viên"]
  C5 --> D2{"Giảng viên quyết định?"}
  D2 -- "Từ chối (Deny)" --> DENY["6. Socket.emit('entry-denied')"]
  DENY --> DENY_MSG["Thông báo yêu cầu bị từ chối"] --> END
  D2 -- "Duyệt (Admit)" --> ADMIT["7. Socket.emit('entry-approved')"]
  ADMIT --> P2P["8. Khởi tạo PeerConnection WebRTC Media Stream"]
  P2P --> ATT["9. Hệ thống tự động ghi nhận Điểm danh (Attendance)"]
  ATT --> SYNC["10. Đồng bộ danh sách học viên Online"]
  SYNC --> END`,
    codeMapping: [
      ['Kiểm tra thành viên', 'middleware/classroomAuth.js', 'checkMembership(req.user._id, req.params.id)'],
      ['Phòng chờ Socket', 'socket/classroom.js', 'request-entry, approve-entry, deny-entry'],
      ['WebRTC Connection', 'public/js/classroom-live.js', 'RTCPeerConnection, addTrack(), ontrack'],
      ['Điểm danh tự động', 'controller/teacher/attendance.controller.js, models/Attendance.js', 'recordCheckIn(), autoMarkPresent()'],
    ]
  }
];
