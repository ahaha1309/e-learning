/**
 * Dữ liệu chi tiết cho 5 biểu đồ cuối cùng (Hình 2-8 -> Hình 2-12)
 * Bao gồm Sequence Diagrams, ERD MongoDB và Deployment Architecture
 */
module.exports = [
  // ─── HÌNH 2-8 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-8',
    title: 'Biểu đồ Tuần tự quy trình tự động sinh câu hỏi trắc nghiệm qua Gemini API',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.9: Thiết kế biểu đồ tuần tự chức năng sinh đề thi bằng Trí tuệ nhân tạo',
    purpose: 'Đặc tả tuần tự theo trục thời gian (từ trên xuống dưới) sự trao đổi thông điệp giữa các đối tượng: Giảng viên, Trình duyệt UI, Route/Middleware, Controller, Service, Google Gemini API và Cơ sở dữ liệu MongoDB.',
    diagramType: 'Biểu đồ Tuần tự (UML Sequence Diagram)',
    nodes: [
      ['T', 'Giảng viên (Teacher)', 'Actor (Hình người)', '#FEF3C7', 'Người dùng gửi file và duyệt câu hỏi'],
      ['UI', 'Browser UI (ai-question-gen.js)', 'Lifeline Boundary', '#E0F2FE', 'Giao diện phía client, hiển thị modal, gửi AJAX'],
      ['RT', 'Express Router & Multer', 'Lifeline Control', '#FEF3C7', 'Định tuyến /teacher/exams/generate-ai-questions, kiểm tra tệp'],
      ['CTL', 'AI Controller', 'Lifeline Control', '#DCFCE7', 'controller/teacher/aiQuestionGen.controller.js'],
      ['SRV', 'AI Service Layer', 'Lifeline Control', '#F3E8FF', 'services/aiQuestionGen.service.js'],
      ['GEM', 'Google Gemini API (gemini-3.8-flash)', 'Lifeline External System', '#E0E7FF', 'Dịch vụ đám mây xử lý LLM'],
      ['DB', 'MongoDB Database (Question & Exam)', 'Lifeline Entity (Database)', '#ECFCCB', 'Lưu trữ các câu hỏi và đề thi'],
    ],
    connections: [
      ['1', 'T (Giảng viên)', 'UI (Browser UI)', 'Mũi tên liền nét 1 chiều (──>)', '1. Chọn file tài liệu & bấm "Tạo câu hỏi bằng AI"', 'Người dùng kích hoạt hành động trên modal'],
      ['2', 'UI (Browser UI)', 'RT (Router & Multer)', 'Mũi tên liền nét 1 chiều (──>)', '2. POST /teacher/exams/generate-ai-questions (FormData)', 'Gửi tệp nhị phân kèm tham số numQuestions, difficulty'],
      ['3', 'RT (Router & Multer)', 'CTL (AI Controller)', 'Mũi tên liền nét 1 chiều (──>)', '3. handleGenerateAI(req, res)', 'Multer ghi đệm file buffer và bàn giao cho Controller'],
      ['4', 'CTL (AI Controller)', 'SRV (AI Service)', 'Mũi tên liền nét 1 chiều (──>)', '4. extractAndGenerateQuestions(fileBuffer, mimetype, options)', 'Controller gọi Service xử lý nghiệp vụ'],
      ['5', 'SRV (AI Service)', 'SRV (AI Service)', 'Mũi tên tự gọi (↺)', '5. parseTextFromBuffer() (pdf-parse / mammoth)', 'Service giải mã tệp lấy chuỗi văn bản thuần'],
      ['6', 'SRV (AI Service)', 'SRV (AI Service)', 'Mũi tên tự gọi (↺)', '6. buildPromptWithSchema(extractedText, options)', 'Ghép văn bản vào Prompt yêu cầu định dạng JSON'],
      ['7', 'SRV (AI Service)', 'GEM (Google Gemini API)', 'Mũi tên liền nét 1 chiều (──>)', '7. HTTPS POST /v1beta/models/gemini-3.8-flash:generateContent', 'Gửi request chứa System Instruction và Prompt'],
      ['8', 'GEM (Google Gemini API)', 'SRV (AI Service)', 'Mũi tên nét đứt phản hồi (<---)', '8. JSON Payload Response (Mảng câu hỏi trắc nghiệm)', 'Gemini trả về mảng các câu hỏi kèm 4 đáp án và giải thích'],
      ['9', 'SRV (AI Service)', 'SRV (AI Service)', 'Mũi tên tự gọi (↺)', '9. cleanAndValidateQuestions() & fallbackExtract()', 'Làm sạch markdown ticks, kiểm tra tính toàn vẹn câu hỏi'],
      ['10', 'SRV (AI Service)', 'CTL (AI Controller)', 'Mũi tên nét đứt phản hồi (<---)', '10. Return { success: true, questions: [...] }', 'Service trả về mảng câu hỏi chuẩn cấu trúc'],
      ['11', 'CTL (AI Controller)', 'UI (Browser UI)', 'Mũi tên nét đứt phản hồi (<---)', '11. HTTP 200 OK (JSON questions preview)', 'Trả dữ liệu về trình duyệt hiển thị xem trước'],
      ['12', 'UI (Browser UI)', 'T (Giảng viên)', 'Mũi tên nét đứt phản hồi (<---)', '12. Render Modal Preview danh sách câu hỏi', 'Hiển thị giao diện xem trước cho giáo viên đọc và sửa'],
      ['13', 'T (Giảng viên)', 'UI (Browser UI)', 'Mũi tên liền nét 1 chiều (──>)', '13. Chỉnh sửa câu hỏi & bấm "Lưu vào Đề thi"', 'Giáo viên xác nhận các câu hỏi đạt yêu cầu'],
      ['14', 'UI (Browser UI)', 'CTL (AI Controller)', 'Mũi tên liền nét 1 chiều (──>)', '14. POST /teacher/exams/save-ai-questions (approvedList)', 'Gửi danh sách câu hỏi đã được giáo viên duyệt'],
      ['15', 'CTL (AI Controller)', 'DB (MongoDB)', 'Mũi tên liền nét 1 chiều (──>)', '15. Question.insertMany() & Exam.findByIdAndUpdate()', 'Lưu các câu hỏi vào CSDL và gán liên kết vào đề thi'],
      ['16', 'DB (MongoDB)', 'CTL (AI Controller)', 'Mũi tên nét đứt phản hồi (<---)', '16. Trả về kết quả ghi thành công (Inserted Records)', 'MongoDB xác nhận lưu thành công'],
      ['17', 'CTL (AI Controller)', 'UI (Browser UI)', 'Mũi tên nét đứt phản hồi (<---)', '17. HTTP 200 OK { success: true, redirectUrl }', 'Báo thành công và chỉ dẫn chuyển hướng'],
      ['18', 'UI (Browser UI)', 'T (Giảng viên)', 'Mũi tên nét đứt phản hồi (<---)', '18. Hiển thị Toast thành công & Cập nhật trang đề thi', 'Giáo viên nhìn thấy các câu hỏi mới đã nằm trong đề thi'],
    ],
    textFlow: `T (Teacher) ──(1)──> UI ──(2. POST FormData)──> RT (Multer) ──(3)──> CTL
                                                                           │ (4. extractAndGenerate)
                                                                           ▼
                                                                 SRV (AI Service)
                                                                    ├──(5. Parse text)
                                                                    ├──(6. Build prompt)
                                                                    └──(7. HTTPS POST)──> GEM (Gemini API)
                                                                                               │ (8. JSON response)
                                                                                               ▼
                                                                 SRV (Validate & Clean) <──────┘
                                                                    │ (10. Return questions)
                                                                    ▼
T (Teacher) <──(12. Preview)── UI <──(11. HTTP 200)── CTL (AI Controller)
    │ (13. Save approved)
    └──> UI ──(14. POST Save)──> CTL ──(15. insertMany)──> DB (MongoDB)
                                   ▲                            │ (16. Success)
                                   └────────────────────────────┘
T (Teacher) <──(18. Toast Success)── UI <──(17. HTTP 200)── CTL`,
    mermaidCode: `sequenceDiagram
  autonumber
  actor T as Giảng viên
  participant UI as Browser (ai-question-gen.js)
  participant RT as Router & Multer
  participant CTL as AI Controller
  participant SRV as AI Service
  participant GEM as Google Gemini API (gemini-3.8-flash)
  participant DB as MongoDB Database

  T->>UI: 1. Chọn tệp PDF/DOCX & cấu hình tham số
  UI->>RT: 2. POST /teacher/exams/generate-ai-questions (FormData)
  RT->>CTL: 3. handleGenerateAI(req, res)
  CTL->>SRV: 4. extractAndGenerateQuestions(buffer, options)
  SRV->>SRV: 5. parseTextFromBuffer() (pdf-parse/mammoth)
  SRV->>SRV: 6. buildPromptWithSchema(text, options)
  SRV->>GEM: 7. HTTPS POST /v1beta/models/gemini-3.8-flash:generateContent
  GEM-->>SRV: 8. JSON Response Payload (Mảng câu hỏi)
  SRV->>SRV: 9. cleanAndValidateQuestions() & fallbackRegex
  SRV-->>CTL: 10. Return { success: true, questions }
  CTL-->>UI: 11. HTTP 200 OK (JSON preview data)
  UI-->>T: 12. Hiển thị Modal Preview danh sách câu hỏi

  T->>UI: 13. Duyệt, sửa câu hỏi & bấm "Lưu vào Đề thi"
  UI->>CTL: 14. POST /teacher/exams/save-ai-questions (approvedQuestions)
  CTL->>DB: 15. Question.insertMany() & Exam.findByIdAndUpdate()
  DB-->>CTL: 16. Ghi thành công (Inserted Records)
  CTL-->>UI: 17. HTTP 200 OK { success: true, redirectUrl }
  UI-->>T: 18. Toast thông báo thành công & Tải lại trang`,
    codeMapping: [
      ['Browser Script', 'public/js/ai-question-gen.js', 'handleUpload(), renderPreviewModal(), submitQuestions()'],
      ['Router & Multer', 'routes/teacher.exam.routes.js, middleware/aiDocUpload.js', 'uploadDoc.single("file"), router.post()'],
      ['Controller', 'controller/teacher/aiQuestionGen.controller.js', 'handleGenerateAI(), handleSaveQuestions()'],
      ['Service Layer', 'services/aiQuestionGen.service.js', 'extractTextFromBuffer(), generateQuestionsFromText()'],
      ['Database Models', 'models/Question.js, models/Exam.js', 'Question.insertMany(), Exam.updateOne()'],
    ]
  },

  // ─── HÌNH 2-9 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-9',
    title: 'Biểu đồ Tuần tự quy trình giám sát và ghi nhận vi phạm thi cử thời gian thực',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.10: Thiết kế biểu đồ tuần tự cơ chế giám sát vi phạm thi cử trực tuyến',
    purpose: 'Mô tả tuần tự luồng phát hiện sinh viên rời khỏi màn hình thi (Alt+Tab, mở tab mới, inspect element), truyền tín hiệu qua WebSocket, lưu vết kiểm toán và cơ chế tự động cưỡng chế nộp bài.',
    diagramType: 'Biểu đồ Tuần tự (UML Sequence Diagram)',
    nodes: [
      ['S', 'Thí sinh (Student)', 'Actor (Hình người)', '#DCFCE7', 'Người đang làm bài kiểm tra'],
      ['UI', 'Exam Client UI (take-exam.js)', 'Lifeline Boundary', '#E0F2FE', 'Bắt sự kiện DOM, blur, visibilitychange'],
      ['SKC', 'Socket.IO Client', 'Lifeline Control', '#FEF3C7', 'Kênh WebSocket phía client'],
      ['SKS', 'Socket.IO Server', 'Lifeline Control', '#F3E8FF', 'socket/examMonitor.js trên máy chủ'],
      ['T_UI', 'Giám thị UI (Teacher Monitor)', 'Lifeline Boundary', '#FFEDD5', 'Dashboard theo dõi thi của giáo viên'],
      ['SRV', 'Exam Integrity Service', 'Lifeline Control', '#DCFCE7', 'services/examIntegrity.service.js'],
      ['DB', 'MongoDB (ExamSubmission)', 'Lifeline Entity', '#ECFCCB', 'Lưu trữ lịch sử vi phạm và điểm số'],
    ],
    connections: [
      ['1', 'S (Thí sinh)', 'UI (Exam Client UI)', 'Mũi tên liền nét (──>)', '1. Thí sinh thực hiện Alt+Tab / Chuyển sang ứng dụng khác', 'Hành vi rời khỏi môi trường thi'],
      ['2', 'UI (Exam Client UI)', 'UI (Exam Client UI)', 'Mũi tên tự gọi (↺)', '2. document.visibilitychange ("hidden") / window.blur', 'Trình duyệt bắt sự kiện mất tiêu điểm'],
      ['3', 'UI (Exam Client UI)', 'UI (Exam Client UI)', 'Mũi tên tự gọi (↺)', '3. violationCount++ & Chụp thời điểm vi phạm', 'Tăng bộ đếm vi phạm cục bộ'],
      ['4', 'UI (Exam Client UI)', 'SKC (Socket Client)', 'Mũi tên liền nét (──>)', '4. emit("exam-violation", { examId, studentId, type: "tab_switch" })', 'Đẩy sự kiện qua socket client'],
      ['5', 'SKC (Socket Client)', 'SKS (Socket Server)', 'Mũi tên liền nét (──>)', '5. WebSocket Frame truyền sự kiện vi phạm thời gian thực', 'Bắn tin qua kênh socket độ trễ thấp'],
      ['6', 'SKS (Socket Server)', 'T_UI (Giám thị UI)', 'Mũi tên liền nét (──>)', '6. emit("student-violation-alert", { studentName, count, type })', 'Báo động đỏ trên màn hình giám sát của giáo viên'],
      ['7', 'SKS (Socket Server)', 'SRV (Integrity Service)', 'Mũi tên liền nét (──>)', '7. recordViolation(examId, studentId, violationData)', 'Ghi nhận vết vi phạm vào nghiệp vụ'],
      ['8', 'SRV (Integrity Service)', 'DB (MongoDB)', 'Mũi tên liền nét (──>)', '8. ExamSubmission.updateOne({ $push: { violations: record } })', 'Lưu nhật ký vi phạm vào CSDL'],
      ['9', 'DB (MongoDB)', 'SRV (Integrity Service)', 'Mũi tên nét đứt phản hồi (<---)', '9. Ghi vết thành công', 'MongoDB phản hồi hoàn tất'],
      ['10', 'SRV (Integrity Service)', 'SKS (Socket Server)', 'Mũi tên nét đứt phản hồi (<---)', '10. Return { currentCount, isExceeded }', 'Kiểm tra xem số lần có vượt ngưỡng không'],
      ['11', 'UI (Exam Client UI)', 'UI (Exam Client UI)', 'Mũi tên tự gọi (↺)', '11. Kiểm tra: violationCount >= maxAllowedTabSwitches', 'Kiểm tra giới hạn cục bộ và từ server'],
      ['12', 'UI (Exam Client UI)', 'S (Thí sinh)', 'Mũi tên nét đứt phản hồi (<---)', '12a. [Nếu chưa quá hạn] Hiển thị Modal Cảnh báo đỏ toàn màn hình', 'Cảnh báo nghiêm khắc nhắc nhở thí sinh'],
      ['13', 'SKS (Socket Server)', 'UI (Exam Client UI)', 'Mũi tên liền nét (──>)', '12b. [Nếu vượt quá hạn] emit("force-submit-exam")', 'Lệnh cưỡng chế nộp bài từ máy chủ'],
      ['14', 'UI (Exam Client UI)', 'SRV (Integrity Service)', 'Mũi tên liền nét (──>)', '13. POST /student/exams/:id/force-submit (answersPayload)', 'Client khóa form và gửi bài nộp cưỡng bức'],
      ['15', 'SRV (Integrity Service)', 'DB (MongoDB)', 'Mũi tên liền nét (──>)', '14. Chấm điểm & Update Submission { status: "submitted", isForce: true }', 'Khóa bài thi vĩnh viễn và lưu điểm số'],
      ['16', 'SRV (Integrity Service)', 'UI (Exam Client UI)', 'Mũi tên nét đứt phản hồi (<---)', '15. Redirect /student/exams/:id/result?reason=violation_limit', 'Chuyển hướng thí sinh sang trang kết quả vi phạm'],
      ['17', 'UI (Exam Client UI)', 'S (Thí sinh)', 'Mũi tên nét đứt phản hồi (<---)', '16. Thông báo bài thi bị thu hồi do vượt quá số lần đổi tab', 'Khóa quyền làm bài'],
    ],
    textFlow: `S (Sinh viên) ──(1. Alt+Tab)──> UI ──(2. visibilitychange)──> (3. count++)
                                 │ (4. emit violation)
                                 ▼
                     SKC ──(5. WS Frame)──> SKS (Socket Server)
                                               ├──(6. Alert Live)──> T_UI (Giám thị)
                                               └──(7. recordViolation)──> SRV ──(8)──> DB
[NHÁNH 1: Chưa quá ngưỡng]
UI ──(12a. Modal Warning)──> S (Sinh viên)

[NHÁNH 2: Vượt quá ngưỡng vi phạm]
SKS ──(12b. force-submit)──> UI ──(13. POST force-submit)──> SRV ──(14. Grade & Lock)──> DB
                                                              │ (15. Redirect result)
                                                              ▼
S (Sinh viên) <──(16. Bị thu bài do gian lận)── UI <──────────┘`,
    mermaidCode: `sequenceDiagram
  autonumber
  actor S as Thí sinh
  participant UI as Exam Client (take-exam.js)
  participant SKC as Socket Client
  participant SKS as Socket Server
  participant T_UI as Dashboard Giám thị
  participant SRV as Integrity Service
  participant DB as MongoDB

  S->>UI: 1. Thí sinh Alt+Tab / Chuyển ứng dụng khác
  UI->>UI: 2. visibilitychange ("hidden") / window.blur
  UI->>UI: 3. violationCount++ & Chụp mốc thời gian
  UI->>SKC: 4. emit("exam-violation", data)
  SKC->>SKS: 5. Gửi sự kiện vi phạm thời gian thực
  par Thông báo Giám thị & Ghi vết
    SKS->>T_UI: 6. emit("student-violation-alert", { name, count })
  and Ghi CSDL
    SKS->>SRV: 7. recordViolation(examId, studentId)
    SRV->>DB: 8. Update violations array
    DB-->>SRV: 9. Ghi thành công
    SRV-->>SKS: 10. Return { currentCount, isExceeded }
  end

  alt violationCount < limit (Chưa vượt ngưỡng)
    UI-->>S: 11a. Hiện Modal cảnh báo đỏ toàn màn hình
  else violationCount >= limit (Vượt ngưỡng vi phạm)
    SKS->>UI: 11b. emit("force-submit-exam")
    UI->>SRV: 12. POST /student/exams/force-submit (answers)
    SRV->>DB: 13. Auto-grade & Save Submission { status: "submitted", isForce: true }
    SRV-->>UI: 14. Redirect /result?reason=violation_limit
    UI-->>S: 15. Thông báo bài thi bị thu hồi do vi phạm quy chế
  end`,
    codeMapping: [
      ['Client Event Listener', 'public/js/take-exam.js', 'window.addEventListener("blur"), visibilitychange'],
      ['Socket Realtime', 'socket/examMonitor.js', 'exam-violation, student-violation-alert, force-submit-exam'],
      ['Integrity Service', 'services/examIntegrity.service.js', 'recordViolation(), checkTabLimit(), forceSubmit()'],
      ['Database Storage', 'models/ExamSubmission.js', 'violations: [{ type, timestamp }], isForceSubmitted: true'],
    ]
  },

  // ─── HÌNH 2-10 ────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-10',
    title: 'Biểu đồ Tuần tự thiết lập kết nối WebRTC và phê duyệt học sinh tại phòng chờ',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.11: Thiết kế biểu đồ tuần tự cơ chế điều khiển lớp học ảo WebRTC',
    purpose: 'Mô tả tuần tự quy trình bắt tay tín hiệu (Signaling handshake), hàng đợi phòng chờ (Waiting Room Queue), cơ chế duyệt vào lớp của Host và thiết lập luồng trực tiếp P2P Audio/Video giữa giảng viên và sinh viên.',
    diagramType: 'Biểu đồ Tuần tự (UML Sequence Diagram)',
    nodes: [
      ['S', 'Sinh viên (Student)', 'Actor (Hình người)', '#DCFCE7', 'Học viên tham gia'],
      ['S_UI', 'Student UI (classroom-live.js)', 'Lifeline Boundary', '#E0F2FE', 'Giao diện phòng học sinh viên'],
      ['SIG', 'Socket.IO Server', 'Lifeline Control', '#FEF3C7', 'Máy chủ trung gian điều phối tín hiệu'],
      ['T_UI', 'Teacher UI (Host)', 'Lifeline Boundary', '#FFEDD5', 'Giao diện phòng học giảng viên'],
      ['T', 'Giảng viên (Host)', 'Actor (Hình người)', '#FEF3C7', 'Chủ tọa lớp học'],
      ['STUN', 'Google STUN Server', 'Lifeline External System', '#ECFCCB', 'Phân giải NAT / ICE Candidate'],
      ['DB', 'MongoDB (Attendance)', 'Lifeline Entity', '#FEE2E2', 'Lưu vết điểm danh'],
    ],
    connections: [
      ['1', 'S (Sinh viên)', 'S_UI (Student UI)', 'Mũi tên liền nét (──>)', '1. Click "Vào lớp học ảo"', 'Sinh viên gửi yêu cầu tham gia'],
      ['2', 'S_UI (Student UI)', 'SIG (Socket.IO Server)', 'Mũi tên liền nét (──>)', '2. Socket.emit("join-waiting-room", { roomId, studentInfo })', 'Đăng ký vào hàng đợi phòng chờ'],
      ['3', 'SIG (Socket.IO Server)', 'T_UI (Teacher UI)', 'Mũi tên liền nét (──>)', '3. Socket.emit("student-waiting-entry", { studentId, name, avatar })', 'Đẩy thông báo có học sinh xin vào'],
      ['4', 'T_UI (Teacher UI)', 'T (Giảng viên)', 'Mũi tên nét đứt phản hồi (<---)', '4. Hiển thị Popup xin duyệt vào lớp', 'Giảng viên thấy danh sách học sinh chờ'],
      ['5', 'T (Giảng viên)', 'T_UI (Teacher UI)', 'Mũi tên liền nét (──>)', '5. Click nút "Chấp nhận" (Admit)', 'Giảng viên duyệt học sinh'],
      ['6', 'T_UI (Teacher UI)', 'SIG (Socket.IO Server)', 'Mũi tên liền nét (──>)', '6. Socket.emit("approve-entry", { studentSocketId })', 'Gửi lệnh duyệt tới máy chủ'],
      ['7', 'SIG (Socket.IO Server)', 'DB (MongoDB)', 'Mũi tên liền nét (──>)', '7. Attendance.create({ classroomId, studentId, joinTime, status: "present" })', 'Ghi nhận điểm danh tự động'],
      ['8', 'SIG (Socket.IO Server)', 'S_UI (Student UI)', 'Mũi tên liền nét (──>)', '8. Socket.emit("entry-approved", { iceConfig })', 'Báo cho sinh viên đã được duyệt và cấp cấu hình ICE'],
      ['9', 'T_UI (Teacher UI)', 'STUN (STUN Server)', 'Mũi tên liền nét (──>)', '9. STUN Request tìm ICE Candidate của Host', 'Host tìm địa chỉ Public IP'],
      ['10', 'STUN (STUN Server)', 'T_UI (Teacher UI)', 'Mũi tên nét đứt phản hồi (<---)', '10. Return Host ICE Candidates', 'Trả danh sách ứng viên kết nối'],
      ['11', 'T_UI (Teacher UI)', 'SIG (Socket.IO Server)', 'Mũi tên liền nét (──>)', '11. Socket.emit("offer", { sdpOffer, targetSocketId })', 'Gửi mô tả phiên SDP Offer'],
      ['12', 'SIG (Socket.IO Server)', 'S_UI (Student UI)', 'Mũi tên liền nét (──>)', '12. Chuyển tiếp SDP Offer tới đúng máy sinh viên', 'Server định tuyến tin nhắn'],
      ['13', 'S_UI (Student UI)', 'STUN (STUN Server)', 'Mũi tên liền nét (──>)', '13. STUN Request tìm ICE Candidate của Sinh viên', 'Sinh viên tìm địa chỉ Public IP'],
      ['14', 'STUN (STUN Server)', 'S_UI (Student UI)', 'Mũi tên nét đứt phản hồi (<---)', '14. Return Student ICE Candidates', 'Trả danh sách ứng viên kết nối'],
      ['15', 'S_UI (Student UI)', 'SIG (Socket.IO Server)', 'Mũi tên liền nét (──>)', '15. Socket.emit("answer", { sdpAnswer, targetSocketId })', 'Gửi SDP Answer đồng ý kết nối'],
      ['16', 'SIG (Socket.IO Server)', 'T_UI (Teacher UI)', 'Mũi tên liền nét (──>)', '16. Chuyển tiếp SDP Answer về cho Host', 'Server bàn giao câu trả lời'],
      ['17', 'T_UI (Teacher UI)', 'S_UI (Student UI)', 'Mũi tên 2 chiều nét đôi (<==>)', '17. Trao đổi ICE Candidates qua lại & Khởi tạo P2P Connection', 'Hai máy hoàn tất bắt tay'],
      ['18', 'T_UI (Teacher UI)', 'S_UI (Student UI)', 'Mũi tên liền nét đậm (━━>)', '18. Trực tiếp truyền Audio / Video / Screen Stream (SRTP P2P)', 'Video và giọng nói truyền trực tiếp không qua server'],
    ],
    textFlow: `S (Sinh viên) ──(1)──> S_UI ──(2. join-waiting)──> SIG ──(3)──> T_UI ──(4)──> T (Giảng viên)
                                                                                  │ (5. Admit)
                                                                                  ▼
S_UI <──(8. entry-approved)── SIG <──(7. Save Attendance)── SIG <──(6. approve)── T_UI
  │                             │                                                 │
  ├──(13,14 STUN Candidate)     │                                                 ├──(9,10 STUN Candidate)
  │                             │                                                 ▼
  │                             ├──(12. Forward Offer) <──(11. SDP Offer)─────────┤
  │                             ▼                                                 │
  └─────(15. SDP Answer)──────> SIG ─────(16. Forward Answer)────────────────────>┤
                                                                                  │
S_UI <═════════════════[17. ICE Candidate Exchange & P2P Handshake]═══════════════>┤
                                                                                  │
S_UI <━━━━━━━━━━━━━━━━━[18. Direct Audio/Video/Screen P2P Stream]━━━━━━━━━━━━━━━━━┘`,
    mermaidCode: `sequenceDiagram
  autonumber
  actor S as Sinh viên
  participant S_UI as Student UI
  participant SIG as Socket.IO Signaling Server
  participant T_UI as Teacher Host UI
  actor T as Giảng viên
  participant STUN as Google STUN Server
  participant DB as MongoDB (Attendance)

  S->>S_UI: 1. Click "Vào lớp học ảo"
  S_UI->>SIG: 2. join-waiting-room (studentData)
  SIG->>T_UI: 3. student-waiting-entry (studentData)
  T_UI-->>T: 4. Hiển thị Popup xin duyệt vào lớp
  T->>T_UI: 5. Click "Duyệt vào lớp" (Admit)
  T_UI->>SIG: 6. approve-entry (studentSocketId)
  
  par Tự động điểm danh & Phê duyệt
    SIG->>DB: 7. Attendance.create(status: "present", joinTime)
  and Báo Client
    SIG->>S_UI: 8. entry-approved (iceConfig)
  end

  T_UI->>STUN: 9. STUN Request (Host ICE)
  STUN-->>T_UI: 10. Return Host Candidates
  T_UI->>SIG: 11. offer (sdpOffer, target: Student)
  SIG->>S_UI: 12. forward offer (sdpOffer)

  S_UI->>STUN: 13. STUN Request (Student ICE)
  STUN-->>S_UI: 14. Return Student Candidates
  S_UI->>SIG: 15. answer (sdpAnswer, target: Host)
  SIG->>T_UI: 16. forward answer (sdpAnswer)

  S_UI<<->>T_UI: 17. Trao đổi ICE Candidates qua Server
  T_UI->>S_UI: 18. Trực tiếp truyền Audio / Video / Screen Share (Direct P2P SRTP)`,
    codeMapping: [
      ['Signaling Handshake', 'socket/classroom.js', 'join-waiting-room, approve-entry, offer, answer, ice-candidate'],
      ['P2P WebRTC Core', 'public/js/classroom-live.js', 'RTCPeerConnection, createOffer(), createAnswer(), setRemoteDescription()'],
      ['Điểm danh tham dự', 'models/Attendance.js, controller/teacher/attendance.controller.js', 'classroomId, studentId, status: "present"'],
    ]
  },

  // ─── HÌNH 2-11 ────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-11',
    title: 'Sơ đồ Quan hệ thực thể (ERD) và cấu trúc dữ liệu NoSQL trong MongoDB',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.12: Thiết kế cơ sở dữ liệu và mô hình dữ liệu quan hệ NoSQL',
    purpose: 'Mô tả cấu trúc 12 Collections cốt lõi trong cơ sở dữ liệu MongoDB Atlas, các trường dữ liệu quan trọng, kiểu dữ liệu, các quan hệ 1-N (One-to-Many), 1-1 và cơ chế tham chiếu ObjectID (Mongoose Ref).',
    diagramType: 'Sơ đồ Thực thể Quan hệ (Entity Relationship Diagram - ERD)',
    nodes: [
      ['ENT_USER', 'User (Tài khoản người dùng)', 'Bảng Thực thể (Entity Table)', '#FEF3C7', '_id, fullName, email, passwordHash, role (admin/teacher/student), avatar, status, createdAt'],
      ['ENT_CLASS', 'Classroom (Lớp học)', 'Bảng Thực thể', '#DCFCE7', '_id, name, code, pinCode, description, teacherId (Ref User), coverImage, isActive, createdAt'],
      ['ENT_MEMBER', 'ClassroomMember (Thành viên lớp)', 'Bảng Thực thể (Junction Table)', '#E0F2FE', '_id, classroomId (Ref Classroom), userId (Ref User), roleInClass, joinedAt'],
      ['ENT_LECTURE', 'Lecture (Bài giảng số)', 'Bảng Thực thể', '#F3E8FF', '_id, title, classroomId (Ref Classroom), content, videoUrl, attachments [{ name, url }], order'],
      ['ENT_ASSIGN', 'Assignment (Bài tập về nhà)', 'Bảng Thực thể', '#FFEDD5', '_id, title, classroomId (Ref Classroom), description, dueDate, maxScore, attachments'],
      ['ENT_ASS_SUB', 'AssignmentSubmission (Bài nộp)', 'Bảng Thực thể', '#FEE2E2', '_id, assignmentId (Ref Assignment), studentId (Ref User), submissionFiles, textContent, score, feedback, submittedAt'],
      ['ENT_EXAM', 'Exam (Đề thi / Kiểm tra)', 'Bảng Thực thể', '#ECFCCB', '_id, title, classroomId (Ref Classroom), durationMinutes, passScore, tabSwitchLimit, accessPassword, questions [{ ref Question }], isActive'],
      ['ENT_QUESTION', 'Question (Ngân hàng câu hỏi)', 'Bảng Thực thể', '#CCFBF1', '_id, classroomId, teacherId, questionText, questionType (single/multiple), options [{ text, isCorrect }], explanation, difficulty, aiGenerated (Boolean)'],
      ['ENT_EXAM_SUB', 'ExamSubmission (Bài nộp thi)', 'Bảng Thực thể', '#FCE7F3', '_id, examId (Ref Exam), studentId (Ref User), answers [{ questionId, selectedOption }], score, violations [{ type, timestamp }], status (submitted/in_progress), isForceSubmitted'],
      ['ENT_ATTEND', 'Attendance (Điểm danh lớp)', 'Bảng Thực thể', '#E0E7FF', '_id, classroomId (Ref Classroom), date, records [{ studentId (Ref User), status (present/absent/late), checkInTime, photoEvidence }]'],
      ['ENT_DISCUSS', 'Discussion (Thảo luận lớp)', 'Bảng Thực thể', '#FEF08A', '_id, classroomId (Ref Classroom), authorId (Ref User), title, content, comments [{ authorId, content, createdAt }]'],
      ['ENT_AUDIT', 'AuditLog (Nhật ký an ninh)', 'Bảng Thực thể', '#F1F5F9', '_id, userId (Ref User), action, targetModel, ipAddress, userAgent, details, timestamp'],
    ],
    connections: [
      ['1', 'ENT_USER (User)', 'ENT_CLASS (Classroom)', 'Đường nối 1 - N (1..*)', '1 - N: teacherId (Một giảng viên tạo nhiều lớp học)', 'User._id <--- Classroom.teacherId'],
      ['2', 'ENT_USER (User)', 'ENT_MEMBER (ClassroomMember)', 'Đường nối 1 - N (1..*)', '1 - N: userId (Một người dùng tham gia nhiều lớp)', 'User._id <--- ClassroomMember.userId'],
      ['3', 'ENT_CLASS (Classroom)', 'ENT_MEMBER (ClassroomMember)', 'Đường nối 1 - N (1..*)', '1 - N: classroomId (Một lớp chứa nhiều thành viên)', 'Classroom._id <--- ClassroomMember.classroomId'],
      ['4', 'ENT_CLASS (Classroom)', 'ENT_LECTURE (Lecture)', 'Đường nối 1 - N (1..*)', '1 - N: classroomId (Một lớp có nhiều bài giảng)', 'Classroom._id <--- Lecture.classroomId'],
      ['5', 'ENT_CLASS (Classroom)', 'ENT_ASSIGN (Assignment)', 'Đường nối 1 - N (1..*)', '1 - N: classroomId (Một lớp có nhiều bài tập)', 'Classroom._id <--- Assignment.classroomId'],
      ['6', 'ENT_ASSIGN (Assignment)', 'ENT_ASS_SUB (Submission)', 'Đường nối 1 - N (1..*)', '1 - N: assignmentId (Một bài tập có nhiều bài nộp)', 'Assignment._id <--- AssignmentSubmission.assignmentId'],
      ['7', 'ENT_USER (User)', 'ENT_ASS_SUB (Submission)', 'Đường nối 1 - N (1..*)', '1 - N: studentId (Một sinh viên nộp bài)', 'User._id <--- AssignmentSubmission.studentId'],
      ['8', 'ENT_CLASS (Classroom)', 'ENT_EXAM (Exam)', 'Đường nối 1 - N (1..*)', '1 - N: classroomId (Một lớp tổ chức nhiều đề thi)', 'Classroom._id <--- Exam.classroomId'],
      ['9', 'ENT_CLASS (Classroom)', 'ENT_QUESTION (Question)', 'Đường nối 1 - N (1..*)', '1 - N: classroomId (Lớp liên kết ngân hàng câu hỏi)', 'Classroom._id <--- Question.classroomId'],
      ['10', 'ENT_EXAM (Exam)', 'ENT_QUESTION (Question)', 'Đường nối N - N (Tham chiếu mảng)', 'N - N: questions [{ type: ObjectId, ref: "Question" }]', 'Exam.questions tham chiếu nhiều Question'],
      ['11', 'ENT_EXAM (Exam)', 'ENT_EXAM_SUB (ExamSubmission)', 'Đường nối 1 - N (1..*)', '1 - N: examId (Một đề thi có nhiều bài nộp)', 'Exam._id <--- ExamSubmission.examId'],
      ['12', 'ENT_USER (User)', 'ENT_EXAM_SUB (ExamSubmission)', 'Đường nối 1 - N (1..*)', '1 - N: studentId (Một sinh viên làm nhiều bài thi)', 'User._id <--- ExamSubmission.studentId'],
      ['13', 'ENT_CLASS (Classroom)', 'ENT_ATTEND (Attendance)', 'Đường nối 1 - N (1..*)', '1 - N: classroomId (Một lớp có nhiều buổi điểm danh)', 'Classroom._id <--- Attendance.classroomId'],
      ['14', 'ENT_CLASS (Classroom)', 'ENT_DISCUSS (Discussion)', 'Đường nối 1 - N (1..*)', '1 - N: classroomId (Một lớp có nhiều chủ đề thảo luận)', 'Classroom._id <--- Discussion.classroomId'],
      ['15', 'ENT_USER (User)', 'ENT_AUDIT (AuditLog)', 'Đường nối 1 - N (1..*)', '1 - N: userId (Một người dùng ghi nhận nhiều hành vi)', 'User._id <--- AuditLog.userId'],
    ],
    textFlow: `[User] (1) ───< Sở hữu >─── (N) [Classroom]
  │                                     │
  ├──(1)──< Ghi danh >──(N) [ClassroomMember] (N) <──┘
  │
  ├──(1)──< Soạn bài >──(N) [Lecture] (N) <── [Classroom]
  │
  ├──(1)──< Giao bài >──(N) [Assignment] (N) <── [Classroom]
  │                           │ (1)
  │                           └──< Nộp bài >──(N) [AssignmentSubmission] (N) >── [User]
  │
  ├──(1)──< Tổ chức >───(N) [Exam] (N) <── [Classroom]
  │                           ├──(N)──< Nhúng / Liên kết >──(N) [Question]
  │                           │
  │                           └──(1)──< Nộp bài thi >──(N) [ExamSubmission] (N) >── [User]
  │
  ├──(1)──< Điểm danh >─(N) [Attendance] (N) <── [Classroom]
  ├──(1)──< Thảo luận >─(N) [Discussion] (N) <── [Classroom]
  └──(1)──< Ghi log >───(N) [AuditLog]`,
    mermaidCode: `erDiagram
  User ||--o{ Classroom : "owns (teacherId)"
  User ||--o{ ClassroomMember : "joins (userId)"
  Classroom ||--o{ ClassroomMember : "contains"
  
  Classroom ||--o{ Lecture : "has"
  Classroom ||--o{ Assignment : "assigns"
  Assignment ||--o{ AssignmentSubmission : "receives"
  User ||--o{ AssignmentSubmission : "submits"

  Classroom ||--o{ Exam : "hosts"
  Exam }o--o{ Question : "contains (Array of Ref)"
  Exam ||--o{ ExamSubmission : "records"
  User ||--o{ ExamSubmission : "takes"

  Classroom ||--o{ Attendance : "tracks"
  Classroom ||--o{ Discussion : "discusses"
  User ||--o{ AuditLog : "logs action"

  User {
    ObjectId _id PK
    string fullName
    string email
    string passwordHash
    string role
    string status
  }
  Classroom {
    ObjectId _id PK
    string name
    string pinCode
    ObjectId teacherId FK
    boolean isActive
  }
  Exam {
    ObjectId _id PK
    string title
    ObjectId classroomId FK
    int durationMinutes
    int tabSwitchLimit
    Array questions
  }
  Question {
    ObjectId _id PK
    string questionText
    Array options
    string explanation
    boolean aiGenerated
  }
  ExamSubmission {
    ObjectId _id PK
    ObjectId examId FK
    ObjectId studentId FK
    float score
    Array violations
    boolean isForceSubmitted
  }`,
    codeMapping: [
      ['User Schema', 'models/User.js', 'fullName, email, password, role, isVerified'],
      ['Classroom & Members', 'models/Classroom.js, models/ClassroomMember.js', 'teacherId, pinCode, members[]'],
      ['Exam & Question', 'models/Exam.js, models/Question.js', 'questions: [{ type: ObjectId, ref: "Question" }], tabSwitchLimit'],
      ['ExamSubmission', 'models/ExamSubmission.js', 'examId, studentId, answers, score, violations'],
      ['Attendance & Audit', 'models/Attendance.js, models/AuditLog.js', 'records: [{ studentId, status }], action, ipAddress'],
    ]
  },

  // ─── HÌNH 2-12 ────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-12',
    title: 'Sơ đồ kiến trúc triển khai hệ thống phân tầng và các dịch vụ tích hợp',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.13: Thiết kế kiến trúc triển khai hệ thống (Deployment Architecture)',
    purpose: 'Mô tả kiến trúc vật lý triển khai ứng dụng trên môi trường thực tế: Tầng Client người dùng, Tầng Reverse Proxy Nginx, Tầng máy chủ ứng dụng Node.js quản trị bởi PM2 Cluster, Tầng CSDL phân tán MongoDB Atlas và Tầng các dịch vụ đám mây bên thứ ba tích hợp qua API.',
    diagramType: 'Sơ đồ Triển khai Phần mềm (Deployment & Integration Diagram)',
    nodes: [
      ['TIER1', 'Tầng Client Devices (Người dùng)', 'Node Thiết bị Client (PC/Laptop/Mobile)', '#E0F2FE', 'Web Browser: Chrome, Edge, Safari, Firefox (Desktop & Mobile Responsive)'],
      ['TIER2', 'Tầng Web Server & Reverse Proxy (Nginx)', 'Node Máy chủ Web (Server Box)', '#FEF3C7', 'Nginx 1.24: SSL/TLS Termination (HTTPS Port 443), Gzip Compression, Caching Static Assets (/public), Load Balancing'],
      ['TIER3', 'Tầng Ứng dụng LMS (Node.js & PM2 Cluster)', 'Node Máy chủ Ứng dụng (App Server)', '#DCFCE7', 'PM2 Process Manager quản lý 2-4 Worker Processes: Express.js (Port 3000), Pug SSR Engine, Multer Parser, Socket.IO Server (WSS)'],
      ['TIER4', 'Tầng Cơ sở dữ liệu (MongoDB Atlas Cluster)', 'Node CSDL Phân tán (DB Replica Set)', '#ECFCCB', 'MongoDB Atlas 7.0: Replica Set 3 Nodes (1 Primary, 2 Secondary), Auto-failover, TLS Encryption at Rest & In-transit'],
      ['TIER5_1', 'Google Gemini AI Service (gemini-3.8-flash)', 'Node Đám mây Ngoại vi (Cloud Service)', '#F3E8FF', 'API sinh câu hỏi trắc nghiệm tự động từ file tài liệu'],
      ['TIER5_2', 'Cloudinary Media CDN', 'Node Đám mây Ngoại vi (Media Cloud)', '#FFEDD5', 'Lưu trữ đám mây: ảnh đại diện avatar, file tài liệu PDF bài giảng, ảnh minh chứng điểm danh'],
      ['TIER5_3', 'Google & Facebook OAuth 2.0', 'Node Đám mây Ngoại vi (Auth Cloud)', '#FEE2E2', 'Dịch vụ xác thực danh tính một chạm (Single Sign-On - SSO)'],
      ['TIER5_4', 'Google STUN Server (stun.l.google.com)', 'Node Đám mây Ngoại vi (STUN Cloud)', '#CCFBF1', 'Máy chủ phân giải NAT và ICE Candidate cho WebRTC Live Class'],
      ['TIER5_5', 'SMTP Mail Server (Google Workspace Gmail)', 'Node Đám mây Ngoại vi (Mail Cloud)', '#F1F5F9', 'Nodemailer gửi mã OTP kích hoạt tài khoản và thông báo điểm thi'],
    ],
    connections: [
      ['1', 'TIER1 (Client Devices)', 'TIER2 (Nginx Reverse Proxy)', 'Mũi tên 2 chiều liền nét (──>)', '1. HTTPS (Port 443) / WSS (WebSocket Secure)', 'Mã hóa TLS 1.3 bảo mật đường truyền'],
      ['2', 'TIER2 (Nginx Reverse Proxy)', 'TIER3 (Node.js PM2 Cluster)', 'Mũi tên 2 chiều liền nét (──>)', '2. Reverse Proxy Pass (http://127.0.0.1:3000)', 'Nginx chuyển tiếp request vào cụm Node.js'],
      ['3', 'TIER3 (Node.js App Server)', 'TIER4 (MongoDB Atlas)', 'Mũi tên 2 chiều liền nét (──>)', '3. Mongoose Pool over TLS (mongodb+srv://...)', 'Truy vấn BSON với cụm CSDL phân tán'],
      ['4', 'TIER3 (Node.js App Server)', 'TIER5_1 (Google Gemini AI)', 'Mũi tên nét đứt 1 chiều (⇢)', '4. REST HTTPS POST (API Key header)', 'Gửi văn bản tài liệu và nhận JSON câu hỏi'],
      ['5', 'TIER3 (Node.js App Server)', 'TIER5_2 (Cloudinary CDN)', 'Mũi tên nét đứt 1 chiều (⇢)', '5. Cloudinary SDK (Upload stream API)', 'Tải file bài tập, ảnh avatar lên CDN'],
      ['6', 'TIER3 (Node.js App Server)', 'TIER5_3 (OAuth 2.0 SSO)', 'Mũi tên nét đứt 1 chiều (⇢)', '6. Passport OAuth 2.0 Handshake', 'Trao đổi Auth Code lấy Access Token và User Profile'],
      ['7', 'TIER1 (Client Devices)', 'TIER5_4 (Google STUN)', 'Mũi tên nét đứt 1 chiều (⇢)', '7. STUN UDP Binding Request (Port 19302)', 'Trình duyệt hỏi IP Public trực tiếp'],
      ['8', 'TIER3 (Node.js App Server)', 'TIER5_5 (SMTP Mail Server)', 'Mũi tên nét đứt 1 chiều (⇢)', '8. SMTP TLS Port 587 (Nodemailer)', 'Gửi email xác nhận và thông báo kết quả'],
    ],
    textFlow: `[TIER 1: Client Devices (Web Browser Desktop/Mobile)]
       │
       │ (1. HTTPS 443 / WSS)
       ▼
[TIER 2: Nginx Web Server & Reverse Proxy]
       │
       │ (2. Proxy Pass 127.0.0.1:3000)
       ▼
[TIER 3: Node.js & PM2 Cluster (Express, Pug SSR, Socket.IO)]
       ├──(3. Mongoose TLS)──> [TIER 4: MongoDB Atlas Replica Set (3 Nodes)]
       ├──(4. REST HTTPS)────> [TIER 5.1: Google Gemini AI (gemini-3.8-flash)]
       ├──(5. Upload SDK)────> [TIER 5.2: Cloudinary Media CDN]
       ├──(6. OAuth2 Flow)───> [TIER 5.3: Google/Facebook SSO]
       └──(8. SMTP 587)──────> [TIER 5.5: Google Workspace SMTP Mailer]

[TIER 1: Client Devices] ───(7. STUN UDP 19302)───> [TIER 5.4: Google STUN Server]`,
    mermaidCode: `graph TD
  Client["Tầng 1: Client Devices (Browser Desktop & Mobile)"]
  Nginx["Tầng 2: Nginx Reverse Proxy (SSL Termination 443 & Gzip)"]
  PM2["Tầng 3: Node.js LMS Cluster (PM2, Express 4.21, Socket.IO)"]
  MongoDB[("Tầng 4: MongoDB Atlas Cluster (3-Node Replica Set)")]

  Gemini["Tầng 5.1: Google Gemini AI (gemini-3.8-flash)"]
  Cloudinary["Tầng 5.2: Cloudinary Media Storage"]
  OAuth["Tầng 5.3: Google & Facebook OAuth 2.0"]
  STUN["Tầng 5.4: Google STUN Server"]
  SMTP["Tầng 5.5: SMTP Mail Server (Nodemailer)"]

  Client -->|"1. HTTPS / WSS"| Nginx
  Nginx -->|"2. Proxy Pass :3000"| PM2
  PM2 -->|"3. Mongoose TLS"| MongoDB
  PM2 -.->|"4. HTTPS REST API"| Gemini
  PM2 -.->|"5. Upload SDK"| Cloudinary
  PM2 -.->|"6. OAuth 2.0"| OAuth
  Client -.->|"7. STUN UDP 19302"| STUN
  PM2 -.->|"8. SMTP Port 587"| SMTP

  style Client fill:#E0F2FE,stroke:#0284C7,stroke-width:2px
  style Nginx fill:#FEF3C7,stroke:#D97706,stroke-width:2px
  style PM2 fill:#DCFCE7,stroke:#16A34A,stroke-width:2px
  style MongoDB fill:#ECFCCB,stroke:#65A30D,stroke-width:2px
  style Gemini fill:#F3E8FF,stroke:#9333EA,stroke-width:2px
  style Cloudinary fill:#FFEDD5,stroke:#EA580C,stroke-width:2px
  style OAuth fill:#FEE2E2,stroke:#DC2626,stroke-width:2px
  style STUN fill:#CCFBF1,stroke:#0D9488,stroke-width:2px
  style SMTP fill:#F1F5F9,stroke:#475569,stroke-width:2px`,
    codeMapping: [
      ['Nginx Configuration', 'nginx.example.conf', 'listen 443 ssl, proxy_pass http://localhost:3000, proxy_set_header Upgrade $http_upgrade'],
      ['PM2 Cluster Manager', 'ecosystem.config.js', 'instances: "max", exec_mode: "cluster", watch: false'],
      ['Database Connection', 'config/database.js', 'mongoose.connect(process.env.MONGO_URI, { maxPoolSize: 50 })'],
      ['External Integrations', 'services/aiQuestionGen.service.js, config/cloudinary.js, config/passport.js', 'Gemini API 3.8 Flash, Cloudinary v2, Passport Strategies'],
    ]
  }
];
