/**
 * Dữ liệu chi tiết cho 5 biểu đồ đầu tiên (Hình 1-1 -> Hình 2-2)
 * Bao gồm Nodes, Ma trận kết nối A -> B, Text Flow, Mermaid Code, Code Mapping
 */
module.exports = [
  // ─── HÌNH 1-1 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 1-1',
    title: 'Kiến trúc mô hình MVC trên nền tảng Express.js và Pug SSR',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 1, Mục 1.2: Mô hình kiến trúc phần mềm MVC và Server-Side Rendering (SSR)',
    purpose: 'Mô tả chi tiết luồng xử lý yêu cầu Client-Server, phân tách 3 tầng Model - View - Controller kết hợp Service Layer và cơ chế kết xuất HTML trực tiếp từ máy chủ (Pug SSR).',
    diagramType: 'Sơ đồ khối kiến trúc phần mềm (Architectural Block Diagram)',
    nodes: [
      ['A', 'Client (Web Browser)', 'Hình chữ nhật bo góc (Client Device)', '#E0F2FE (Xanh dương nhạt)', 'Trình duyệt phía người dùng (Chrome, Edge) gửi HTTP Request và nhận HTML/CSS/JS'],
      ['B', 'Express Routing & Middleware', 'Hình chữ nhật viền đôi', '#FEF3C7 (Vàng nhạt)', 'Định tuyến URL, xác thực Session, giải mã Cookie, kiểm tra bảo mật CSRF & XSS'],
      ['C', 'Controller Layer', 'Hình chữ nhật bo góc', '#DCFCE7 (Xanh lá nhạt)', 'Tiếp nhận tham số request, điều phối logic, gọi Service và chuẩn bị dữ liệu render'],
      ['D', 'Service Layer', 'Hình chữ nhật bo góc', '#F3E8FF (Tím nhạt)', 'Chứa toàn bộ Business Logic: xử lý thuật toán, tính toán điểm, gọi AI, upload file'],
      ['E', 'Model (Mongoose ODM)', 'Hình chữ nhật viền đôi', '#FEE2E2 (Đỏ nhạt)', 'Định nghĩa Schema, validate dữ liệu, cung cấp các phương thức thao tác MongoDB'],
      ['F', 'MongoDB Atlas Database', 'Hình trụ (Database Cylinder)', '#ECFCCB (Xanh cốm)', 'Cơ sở dữ liệu NoSQL lưu trữ tài liệu BSON, chỉ mục Index, Replica Set'],
      ['G', 'Pug View Engine (SSR)', 'Hình chữ nhật vát góc', '#FFEDD5 (Cam nhạt)', 'Biên dịch template .pug và nhúng dữ liệu từ Controller để sinh HTML tĩnh'],
      ['H', 'External Cloud APIs', 'Hình đám mây (Cloud)', '#E0E7FF (Xanh chàm)', 'Google Gemini 3.8 Flash (sinh câu hỏi), Cloudinary (lưu ảnh/video), SMTP Mailer'],
    ],
    connections: [
      ['1', 'A (Client Browser)', 'B (Express Middleware)', 'Mũi tên liền nét 1 chiều (──>)', '1. HTTP Request (GET/POST /exams, cookies, csrf)', 'Người dùng thực hiện hành động trên giao diện gửi request đến Web Server'],
      ['2', 'B (Express Middleware)', 'B (Express Middleware)', 'Mũi tên cong phản hồi (↺)', '2. Verify session, CSRF token, rateLimit()', 'Hệ thống kiểm tra tính hợp lệ của phiên đăng nhập và bảo mật trước khi cho qua'],
      ['3', 'B (Express Middleware)', 'C (Controller Layer)', 'Mũi tên liền nét 1 chiều (──>)', '3. Next() chuyển dispatch đến Controller tương ứng', 'Định tuyến chuẩn xác chuyển control tới hàm controller phụ trách'],
      ['4', 'C (Controller Layer)', 'D (Service Layer)', 'Mũi tên liền nét 1 chiều (──>)', '4. Gọi hàm xử lý nghiệp vụ chuyên biệt (Business call)', 'Controller không xử lý logic phức tạp mà ủy thác hoàn toàn cho tầng Service'],
      ['5', 'D (Service Layer)', 'H (External Cloud APIs)', 'Mũi tên nét đứt 1 chiều (⇢)', '5. HTTPS REST API Request (Prompt AI, Upload file)', 'Service giao tiếp với Google Gemini API hoặc Cloudinary Storage'],
      ['6', 'H (External Cloud APIs)', 'D (Service Layer)', 'Mũi tên nét đứt 1 chiều (⇢)', '6. JSON Response / Cloud URL phản hồi', 'Dịch vụ đám mây trả kết quả phân tích AI hoặc liên kết tệp lưu trữ'],
      ['7', 'D (Service Layer)', 'E (Model / Mongoose)', 'Mũi tên liền nét 1 chiều (──>)', '7. Query / Save / Update dữ liệu đối tượng', 'Service gọi các hàm Mongoose Model: find(), create(), aggregate()'],
      ['8', 'E (Model / Mongoose)', 'F (MongoDB Atlas)', 'Mũi tên liền nét 1 chiều (──>)', '8. BSON Wire Protocol over TLS/TCP', 'Mongoose thực thi câu lệnh truy vấn xuống cơ sở dữ liệu MongoDB Atlas'],
      ['9', 'F (MongoDB Atlas)', 'E (Model / Mongoose)', 'Mũi tên nét đứt 1 chiều (⇢)', '9. Trả kết quả bản ghi Documents / BSON', 'MongoDB trả về dữ liệu thô dạng document cho ODM Mongoose'],
      ['10', 'E (Model / Mongoose)', 'D (Service Layer)', 'Mũi tên nét đứt 1 chiều (⇢)', '10. Trả Mongoose Document / Plain Object', 'Mongoose ánh xạ thành Javascript Object cho Service tiếp tục xử lý'],
      ['11', 'D (Service Layer)', 'C (Controller Layer)', 'Mũi tên nét đứt 1 chiều (⇢)', '11. Trả kết quả nghiệp vụ hoàn tất cho Controller', 'Service bàn giao dữ liệu đã tính toán sạch cho Controller'],
      ['12', 'C (Controller Layer)', 'G (Pug View Engine)', 'Mũi tên liền nét 1 chiều (──>)', '12. res.render("view-name", viewModelData)', 'Controller nạp template tương ứng kèm biến dữ liệu sang Pug Engine'],
      ['13', 'G (Pug View Engine)', 'B (Express Middleware)', 'Mũi tên liền nét 1 chiều (──>)', '13. Biên dịch thành chuỗi HTML hoàn chỉnh', 'Pug engine kết hợp layout base và view con tạo cây DOM HTML hoàn chỉnh'],
      ['14', 'B (Express Middleware)', 'A (Client Browser)', 'Mũi tên liền nét 1 chiều (──>)', '14. HTTP 200 OK Response (HTML + CSS + Session Cookie)', 'Server gửi gói tin HTML hoàn chỉnh về cho trình duyệt Client hiển thị tức thì'],
    ],
    textFlow: `[A: Client Browser] 
    └──(1. HTTP Request)──> [B: Express Routing/Middleware]
                                └──(3. Dispatch)──> [C: Controller]
                                                         └──(4. Invoke)──> [D: Service Layer]
                                                                                ├──(5. REST)──> [H: Cloud APIs (Gemini/Cloudinary)]
                                                                                └──(7. CRUD)──> [E: Mongoose ODM]
                                                                                                     └──(8. TCP)──> [F: MongoDB Atlas]
[A: Client Browser] <──(14. HTML 200 OK)── [B: Response] <──(13. HTML)── [G: Pug SSR] <──(12. Render Data)── [C: Controller]`,
    mermaidCode: `graph TD
  A["A: Client (Web Browser)"] -->|"1. HTTP Request (GET/POST)"| B["B: Express Routing & Middleware"]
  B -->|"2. Verify Session & CSRF"| B
  B -->|"3. Dispatch Route"| C["C: Controller Layer"]
  C -->|"4. Execute Business Logic"| D["D: Service Layer"]
  D -.->|"5. HTTPS Request"| H["H: External Cloud APIs (Gemini/Cloudinary)"]
  H -.->|"6. JSON Response"| D
  D -->|"7. Mongoose Queries"| E["E: Model (Mongoose ODM)"]
  E -->|"8. BSON Wire Protocol"| F[("F: MongoDB Atlas Database")]
  F -.->|"9. Return Documents"| E
  E -.->|"10. Plain Objects"| D
  D -.->|"11. Return Business Data"| C
  C -->|"12. res.render(view, data)"| G["G: Pug View Engine (SSR)"]
  G -->|"13. Compile HTML"| B
  B -->|"14. HTTP 200 OK (HTML/CSS)"| A

  style A fill:#E0F2FE,stroke:#0284C7,stroke-width:2px
  style B fill:#FEF3C7,stroke:#D97706,stroke-width:2px
  style C fill:#DCFCE7,stroke:#16A34A,stroke-width:2px
  style D fill:#F3E8FF,stroke:#9333EA,stroke-width:2px
  style E fill:#FEE2E2,stroke:#DC2626,stroke-width:2px
  style F fill:#ECFCCB,stroke:#65A30D,stroke-width:2px
  style G fill:#FFEDD5,stroke:#EA580C,stroke-width:2px
  style H fill:#E0E7FF,stroke:#4F46E5,stroke-width:2px`,
    codeMapping: [
      ['Client Browser (A)', 'public/js/main.js, public/js/take-exam.js', 'Bắt sự kiện giao diện, gửi AJAX/Form Submit'],
      ['Express Middleware (B)', 'index.js, middleware/auth.js, middleware/csrf.js', 'Cấu hình session, csurf(), express.urlencoded()'],
      ['Controller Layer (C)', 'controller/teacher/exam.controller.js, controller/student/exam.controller.js', 'Điều hướng hàm createExam(), submitExam()'],
      ['Service Layer (D)', 'services/aiQuestionGen.service.js, services/examIntegrity.service.js', 'Hàm extractAndGenerate(), verifySubmission()'],
      ['Model Layer (E)', 'models/Exam.js, models/Question.js, models/ExamSubmission.js', 'Schema Mongoose, validation rules, index'],
      ['MongoDB Atlas (F)', 'config/database.js', 'Mongoose.connect(process.env.MONGO_URI)'],
      ['Pug View Engine (G)', 'views/layouts/base.pug, views/teacher/exams/*.pug', 'Template kế thừa, mixins, render HTML tĩnh'],
      ['External APIs (H)', 'services/aiQuestionGen.service.js, config/cloudinary.js', 'GoogleGenAI(gemini-3.8-flash), Cloudinary SDK'],
    ]
  },

  // ─── HÌNH 1-2 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 1-2',
    title: 'Mô hình xử lý bất đồng bộ Non-blocking I/O và Event Loop trong Node.js',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 1, Mục 1.3: Mô hình xử lý bất đồng bộ Non-blocking I/O và kiến trúc Event-Driven',
    purpose: 'Giải thích nguyên lý Node.js xử lý hàng nghìn kết nối đồng thời trong hệ thống LMS trên môi trường đơn luồng (Single Thread) kết hợp Libuv Worker Threads.',
    diagramType: 'Sơ đồ luồng cơ chế thực thi (Engine Architecture Flow)',
    nodes: [
      ['A', 'Incoming HTTP/WS Requests', 'Hàng các hình chữ nhật', '#E0F2FE (Xanh dương nhạt)', 'Các yêu cầu đồng thời từ sinh viên nộp bài thi, xem video, ping WebSocket'],
      ['B', 'Call Stack (V8 Engine)', 'Hình chữ nhật dọc (Ngăn xếp LIFO)', '#FEF3C7 (Vàng nhạt)', 'Ngăn xếp thực thi mã JavaScript chính trên Main Thread duy nhất'],
      ['C', 'Node.js Core C++ APIs', 'Hình chữ nhật bo góc', '#F3E8FF (Tím nhạt)', 'Cầu nối giữa mã JS và thư viện C++ cấp thấp (fs, crypto, net, zlib)'],
      ['D', 'Libuv Thread Pool (Workers)', 'Cụm 4 hình chữ nhật con', '#FEE2E2 (Đỏ nhạt)', 'Nhóm 4 luồng nền C++ xử lý tác vụ nặng không chặn: Đọc file PDF, băm mật khẩu bcrypt'],
      ['E', 'OS Kernel (epoll/kqueue/IOCP)', 'Hình chữ nhật viền đôi', '#ECFCCB (Xanh cốm)', 'Xử lý Network I/O không đồng bộ ở tầng nhân hệ điều hành (TCP sockets, MongoDB)'],
      ['F', 'Microtask Queue', 'Hàng đợi ngang (FIFO nhỏ)', '#FCE7F3 (Hồng nhạt)', 'Ưu tiên cao nhất: process.nextTick(), Promise.then(), catch(), finally()'],
      ['G', 'Macrotask / Callback Queue', 'Hàng đợi ngang (FIFO lớn 4 pha)', '#FFEDD5 (Cam nhạt)', 'Chứa các callback: Timers (setTimeout), I/O Callbacks, Check (setImmediate), Close'],
      ['H', 'Event Loop', 'Vòng tròn xoay (Circle Loop ↺)', '#CCFBF1 (Xanh ngọc)', 'Vòng lặp giám sát Call Stack: Khi Stack rỗng, bốc task từ Queue đưa lên Stack'],
    ],
    connections: [
      ['1', 'A (Incoming Requests)', 'B (Call Stack)', 'Mũi tên liền nét 1 chiều (──>)', '1. Đẩy Request Callback vào Call Stack', 'Yêu cầu từ client được đưa vào ngăn xếp thực thi của V8'],
      ['2', 'B (Call Stack)', 'B (Call Stack)', 'Mũi tên tự trỏ (↺)', '2. Thực thi mã đồng bộ tuần tự', 'V8 xử lý biến, câu lệnh điều kiện, lặp trên Main Thread'],
      ['3', 'B (Call Stack)', 'C (Node.js Core APIs)', 'Mũi tên liền nét 1 chiều (──>)', '3. Ủy thác tác vụ I/O nặng bất đồng bộ', 'Gặp hàm async (fs.readFile, bcrypt.hash, http.get), đẩy xuống C++ layer'],
      ['4', 'C (Node.js Core APIs)', 'D (Libuv Thread Pool)', 'Mũi tên liền nét 1 chiều (──>)', '4a. Phân bổ File I/O & CPU-intensive tasks', 'Đọc tệp đề thi PDF (pdf-parse), băm mật khẩu bcrypt, nén gzip'],
      ['5', 'C (Node.js Core APIs)', 'E (OS Kernel)', 'Mũi tên liền nét 1 chiều (──>)', '4b. Phân bổ Network I/O non-blocking', 'Kết nối Socket.IO phòng học, truy vấn MongoDB Atlas, gọi Gemini API'],
      ['6', 'B (Call Stack)', 'F (Microtask Queue)', 'Mũi tên liền nét 1 chiều (──>)', '5. Promise resolution đẩy callback', 'Các resolve/reject của Promise được xếp ngay vào hàng đợi vi nhiệm'],
      ['7', 'D (Libuv Thread Pool)', 'G (Macrotask Queue)', 'Mũi tên nét đứt 1 chiều (⇢)', '6a. Hoàn tất đọc file/crypto, đẩy callback', 'Libuv gửi kết quả và callback vào I/O Callback Queue'],
      ['8', 'E (OS Kernel)', 'G (Macrotask Queue)', 'Mũi tên nét đứt 1 chiều (⇢)', '6b. Socket có dữ liệu, thông báo sự kiện', 'HĐH báo socket sẵn sàng đọc/ghi, đưa callback vào hàng đợi'],
      ['9', 'H (Event Loop)', 'B (Call Stack)', 'Mũi tên 2 chiều giám sát (<──>)', '7. Liên tục kiểm tra Call Stack có rỗng không', 'Nếu Call Stack còn hàm đang chạy, Event Loop chờ đợi, không chen ngang'],
      ['10', 'H (Event Loop)', 'F (Microtask Queue)', 'Mũi tên liền nét 1 chiều (──>)', '8. Ưu tiên bốc cạn Microtask Queue trước', 'Toàn bộ Promise callback được đưa lên Stack xử lý sạch sẽ'],
      ['11', 'F (Microtask Queue)', 'B (Call Stack)', 'Mũi tên liền nét 1 chiều (──>)', '9. Chuyển hàm callback lên Call Stack thực thi', 'V8 thực thi hàm then/catch'],
      ['12', 'H (Event Loop)', 'G (Macrotask Queue)', 'Mũi tên liền nét 1 chiều (──>)', '10. Bốc 1 callback từ Macrotask Queue theo pha', 'Lần lượt quét Timers -> I/O -> Check -> Close'],
      ['13', 'G (Macrotask Queue)', 'B (Call Stack)', 'Mũi tên liền nét 1 chiều (──>)', '11. Đẩy callback lên Call Stack', 'V8 tiếp tục thực thi mã xử lý phản hồi dữ liệu về cho người dùng'],
    ],
    textFlow: `[A: Incoming Requests] ──(1)──> [B: Call Stack (V8)] ──(3)──> [C: C++ Bindings]
                                        │                                 ├──(4a)──> [D: Libuv Threads (File/Crypto)]
                                        │ (5. Promise)                    └──(4b)──> [E: OS Kernel (Network/Sockets)]
                                        ▼                                                   │ (6a, 6b Callback done)
                                [F: Microtask Queue]                                        ▼
                                        ▲                                         [G: Macrotask Queue]
                                        │ (8. Ưu tiên)                                      ▲
                                [H: Event Loop] ──(7. Kiểm tra Call Stack rỗng)─────────────┘ (10. Bốc theo pha)
                                        │ (9, 11)
                                        └───> Đẩy callback ngược về [B: Call Stack]`,
    mermaidCode: `graph TD
  A["A: Incoming HTTP/WS Requests"] -->|"1. Push to Stack"| B["B: Call Stack (V8 Main Thread)"]
  B -->|"2. Sync Execution"| B
  B -->|"3. Delegate Async I/O"| C["C: Node.js Core C++ APIs"]
  C -->|"4a. File I/O & Crypto"| D["D: Libuv Thread Pool (Workers)"]
  C -->|"4b. Network Sockets"| E["E: OS Kernel (epoll/kqueue)"]
  B -->|"5. Promise.then()"| F["F: Microtask Queue (High Priority)"]
  D -.->|"6a. Task Done Callback"| G["G: Macrotask Queue (Timers/IO/Check)"]
  E -.->|"6b. Network Event"| G
  H(("H: Event Loop")) <-->|"7. Check Stack Empty?"| B
  H -->|"8. Drain Microtasks First"| F
  F -->|"9. Execute on V8"| B
  H -->|"10. Pick Next Macrotask"| G
  G -->|"11. Push Callback"| B

  style A fill:#E0F2FE,stroke:#0284C7,stroke-width:2px
  style B fill:#FEF3C7,stroke:#D97706,stroke-width:2px
  style C fill:#F3E8FF,stroke:#9333EA,stroke-width:2px
  style D fill:#FEE2E2,stroke:#DC2626,stroke-width:2px
  style E fill:#ECFCCB,stroke:#65A30D,stroke-width:2px
  style F fill:#FCE7F3,stroke:#DB2777,stroke-width:2px
  style G fill:#FFEDD5,stroke:#EA580C,stroke-width:2px
  style H fill:#CCFBF1,stroke:#0D9488,stroke-width:3px`,
    codeMapping: [
      ['Call Stack (B)', 'index.js, controller/*.js', 'Thực thi mã điều hướng và chuẩn bị tham số'],
      ['Libuv Thread Pool (D)', 'middleware/aiDocUpload.js, services/aiQuestionGen.service.js', 'multer xử lý ghi đĩa đệm, pdf-parse giải mã nhị phân tệp'],
      ['OS Kernel Async (E)', 'config/database.js, socket/classroom.js', 'Mongoose kết nối MongoDB qua socket TLS, Socket.IO duy trì kết nối WebSocket'],
      ['Microtask Queue (F)', 'controller/teacher/exam.controller.js', 'Cụm await Exam.findById(), Promise.all()'],
      ['Macrotask Queue (G)', 'services/examIntegrity.service.js', 'setTimeout() đếm lùi thời gian làm bài, socket heartbeat ping/pong'],
    ]
  },

  // ─── HÌNH 1-3 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 1-3',
    title: 'Cơ chế trao đổi tín hiệu (Signaling) WebRTC qua Socket.IO trong lớp học ảo',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 1, Mục 1.4: Công nghệ truyền thông thời gian thực WebRTC và WebSocket (Socket.IO)',
    purpose: 'Làm rõ 2 giai đoạn: Giai đoạn 1 trao đổi thông tin SDP/ICE qua máy chủ trung gian (Signaling Server) và Giai đoạn 2 truyền tải âm thanh, video, chia sẻ màn hình P2P trực tiếp độ trễ mili-giây.',
    diagramType: 'Sơ đồ giao thức truyền thông (Protocol & Signaling Architecture)',
    nodes: [
      ['A', 'Giảng viên / Host (Peer A)', 'Hình chữ nhật bo góc (Host Device)', '#E0F2FE (Xanh dương nhạt)', 'Máy chủ tọa lớp học, phát camera/mic và quản lý chia sẻ màn hình'],
      ['B', 'Socket.IO Signaling Server', 'Hình chữ nhật viền đôi (Node.js)', '#FEF3C7 (Vàng nhạt)', 'Máy chủ Express/Socket.IO định tuyến sự kiện signaling giữa các peer'],
      ['C', 'STUN Server (Google STUN)', 'Hình đám mây (Cloud Service)', '#ECFCCB (Xanh cốm)', 'Máy chủ NAT Traversal phân giải địa chỉ IP Public và Port của client'],
      ['D', 'Sinh viên / Học viên (Peer B)', 'Hình chữ nhật bo góc (Student Device)', '#DCFCE7 (Xanh lá nhạt)', 'Máy người học nhận stream bài giảng và gửi video/âm thanh thảo luận'],
      ['E', 'Kênh P2P Media Stream (Direct UDP)', 'Ống truyền dẫn 2 chiều (Pipe)', '#FFEDD5 (Cam đậm)', 'Kênh truyền thông trực tiếp Peer-to-Peer sử dụng SRTP/SCTP qua UDP'],
    ],
    connections: [
      ['1', 'A (Giảng viên)', 'B (Signaling Server)', 'Mũi tên liền nét 1 chiều (──>)', '1. Socket.emit("join-room", { roomId, isTeacher: true })', 'Giảng viên khởi tạo phòng học ảo và kết nối socket room'],
      ['2', 'D (Sinh viên)', 'B (Signaling Server)', 'Mũi tên liền nét 1 chiều (──>)', '2. Socket.emit("join-room", { roomId, studentId })', 'Sinh viên bấm tham gia lớp học ảo sau khi qua phòng chờ'],
      ['3', 'B (Signaling Server)', 'A (Giảng viên)', 'Mũi tên liền nét 1 chiều (──>)', '3. Socket.emit("user-connected", { studentSocketId })', 'Server thông báo cho Giảng viên biết có học viên mới vừa vào phòng'],
      ['4', 'A (Giảng viên)', 'C (STUN Server)', 'Mũi tên nét đứt 1 chiều (⇢)', '4. STUN Binding Request (UDP)', 'Peer A hỏi STUN server địa chỉ IP công khai và Port mở của mình'],
      ['5', 'C (STUN Server)', 'A (Giảng viên)', 'Mũi tên nét đứt 1 chiều (⇢)', '5. STUN Binding Success Response (Public IP:Port)', 'STUN trả về ICE Candidate chứa IP:Port của Giảng viên'],
      ['6', 'A (Giảng viên)', 'B (Signaling Server)', 'Mũi tên liền nét 1 chiều (──>)', '6. Socket.emit("offer", { sdpOffer, targetId: studentSocketId })', 'Giảng viên tạo SDP Offer mô tả codec, resolution và gửi qua Server'],
      ['7', 'B (Signaling Server)', 'D (Sinh viên)', 'Mũi tên liền nét 1 chiều (──>)', '7. Socket.to(targetId).emit("offer", { sdpOffer, senderId })', 'Server chuyển tiếp chính xác SDP Offer tới socket của Sinh viên'],
      ['8', 'D (Sinh viên)', 'C (STUN Server)', 'Mũi tên nét đứt 1 chiều (⇢)', '8. STUN Binding Request (UDP)', 'Sinh viên hỏi STUN server địa chỉ IP công khai và Port của mình'],
      ['9', 'C (STUN Server)', 'D (Sinh viên)', 'Mũi tên nét đứt 1 chiều (⇢)', '9. STUN Binding Success Response (Public IP:Port)', 'STUN trả về ICE Candidate của Sinh viên'],
      ['10', 'D (Sinh viên)', 'B (Signaling Server)', 'Mũi tên liền nét 1 chiều (──>)', '10. Socket.emit("answer", { sdpAnswer, targetId: teacherSocketId })', 'Sinh viên tạo SDP Answer chấp nhận thông số và gửi ngược lại Server'],
      ['11', 'B (Signaling Server)', 'A (Giảng viên)', 'Mũi tên liền nét 1 chiều (──>)', '11. Socket.to(targetId).emit("answer", { sdpAnswer })', 'Server chuyển tiếp SDP Answer về cho Giảng viên'],
      ['12', 'A (Giảng viên)', 'B (Signaling Server)', 'Mũi tên 2 chiều (<──>)', '12. Socket.emit("ice-candidate", candidate)', 'Hai bên trao đổi các gói ICE Candidate qua lại qua Server để tìm đường tối ưu'],
      ['13', 'B (Signaling Server)', 'D (Sinh viên)', 'Mũi tên 2 chiều (<──>)', '13. Chuyển tiếp ICE Candidate hai chiều', 'Server trung gian trao đổi thông tin kết nối mạng chi tiết'],
      ['14', 'A (Giảng viên)', 'E (Kênh P2P Direct)', 'Mũi tên liền nét 1 chiều (──>)', '14a. Thiết lập kênh truyền SRTP (Direct UDP Media)', 'Khi hoàn tất handshake, hai máy bypass server và kết nối thẳng P2P'],
      ['15', 'E (Kênh P2P Direct)', 'D (Sinh viên)', 'Mũi tên liền nét 1 chiều (──>)', '14b. Truyền Audio, Video 720p/1080p, Screen Share', 'Video bài giảng và âm thanh truyền trực tiếp độ trễ dưới 200ms'],
      ['16', 'D (Sinh viên)', 'E (Kênh P2P Direct)', 'Mũi tên nét đứt 1 chiều (⇢)', '15. Gửi ngược Audio/Video webcam học viên', 'Sinh viên phát biểu trao đổi hai chiều với giảng viên'],
    ],
    textFlow: `[GIAI ĐOẠN 1: SIGNALING - QUA SERVER]
Giảng viên (A) ──(1. Join)──> [Server (B)] <──(2. Join)── Sinh viên (D)
Giảng viên (A) <──(4,5 STUN)── [STUN (C)] ──(8,9 STUN)──> Sinh viên (D)
Giảng viên (A) ──(6. SDP Offer)──> [Server (B)] ──(7. Forward)──> Sinh viên (D)
Sinh viên (D) ──(10. SDP Answer)──> [Server (B)] ──(11. Forward)──> Giảng viên (A)
Giảng viên (A) <──(12, 13. Trao đổi ICE Candidates qua Server)──> Sinh viên (D)

[GIAI ĐOẠN 2: PEER-TO-PEER - TRUYỀN DỮ LIỆU TRỰC TIẾP]
Giảng viên (A) <═════[E: Direct P2P Media Stream (SRTP over UDP)]═════> Sinh viên (D)`,
    mermaidCode: `sequenceDiagram
  autonumber
  actor A as Giảng viên (Peer A)
  participant S as Socket.IO Signaling Server
  participant STUN as Google STUN Server
  actor B as Sinh viên (Peer B)

  Note over A,B: Giai đoạn 1: Bắt tay Tín hiệu (Signaling qua Server)
  A->>S: join-room (roomId, Host)
  B->>S: join-room (roomId, Student)
  S->>A: user-connected (studentSocketId)
  
  A->>STUN: Request NAT Mapping (IP & Port)
  STUN-->>A: Return Host ICE Candidate
  A->>S: offer (sdpOffer, target: B)
  S->>B: forward offer (sdpOffer, sender: A)
  
  B->>STUN: Request NAT Mapping (IP & Port)
  STUN-->>B: Return Student ICE Candidate
  B->>S: answer (sdpAnswer, target: A)
  S->>A: forward answer (sdpAnswer, sender: B)
  
  A->>S: ice-candidate (candidate A)
  S->>B: forward ice-candidate (candidate A)
  B->>S: ice-candidate (candidate B)
  S->>A: forward ice-candidate (candidate B)

  Note over A,B: Giai đoạn 2: Kết nối P2P Media Stream trực tiếp (Bypass Server)
  A->>B: P2P Direct Media: Video / Audio / Screen Share (SRTP UDP)
  B-->>A: P2P Direct Media: Mic Voice / Webcam Feedback (SRTP UDP)`,
    codeMapping: [
      ['Signaling Client Host', 'public/js/classroom-live.js', 'RTCPeerConnection, createOffer(), setLocalDescription()'],
      ['Signaling Server', 'socket/classroom.js, index.js', 'io.on("connection"), socket.on("offer"), socket.to().emit()'],
      ['STUN Server Configuration', 'public/js/classroom-live.js', 'iceServers: [{ urls: "stun:stun.l.google.com:19302" }]'],
      ['Waiting Room & Admission', 'socket/classroom.js, views/teacher/classrooms/live.pug', 'Sự kiện "request-entry", "approve-entry", "reject-entry"'],
    ]
  },

  // ─── HÌNH 2-1 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-1',
    title: 'Biểu đồ Ca sử dụng (Use Case) tổng quát của hệ thống E-Learning LMS',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.2: Đặc tả yêu cầu chức năng và biểu đồ Ca sử dụng tổng quát',
    purpose: 'Cung cấp góc nhìn toàn cảnh về phạm vi chức năng hệ thống, mối tương tác giữa 3 Actor người dùng chính (Giảng viên, Sinh viên, Quản trị viên), 1 Actor hệ thống ngoài (Google Gemini AI) với 12 ca sử dụng cốt lõi.',
    diagramType: 'Biểu đồ Ca sử dụng (Use Case Diagram)',
    nodes: [
      ['ACT1', 'Giảng viên (Teacher)', 'Actor (Hình người)', '#FEF3C7', 'Người dùng tạo lớp, đăng tải bài giảng, tổ chức kiểm tra, giám sát thi và mở lớp học ảo'],
      ['ACT2', 'Sinh viên (Student)', 'Actor (Hình người)', '#DCFCE7', 'Người học tham gia lớp học bằng mã PIN, học bài giảng, làm bài thi online, điểm danh'],
      ['ACT3', 'Quản trị viên (Admin)', 'Actor (Hình người)', '#FEE2E2', 'Quản trị người dùng, duyệt hồ sơ giảng viên, cấu hình thông số, theo dõi audit log'],
      ['ACT4', 'Google Gemini AI', 'Actor hệ thống (Hộp có icon AI)', '#E0E7FF', 'Dịch vụ trí tuệ nhân tạo bên ngoài phân tích tài liệu và sinh bộ câu hỏi trắc nghiệm'],
      ['SYS', 'Hệ thống E-Learning LMS', 'Khung ranh giới hệ thống (System Boundary)', '#FFFFFF', 'Ranh giới bao quanh toàn bộ 12 Use Cases'],
      ['UC1', 'UC01: Đăng nhập & Xác thực bảo mật', 'Hình Oval', '#F1F5F9', 'Xác thực tài khoản qua mật khẩu băm bcrypt hoặc Google/Facebook OAuth2'],
      ['UC2', 'UC02: Quản lý Hồ sơ & Đổi mật khẩu', 'Hình Oval', '#F1F5F9', 'Cập nhật avatar Cloudinary, họ tên, email, đổi mật khẩu'],
      ['UC3', 'UC03: Quản lý Lớp học & Thành viên', 'Hình Oval', '#F1F5F9', 'Tạo lớp, cấp mã mời, quản lý danh sách học sinh, phân nhóm'],
      ['UC4', 'UC04: Quản lý Bài giảng & Tài liệu số', 'Hình Oval', '#F1F5F9', 'Đăng tải video, tài liệu PDF, bài học theo chương mục'],
      ['UC5', 'UC05: Tạo & Quản lý Đề thi trắc nghiệm', 'Hình Oval', '#F1F5F9', 'Thiết lập thời gian làm bài, số lần đổi tab, ma trận đề, ngân hàng câu hỏi'],
      ['UC6', 'UC06: Tự động sinh câu hỏi bằng AI', 'Hình Oval', '#F3E8FF', 'Tải tệp PDF/Docx lên và nhận về danh sách câu hỏi trắc nghiệm tự động'],
      ['UC7', 'UC07: Tham gia Lớp học ảo & Điểm danh', 'Hình Oval', '#F1F5F9', 'Phòng học trực tuyến WebRTC, duyệt phòng chờ, nhận diện điểm danh'],
      ['UC8', 'UC08: Tham gia Thi trực tuyến có giám sát', 'Hình Oval', '#F1F5F9', 'Làm bài thi trên sandbox, phát hiện tab switch, toàn màn hình, tự động nộp'],
      ['UC9', 'UC09: Thảo luận & Tương tác lớp học', 'Hình Oval', '#F1F5F9', 'Đăng câu hỏi thảo luận, bình luận trả lời, thông báo thời gian thực'],
      ['UC10', 'UC10: Quản lý Người dùng & Phân quyền', 'Hình Oval', '#F1F5F9', 'Khóa/Mở tài khoản, phê duyệt giáo viên, chỉ định vai trò Admin/Teacher/Student'],
      ['UC11', 'UC11: Giám sát Hệ thống & Báo cáo KPI', 'Hình Oval', '#F1F5F9', 'Biểu đồ tăng trưởng người dùng, tỷ lệ hoàn thành khóa học, lưu lượng thi'],
      ['UC12', 'UC12: Cấu hình Hệ thống & Nhật ký Audit Log', 'Hình Oval', '#F1F5F9', 'Thiết lập SMTP, giới hạn tải tệp, xem vết nhật ký đăng nhập và hành động'],
    ],
    connections: [
      ['1', 'ACT1 (Giảng viên)', 'UC3 (Quản lý Lớp học)', 'Đường nối liền nét (──)', 'Association (Tạo và quản lý lớp học)', 'Giảng viên sở hữu và quản trị lớp học'],
      ['2', 'ACT1 (Giảng viên)', 'UC4 (Quản lý Bài giảng)', 'Đường nối liền nét (──)', 'Association (Soạn bài giảng)', 'Đăng tài liệu PDF và video bài học'],
      ['3', 'ACT1 (Giảng viên)', 'UC5 (Quản lý Đề thi)', 'Đường nối liền nét (──)', 'Association (Thiết lập bài kiểm tra)', 'Tạo kỳ thi và cài đặt quy chế chống gian lận'],
      ['4', 'ACT1 (Giảng viên)', 'UC7 (Lớp học ảo & Điểm danh)', 'Đường nối liền nét (──)', 'Association (Chủ tọa mở phòng học)', 'Duyệt phòng chờ và phát bài giảng video'],
      ['5', 'ACT1 (Giảng viên)', 'UC9 (Thảo luận & Tương tác)', 'Đường nối liền nét (──)', 'Association (Giải đáp thắc mắc)', 'Tương tác hai chiều với sinh viên'],
      ['6', 'UC5 (Quản lý Đề thi)', 'UC6 (Sinh câu hỏi bằng AI)', 'Mũi tên nét đứt có chữ <<extend>> (⇢)', '<<extend>> (Tùy chọn sinh tự động)', 'Khi tạo đề thi, giảng viên có thể chọn sinh câu hỏi từ tài liệu bằng AI'],
      ['7', 'UC6 (Sinh câu hỏi bằng AI)', 'ACT4 (Google Gemini AI)', 'Đường nối liền nét (──)', 'Association (Gọi REST API)', 'Hệ thống gửi văn bản tài liệu sang Gemini 3.8 Flash để nhận câu hỏi'],
      ['8', 'ACT2 (Sinh viên)', 'UC3 (Quản lý Lớp học)', 'Đường nối liền nét (──)', 'Association (Tham gia bằng mã PIN)', 'Sinh viên nhập mã 6 ký tự để ghi danh vào lớp'],
      ['9', 'ACT2 (Sinh viên)', 'UC4 (Quản lý Bài giảng)', 'Đường nối liền nét (──)', 'Association (Học tập & Tải tài liệu)', 'Xem bài học trực tuyến và tải tài liệu đính kèm'],
      ['10', 'ACT2 (Sinh viên)', 'UC7 (Lớp học ảo & Điểm danh)', 'Đường nối liền nét (──)', 'Association (Vào lớp học & Check-in)', 'Chờ duyệt vào phòng học ảo và điểm danh tự động'],
      ['11', 'ACT2 (Sinh viên)', 'UC8 (Làm bài thi trực tuyến)', 'Đường nối liền nét (──)', 'Association (Làm bài có giám sát)', 'Sinh viên làm bài thi trắc nghiệm, chịu cơ chế giám sát vi phạm'],
      ['12', 'ACT2 (Sinh viên)', 'UC9 (Thảo luận & Tương tác)', 'Đường nối liền nét (──)', 'Association (Đặt câu hỏi / Bình luận)', 'Trao đổi bài học với thầy cô và bạn bè'],
      ['13', 'ACT3 (Quản trị viên)', 'UC10 (Quản lý Người dùng)', 'Đường nối liền nét (──)', 'Association (Kiểm soát tài khoản)', 'Khóa tài khoản vi phạm, duyệt hồ sơ giáo viên'],
      ['14', 'ACT3 (Quản trị viên)', 'UC11 (Giám sát Báo cáo KPI)', 'Đường nối liền nét (──)', 'Association (Theo dõi vận hành)', 'Xem biểu đồ tăng trưởng và sức khỏe hệ thống'],
      ['15', 'ACT3 (Quản trị viên)', 'UC12 (Cấu hình & Audit Log)', 'Đường nối liền nét (──)', 'Association (Thiết lập tham số)', 'Quản lý khóa API, máy chủ email và lịch sử thao tác'],
      ['16', 'Tất cả Use Cases (UC2 -> UC12)', 'UC1 (Đăng nhập & Xác thực)', 'Mũi tên nét đứt có chữ <<include>> (⇢)', '<<include>> (Bắt buộc phải đăng nhập)', 'Mọi tác vụ nghiệp vụ đều yêu cầu người dùng phải xác thực phiên hợp lệ'],
    ],
    textFlow: `[Giảng viên] ──┬──> [UC03: Quản lý Lớp học]
                 ├──> [UC04: Quản lý Bài giảng]
                 ├──> [UC05: Quản lý Đề thi] ──<<extend>>──> [UC06: Sinh đề AI] ──> [Google Gemini AI]
                 ├──> [UC07: Lớp học ảo & Điểm danh]
                 └──> [UC09: Thảo luận & Tương tác]

[Sinh viên]  ──┬──> [UC03: Quản lý Lớp học (Tham gia)]
                 ├──> [UC04: Học bài giảng]
                 ├──> [UC07: Vào học ảo & Điểm danh]
                 ├──> [UC08: Thi trực tuyến có giám sát]
                 └──> [UC09: Thảo luận & Tương tác]

[Quản trị viên] ┬──> [UC10: Quản lý Người dùng]
                 ├──> [UC11: Giám sát Báo cáo KPI]
                 └──> [UC12: Cấu hình Hệ thống & Audit Log]

[Mọi Use Case] ──<<include>>──> [UC01: Đăng nhập & Xác thực bảo mật]`,
    mermaidCode: `graph LR
  Teacher(("Giảng viên"))
  Student(("Sinh viên"))
  Admin(("Quản trị viên"))
  Gemini["Google Gemini AI"]

  subgraph LMS ["Hệ thống E-Learning LMS"]
    UC1(["UC01: Đăng nhập & Xác thực"])
    UC2(["UC02: Quản lý Hồ sơ"])
    UC3(["UC03: Quản lý Lớp học"])
    UC4(["UC04: Quản lý Bài giảng"])
    UC5(["UC05: Quản lý Đề thi"])
    UC6(["UC06: Tự động sinh câu hỏi bằng AI"])
    UC7(["UC07: Lớp học ảo & Điểm danh"])
    UC8(["UC08: Thi trực tuyến có giám sát"])
    UC9(["UC09: Thảo luận lớp học"])
    UC10(["UC10: Quản lý Người dùng"])
    UC11(["UC11: Giám sát Báo cáo KPI"])
    UC12(["UC12: Cấu hình & Audit Log"])
  end

  Teacher --- UC3
  Teacher --- UC4
  Teacher --- UC5
  Teacher --- UC7
  Teacher --- UC9

  Student --- UC3
  Student --- UC4
  Student --- UC7
  Student --- UC8
  Student --- UC9

  Admin --- UC10
  Admin --- UC11
  Admin --- UC12

  UC5 -.->|"<<extend>>"| UC6
  UC6 --- Gemini

  UC3 -.->|"<<include>>"| UC1
  UC5 -.->|"<<include>>"| UC1
  UC7 -.->|"<<include>>"| UC1
  UC8 -.->|"<<include>>"| UC1
  UC10 -.->|"<<include>>"| UC1`,
    codeMapping: [
      ['Giảng viên (ACT1)', 'middleware/auth.js (req.user.role === "teacher")', 'Phân quyền truy cập các route /teacher/*'],
      ['Sinh viên (ACT2)', 'middleware/auth.js (req.user.role === "student")', 'Phân quyền truy cập các route /student/*'],
      ['Quản trị viên (ACT3)', 'middleware/auth.js (req.user.role === "admin")', 'Phân quyền truy cập các route /admin/*'],
      ['Sinh câu hỏi AI (UC6)', 'controller/teacher/aiQuestionGen.controller.js', 'Hàm handleGenerateAI(), handleSaveQuestions()'],
      ['Thi trực tuyến (UC8)', 'controller/student/exam.controller.js, services/examIntegrity.service.js', 'Hàm takeExam(), submitExam(), logViolation()'],
      ['Đăng nhập xác thực (UC1)', 'controller/auth.controller.js, config/passport.js', 'LocalStrategy, GoogleStrategy, bcrypt.compare()'],
    ]
  },

  // ─── HÌNH 2-2 ─────────────────────────────────────────────────────────────
  {
    id: 'Hình 2-2',
    title: 'Biểu đồ Ca sử dụng phân rã phân hệ Giảng viên',
    status: 'ĐÃ TRIỂN KHAI THỰC TẾ',
    chapterLocation: 'Chương 2, Mục 2.3: Đặc tả phân rã chức năng phân hệ Giảng viên (Teacher Subsystem)',
    purpose: 'Chi tiết hóa toàn bộ các hành động, quy trình nghiệp vụ chuyên sâu của người thầy trên LMS: từ quản lý thành viên, biên soạn học liệu, tổ chức thi kiểm tra, sinh đề AI cho đến điều hành lớp học ảo.',
    diagramType: 'Biểu đồ Ca sử dụng phân rã (Subsystem Use Case Diagram)',
    nodes: [
      ['ACT1', 'Giảng viên (Teacher)', 'Actor (Hình người)', '#FEF3C7', 'Chủ thể thực hiện tất cả các thao tác giảng dạy và đánh giá'],
      ['ACT2', 'Google Gemini API', 'Actor hệ thống (Khối AI)', '#E0E7FF', 'Dịch vụ trí tuệ nhân tạo tiếp nhận tài liệu để sinh câu hỏi trắc nghiệm'],
      ['PKG1', 'Gói: Quản lý Lớp học', 'Gói Package UML (Thư mục)', '#F1F5F9', 'Bao gồm các ca sử dụng liên quan đến tổ chức lớp'],
      ['UC_T01', 'Tạo lớp học mới & Cấp mã PIN', 'Hình Oval', '#FFFFFF', 'Sinh mã tham gia 6 ký tự ngẫu nhiên duy nhất'],
      ['UC_T02', 'Duyệt & Quản lý Học sinh', 'Hình Oval', '#FFFFFF', 'Xem danh sách, thêm học sinh trực tiếp, xóa khỏi lớp'],
      ['UC_T03', 'Phân nhóm học tập (Groups)', 'Hình Oval', '#FFFFFF', 'Chia nhóm học sinh để giao đề bài theo nhóm'],
      ['PKG2', 'Gói: Quản lý Giảng dạy & Học liệu', 'Gói Package UML', '#F1F5F9', 'Bao gồm bài giảng, bài tập về nhà và lớp học ảo'],
      ['UC_T04', 'Đăng tải Bài giảng (Video/PDF)', 'Hình Oval', '#FFFFFF', 'Soạn nội dung văn bản, đính kèm file, nhúng video bài giảng'],
      ['UC_T05', 'Giao Bài tập về nhà (Assignment)', 'Hình Oval', '#FFFFFF', 'Quy định hạn nộp (deadline), tiêu chí chấm và file mẫu'],
      ['UC_T06', 'Mở Lớp học ảo (Live Class)', 'Hình Oval', '#FFFFFF', 'Khởi tạo phòng WebRTC, chia sẻ màn hình, phát camera'],
      ['UC_T07', 'Duyệt Học sinh tại Phòng chờ', 'Hình Oval', '#FFFFFF', 'Phê duyệt (Admit) hoặc từ chối (Deny) học sinh vào lớp học ảo'],
      ['UC_T08', 'Xuất Bảng Điểm danh tự động', 'Hình Oval', '#FFFFFF', 'Tổng hợp kết quả điểm danh có minh chứng webcam và giờ vào ra'],
      ['PKG3', 'Gói: Khảo thí & Đề thi AI', 'Gói Package UML', '#F1F5F9', 'Bao gồm ngân hàng câu hỏi, tạo đề và sinh đề tự động'],
      ['UC_T09', 'Tạo Đề thi & Cấu hình Giám sát', 'Hình Oval', '#FFFFFF', 'Cài đặt thời gian, giới hạn đổi tab (tabSwitchLimit), mật khẩu thi'],
      ['UC_T10', 'Soạn Câu hỏi thủ công', 'Hình Oval', '#FFFFFF', 'Nhập từng câu hỏi, 4 đáp án A-B-C-D, chọn đáp án đúng và giải thích'],
      ['UC_T11', 'Tự động sinh câu hỏi từ tài liệu bằng AI', 'Hình Oval', '#F3E8FF', 'Upload tệp PDF/Docx, chọn số lượng câu, độ khó để Gemini sinh'],
      ['UC_T12', 'Xem & Chấm bài tự luận', 'Hình Oval', '#FFFFFF', 'Xem bài nộp tự luận, chấm điểm thang 10 và để lại nhận xét'],
      ['UC_T13', 'Xuất Bảng điểm & Thống kê kỳ thi', 'Hình Oval', '#FFFFFF', 'Xuất file Excel/CSV bảng điểm, biểu đồ phân phối phổ điểm'],
    ],
    connections: [
      ['1', 'ACT1 (Giảng viên)', 'UC_T01 (Tạo lớp & cấp PIN)', 'Đường nối liền nét (──)', 'Thực hiện tạo lớp học', 'Hệ thống lưu Classroom vào MongoDB'],
      ['2', 'ACT1 (Giảng viên)', 'UC_T02 (Duyệt học sinh)', 'Đường nối liền nét (──)', 'Quản lý danh sách học sinh', 'Thêm học sinh từ modal hoặc duyệt mã PIN'],
      ['3', 'ACT1 (Giảng viên)', 'UC_T03 (Phân nhóm)', 'Đường nối liền nét (──)', 'Tổ chức nhóm làm việc', 'Chia nhóm học sinh theo chủ đề'],
      ['4', 'ACT1 (Giảng viên)', 'UC_T04 (Đăng bài giảng)', 'Đường nối liền nét (──)', 'Đăng tải tài liệu học tập', 'Lưu Lecture và upload file Cloudinary'],
      ['5', 'ACT1 (Giảng viên)', 'UC_T05 (Giao bài tập)', 'Đường nối liền nét (──)', 'Tạo assignment', 'Thiết lập hạn nộp và hướng dẫn'],
      ['6', 'ACT1 (Giảng viên)', 'UC_T06 (Mở lớp học ảo)', 'Đường nối liền nét (──)', 'Khởi chạy WebRTC Host', 'Kích hoạt WebSocket room lớp học'],
      ['7', 'UC_T06 (Mở lớp học ảo)', 'UC_T07 (Duyệt phòng chờ)', 'Mũi tên nét đứt có chữ <<include>> (⇢)', '<<include>> (Bắt buộc kiểm duyệt)', 'Học sinh vào lớp phải qua phòng chờ để giáo viên duyệt'],
      ['8', 'UC_T06 (Mở lớp học ảo)', 'UC_T08 (Xuất bảng điểm danh)', 'Mũi tên nét đứt có chữ <<extend>> (⇢)', '<<extend>> (Tùy chọn xuất file)', 'Kết thúc buổi học xuất dữ liệu tham dự ra Excel'],
      ['9', 'ACT1 (Giảng viên)', 'UC_T09 (Tạo đề & cấu hình)', 'Đường nối liền nét (──)', 'Tổ chức kỳ thi', 'Tạo Exam schema với các cờ giám sát'],
      ['10', 'UC_T09 (Tạo đề thi)', 'UC_T10 (Soạn thủ công)', 'Mũi tên nét đứt có chữ <<extend>> (⇢)', '<<extend>> (Nhập tay)', 'Giáo viên tự gõ câu hỏi'],
      ['11', 'UC_T09 (Tạo đề thi)', 'UC_T11 (Sinh câu hỏi bằng AI)', 'Mũi tên nét đứt có chữ <<extend>> (⇢)', '<<extend>> (Sinh tự động)', 'Giáo viên upload tài liệu để AI sinh câu hỏi'],
      ['12', 'UC_T11 (Sinh câu hỏi bằng AI)', 'ACT2 (Google Gemini API)', 'Đường nối liền nét (──)', 'Association (Gửi tài liệu & nhận JSON)', 'Tương tác API Gemini 3.8 Flash qua HTTPS'],
      ['13', 'ACT1 (Giảng viên)', 'UC_T12 (Chấm bài tự luận)', 'Đường nối liền nét (──)', 'Đánh giá bài nộp', 'Chấm điểm và phản hồi nhận xét'],
      ['14', 'ACT1 (Giảng viên)', 'UC_T13 (Xuất bảng điểm)', 'Đường nối liền nét (──)', 'Báo cáo thống kê', 'Xuất file CSV/Excel điểm số toàn lớp'],
    ],
    textFlow: `[Giảng viên]
  ├──> [Quản lý Lớp học]: Tạo lớp & Cấp PIN ── Duyệt học sinh ── Phân nhóm
  ├──> [Học liệu & Trực tuyến]: Đăng bài giảng ── Giao bài tập ── Mở lớp học ảo (Live)
  │                                                                    ├──<<include>>──> Duyệt phòng chờ
  │                                                                    └──<<extend>>───> Xuất điểm danh
  └──> [Khảo thí & Đề thi]: Tạo đề thi & Cấu hình giám sát
                                ├──<<extend>>──> Soạn câu hỏi thủ công
                                ├──<<extend>>──> Sinh câu hỏi bằng AI ──> [Google Gemini API]
                                ├── Chấm bài tự luận
                                └── Xuất bảng điểm kỳ thi`,
    mermaidCode: `graph TD
  Teacher(("Giảng viên"))
  Gemini["Google Gemini API"]

  subgraph ClassPkg ["Phân hệ Quản lý Lớp học"]
    UC_T01(["Tạo lớp học & Cấp mã PIN"])
    UC_T02(["Duyệt & Quản lý học sinh"])
    UC_T03(["Phân nhóm học tập"])
  end

  subgraph TeachPkg ["Phân hệ Giảng dạy & Trực tuyến"]
    UC_T04(["Đăng bài giảng (Video/PDF)"])
    UC_T05(["Giao bài tập về nhà"])
    UC_T06(["Mở lớp học ảo (Live Class)"])
    UC_T07(["Duyệt học sinh phòng chờ"])
    UC_T08(["Xuất bảng điểm danh"])
  end

  subgraph ExamPkg ["Phân hệ Khảo thí & Đề thi"]
    UC_T09(["Tạo đề thi & Cài đặt giám sát"])
    UC_T10(["Soạn câu hỏi thủ công"])
    UC_T11(["Sinh câu hỏi từ tài liệu bằng AI"])
    UC_T12(["Chấm bài tự luận"])
    UC_T13(["Xuất bảng điểm & Thống kê"])
  end

  Teacher --- UC_T01
  Teacher --- UC_T02
  Teacher --- UC_T03
  Teacher --- UC_T04
  Teacher --- UC_T05
  Teacher --- UC_T06
  UC_T06 -.->|"<<include>>"| UC_T07
  UC_T06 -.->|"<<extend>>"| UC_T08

  Teacher --- UC_T09
  UC_T09 -.->|"<<extend>>"| UC_T10
  UC_T09 -.->|"<<extend>>"| UC_T11
  UC_T11 --- Gemini
  Teacher --- UC_T12
  Teacher --- UC_T13`,
    codeMapping: [
      ['Quản lý lớp học', 'controller/teacher/classroom.controller.js', 'createClassroom(), addMember(), removeMember()'],
      ['Bài giảng & Học liệu', 'controller/teacher/lecture.controller.js', 'createLecture(), uploadMaterial()'],
      ['Lớp học ảo & Điểm danh', 'socket/classroom.js, controller/teacher/attendance.controller.js', 'handleLiveClass(), exportAttendance()'],
      ['Tạo đề thi & Giám sát', 'controller/teacher/exam.controller.js', 'createExam(), updateExamSettings()'],
      ['Tự động sinh câu hỏi AI', 'controller/teacher/aiQuestionGen.controller.js, services/aiQuestionGen.service.js', 'handleGenerateAI(), generateQuestionsFromText()'],
      ['Chấm bài & Điểm số', 'controller/teacher/exam.controller.js, services/gradebook.service.js', 'gradeSubmission(), exportGradebook()'],
    ]
  }
];
