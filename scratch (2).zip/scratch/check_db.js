const mongoose = require('mongoose');
const QuestionBank = require('../models/QuestionBank');
const Question = require('../models/Question');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

async function run() {
  await mongoose.connect(process.env.MONGO_URL);
  console.log('Connected to DB');
  
  const qbs = await QuestionBank.find({});
  console.log('QuestionBank documents:');
  console.log(JSON.stringify(qbs, null, 2));

  const qs = await Question.find({});
  console.log('Question documents:');
  console.log(JSON.stringify(qs, null, 2));

  process.exit(0);
}

run();
