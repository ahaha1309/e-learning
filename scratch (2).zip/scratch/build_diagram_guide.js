/**
 * Script xây dựng tài liệu Hướng dẫn tự vẽ và tái tạo toàn bộ biểu đồ
 * với định dạng A -> B cực kỳ chi tiết, rõ ràng từng mũi tên, nhãn và mã Mermaid/PlantUML.
 */
const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel,
  AlignmentType, PageBreak, ShadingType, Table, TableRow, TableCell,
  WidthType, BorderStyle
} = require('docx');

console.log('Khởi động script tạo tài liệu hướng dẫn vẽ biểu đồ chi tiết...');
