/**
 * Script xây dựng tài liệu Word: HƯỚNG DẪN TỰ VẼ VÀ TÁI TẠO TOÀN BỘ 15 BIỂU ĐỒ BÁO CÁO ĐỒ ÁN
 * Với đặc tả chi tiết từng mũi tên A -> B, nhãn text, kiểu đường nối, mã Mermaid và Code Mapping.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel,
  AlignmentType, PageBreak, ShadingType, Table, TableRow, TableCell,
  WidthType, BorderStyle
} = require('docx');

// ─── STYLES & HELPERS ────────────────────────────────────────────────────────
const COLOR_PRIMARY = '1E3A8A'; // Navy Blue
const COLOR_SECONDARY = '0D9488'; // Teal
const COLOR_TEXT = '1F2937'; // Slate 800
const COLOR_MUTED = '4B5563'; // Slate 600
const COLOR_BG_LIGHT = 'F8FAFC'; // Slate 50
const COLOR_BORDER = 'CBD5E1'; // Slate 300
const COLOR_HEADER_BG = '1E3A8A';
const COLOR_CALLOUT_BG = 'EFF6FF'; // Light blue

const tableBorder = {
  top: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
  bottom: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
  left: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
  right: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
  insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: 'E2E8F0' },
  insideVertical: { style: BorderStyle.SINGLE, size: 2, color: 'E2E8F0' },
};

function titleDoc(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun({
        text,
        bold: true,
        size: 32, // 16pt
        color: COLOR_PRIMARY,
        font: 'Times New Roman',
      }),
    ],
    spacing: { before: 200, after: 120 },
  });
}

function subTitleDoc(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun({
        text,
        italics: true,
        size: 24, // 12pt
        color: COLOR_MUTED,
        font: 'Times New Roman',
      }),
    ],
    spacing: { after: 280 },
  });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [
      new TextRun({
        text,
        bold: true,
        size: 28, // 14pt
        color: COLOR_PRIMARY,
        font: 'Times New Roman',
      }),
    ],
    spacing: { before: 400, after: 180 },
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [
      new TextRun({
        text,
        bold: true,
        size: 26, // 13pt
        color: COLOR_PRIMARY,
        font: 'Times New Roman',
      }),
    ],
    spacing: { before: 320, after: 140 },
  });
}

function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    children: [
      new TextRun({
        text,
        bold: true,
        size: 24, // 12pt
        color: COLOR_SECONDARY,
        font: 'Times New Roman',
      }),
    ],
    spacing: { before: 220, after: 100 },
  });
}

function p(text, opts = {}) {
  return new Paragraph({
    children: [
      new TextRun({
        text,
        size: 22, // 11pt
        color: opts.color || COLOR_TEXT,
        bold: opts.bold || false,
        italics: opts.italics || false,
        font: opts.font || 'Times New Roman',
      }),
    ],
    alignment: opts.align || AlignmentType.LEFT,
    spacing: { after: opts.spacingAfter !== undefined ? opts.spacingAfter : 100 },
    indent: opts.indent ? { left: opts.indent } : undefined,
  });
}

function callout(title, lines) {
  const paras = [];
  paras.push(
    new Paragraph({
      children: [
        new TextRun({
          text: title,
          bold: true,
          size: 22,
          color: COLOR_PRIMARY,
          font: 'Times New Roman',
        }),
      ],
      spacing: { after: 60 },
    })
  );
  lines.forEach((l) => {
    paras.push(
      new Paragraph({
        children: [
          new TextRun({
            text: l,
            size: 21,
            color: COLOR_TEXT,
            font: 'Times New Roman',
          }),
        ],
        spacing: { after: 40 },
      })
    );
  });

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE },
      bottom: { style: BorderStyle.NONE },
      right: { style: BorderStyle.NONE },
      left: { style: BorderStyle.SINGLE, size: 24, color: COLOR_PRIMARY },
      insideHorizontal: { style: BorderStyle.NONE },
      insideVertical: { style: BorderStyle.NONE },
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            children: paras,
            shading: { type: ShadingType.SOLID, color: COLOR_CALLOUT_BG },
            margins: { top: 120, bottom: 120, left: 160, right: 160 },
          }),
        ],
      }),
    ],
  });
}

function codeBlock(codeText) {
  const lines = codeText.trim().split('\n');
  const paras = lines.map(
    (line) =>
      new Paragraph({
        children: [
          new TextRun({
            text: line,
            size: 18, // 9pt
            font: 'Consolas',
            color: '1E293B',
          }),
        ],
        spacing: { after: 20 },
      })
  );

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: tableBorder,
    rows: [
      new TableRow({
        children: [
          new TableCell({
            children: paras,
            shading: { type: ShadingType.SOLID, color: 'F1F5F9' },
            margins: { top: 100, bottom: 100, left: 140, right: 140 },
          }),
        ],
      }),
    ],
  });
}

function createTable(headers, rowsData, colWidths = []) {
  const headerRow = new TableRow({
    isHeader: true,
    children: headers.map((h, i) => {
      const cellOpts = {
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: h,
                bold: true,
                size: 20, // 10pt
                color: 'FFFFFF',
                font: 'Times New Roman',
              }),
            ],
            spacing: { before: 60, after: 60 },
          }),
        ],
        shading: { type: ShadingType.SOLID, color: COLOR_HEADER_BG },
        margins: { top: 80, bottom: 80, left: 100, right: 100 },
      };
      if (colWidths[i]) {
        cellOpts.width = { size: colWidths[i], type: WidthType.PERCENTAGE };
      }
      return new TableCell(cellOpts);
    }),
  });

  const bodyRows = rowsData.map((row, rIdx) => {
    const isAlt = rIdx % 2 === 1;
    return new TableRow({
      children: row.map((cellText, cIdx) => {
        const cellOpts = {
          children: [
            new Paragraph({
              alignment: cIdx === 0 || cIdx === 1 ? AlignmentType.CENTER : AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: String(cellText),
                  size: 19, // 9.5pt
                  color: COLOR_TEXT,
                  font: 'Times New Roman',
                }),
              ],
              spacing: { before: 40, after: 40 },
            }),
          ],
          shading: {
            type: ShadingType.SOLID,
            color: isAlt ? COLOR_BG_LIGHT : 'FFFFFF',
          },
          margins: { top: 60, bottom: 60, left: 90, right: 90 },
        };
        if (colWidths[cIdx]) {
          cellOpts.width = { size: colWidths[cIdx], type: WidthType.PERCENTAGE };
        }
        return new TableCell(cellOpts);
      }),
    });
  });

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: tableBorder,
    rows: [headerRow, ...bodyRows],
  });
}

module.exports = {
  Document, Packer, Paragraph, TextRun, HeadingLevel,
  AlignmentType, PageBreak, ShadingType, Table, TableRow, TableCell,
  WidthType, BorderStyle,
  titleDoc, subTitleDoc, h1, h2, h3, p, callout, codeBlock, createTable
};
