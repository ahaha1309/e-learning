const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

const modelsDir = path.join(__dirname, '../models');
const files = fs.readdirSync(modelsDir).filter(f => f.endsWith('.js'));

const schemas = {};

for (const file of files) {
  try {
    const model = require(path.join(modelsDir, file));
    if (model && model.schema) {
      const paths = model.schema.paths;
      const schemaStruct = {};
      
      for (const [pathName, schemaType] of Object.entries(paths)) {
        if (pathName === '__v') continue;
        
        let typeStr = schemaType.instance;
        let ref = null;
        let isArray = false;
        let required = !!(schemaType.options && schemaType.options.required);
        let index = !!(schemaType._index);
        
        if (schemaType.instance === 'Array') {
          isArray = true;
          if (schemaType.caster) {
            typeStr = `[${schemaType.caster.instance}]`;
            if (schemaType.caster.options && schemaType.caster.options.ref) {
              ref = schemaType.caster.options.ref;
            }
          }
        } else if (schemaType.options && schemaType.options.ref) {
          ref = schemaType.options.ref;
        }

        schemaStruct[pathName] = {
          type: typeStr,
          ref: ref,
          required: required,
          index: index,
        };
      }
      schemas[model.modelName] = schemaStruct;
    }
  } catch (err) {
    console.error(`Error loading ${file}:`, err.message);
  }
}

fs.writeFileSync(path.join(__dirname, '../schema_map.json'), JSON.stringify(schemas, null, 2));
console.log('Schema map saved to schema_map.json');
