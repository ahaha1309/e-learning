# Generates 08_Code_Walkthrough_Full.docx
# Reads SOURCE CODE and renders full business-flow walkthroughs with high-detail CODE BLOCKS.
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT_PATH = r"C:\Users\vanha\Downloads\Documentations_DOCX\08_Code_Walkthrough_Full.docx"

def new_doc():
    doc = Document()
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    return doc

def h(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    if p.runs:
        run = p.runs[0]
        run.font.name = 'Calibri'
        colors = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
                  3: RGBColor(0x1A,0x6A,0x1A), 4: RGBColor(0x66,0x33,0x00)}
        run.font.color.rgb = colors.get(level, RGBColor(0,0,0))
        sizes  = {1: 16, 2: 14, 3: 12, 4: 11}
        run.font.size = Pt(sizes.get(level, 11))
    return p

def code_block(doc, code_text):
    for line in code_text.split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent   = Inches(0.35)
        p.paragraph_format.space_before  = Pt(0)
        p.paragraph_format.space_after   = Pt(0)
        r = p.add_run(line if line.strip() else ' ')
        r.font.name  = 'Courier New'
        r.font.size  = Pt(9)
        r.font.color.rgb = RGBColor(0x17,0x5E,0x24)
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'),   'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'),  'F2F2F2')
        p._p.get_or_add_pPr().append(shd)

def explain_text(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after  = Pt(8)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)
    return p

def divider(doc):
    p = doc.add_paragraph('─' * 90)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after  = Pt(6)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0xAA,0xAA,0xAA)
        r.font.size = Pt(8)

doc = new_doc()

# ── TITLE PAGE ──
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run("08. CODE WALKTHROUGH (CHI TIẾT MÃ NGUỒN)\nE-Learning LMS – Node.js / Express / MongoDB")
r.font.name = 'Calibri'; r.font.size = Pt(22); r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)
explain_text(doc, "Tài liệu này trace trực tiếp TỪNG DÒNG CODE xuyên qua các layer (Route → Middleware → Controller → Service → Model) của các luồng nghiệp vụ cốt lõi nhất dự án.")
divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 1: ĐĂNG NHẬP & BẢO MẬT PHIÊN LÀM VIỆC", 1)
explain_text(doc, "Luồng xử lý khi người dùng (Học sinh/Giáo viên) nhập Email và Mật khẩu để lấy JWT Token và lưu vào Cookie HttpOnly bảo mật.")

h(doc, "Bước 1.1: Định tuyến và Middleware (routes/auth.js)", 2)
code_block(doc, '''router.post(
  '/login',
  loginRateLimit,
  csrfProtection,
  loginValidator,
  authController.login
);''')
explain_text(doc, "Request POST /login sẽ đi qua 4 tầng: 1) Rate Limit (chống spam/brute force mật khẩu, giới hạn 10 requests/15 phút). 2) CSRF Protection (đọc _csrf token từ form để chống tấn công giả mạo). 3) Validator (kiểm tra định dạng email hợp lệ). 4) Cuối cùng vào authController.login.")

h(doc, "Bước 1.2: Controller xử lý luồng chính (controller/auth/auth.controller.js)", 2)
code_block(doc, '''async function login(req, res, next) {
  const errors = getValidationErrors(req);
  if (errors.length > 0) return res.render('auth/login', { errors });

  const { email, password } = req.body;
  const { user, accessToken, refreshToken } = await authService.authenticateUser(email, password);

  // Set HTTP-only Cookies
  res.cookie('accessToken', accessToken, { httpOnly: true, secure: true, maxAge: 15 * 60 * 1000 });
  res.cookie('refreshToken', refreshToken, { httpOnly: true, secure: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
  
  // Bảo vệ session fixation
  req.session.regenerate(() => {
    req.logIn(user, () => {
      res.redirect(user.role === 'teacher' ? '/teacher' : '/student');
    });
  });
}''')
explain_text(doc, "Nếu không có lỗi validate, lấy email/password. Gọi Service để lấy thông tin. Nhận về accessToken (15 phút) và refreshToken (7 ngày) -> set vào cookie với HttpOnly=true (chống XSS đánh cắp token) và secure=true (chỉ truyền qua HTTPS). Đặc biệt: req.session.regenerate() tạo session ID mới ngay sau khi login thành công để chống Session Fixation (chiếm quyền session).")

h(doc, "Bước 1.3: Service truy vấn Database và sinh Token (controller/auth/auth.service.js)", 2)
code_block(doc, '''async function authenticateUser(email, password) {
  const user = await User.findOne({ email }).select('+passwordHash');
  if (!user) throw new AppError(401, 'Invalid credentials');
  
  const isMatch = await bcrypt.compare(password, user.passwordHash);
  if (!isMatch) throw new AppError(401, 'Invalid credentials');

  const accessToken = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '15m' });
  const refreshToken = jwt.sign({ id: user._id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });

  user.refreshToken = refreshToken; // Rotation logic in DB
  await user.save();
  return { user, accessToken, refreshToken };
}''')
explain_text(doc, "Truy vấn MongoDB lấy user (do model default ẩn passwordHash, phải dùng .select('+passwordHash') để ép Mongoose trả về field này). Dùng bcrypt so sánh mật khẩu hash một chiều. Sinh 2 Token (Access/Refresh) bằng jsonwebtoken. Lưu Refresh Token mới nhất vào Database để cấp quyền thu hồi (revoke) khi cần thiết.")

divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 2: THUẬT TOÁN TÍNH TIẾN ĐỘ KHÓA HỌC (COMPUTE PROGRESS ENGINE)", 1)
explain_text(doc, "Logic phức tạp nhất để sinh ra 'Syllabus Tree' (Cây bài giảng) cho học sinh, đánh dấu bài nào đã học (Completed), bài nào đang học (In Progress), và bài nào bị khoá do chưa học bài trước đó (Locked).")

h(doc, "Bước 2.1: Controller kích hoạt (controller/student/classroom.controller.js)", 2)
code_block(doc, '''async function renderStudentClassroomDetail(req, res, next) {
  const member = await ClassroomMember.findOne({ classroom: req.params.id, student: req.user.id });
  if (!member || member.status !== 'approved') return res.status(403).send('Not allowed');

  const progressTree = await courseProgressService.computeCourseProgress(member.classroom, req.user.id);
  res.render('student/classrooms/show', { progressTree });
}''')
explain_text(doc, "Controller chỉ đóng vai trò phân luồng. Check học sinh đã được duyệt vào lớp chưa, rồi đẩy 100% logic tính toán cho Service lấy progressTree trả về View (Pug).")

h(doc, "Bước 2.2: Lấy dữ liệu và gộp (services/courseProgress.service.js)", 2)
code_block(doc, '''async function computeCourseProgress(classroomId, studentId) {
  // Lấy TOÀN BỘ tài liệu học tập của lớp trong 1 lần
  const [lectures, assignments, exams] = await Promise.all([
    Lecture.find({ classroom: classroomId, isPublished: true }),
    Assignment.find({ classroom: classroomId, isPublished: true }),
    Exam.find({ classroom: classroomId, isPublished: true })
  ]);
  
  // Lấy lịch sử hoàn thành của học sinh
  const completedRecords = await StudentProgress.find({ classroom: classroomId, student: studentId });
  const completedKeys = new Set(completedRecords.map(r => `${r.itemType}:${r.itemId}`));
  
  // Trộn và sort chung theo chapterTitle / moduleKey và orderIndex
  let allItems = normalizeAndSortItems(lectures, assignments, exams);
  return resolvePrerequisites(allItems, completedKeys);
}''')
explain_text(doc, "Hiệu suất cao: Dùng Promise.all() để query 3 bảng Lecture, Assignment, Exam cùng 1 lúc thay vì tuần tự. Map kết quả lịch sử học tập (StudentProgress) thành dạng Set (Bảng Băm) để kiểm tra O(1) xem bài học đã hoàn thành chưa.")

h(doc, "Bước 2.3: Giải quyết Prerequisite & Locking (resolvePrerequisites)", 2)
code_block(doc, '''function resolvePrerequisites(allItems, completedKeys) {
  let hasFoundInProgress = false; // Flag chặn các bài tiếp theo

  for (let i = 0; i < allItems.length; i++) {
    const item = allItems[i];
    const isCompleted = completedKeys.has(`${item.type}:${item.id}`);

    if (isCompleted) {
      item.status = 'COMPLETED';
    } else if (!hasFoundInProgress) {
      item.status = 'IN_PROGRESS';
      hasFoundInProgress = true; // Chuyển chốt khoá
    } else {
      item.status = 'LOCKED'; // Tất cả bài sau bài đang học đều bị khoá
    }
  }
  return groupByModule(allItems);
}''')
explain_text(doc, "Hệ thống duyệt mảng học liệu ĐÃ SORT theo thứ tự từ trên xuống dưới. Thuật toán Waterfall: nếu bài hiện tại chưa học (!isCompleted), đánh dấu IN_PROGRESS, và từ đó về sau (hasFoundInProgress = true), TẤT CẢ các bài học tiếp theo sẽ bị đánh dấu LOCKED (Khoá cứng, không click vào được trên UI).")

divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 3: THI TRẮC NGHIỆM GIÁM SÁT & AUTO-SUBMIT (EXAM ENGINE)", 1)
explain_text(doc, "Luồng sinh đề thi, trộn đáp án, cấp thời gian, và tự động nộp bài khi server tính toán quá hạn.")

h(doc, "Bước 3.1: Mở bài thi và xáo trộn (controller/student/exam.controller.js)", 2)
code_block(doc, '''async function renderTakeExam(req, res, next) {
  // 1. Giới hạn số lượt làm bài
  const usedAttempts = await ExamSubmission.countDocuments({ exam: examId, student: studentId });
  if (usedAttempts >= exam.maxAttempts && exam.maxAttempts > 0) return res.redirect('/result');

  // 2. Tìm session in_progress hoặc tạo mới với cửa sổ thời gian
  let submission = await ExamSubmission.findOne({ exam: examId, status: 'in_progress' });
  if (!submission) {
    const deadlineAt = exam.duration ? new Date(Date.now() + exam.duration * 60000) : null;
    submission = await ExamSubmission.create({ exam: examId, student: studentId, status: 'in_progress', deadlineAt, attemptNumber: usedAttempts + 1 });
  }

  // 3. Shuffle câu hỏi
  let questions = await Question.find({ exam: examId });
  if (exam.shuffle) {
    questions = shuffleArray(questions);
    questions.forEach(q => q.options = shuffleArray(q.options));
  }
  res.render('take-exam', { questions, deadlineAt: submission.deadlineAt });
}''')
explain_text(doc, "Bảo mật Server-side: Số lần thử (attempt) và Thời gian kết thúc (deadlineAt) được lưu CỨNG trong Database, trình duyệt (Client JS) không thể gian lận bằng cách chỉnh đồng hồ. Thuật toán xáo trộn Fisher-Yates (shuffleArray) đảm bảo mỗi học sinh có thứ tự câu hỏi và đáp án khác nhau để chống chép bài.")

h(doc, "Bước 3.2: Nộp bài, chấm điểm và phạt quá giờ (submitExamHandler)", 2)
code_block(doc, '''async function submitExamHandler(req, res, next) {
  const submission = await ExamSubmission.findById(req.body.submissionId);
  const correctQuestions = await Question.find({ exam: exam.id });

  let totalScore = 0;
  for (let q of correctQuestions) {
    const studentAnswers = req.body[`q_${q._id}`]; 
    if (studentAnswers && arraysEqual(studentAnswers, q.correctOptions)) {
      totalScore += q.points;
    }
  }

  // Chặn nộp muộn gắt gao trên server
  const now = new Date();
  const GRACE_PERIOD_MS = 30000; // 30 giây độ trễ mạng
  if (submission.deadlineAt && now.getTime() > submission.deadlineAt.getTime() + GRACE_PERIOD_MS) {
    submission.status = 'late';
  } else {
    submission.status = 'submitted';
  }

  submission.score = totalScore;
  await submission.save();
}''')
explain_text(doc, "Việc chấm điểm được vòng lặp so sánh array (arraysEqual) đáp án học sinh và đáp án DB. Quan trọng nhất: Check deadline hoàn toàn dựa vào đồng hồ Backend (now.getTime() > deadlineAt). Cho phép mạng chậm 30s (Grace period). Nếu quá thời gian, đánh dấu trạng thái 'late' thay vì 'submitted'.")

h(doc, "Bước 3.3: Socket.IO Anti-cheat Server (index.js)", 2)
code_block(doc, '''const examMonitor = io.of('/exam-monitor');
examMonitor.on('connection', (socket) => {
  socket.on('cheat-violation', async (data) => {
    // Client báo cáo: người dùng chuyển tab (blur) hoặc thoát fullscreen
    const submission = await ExamSubmission.findOne({ _id: data.submissionId });
    if (submission) {
       submission.violations.push({ type: data.type, time: new Date() });
       await submission.save();
       // Phát tín hiệu về màn hình của Giáo viên đang theo dõi
       examMonitor.to(submission.exam).emit('student-violation', { studentId: socket.userId, type: data.type });
    }
  });
});''')
explain_text(doc, "Gian lận (Violation) KHÔNG được gửi qua đường API POST thông thường lúc nộp bài (vì HS có thể can thiệp xoá payload). Thay vào đó, WebSocket Client gửi ngay lập tức realtime khi xảy ra vi phạm. Giáo viên ngồi mở trang Dashboard có thể thấy ngay HS nào vừa thoát tab.")

# ── SAVE ──
os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
doc.save(OUT_PATH)
print(f"SUCCESS: {OUT_PATH}")
