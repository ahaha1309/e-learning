"""
03_Backend_Code_Explanation_Full_v3.docx
Format chuẩn: Code trích nguyên văn → giải thích chi tiết ngay bên dưới,
theo từng phần đánh số dòng, giống mẫu admin/classroom.controller.js.
"""
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = r"C:\Users\vanha\Downloads\Documentations_DOCX\03_Backend_Code_Explanation_Full.docx"

# ══════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ══════════════════════════════════════════════════════
def new_doc():
    doc = Document()
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    return doc

def heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    if p.runs:
        r = p.runs[0]
        r.font.name = 'Calibri'
        clr = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
               3: RGBColor(0x1A,0x6A,0x1A), 4: RGBColor(0x66,0x33,0x00)}
        r.font.color.rgb = clr.get(level, RGBColor(0,0,0))
        sz = {1:16, 2:13, 3:11, 4:10}
        r.font.size = Pt(sz.get(level, 11))
    return p

def code_block(doc, code_text):
    """Khối code màu xanh lá, nền xám nhạt — giống code fence."""
    for line in code_text.split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent   = Inches(0.35)
        p.paragraph_format.space_before  = Pt(0)
        p.paragraph_format.space_after   = Pt(0)
        r = p.add_run(line if line.strip() else ' ')
        r.font.name  = 'Courier New'
        r.font.size  = Pt(9)
        r.font.color.rgb = RGBColor(0x17,0x5E,0x24)
        # nền xám nhạt
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'),   'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'),  'F2F2F2')
        p._p.get_or_add_pPr().append(shd)

def explain_text(doc, text):
    """Đoạn giải thích thường bên dưới code block."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after  = Pt(8)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)
    return p

def bullet(doc, text, level=0):
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.left_indent = Inches(0.5 + level*0.3)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after  = Pt(2)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)

def meta_label(doc, label, value):
    """Dòng nhỏ kiểu 'Gọi từ đâu: ...' hoặc 'Route: ...'"""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after  = Pt(4)
    rb = p.add_run(f'{label}: ')
    rb.bold = True
    rb.font.name = 'Calibri'
    rb.font.size = Pt(10.5)
    rv = p.add_run(value)
    rv.font.name = 'Calibri'
    rv.font.size = Pt(10.5)
    rv.font.color.rgb = RGBColor(0x00,0x55,0x99)

def divider(doc):
    p = doc.add_paragraph('─' * 90)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after  = Pt(6)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0xAA,0xAA,0xAA)
        r.font.size = Pt(8)

def page_break(doc):
    doc.add_page_break()

def note_box(doc, text):
    p = doc.add_paragraph()
    r = p.add_run(f'📌 Lưu ý: {text}')
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)
    r.font.color.rgb = RGBColor(0xCC,0x66,0x00)
    r.bold = True

# ══════════════════════════════════════════════════════
# BUILD DOCUMENT
# ══════════════════════════════════════════════════════
doc = new_doc()

# ──── TITLE ────────────────────────────────────────────
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run('03. GIẢI THÍCH CODE BACKEND TOÀN BỘ\nE-Learning LMS — Node.js / Express / MongoDB')
r.font.name = 'Calibri'; r.font.size = Pt(20); r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)
explain_text(doc, 'Mỗi file được đọc thực tế từ source code. Code được trích nguyên văn, giải thích từng dòng/cụm một cách chính xác.')
divider(doc)
page_break(doc)

# ══════════════════════════════════════════════════════════════════════════════
# CHƯƠNG 1 — MODELS
# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 1 — MODELS (Định nghĩa cấu trúc dữ liệu MongoDB)', 1)
explain_text(doc, 'Mỗi Model = 1 Collection trong MongoDB. Schema định nghĩa fields, kiểu dữ liệu, ràng buộc và hook tự động. Không chứa business logic — chỉ mô tả hình dạng dữ liệu.')

# ──────────────────────────────────────────────────────
heading(doc, '1.1  models/User.js', 2)
explain_text(doc, 'Collection: users — Lưu toàn bộ tài khoản (admin / teacher / student). Đây là model trung tâm nhất vì mọi model khác đều reference đến User.')

heading(doc, 'Phần 1 — Import và Khai báo Schema (Dòng 1–6)', 3)
code_block(doc, '''const bcrypt = require('bcrypt');
const crypto = require('crypto');
const mongoose = require('mongoose');
const { Schema } = mongoose;''')
explain_text(doc, 'bcrypt: thư viện hash mật khẩu (không thể đảo ngược). crypto: built-in Node.js dùng để hash refresh token bằng SHA-256. mongoose: ODM kết nối MongoDB. Schema là class để định nghĩa cấu trúc document.')

heading(doc, 'Phần 2 — Field passwordHash (Dòng 23–27)', 3)
code_block(doc, '''passwordHash: {
  type: String,
  select: false,
  default: null,
},''')
explain_text(doc, '''"select: false" có nghĩa là khi bạn gọi User.find() hay User.findOne() thì MongoDB sẽ KHÔNG tự động trả về field này. Muốn lấy passwordHash phải chủ động thêm .select("+passwordHash"). Đây là biện pháp bảo mật quan trọng: không bao giờ vô tình trả hash mật khẩu về frontend hay log ra console.''')

heading(doc, 'Phần 3 — Field role (Dòng 28–33)', 3)
code_block(doc, '''role: {
  type: String,
  enum: ['admin', 'teacher', 'student'],
  default: 'student',
  required: true,
},''')
explain_text(doc, 'enum giới hạn chỉ 3 giá trị hợp lệ. Nếu code cố set role="superuser" → Mongoose throw ValidationError trước khi ghi vào DB. default="student" vì đó là loại tài khoản phổ biến nhất khi đăng ký.')

heading(doc, 'Phần 4 — Field status với dynamic default (Dòng 34–40)', 3)
code_block(doc, '''status: {
  type: String,
  enum: ['pending', 'active', 'rejected'],
  default: function setDefaultStatus() {
    return this.role === 'teacher' ? 'pending' : 'active';
  },
},''')
explain_text(doc, 'Dùng hàm thay vì giá trị cố định để tham chiếu "this" (document đang được tạo). Logic: teacher mới đăng ký phải chờ admin duyệt (pending), còn student tự động active ngay. Nếu dùng default:"active" thì teacher cũng active — sai logic.')

heading(doc, 'Phần 5 — Field refreshTokenHash (Dòng 64–68)', 3)
code_block(doc, '''refreshTokenHash: {
  type: String,
  select: false,
  default: null,
},''')
explain_text(doc, 'KHÔNG lưu refresh token trực tiếp vào DB. Lưu SHA-256 hash của nó. Lý do: nếu DB bị hack và attacker lấy được hash này, họ vẫn không thể dùng hash đó làm refresh token thật (hash một chiều). Giống cách bcrypt bảo vệ password.')

heading(doc, 'Phần 6 — Instance Method: setPassword (Dòng 84–87)', 3)
meta_label(doc, 'Gọi từ đâu', 'auth.service.js::registerUser() và profile.service.js::changePassword()')
code_block(doc, '''userSchema.methods.setPassword = async function setPassword(password) {
  this.passwordHash = await bcrypt.hash(password, 12);
  this.passwordChangedAt = new Date();
};''')
explain_text(doc, 'bcrypt.hash(password, 12): số 12 là salt rounds = 2^12 = 4096 vòng lặp hash. Càng cao càng chậm và càng khó brute-force. Sau khi hash xong, cập nhật passwordChangedAt để có thể vô hiệu hóa JWT cũ (tính năng nâng cao). Hàm này được gắn lên từng User document như một method.')

heading(doc, 'Phần 7 — Instance Method: comparePassword (Dòng 89–95)', 3)
meta_label(doc, 'Gọi từ đâu', 'auth.service.js::authenticateUser() và profile.service.js::changePassword()')
code_block(doc, '''userSchema.methods.comparePassword = function comparePassword(password) {
  if (!this.passwordHash) {
    return false;
  }
  return bcrypt.compare(password, this.passwordHash);
};''')
explain_text(doc, 'bcrypt.compare so sánh plaintext password với hash đã lưu — không cần giải mã. Guard "if (!this.passwordHash) return false" xử lý tài khoản OAuth (Google/Facebook login): họ không có password, trả false thay vì crash. bcrypt.compare trả về Promise<boolean>.')

heading(doc, 'Phần 8 — Instance Methods: setRefreshToken và matchesRefreshToken (Dòng 97–104)', 3)
code_block(doc, '''userSchema.methods.setRefreshToken = function setRefreshToken(token) {
  this.refreshTokenHash = crypto.createHash('sha256').update(token).digest('hex');
};

userSchema.methods.matchesRefreshToken = function matchesRefreshToken(token) {
  const incomingHash = crypto.createHash('sha256').update(token).digest('hex');
  return this.refreshTokenHash === incomingHash;
};''')
explain_text(doc, 'setRefreshToken: hash token bằng SHA-256 rồi lưu. matchesRefreshToken: khi validate, hash lại token đến và so sánh với hash đã lưu. Nếu khớp → token hợp lệ. Không cần giải mã, hoàn toàn one-way.')

heading(doc, 'Phần 9 — toJSON Transform (Dòng 114–120)', 3)
code_block(doc, '''userSchema.set('toJSON', {
  transform(doc, ret) {
    delete ret.passwordHash;
    delete ret.refreshTokenHash;
    return ret;
  },
});''')
explain_text(doc, 'Khi document bị JSON.stringify (res.json(user), hoặc truyền vào Pug view), transform chạy tự động và xóa passwordHash + refreshTokenHash. An toàn tuyệt đối: dù developer quên không lọc, 2 field nhạy cảm này không bao giờ lộ ra ngoài.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.2  models/Classroom.js', 2)
explain_text(doc, 'Collection: classrooms — Lưu thông tin lớp học, cấu hình điểm số và quy tắc hoàn thành. Tự động sinh mã code 6 ký tự khi tạo.')

heading(doc, 'Phần 1 — Hàm sinh mã lớp (Dòng 6–8)', 3)
code_block(doc, '''function generateClassroomCode() {
  return crypto.randomBytes(3).toString('hex').toUpperCase();
}''')
explain_text(doc, 'crypto.randomBytes(3) tạo 3 bytes ngẫu nhiên (an toàn về mặt cryptographic). toString("hex") chuyển sang hex string → 6 ký tự (mỗi byte = 2 hex chars). toUpperCase() → ví dụ "A3F12B". Đây là mã mời học sinh tham gia lớp.')

heading(doc, 'Phần 2 — Field code (Dòng 30–35)', 3)
code_block(doc, '''code: {
  type: String,
  required: true,
  unique: true,
  index: true,
},''')
explain_text(doc, 'unique: true tạo unique index trong MongoDB, đảm bảo không có 2 lớp trùng code. index: true tạo thêm index để query tìm lớp theo code nhanh (O(log n) thay vì O(n) full scan). Học sinh nhập mã → query rất nhanh nhờ index này.')

heading(doc, 'Phần 3 — gradeWeights (Dòng 50–63)', 3)
code_block(doc, '''gradeWeights: [
  {
    itemType: {
      type: String,
      enum: ['LESSON', 'QUIZ', 'ASSIGNMENT', 'EXAM'],
      required: true,
    },
    weight: { type: Number, default: 1, min: 0 },
  },
],''')
explain_text(doc, 'Mảng cấu hình trọng số điểm cho từng loại nội dung. GV có thể đặt: [{itemType:"EXAM", weight:70}, {itemType:"ASSIGNMENT", weight:30}] = bài thi chiếm 70%, bài tập 30%. gradebook.service.js đọc field này để tính điểm tổng. Mảng rỗng = tính trung bình đơn giản không trọng số.')

heading(doc, 'Phần 4 — completionRules (Dòng 78–99)', 3)
code_block(doc, '''completionRules: {
  requireAllItems:    { type: Boolean, default: false },
  minOverallPercent:  { type: Number,  default: null, min: 0, max: 100 },
  requiredItemTypes:  { type: [String], enum: ['LESSON','QUIZ','ASSIGNMENT','EXAM'], default: [] },
},''')
explain_text(doc, '3 quy tắc hoàn thành khóa học (completion.service.js đọc và kiểm tra):')
bullet(doc, 'requireAllItems = true → học sinh phải học TẤT CẢ bài được publish mới được coi là hoàn thành')
bullet(doc, 'minOverallPercent = 70 → phải đạt ít nhất 70% điểm tổng kết')
bullet(doc, 'requiredItemTypes = ["EXAM"] → phải làm ít nhất 1 bài thi')
explain_text(doc, 'Mặc định tất cả null/false → không có yêu cầu gì → học sinh được coi là hoàn thành chỉ cần tham gia lớp. Backward compatible: lớp tạo trước khi có tính năng này vẫn hoạt động bình thường.')

heading(doc, 'Phần 5 — Pre-validate hook (Dòng 107–113)', 3)
code_block(doc, '''classroomSchema.pre('validate', function ensureClassroomCode(next) {
  if (!this.code) {
    this.code = generateClassroomCode();
  }
  next();
});''')
explain_text(doc, 'Hook chạy TRƯỚC khi Mongoose validate document. Nếu code chưa có (lần đầu tạo lớp), tự động sinh code ngẫu nhiên. Controller không cần gọi generateCode() thủ công — Model tự lo. "next()" bắt buộc phải gọi để pipeline tiếp tục; quên gọi → request bị treo mãi.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.3  models/ClassroomMember.js', 2)
explain_text(doc, 'Collection: classroommembers — Bảng liên kết giữa Student và Classroom (quan hệ nhiều-nhiều). Quản lý trạng thái membership.')

heading(doc, 'Phần 1 — Field status (Dòng 19–23)', 3)
code_block(doc, '''status: {
  type: String,
  enum: ['pending', 'approved', 'rejected', 'left'],
  default: 'pending',
},''')
explain_text(doc, '4 trạng thái của membership:')
bullet(doc, 'pending: học sinh đã gửi yêu cầu, chờ GV duyệt (khi lớp bật approvalRequired=true)')
bullet(doc, 'approved: được vào lớp, có thể xem bài giảng, làm bài thi')
bullet(doc, 'rejected: GV từ chối — học sinh không thể tham gia lại với code này')
bullet(doc, 'left: tự rời lớp')
explain_text(doc, 'Khi truy vấn dữ liệu học sinh của lớp, luôn phải filter {status:"approved"} để loại bỏ pending/rejected/left.')

heading(doc, 'Phần 2 — Fields Tùy chỉnh Điểm số (Manual Overrides)', 3)
code_block(doc, '''useManualMidterm:   { type: Boolean, default: false },
manualMidtermScore: { type: Number, default: null, min: 0, max: 10 },
useManualFinal:     { type: Boolean, default: false },
manualFinalScore:   { type: Number, default: null, min: 0, max: 10 },''')
explain_text(doc, 'Các trường này dùng để ghi đè điểm tự động (Sổ điểm 10/30/60). Khi giáo viên nhập điểm thủ công, useManual=true và gradebook sẽ dùng điểm này thay vì lấy trung bình các bài thi (midterm/final) tương ứng. Thiết kế này giúp hệ thống linh hoạt trong việc chấm điểm giấy rồi nhập vào web.')

heading(doc, 'Phần 3 — Unique Index (Dòng 39)', 3)
code_block(doc, '''classroomMemberSchema.index({ classroom: 1, student: 1 }, { unique: true });''')
explain_text(doc, 'Compound unique index đảm bảo mỗi học sinh chỉ có đúng 1 bản ghi trong 1 lớp. Ngăn race condition: nếu học sinh bấm "Tham gia" 2 lần nhanh tạo ra 2 request cùng lúc, MongoDB chỉ chấp nhận 1 cái, cái còn lại bị ném E11000 duplicate key error. Controller bắt error này và trả flash message thân thiện.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.4  models/Lecture.js', 2)
explain_text(doc, 'Collection: lectures — Lưu nội dung bài giảng (text HTML từ TinyMCE, link video, PDF...).')

heading(doc, 'Phần 1 — Fields chính (Dòng 5–64)', 3)
code_block(doc, '''chapterTitle: { type: String, required: true, maxlength: 160 },
title:        { type: String, required: true, maxlength: 180 },
content:      { type: String, trim: true, default: '' },
resourceType: { type: String, enum: ['pdf','ppt','video','document','link','text'], default: 'text' },
orderIndex:   { type: Number, default: 0 },
isPublished:  { type: Boolean, default: true },''')
explain_text(doc, 'chapterTitle là field quan trọng nhất: courseProgress.service.js dùng nó làm "module key" để nhóm bài giảng cùng chương vào 1 group. Ví dụ: "Chương 1: Giới thiệu Python". content chứa HTML từ TinyMCE editor.')
bullet(doc, 'resourceType: view Pug dùng giá trị này để render icon phù hợp (PDF icon, video player, link...). Không ảnh hưởng logic lưu trữ')
bullet(doc, 'orderIndex: số thứ tự trong chương. GV sắp xếp bài theo số này. Khi query: .sort({chapterTitle:1, orderIndex:1, createdAt:1})')
bullet(doc, 'isPublished: default true — bài giảng tạo ra là public ngay. Khác với Exam (default false)')

heading(doc, 'Phần 2 — Index (Dòng 66)', 3)
code_block(doc, '''lectureSchema.index({ classroom: 1, chapterTitle: 1, orderIndex: 1 });''')
explain_text(doc, 'Index compound cho đúng pattern query phổ biến nhất: tìm tất cả bài giảng của lớp X, nhóm theo chương, sort theo orderIndex. MongoDB dùng index này để thực hiện cả filter + sort mà không cần full collection scan.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.5  models/Assignment.js', 2)
explain_text(doc, 'Collection: assignments — Lưu bài tập về nhà do GV tạo.')

heading(doc, 'Phần 1 — Fields deadline và chấm điểm (Dòng 35–68)', 3)
code_block(doc, '''totalPoints:         { type: Number, default: 10, min: 0 },
dueDate:             { type: Date, required: true },
allowLateSubmission: { type: Boolean, default: false },
rubric:              { type: Schema.Types.ObjectId, ref: 'Rubric', default: null },''')
explain_text(doc, 'dueDate required: bài tập bắt buộc phải có deadline. allowLateSubmission kiểm soát behavior sau deadline:')
bullet(doc, 'false (default): sau dueDate → controller trả 403 "Deadline đã qua", không cho nộp')
bullet(doc, 'true: vẫn nộp được, chỉ bị đánh dấu là nộp muộn trong hệ thống')
explain_text(doc, 'rubric là optional. null = GV chấm điểm tự do (nhập con số). Có giá trị = GV chấm theo rubric (từng tiêu chí). grading.service.js xử lý cả 2 path này.')

heading(doc, 'Phần 2 — Field attachments (Dòng 61–69)', 3)
code_block(doc, '''attachments: [
  {
    fileName: { type: String, required: true },
    fileUrl:  { type: String, required: true },  // '/uploads/assignments/{filename}'
    fileType: { type: String, default: 'file' },
    fileSize: { type: Number, default: 0 },
    uploadedAt: { type: Date, default: Date.now },
  },
],''')
explain_text(doc, 'Mảng file đính kèm của GV (đề bài, tài liệu tham khảo, ví dụ mẫu). fileUrl lưu đường dẫn tương đối bắt đầu bằng "/uploads/". Multer middleware upload file lên disk, controller điền filename vào đây. Học sinh download qua URL tương đối này.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.6  models/Submission.js', 2)
explain_text(doc, 'Collection: submissions — Bài nộp của học sinh cho từng assignment. Unique: 1 học sinh chỉ có 1 bài nộp cho mỗi assignment (nộp lại thì update, không tạo mới).')

heading(doc, 'Phần 1 — Sub-schema SubmissionFile (Dòng 5–30)', 3)
code_block(doc, '''const submissionFileSchema = new Schema(
  { name: String, url: String, mimeType: String, size: Number },
  { _id: false }
);''')
explain_text(doc, '"_id: false": sub-document này không cần ObjectId riêng vì nó là embedded object trong Submission, không cần tham chiếu độc lập từ nơi khác. Tiết kiệm bộ nhớ và giảm index overhead.')

heading(doc, 'Phần 2 — Field status (Dòng 67–71)', 3)
code_block(doc, '''status: {
  type: String,
  enum: ['draft', 'submitted', 'graded', 'returned'],
  default: 'submitted',
},''')
explain_text(doc, '4 trạng thái của bài nộp:')
bullet(doc, 'draft: đang soạn (hệ thống hiện không dùng — không có tính năng lưu nháp, click Nộp là submitted luôn)')
bullet(doc, 'submitted: đã nộp, chờ GV chấm')
bullet(doc, 'graded: GV đã chấm, có score và teacherComment')
bullet(doc, 'returned: GV trả lại yêu cầu làm lại (tính năng nâng cao)')

heading(doc, 'Phần 3 — Field rubricGrades (Dòng 92–98)', 3)
code_block(doc, '''rubricGrades: [
  {
    criterion: { type: Schema.Types.ObjectId, ref: 'Rubric.criteria' },
    points:    { type: Number, default: 0, min: 0 },
    comment:   { type: String, trim: true, default: '' },
  },
],''')
explain_text(doc, 'Chỉ có dữ liệu khi GV chấm bằng rubric. Mỗi phần tử = điểm của 1 criterion cụ thể. submission.score = tổng tất cả criterion.points (được sync bởi grading.service.js). Nếu GV chấm thủ công (freehand), mảng này rỗng và score được nhập trực tiếp.')

heading(doc, 'Phần 4 — Unique Index (Dòng 106)', 3)
code_block(doc, '''submissionSchema.index({ assignment: 1, student: 1 }, { unique: true });''')
explain_text(doc, 'Một học sinh chỉ được có 1 bài nộp cho 1 assignment. Khi nộp lại: controller dùng Submission.findOne() rồi update (không create mới) để không vi phạm constraint này.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.7  models/Exam.js', 2)
explain_text(doc, 'Collection: exams — Thông tin bài kiểm tra/thi. Mặc định isPublished=false (khác Lecture) để GV phải chủ động publish sau khi chuẩn bị xong.')

heading(doc, 'Phần 1 — Fields kiểm soát thời gian (Dòng 30–42)', 3)
code_block(doc, '''duration:  { type: Number, default: 60 },  // phút, 0 = không giới hạn
startTime: { type: Date, default: null },
endTime:   { type: Date, default: null },''')
explain_text(doc, 'duration: examIntegrity.service.js dùng field này để tính server-side deadline: deadlineAt = startedAt + duration * 60 * 1000 ms. duration=0 → deadline=null → không giới hạn thời gian.')
bullet(doc, 'startTime/endTime: khung thời gian mở cửa thi. null = không giới hạn. Đặt startTime=08:00, endTime=10:00 → thi chỉ mở trong 2 tiếng')
bullet(doc, 'Controller và view đọc 2 field này để hiện "Chưa mở" / "Đã đóng" / "Đang mở"')

heading(doc, 'Phần 1.5 — Phân loại bài thi (examType)', 3)
code_block(doc, '''examType: { 
  type: String, 
  enum: ['normal', 'midterm', 'final'], 
  default: 'normal' 
},''')
explain_text(doc, 'Phân loại bài thi để phục vụ Sổ điểm (Gradebook). "midterm" sẽ được gom vào cột Giữa kỳ (30%), "final" sẽ được gom vào cột Cuối kỳ (60%). "normal" là bài thi phụ không tính vào điểm chính quy.')

heading(doc, 'Phần 2 — Fields kiểm soát lượt thi (Dòng 47–51)', 3)
code_block(doc, '''maxAttempts: { type: Number, default: 1 },  // 0 = không giới hạn''')
explain_text(doc, 'Default = 1 → học sinh chỉ được thi 1 lần. 0 = thi không giới hạn số lần. examIntegrity.service.js::canStartAttempt(usedAttempts, maxAttempts) kiểm tra trước khi mở bài: đếm số lần đã có trạng thái terminal (submitted/graded/late/auto_submitted), so sánh với maxAttempts.')

heading(doc, 'Phần 3 — Fields chống gian lận (Dòng 57–72)', 3)
code_block(doc, '''strictMode:    { type: Boolean, default: false },
maxViolations: { type: Number, default: 0 },   // 0 = chỉ ghi log, không tự nộp
shuffle:       { type: Boolean, default: false },''')
explain_text(doc, 'strictMode=true: frontend bật fullscreen bắt buộc, chặn copy/paste, phát hiện tab switch. maxViolations: ngưỡng để hệ thống tự nộp bài (auto_submitted). maxViolations=0 → chỉ ghi log vi phạm, không tự nộp. shuffle=true → Fisher-Yates xáo trộn thứ tự câu hỏi VÀ options mỗi khi học sinh mở bài.')

heading(doc, 'Phần 4 — Fields totalPoints và questionCount (Dòng 77–84)', 3)
code_block(doc, '''totalPoints:   { type: Number, default: 0 },
questionCount: { type: Number, default: 0 },''')
explain_text(doc, 'Hai field denormalized: tính sẵn và lưu, không cần aggregate mỗi lần query. Được cập nhật tự động bởi Question model hooks:')
bullet(doc, 'Question.pre("save"): khi thêm câu mới → $inc { questionCount: +1, totalPoints: +question.points }')
bullet(doc, 'Question.post("findOneAndDelete"): khi xóa câu → $inc { questionCount: -1, totalPoints: -question.points }')
explain_text(doc, 'Mục đích: tránh phải COUNT + SUM mỗi lần hiển thị exam card → tiết kiệm N queries.')

heading(doc, 'Phần 5 — Field showResult (Dòng 52–56)', 3)
code_block(doc, '''showResult: {
  type: String,
  enum: ['none', 'after_submit', 'after_exam_ends'],
  default: 'after_submit',
},''')
explain_text(doc, 'Kiểm soát khi nào học sinh thấy kết quả:')
bullet(doc, 'none: không bao giờ thấy điểm, chỉ biết đã nộp')
bullet(doc, 'after_submit (default): thấy ngay khi nộp xong')
bullet(doc, 'after_exam_ends: phải chờ đến khi endTime qua (tránh học sinh báo đáp án cho nhau khi thi cùng lúc)')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.8  models/Question.js', 2)
explain_text(doc, 'Collection: questions — Mỗi câu hỏi trong 1 bài thi. Có 2 Mongoose hooks tự động sync totalPoints và questionCount của Exam.')

heading(doc, 'Phần 1 — Field type và options (Dòng 13–28)', 3)
code_block(doc, '''type: {
  type: String,
  enum: ['multiple_choice', 'multiple_answer', 'essay'],
  required: true,
  default: 'multiple_choice',
},
options: [
  {
    text:      { type: String, required: true },
    isCorrect: { type: Boolean, default: false },
  },
],''')
explain_text(doc, '3 loại câu hỏi:')
bullet(doc, 'multiple_choice: chọn 1 đáp án đúng từ nhiều lựa chọn')
bullet(doc, 'multiple_answer: chọn NHIỀU đáp án đúng — phải chọn đúng TẤT CẢ, không partial credit')
bullet(doc, 'essay: câu tự luận, học sinh gõ text. Không tự chấm được, chờ GV chấm thủ công')
explain_text(doc, 'options.isCorrect: GV đánh dấu đáp án đúng khi tạo câu. Khi học sinh nộp bài, controller lấy optionIds có isCorrect=true rồi so sánh với optionIds học sinh chọn.')

heading(doc, 'Phần 2 — Pre-save Hook tự động cộng điểm (Dòng 57–63)', 3)
code_block(doc, '''questionSchema.pre('save', async function (next) {
  if (this.isNew) {
    const Exam = mongoose.model('Exam');
    await Exam.findByIdAndUpdate(this.exam, {
      $inc: { questionCount: 1, totalPoints: this.points }
    });
  }
  next();
});''')
explain_text(doc, '"this.isNew" kiểm tra đây có phải lần đầu save không (tránh hook chạy khi update câu hỏi). $inc là atomic increment của MongoDB — không có race condition. Kết quả: GV thêm câu hỏi 5 điểm → exam.totalPoints tự động tăng 5, exam.questionCount tăng 1. GV không cần cộng tay.')

heading(doc, 'Phần 3 — Post-delete Hook tự động trừ điểm (Dòng 65–70)', 3)
code_block(doc, '''questionSchema.post('findOneAndDelete', async function (doc) {
  if (doc) {
    const Exam = mongoose.model('Exam');
    await Exam.findByIdAndUpdate(doc.exam, {
      $inc: { questionCount: -1, totalPoints: -doc.points }
    });
  }
});''')
explain_text(doc, '"post" thay vì "pre" vì cần có document đã bị xóa (doc) để biết trừ bao nhiêu điểm. Nếu xóa thất bại, hook không chạy → totalPoints không bị trừ nhầm. Guard "if (doc)" đảm bảo doc tồn tại trước khi đọc doc.points.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.9  models/ExamSubmission.js', 2)
explain_text(doc, 'Collection: examsubmissions — Mỗi lần làm bài thi của học sinh (kể cả đang làm dở). Đây là model phức tạp nhất với nhiều trạng thái và index bảo vệ race condition.')

heading(doc, 'Phần 1 — Field status (Dòng 61–65)', 3)
code_block(doc, '''status: {
  type: String,
  enum: ['in_progress', 'submitted', 'graded', 'late', 'auto_submitted'],
  default: 'in_progress',
},''')
explain_text(doc, 'Vòng đời của 1 lần làm bài:')
bullet(doc, 'in_progress: bài đang mở, học sinh đang làm')
bullet(doc, 'submitted: đã nộp đúng hạn (server clock trong deadline + 30s grace period)')
bullet(doc, 'late: đã nộp nhưng quá deadline → vẫn được chấm, chỉ đánh dấu để GV xử lý theo policy')
bullet(doc, 'auto_submitted: hệ thống tự nộp khi hết giờ hoặc vượt maxViolations (Socket.IO event)')
bullet(doc, 'graded: GV đã chấm xong tất cả câu tự luận')

heading(doc, 'Phần 2 — Field deadlineAt (Dòng 73–76)', 3)
code_block(doc, '''deadlineAt: {
  type: Date,
  default: null,  // null khi exam.duration === 0
},''')
explain_text(doc, 'Deadline tính từ phía SERVER, được tính 1 lần khi học sinh bấm "Bắt đầu thi": deadlineAt = startedAt + exam.duration * 60000. Không phụ thuộc đồng hồ client. Khi học sinh nộp bài: evaluateDeadline(submission.deadlineAt, new Date()) so sánh với server clock + 30s grace. null khi duration=0 (không giới hạn thời gian).')

heading(doc, 'Phần 3 — Field attemptNumber (Dòng 80–83)', 3)
code_block(doc, '''attemptNumber: { type: Number, default: 1 },''')
explain_text(doc, 'Lần thi thứ mấy (1-based). Lần đầu = 1, lần 2 = 2... Kết hợp với unique index {exam, student, attemptNumber} để chặn race condition: nếu học sinh bấm "Bắt đầu thi" 2 lần nhanh tạo 2 request concurrent, chỉ 1 request thành công tạo attempt, cái còn lại bị E11000 và redirect sang trang kết quả.')

heading(doc, 'Phần 4 — Field violations (Dòng 88–94)', 3)
code_block(doc, '''violations: [
  {
    type:    { type: String, enum: ['blur','visibility_hidden','fullscreen_exit','copy','cut','paste','tab_switch','right_click'] },
    time:    { type: Date },
    details: { type: String },
  },
],''')
explain_text(doc, 'Log gian lận. QUAN TRỌNG: field này chỉ được ghi từ Socket.IO server-side (/exam-monitor namespace), KHÔNG đọc từ req.body. Lý do: nếu nhận violations từ request body, học sinh có thể tự xóa hoặc giả mạo log vi phạm của mình. Server phải là nguồn sự thật duy nhất cho dữ liệu integrity.')

heading(doc, 'Phần 5 — Các Indexes (Dòng 108–119)', 3)
code_block(doc, '''// Pattern: lấy bài nộp của student trong exam, mới nhất trước
examSubmissionSchema.index({ exam: 1, student: 1, submittedAt: -1 });

// Chặn race condition: không thể có 2 attempt cùng number
examSubmissionSchema.index({ exam: 1, student: 1, attemptNumber: 1 }, { unique: true });

// Quét auto-submit và grading queue
examSubmissionSchema.index({ exam: 1, status: 1 });''')
explain_text(doc, '3 indexes mỗi cái phục vụ 1 use case:')
bullet(doc, 'Index 1: render trang kết quả — lấy lịch sử thi của học sinh cho 1 exam')
bullet(doc, 'Index 2: chặn race condition — unique (exam, student, attemptNumber)')
bullet(doc, 'Index 3: GV/job query "tất cả bài in_progress đã hết giờ" để auto-submit sweep')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.10  models/StudentProgress.js', 2)
explain_text(doc, 'Collection: studentprogresses — Completion ledger (sổ ghi nhận hoàn thành). ĐÂY LÀ COLLECTION TRUNG TÂM NHẤT: mọi tính năng (course progress, gradebook, completion check) đều đọc từ đây.')

heading(doc, 'Phần 1 — Ý nghĩa thiết kế (Comment đầu file)', 3)
code_block(doc, '''// Tracks WHICH content items a student has completed.
// Unlock/locked status is never stored; it is always recomputed from
// this collection at request time (see services/courseProgress.service.js).''')
explain_text(doc, 'Triết lý thiết kế: chỉ lưu "học sinh đã làm gì" (fact), KHÔNG lưu "bài nào bị lock" (derived state). Trạng thái LOCKED/IN_PROGRESS được tính lại mỗi lần request từ dữ liệu trong collection này. Lợi ích: không bao giờ bị stale state, không cần trigger/event để cập nhật.')

heading(doc, 'Phần 2 — Fields evidence (Dòng 41–53)', 3)
code_block(doc, '''score:       { type: Number, default: null },
maxScore:    { type: Number, default: null },
submittedAt: { type: Date, default: null },''')
explain_text(doc, 'Ba field "evidence" chỉ có giá trị cho graded content (ASSIGNMENT, EXAM). Lecture (LESSON) để null. gradebook.service.js chỉ lấy rows có score IS NOT NULL AND maxScore > 0. Khi GV chấm lại, markComplete() gọi lại với score mới → cập nhật bản ghi → gradebook tức thì phản ánh.')

heading(doc, 'Phần 3 — Unique Index (Dòng 61–64)', 3)
code_block(doc, '''studentProgressSchema.index(
  { classroom: 1, student: 1, itemType: 1, itemId: 1 },
  { unique: true }
);''')
explain_text(doc, '4-field unique index là trái tim của completion ledger. Đảm bảo: 1 học sinh chỉ có 1 bản ghi hoàn thành cho mỗi (classroom, loại nội dung, nội dung cụ thể). Đây là lý do helper/progress.js::markComplete() dùng findOneAndUpdate+upsert: không lo tạo duplicate, idempotent — gọi 100 lần kết quả như gọi 1 lần.')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.11  models/Rubric.js', 2)
explain_text(doc, 'Collection: rubrics — Template chấm điểm theo tiêu chí. GV tạo rubric rồi gán vào Assignment. Có pre-validate hook tự sync tổng điểm.')

heading(doc, 'Phần 1 — Sub-schema rubricCriterionSchema (Dòng 9–35)', 3)
code_block(doc, '''const rubricCriterionSchema = new Schema({
  label:       { type: String, required: true, maxlength: 120 },
  description: { type: String, default: '' },
  maxPoints:   { type: Number, required: true, min: 0 },
  scale: [
    { points: { type: Number }, label: { type: String } }
  ],
}, { _id: true });''')
explain_text(doc, 'Mỗi criterion là 1 tiêu chí chấm. maxPoints là điểm tối đa. scale là các mức gợi ý để GV click nhanh trong UI — ví dụ: [{points:10, label:"Xuất sắc"}, {points:7, label:"Khá"}, {points:4, label:"Trung bình"}, {points:0, label:"Chưa đạt"}].')

heading(doc, 'Phần 2 — Pre-validate Hook tự động sync maxPoints (Dòng 79–82)', 3)
code_block(doc, '''rubricSchema.pre('validate', function reconcileMaxPoints(next) {
  this.maxPoints = (this.criteria || []).reduce((sum, c) => sum + (Number(c.maxPoints) || 0), 0);
  next();
});''')
explain_text(doc, 'Mỗi lần save rubric (dù thêm/xóa/sửa criterion), tự tính lại rubric.maxPoints = tổng tất cả criteria.maxPoints. Đảm bảo maxPoints không bao giờ bị stale. grading.service.js dùng rubric.maxPoints làm maxScore khi gọi markComplete().')

divider(doc)

# ──────────────────────────────────────────────────────
heading(doc, '1.12  models/Notification.js', 2)
explain_text(doc, 'Collection: notifications — Thông báo trong hệ thống (bell icon trên navbar).')

heading(doc, 'Phần 1 — Field isRead và Index (Dòng 26–37)', 3)
code_block(doc, '''isRead: { type: Boolean, default: false, index: true },
// ...
notificationSchema.index({ recipient: 1, isRead: 1, createdAt: -1 });''')
explain_text(doc, 'isRead default false = chưa đọc. middleware/currentUser.js query countDocuments({recipient:userId, isRead:false}) MỖI REQUEST để hiển thị số badge trên navbar. Compound index {recipient, isRead, createdAt} bao gồm đủ cả 3 fields của query và sort → MongoDB dùng được index toàn bộ, không cần sort thêm.')

page_break(doc)

# ══════════════════════════════════════════════════════════════════════════════
# CHƯƠNG 2 — MIDDLEWARE
# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 2 — MIDDLEWARE', 1)
explain_text(doc, 'Middleware chạy trong pipeline của mỗi HTTP request, theo thứ tự đăng ký trong index.js. Có 3 loại: security (helmet, xss), authentication (passport), và application logic (currentUser).')

heading(doc, '2.1  middleware/rbac.js — Xác thực và Phân quyền', 2)

heading(doc, 'Phần 1 — Hàm requireAuth (Dòng ~5–12)', 3)
meta_label(doc, 'Gắn vào route', 'Tất cả route cần login: /student/*, /teacher/*, /admin/*')
code_block(doc, '''function requireAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  if (req.headers.accept?.includes('application/json'))
    return res.status(401).json({ error: 'Unauthorized' });
  return res.redirect('/auth/login');
}''')
explain_text(doc, 'req.isAuthenticated() là hàm của Passport.js, trả true nếu session hợp lệ (user đã đăng nhập). Phân biệt 2 loại request:')
bullet(doc, 'API call (Accept: application/json): trả JSON 401 — frontend JS có thể handle')
bullet(doc, 'Page request (trình duyệt): redirect sang trang login')

heading(doc, 'Phần 2 — Hàm requireRole (Dòng ~14–23)', 3)
meta_label(doc, 'Gắn vào route', 'requireRole("teacher") → route /teacher/*; requireRole("admin") → route /admin/*')
code_block(doc, '''function requireRole(...roles) {
  return function (req, res, next) {
    if (!req.isAuthenticated()) return res.redirect('/auth/login');
    if (!roles.includes(req.user.role))
      return res.status(403).render('errors/403', { title: 'Access Denied', path: req.originalUrl });
    return next();
  };
}''')
explain_text(doc, 'Factory function — nhận nhiều role, trả ra middleware. Ví dụ: requireRole("teacher") tạo middleware chỉ cho teacher qua. requireRole("admin", "teacher") cho cả 2. req.user.role được Passport deserialize từ session cookie. Không khớp role → render trang 403, không redirect.')

divider(doc)

heading(doc, '2.2  middleware/currentUser.js — Dữ liệu toàn cục cho mọi View', 2)
meta_label(doc, 'Đăng ký ở', 'index.js: app.use(attachCurrentUser) — chạy trên MỌI request')

heading(doc, 'Phần 1 — Gắn user vào res.locals (Dòng 6–11)', 3)
code_block(doc, '''async function attachCurrentUser(req, res, next) {
  const authenticated = req.isAuthenticated ? req.isAuthenticated() : Boolean(req.user);
  res.locals.currentUser   = authenticated ? req.user : null;
  res.locals.isAuthenticated = authenticated;
  res.locals.path = req.originalUrl || req.path;''')
explain_text(doc, 'res.locals là object được truyền tự động vào mọi Pug view mà không cần controller phải truyền riêng. Gán currentUser, isAuthenticated, path vào đây → tất cả layout và partial Pug templates có thể dùng ngay. Guard "req.isAuthenticated ?" để xử lý case middleware chạy trước Passport init.')

heading(doc, 'Phần 2 — Đếm notifications chưa đọc (Dòng 13–22)', 3)
code_block(doc, '''if (authenticated && req.user) {
  try {
    res.locals.unreadCount = await Notification.countDocuments({
      recipient: req.user.id,
      isRead: false
    });
  } catch (err) {
    res.locals.unreadCount = 0;
  }''')
explain_text(doc, 'Query đếm notification chưa đọc của user đang login. Chạy MỌI request → hiển thị badge số thực thời gian trên navbar. Bọc trong try/catch: nếu DB lỗi, badge hiện 0 thay vì crash cả request. Có thể tối ưu bằng Redis cache nếu traffic lớn.')

heading(doc, 'Phần 3 — Badge số teacher chờ duyệt (chỉ cho Admin) (Dòng 34–43)', 3)
code_block(doc, '''if (req.user.role === 'admin') {
  try {
    res.locals.pendingCount = await User.countDocuments({
      role: 'teacher',
      status: 'pending',
    });
  } catch (err) {
    res.locals.pendingCount = 0;
  }
}''')
explain_text(doc, 'Chỉ chạy khi user là admin. Đếm số giáo viên đang chờ duyệt để hiển thị badge trong admin sidebar. Không chạy cho teacher/student để tránh query thừa. Role check ở đây, không cần middleware riêng.')

heading(doc, 'Phần 4 — Đọc tên site từ DB (Dòng 49–54)', 3)
code_block(doc, '''const siteNameSetting = await SystemSetting.findOne({ key: 'siteName' });
res.locals.siteName = siteNameSetting ? siteNameSetting.value : 'E-Learning LMS';''')
explain_text(doc, 'Admin có thể đổi tên site trong Settings mà không cần restart server — giá trị đọc từ DB mỗi request. siteName được render trong <title> tag và navbar của mọi trang. Fallback "E-Learning LMS" khi chưa cấu hình.')

page_break(doc)

# ══════════════════════════════════════════════════════════════════════════════
# CHƯƠNG 3 — HELPERS
# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 3 — HELPERS (Hàm dùng chung)', 1)

heading(doc, '3.1  helper/progress.js — markComplete() [ĐIỂM GHI DUY NHẤT]', 2)
explain_text(doc, 'Đây là hàm quan trọng nhất trong toàn bộ hệ thống. Mọi loại nội dung (lecture, assignment, exam) đều funneling qua đây để ghi completion.')
meta_label(doc, 'Gọi từ đâu', 'student/lecture.controller.js, student/submission.controller.js, student/exam.controller.js, teacher/submission.controller.js, services/grading.service.js, services/exam.service.js')

heading(doc, 'Phần 1 — Signature và Filter (Dòng 25–30)', 3)
code_block(doc, '''async function markComplete({ student, classroom, itemType, itemId, evidence = {} }) {
  const filter = { classroom, student, itemType, itemId };
  const update = { completedAt: new Date() };''')
explain_text(doc, 'filter xác định chính xác 1 record duy nhất: (student X, classroom Y, loại nội dung Z, item cụ thể). Đây chính là 4 fields của unique index trong StudentProgress. update luôn cập nhật completedAt = bây giờ.')

heading(doc, 'Phần 2 — Điền evidence có điều kiện (Dòng 32–41)', 3)
code_block(doc, '''if (evidence.score !== undefined)     update.score = evidence.score;
if (evidence.maxScore !== undefined)  update.maxScore = evidence.maxScore;
if (evidence.submittedAt !== undefined) update.submittedAt = evidence.submittedAt;''')
explain_text(doc, 'Chỉ set evidence fields khi được cung cấp (không undefined). Lecture gọi markComplete({}) không có evidence → score/maxScore vẫn là null (đúng vì lecture không có điểm). Assignment gọi lại khi GV chấm → truyền score mới → cập nhật score, completedAt không đổi.')

heading(doc, 'Phần 3 — Upsert vào DB (Dòng 43–46)', 3)
code_block(doc, '''await StudentProgress.findOneAndUpdate(filter, update, {
  upsert: true,
  setDefaultsOnInsert: true,
});''')
explain_text(doc, 'upsert: true — tạo mới nếu chưa có, cập nhật nếu đã có. setDefaultsOnInsert — khi tạo mới, áp dụng Schema default values. Atomic MongoDB operation: không có race condition, không cần lock. Học sinh click "Đã học xong" 100 lần → chỉ có 1 record trong DB.')

divider(doc)

heading(doc, '3.2  helper/token.js — Tạo JWT', 2)

heading(doc, 'Phần 1 — Access Token (Dòng 4–15)', 3)
code_block(doc, '''function createAccessToken(user) {
  return jwt.sign(
    { sub: user.id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );
}''')
explain_text(doc, 'Payload: sub = user ID (tiêu chuẩn JWT claim), role = nhúng vào token để middleware RBAC đọc mà không cần query DB. expiresIn 15m: token ngắn hạn, hết hạn buộc phải dùng refresh token để gia hạn. Ký bằng JWT_SECRET (HMAC-SHA256).')

heading(doc, 'Phần 2 — Refresh Token (Dòng 17–27)', 3)
code_block(doc, '''function createRefreshToken(user) {
  return jwt.sign(
    { sub: user.id, tokenType: 'refresh' },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
  );
}''')
explain_text(doc, 'tokenType: "refresh" phân biệt với access token — không thể dùng refresh token ở endpoint cần access token (và ngược lại). Ký bằng JWT_REFRESH_SECRET KHÁC với JWT_SECRET. Tồn tại 7 ngày. Hash của nó được lưu vào User.refreshTokenHash trong DB.')

heading(doc, 'Phần 3 — Hash Token (Dòng 30–32)', 3)
code_block(doc, '''function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}''')
explain_text(doc, 'SHA-256 hash của token (one-way). Dùng để lưu refreshToken vào DB an toàn. Khi validate: hash lại token từ cookie, so sánh với hash trong DB. Nếu DB bị dump, attacker chỉ thấy hash, không thể dùng hash đó để đăng nhập.')

divider(doc)

heading(doc, '3.3  helper/notification.helper.js', 2)

heading(doc, 'Phần 1 — sendNotification (Dòng 11–25)', 3)
code_block(doc, '''async function sendNotification(recipientId, title, message, link = '#') {
  try {
    const notification = await Notification.create({ recipient: recipientId, title, message, link });
    return notification;
  } catch (error) {
    console.error('Failed to send notification:', error);
    return null;  // không throw — không crash main flow
  }
}''')
explain_text(doc, 'Bắt exception và trả null thay vì re-throw. Lý do: notification là tính năng phụ — lỗi notification KHÔNG được làm crash main business logic (ví dụ: tạo bài tập thành công nhưng gửi notification lỗi → vẫn trả "OK" cho GV). Controller dùng Promise.allSettled (không phải Promise.all) để 1 notification lỗi không block toàn bộ.')

heading(doc, 'Phần 2 — sendBulkNotifications (Dòng 35–47)', 3)
code_block(doc, '''async function sendBulkNotifications(recipientIds, title, message, link = '#') {
  try {
    const notifications = recipientIds.map(id => ({ recipient: id, title, message, link }));
    await Notification.insertMany(notifications);
  } catch (error) {
    console.error('Failed to send bulk notifications:', error);
  }
}''')
explain_text(doc, 'insertMany gửi 1 bulk write command đến MongoDB thay vì N insert riêng lẻ. Cho N học sinh: tiết kiệm N-1 round trips (rất đáng kể khi lớp có 50-100 học sinh). Không trả giá trị vì caller không cần biết kết quả từng notification.')

page_break(doc)

# ══════════════════════════════════════════════════════════════════════════════
# CHƯƠNG 4 — SERVICES
# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 4 — SERVICES (Business Logic)', 1)
explain_text(doc, 'Services chứa business logic phức tạp, tách khỏi Controller. Nhiều service là pure functions (không query DB) để dễ unit test.')

heading(doc, '4.1  controller/auth/auth.service.js', 2)

heading(doc, 'Phần 1 — sanitizeUser (Dòng 4–13)', 3)
code_block(doc, '''function sanitizeUser(user) {
  return {
    id: user.id, name: user.name, email: user.email,
    role: user.role, status: user.status, provider: user.provider,
  };
}''')
explain_text(doc, 'Tạo plain object an toàn từ User document. Trả chỉ 6 fields cần thiết cho session/cookie. Dù Model đã có toJSON transform, hàm này đảm bảo controller/service không vô tình truyền thêm dữ liệu nhạy cảm vào các đối tượng khác.')

heading(doc, 'Phần 2 — registerUser (Dòng 15–40)', 3)
meta_label(doc, 'Gọi từ đâu', 'auth.controller.js::register()')
code_block(doc, '''async function registerUser(payload) {
  const email = payload.email.toLowerCase();
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    const error = new Error('An account with this email already exists.');
    error.statusCode = 409;
    throw error;
  }
  const targetRole = payload.role === 'teacher' ? 'teacher' : 'student';
  const user = new User({ name, email, role: targetRole,
    status: targetRole === 'teacher' ? 'pending' : 'active' });
  await user.setPassword(payload.password);
  await user.save();
  return user;
}''')
explain_text(doc, 'Normalize email về lowercase trước khi tìm (tránh "User@Gmail.com" vs "user@gmail.com"). Tìm email trùng thủ công để trả lỗi 409 với message rõ ràng (không để MongoDB ném E11000 thô).')
bullet(doc, 'targetRole: whitelist — chỉ chấp nhận "teacher", mọi giá trị khác đều thành "student". Ngăn user tự đặt role="admin"')
bullet(doc, 'Teacher: status="pending" — chờ admin duyệt. Student: status="active" — vào ngay')
bullet(doc, 'setPassword(): bcrypt hash với salt rounds 12')

heading(doc, 'Phần 3 — authenticateUser (Dòng 42–65)', 3)
meta_label(doc, 'Gọi từ đâu', 'auth.controller.js::login()')
code_block(doc, '''async function authenticateUser(email, password) {
  const user = await User.findOne({ email: email.toLowerCase() })
    .select('+passwordHash +refreshTokenHash');

  if (!user || user.provider !== 'local') {
    const error = new Error('Invalid email or password.');
    error.statusCode = 401;
    throw error;
  }
  const passwordMatches = await user.comparePassword(password);
  if (!passwordMatches) {
    const error = new Error('Invalid email or password.');
    error.statusCode = 401;
    throw error;
  }
  if (user.status === 'rejected') { ... throw 403 ... }
  return user;
}''')
explain_text(doc, '.select("+passwordHash +refreshTokenHash") override "select:false" trong Schema để lấy hash. Kiểm tra provider:"local" để chặn Google/Facebook users đăng nhập bằng form password (họ không có passwordHash).')
bullet(doc, 'Cùng 1 message lỗi cho cả "email không tồn tại" và "sai password" → không leak thông tin (attacker không biết email có tồn tại không)')
bullet(doc, '"rejected" check: tài khoản bị admin từ chối → 403, không cho vào')

heading(doc, 'Phần 4 — buildAuthSession (Dòng 67–80)', 3)
meta_label(doc, 'Gọi từ đâu', 'auth.controller.js::login() và auth.controller.js::register()')
code_block(doc, '''async function buildAuthSession(user) {
  const accessToken = createAccessToken(user);
  const refreshToken = createRefreshToken(user);
  user.setRefreshToken(refreshToken);  // lưu SHA-256 hash vào user.refreshTokenHash
  user.lastLoginAt = new Date();
  await user.save();
  return { user: sanitizeUser(user), accessToken, refreshToken };
}''')
explain_text(doc, 'Tạo cả 2 token cùng lúc. setRefreshToken() hash token rồi lưu vào DB. Cập nhật lastLoginAt để admin biết user hoạt động lần cuối khi nào. sanitizeUser() đảm bảo không trả passwordHash ra ngoài.')

heading(doc, 'Phần 5 — rotateRefreshToken (Dòng 82–94)', 3)
meta_label(doc, 'Gọi từ đâu', 'auth.controller.js::refresh()')
code_block(doc, '''async function rotateRefreshToken(incomingToken) {
  const payload = require('jsonwebtoken').verify(incomingToken, process.env.JWT_REFRESH_SECRET);
  const user = await User.findById(payload.sub).select('+refreshTokenHash');
  if (!user || !user.matchesRefreshToken(incomingToken)) {
    const error = new Error('Refresh token is invalid or expired.');
    error.statusCode = 401;
    throw error;
  }
  return buildAuthSession(user);  // sinh cặp token MỚI, lưu hash mới vào DB
}''')
explain_text(doc, 'Token Rotation pattern: mỗi lần refresh, token cũ bị vô hiệu hóa và cấp token mới. user.matchesRefreshToken() hash token đến rồi so sánh với hash trong DB. Nếu token cũ đã bị dùng hoặc đánh cắp → hash không match → 401. buildAuthSession() tạo token mới và overwrite hash trong DB → token cũ vô dụng.')

heading(doc, 'Phần 6 — upsertOAuthUser (Dòng 106–138)', 3)
meta_label(doc, 'Gọi từ đâu', 'Passport Google/Facebook strategy callbacks')
code_block(doc, '''async function upsertOAuthUser(profile, provider) {
  let user = await User.findOne({
    $or: [
      { provider, providerId },
      ...(email ? [{ email }] : []),
    ],
  }).select('+refreshTokenHash');

  if (!user) {
    user = new User({ name, email, role: 'student', provider, providerId, status: 'active' });
  } else {
    user.provider = provider; user.providerId = providerId;
    user.avatarUrl = avatarUrl || user.avatarUrl;
    user.status = user.status === 'rejected' ? 'rejected' : 'active';
  }
  await user.save(); return user;
}''')
explain_text(doc, '$or query: tìm user theo providerId (đã từng OAuth trước đó) HOẶC email (có tài khoản local cùng email). Nếu tìm thấy bằng email → link OAuth vào tài khoản local đó thay vì tạo mới. Nếu chưa có: tạo user mới với role="student" và status="active" (OAuth users không cần duyệt). Guard: nếu đã bị rejected → vẫn rejected, không tự active lại.')

divider(doc)

heading(doc, '4.2  services/courseProgress.service.js — Engine Tiến Độ Học Tập [PHỨC TẠP NHẤT]', 2)
explain_text(doc, 'File quan trọng nhất trong backend. Quyết định bài học nào LOCKED, COMPLETED, IN_PROGRESS. Toàn bộ logic xử lý trong memory sau 2 batch queries — không có N+1.')

heading(doc, 'Phần 1 — Constants (Dòng 8–24)', 3)
code_block(doc, '''const ITEM_STATUS = Object.freeze({
  COMPLETED: 'COMPLETED', IN_PROGRESS: 'IN_PROGRESS',
  NOT_STARTED: 'NOT_STARTED', LOCKED: 'LOCKED',
});
const CONTENT_TYPES = Object.freeze({
  LESSON: 'LESSON', QUIZ: 'QUIZ', ASSIGNMENT: 'ASSIGNMENT', EXAM: 'EXAM',
});
const ASSIGNMENTS_MODULE_KEY = 'Bài tập';
const EXAMS_MODULE_KEY = 'Bài thi';''')
explain_text(doc, 'Object.freeze() ngăn code khác ghi đè giá trị. Thay vì dùng string literal "LOCKED" rải rác (dễ typo), code luôn dùng ITEM_STATUS.LOCKED. ASSIGNMENTS_MODULE_KEY và EXAMS_MODULE_KEY là tên module mặc định khi assignment/exam không có chapterTitle.')

heading(doc, 'Phần 2 — buildContentItems() (Dòng 87–110)', 3)
meta_label(doc, 'Gọi từ đâu', 'computeCourseProgress() bên dưới')
code_block(doc, '''async function buildContentItems(classroomId) {
  const [lectures, assignments, exams] = await Promise.all([
    Lecture.find({ classroom: classroomId, isPublished: true })
      .sort({ chapterTitle: 1, orderIndex: 1, createdAt: 1 }).lean(),
    Assignment.find({ classroom: classroomId, isPublished: true })
      .sort({ dueDate: 1, createdAt: 1 }).lean(),
    Exam.find({ classroom: classroomId, isPublished: true })
      .sort({ createdAt: 1 }).lean(),
  ]);
  // ...normalize và sort global
}''')
explain_text(doc, 'Promise.all: 3 query chạy SONG SONG, không tuần tự. .lean() trả plain JS object, không phải Mongoose document → nhanh hơn, ít RAM hơn. Kết quả được normalize về chung 1 DTO shape (ContentItem) qua hàm toContentItem().')
bullet(doc, 'Lecture: sort theo chapterTitle → trong chương sort theo orderIndex')
bullet(doc, 'Assignment: sort theo dueDate (deadline gần nhất lên trước)')
bullet(doc, 'Exam: sort theo createdAt (mới nhất lên trước)')

heading(doc, 'Phần 3 — Sort global và merge (Dòng 101–109)', 3)
code_block(doc, '''items.sort((a, b) => {
  if (a.moduleKey !== b.moduleKey) return a.moduleKey.localeCompare(b.moduleKey);
  if (a.order !== b.order) return a.order - b.order;
  return a.createdAt - b.createdAt;
});''')
explain_text(doc, 'Sau khi normalize tất cả 3 loại về cùng DTO, sort global theo: 1) moduleKey (tên chương), 2) orderIndex, 3) createdAt. Kết quả: bài giảng chương 1 → bài giảng chương 2 → "Bài tập" → "Bài thi". Thứ tự này được dùng để xác định prerequisite.')

heading(doc, 'Phần 4 — getCompletedItemKeys() (Dòng 116–121)', 3)
code_block(doc, '''async function getCompletedItemKeys(classroomId, studentId) {
  const rows = await StudentProgress.find({ classroom: classroomId, student: studentId })
    .select('itemType itemId -_id').lean();
  return new Set(rows.map(r => `${r.itemType}:${String(r.itemId)}`));
}''')
explain_text(doc, 'Dùng Set<string> thay vì mảng để lookup O(1) thay vì O(n). Key format: "LESSON:64f8abc...". Sau này completedKeys.has("LESSON:64f8abc...") cực nhanh. .select("itemType itemId -_id") chỉ lấy 2 fields cần thiết, bỏ _id → giảm data transfer.')

heading(doc, 'Phần 5 — resolvePrerequisite() (Dòng 158–169)', 3)
code_block(doc, '''function resolvePrerequisite(item, moduleItems) {
  const position = moduleItems.indexOf(item);
  if (position <= 0) return null;  // item đầu tiên không có prereq
  for (let i = position - 1; i >= 0; i--) {
    if (moduleItems[i].isRequired) return moduleItems[i];
  }
  return null;
}''')
explain_text(doc, 'Tìm prerequisite của item: đi ngược từ vị trí hiện tại, tìm item isRequired đầu tiên trong cùng module. Item đầu tiên (position=0) → null (không bị chặn). Logic này xác định xem bài học nào cần hoàn thành TRƯỚC bài học hiện tại.')

heading(doc, 'Phần 6 — resolveStatus() (Dòng 180–191)', 3)
code_block(doc, '''function resolveStatus(item, moduleItems, completedKeys, isCurrent) {
  if (completedKeys.has(item.id))                          return ITEM_STATUS.COMPLETED;
  const prereq = resolvePrerequisite(item, moduleItems);
  if (prereq && !completedKeys.has(prereq.id))             return ITEM_STATUS.LOCKED;
  return isCurrent ? ITEM_STATUS.IN_PROGRESS : ITEM_STATUS.NOT_STARTED;
}''')
explain_text(doc, 'Pure function — 4 bước quyết định trạng thái:')
bullet(doc, 'Đã hoàn thành → COMPLETED')
bullet(doc, 'Có prereq và prereq chưa done → LOCKED (bị chặn)')
bullet(doc, 'Unlocked + là item chưa done đầu tiên trong module → IN_PROGRESS ("bài đang học")')
bullet(doc, 'Còn lại (unlocked nhưng sau IN_PROGRESS) → NOT_STARTED')

heading(doc, 'Phần 7 — computeCourseProgress() — Hàm public duy nhất (Dòng 198–297)', 3)
meta_label(doc, 'Gọi từ đâu', 'student/classroom.controller.js, completion.service.js::checkItemAccess()')
code_block(doc, '''async function computeCourseProgress(classroom, studentId) {
  const classroomId = classroom.id || classroom._id;
  const [items, completedKeys] = await Promise.all([
    buildContentItems(classroomId),
    getCompletedItemKeys(classroomId, studentId),
  ]);
  // ...xử lý modules, status, tính percent
  return {
    progressPercent, totalItems, completedItems,
    currentLesson, nextLesson, lastCompletedLesson, modules,
  };
}''')
explain_text(doc, 'CHỈ 2 batch queries dù classroom có hàng trăm items. Toàn bộ logic tính status, grouping, tính percent đều là pure JavaScript trong memory sau 2 queries đó. Trả object đầy đủ cho view render, không cần view tự tính toán thêm.')
bullet(doc, 'progressPercent: % hoàn thành tổng lớp học')
bullet(doc, 'currentLesson: item đang IN_PROGRESS → nút "Tiếp tục học"')
bullet(doc, 'nextLesson: item NOT_STARTED đầu tiên → nút "Bài tiếp theo"')
bullet(doc, 'modules: mảng các chương, mỗi chương có children với status đã resolve')

divider(doc)

heading(doc, '4.3  services/gradebook.service.js — Tính Điểm Sổ Điểm', 2)

heading(doc, 'Phần 1 — normalizeWeights() (Dòng 33–50)', 3)
meta_label(doc, 'Gọi từ đâu', 'computeGradebook()')
code_block(doc, '''function normalizeWeights(weights) {
  const map = {};
  let total = 0;
  for (const w of weights) {
    if (!w || !w.itemType) continue;
    const weight = Number(w.weight);
    if (!Number.isFinite(weight) || weight < 0) continue;
    map[w.itemType] = (map[w.itemType] || 0) + weight;
    total += weight;
  }
  if (total <= 0) return null;
  for (const key of Object.keys(map)) { map[key] = map[key] / total; }
  return map;
}''')
explain_text(doc, 'Nhận mảng [{itemType, weight}] từ classroom.gradeWeights, normalize về map {itemType: tỷ lệ}. Ví dụ: [{itemType:"EXAM", weight:70}, {itemType:"ASSIGNMENT", weight:30}] → {EXAM:0.7, ASSIGNMENT:0.3}.')
bullet(doc, 'Guard: bỏ qua weight âm, NaN, hoặc thiếu itemType')
bullet(doc, 'total<=0 → return null → caller biết là "không có trọng số", tính trung bình đơn giản')

heading(doc, 'Phần 2 — gradeAverage() (Dòng 64–114)', 3)
meta_label(doc, 'Gọi từ đâu', 'computeGradebook()')
code_block(doc, '''function gradeAverage(scoredItems, normalizedWeights) {
  const byType = {};
  for (const item of scoredItems) {
    if (!(item.maxScore > 0)) continue;  // bỏ qua lecture và chưa chấm
    if (!byType[item.itemType]) byType[item.itemType] = { sum: 0, count: 0 };
    byType[item.itemType].sum += item.percent;
    byType[item.itemType].count += 1;
  }
  // tính typeAverages { EXAM: {percent:82.5, count:2}, ASSIGNMENT: {percent:75, count:3} }
  // nếu có weight: percent = sum(typeAvg * weight) / weightUsed
  // nếu không weight: percent = unweightedAverage(typeAverages)
}''')
explain_text(doc, 'Guard "!(item.maxScore > 0)": loại bỏ lecture (maxScore null) và item chưa chấm (maxScore = 0 hoặc null). Gom nhóm theo itemType, tính tổng phần trăm và đếm số lượng trong mỗi type.')
bullet(doc, 'Có trọng số: overallPercent = EXAM_avg * 0.7 + ASSIGNMENT_avg * 0.3. Ví dụ: 82.5*0.7 + 75*0.3 = 57.75 + 22.5 = 80.25')
bullet(doc, 'Không có trọng số: trung bình đơn giản của tất cả type averages')
bullet(doc, 'Fallback: nếu student không có item nào match weight → dùng unweighted để không trả NaN')

heading(doc, 'Phần 3 — computeGradebook() (Dòng 152–202)', 3)
meta_label(doc, 'Gọi từ đâu', 'teacher/classroom.controller.js::renderGradebook() và exportGradebookCsv()')
code_block(doc, '''async function computeGradebook(classroom, studentId) {
  const query = {
    classroom: classroomId,
    score: { $ne: null },
    maxScore: { $gt: 0 },
  };
  if (studentId) query.student = studentId;
  const rows = await StudentProgress.find(query).lean();

  const byItem = rows.filter(...).map(r => ({
    itemType: r.itemType, itemId: String(r.itemId),
    score: r.score, maxScore: r.maxScore,
    percent: Math.round((r.score / r.maxScore * 100) * 10) / 10,
  }));
  const { percent, byType } = gradeAverage(byItem, normalizedWeights);
  const letter = letterFor(percent, classroom.gradingScale);
  return { classroomId, overallPercent: percent, letter, byItem, byType };
}''')
explain_text(doc, 'Query chỉ lấy rows CÓ ĐIỂM: score != null VÀ maxScore > 0. Lecture rows (score null) tự động bị loại. Tính percent cho từng item = score/maxScore * 100. Sau đó gradeAverage() tổng hợp. letterFor() tra bảng gradingScale để trả chữ cái (A/B/C...).')

divider(doc)

heading(doc, '4.4  services/examIntegrity.service.js — Kiểm Soát Thi Cử Server-Side', 2)

heading(doc, 'Phần 1 — computeDeadline() (Dòng 20–26)', 3)
meta_label(doc, 'Gọi từ đâu', 'student/exam.controller.js::renderTakeExam()')
code_block(doc, '''const SUBMIT_GRACE_MS = 30 * 1000;  // 30 giây

function computeDeadline(startedAt, durationMinutes) {
  const start = new Date(startedAt).getTime();
  if (!Number.isFinite(start)) return null;
  const minutes = Number(durationMinutes);
  if (!Number.isFinite(minutes) || minutes <= 0) return null;
  return new Date(start + minutes * 60 * 1000);
}''')
explain_text(doc, 'Tính deadline tuyệt đối = startedAt + duration phút (tính ra milliseconds). Guard: nếu startedAt invalid hoặc duration <= 0 → return null (exam không giới hạn thời gian). SUBMIT_GRACE_MS = 30s buffer bù trừ network latency và clock skew.')

heading(doc, 'Phần 2 — evaluateDeadline() (Dòng 43–56)', 3)
meta_label(doc, 'Gọi từ đâu', 'student/exam.controller.js::submitExamHandler()')
code_block(doc, '''function evaluateDeadline(deadlineAt, now = new Date()) {
  if (!deadlineAt) return { isLate: false, reason: 'untimed_exam' };
  if (t > deadline + SUBMIT_GRACE_MS)
    return { isLate: true, reason: 'past_deadline' };
  return { isLate: false, reason: 'within_deadline' };
}''')
explain_text(doc, 'Quyết định nộp bài đúng hạn hay muộn. Dùng SERVER clock (new Date()), không phải client timer. Bài nộp muộn: isLate=true → status="late" (vẫn chấm, không mất đáp án). Thiết kế chủ ý: tha hơn là cứng nhắc (flip branch nếu muốn từ chối luôn).')

heading(doc, 'Phần 3 — canStartAttempt() (Dòng 66–72)', 3)
meta_label(doc, 'Gọi từ đâu', 'student/exam.controller.js::renderTakeExam() và renderAllStudentExams()')
code_block(doc, '''function canStartAttempt(submittedCount, maxAttempts) {
  const max = Number(maxAttempts);
  if (!Number.isFinite(max) || max <= 0) return true;  // unlimited
  return count < max;
}''')
explain_text(doc, 'maxAttempts=0 → unlimited → return true. Đếm submittedCount chỉ tính trạng thái terminal (submitted/graded/late/auto_submitted). in_progress KHÔNG tính — học sinh đang làm bài không bị chặn khởi động lại. Guard Number.isFinite để xử lý maxAttempts=undefined hoặc NaN.')

divider(doc)

heading(doc, '4.5  services/completion.service.js — Đánh Giá Hoàn Thành Khóa Học', 2)

heading(doc, 'Phần 1 — checkItemAccess() (Dòng 101–123)', 3)
meta_label(doc, 'Gọi từ đâu', 'student/lecture.controller.js::renderStudentLectureDetail()')
code_block(doc, '''async function checkItemAccess({ classroom, studentId, itemType, itemId }) {
  const tree = await computeCourseProgress(classroom, studentId);
  const key = `${itemType}:${String(itemId)}`;
  for (const module of tree.modules) {
    for (const child of module.children) {
      if (child.id === key) {
        const allowed = child.status !== ITEM_STATUS.LOCKED;
        return { allowed, reason: allowed ? 'ok' : 'prerequisite_incomplete', status: child.status };
      }
    }
  }
  return { allowed: false, reason: 'item_not_published', status: 'UNKNOWN' };
}''')
explain_text(doc, 'Server-side gate: ngăn học sinh bypass bằng cách gõ thẳng URL bài bị khóa. Dùng cùng computeCourseProgress → kết quả NHẤT QUÁN với sidebar (sidebar hiện LOCKED = server cũng chặn, không bao giờ mâu thuẫn). Item không có trong tree → unpublished/sai lớp → từ chối.')

heading(doc, 'Phần 2 — evaluateCompletion() (Dòng 30–88) — Pure Function', 3)
meta_label(doc, 'Gọi từ đâu', 'evaluateClassroomCompletion() bên dưới')
code_block(doc, '''function evaluateCompletion({ completedCount, totalCount, gradePercent, typeCounts, rules }) {
  const met = []; const missing = [];

  // Rule 1: requireAllItems
  const allItemsDone = totalCount <= 0 ? false : completedCount >= totalCount;
  if (!requireAllItems)      met.push('no_requireAllItems');
  else if (allItemsDone)     met.push('all_items_completed');
  else  missing.push(`all_items_completed (${completedCount}/${totalCount})`);

  // Rule 2: minOverallPercent
  if (!hasMinPercent)                              met.push('no_minOverallPercent');
  else if (gradePercent >= minOverallPercent)      met.push(`min_overall_percent (...)`);
  else  missing.push(`min_overall_percent (need ${minOverallPercent})`);

  // Rule 3: requiredItemTypes
  for (const itemType of requiredItemTypes) {
    if (typeCounts[itemType] > 0) met.push(`required_${itemType}`);
    else                          missing.push(`required_${itemType} (need >= 1)`);
  }

  const isComplete = missing.length === 0;
  return { isComplete, isPassing, met, missing };
}''')
explain_text(doc, 'Pure function, không query DB. Nhận evidence đã tổng hợp và kiểm tra từng rule. met[] và missing[] ghi chi tiết → dùng để debug hoặc hiển thị cho học sinh biết còn thiếu gì. isComplete = ALL rules pass (missing.length === 0).')

divider(doc)

heading(doc, '4.6  services/grading.service.js — Chấm Điểm Theo Rubric', 2)

heading(doc, 'Phần 1 — computeRubricTotal() (Dòng 28–45) — Pure Function', 3)
code_block(doc, '''function computeRubricTotal(rubric, gradesMap) {
  for (const c of criteria) {
    const raw = Number(map[String(c._id)]);
    const max = Number(c.maxPoints) || 0;
    const awarded = Number.isFinite(raw)
      ? Math.min(Math.max(raw, 0), max)
      : 0;
    total += awarded;
  }
  return { total, grades };
}''')
explain_text(doc, 'Math.min(Math.max(raw, 0), max): clamp điểm vào [0, maxPoints]. GV không thể cho điểm âm hoặc vượt quá ceiling của criterion. Nếu GV bỏ trống criterion (raw = NaN) → awarded = 0. Pure function, không DB → dễ unit test.')

heading(doc, 'Phần 2 — gradeWithRubric() (Dòng 60–108)', 3)
meta_label(doc, 'Gọi từ đâu', 'teacher/submission.controller.js::rubricGradeHandler()')
code_block(doc, '''async function gradeWithRubric({ submissionId, assignmentId, teacherId, gradesMap }) {
  const assignment = await Assignment.findOne({ _id: assignmentId, teacher: teacherId });
  if (!assignment || !assignment.rubric) throw new AppError('Assignment has no rubric.', 422);

  const rubric = await Rubric.findOne({ _id: assignment.rubric, teacher: teacherId });
  const { total, grades } = computeRubricTotal(rubric, gradesMap);

  submission.rubricGrades = grades;
  submission.score = total;
  submission.status = 'graded';
  submission.gradedAt = new Date();
  await submission.save();

  await markComplete({ ..., evidence: { score: total, maxScore: rubric.maxPoints, ... } });
  return submission;
}''')
explain_text(doc, 'Ownership check: findOne với cả assignmentId AND teacher:teacherId. GV khác thử chấm → không tìm thấy → 422. Sau khi save submission: gọi markComplete() → StudentProgress được cập nhật với điểm mới → gradebook tức thì phản ánh mà không cần query riêng.')

divider(doc)

heading(doc, '4.7  services/exam.service.js', 2)

heading(doc, 'Phần 1 — generateMatrixQuestions() (Dòng 11–59)', 3)
meta_label(doc, 'Gọi từ đâu', 'teacher/exam.controller.js::generateMatrixHandler()')
code_block(doc, '''const matchingQuestions = await QuestionBank.aggregate([
  { $match: { teacher: teacherId, subject, difficulty: reqConfig.difficulty } },
  { $sample: { size: reqConfig.count } }
]);''')
explain_text(doc, '$sample trong MongoDB Aggregation: lấy NGẪU NHIÊN N documents thỏa điều kiện — không cần shuffle trong code, MongoDB tự xử lý. Efficient vì random sampling được optimize ở DB level. Mỗi difficulty level chạy 1 query riêng (nhan_biet, thong_hieu, van_dung).')

heading(doc, 'Phần 2 — gradeSubmission() (Dòng 61–114)', 3)
meta_label(doc, 'Gọi từ đâu', 'teacher/exam.controller.js::submitGradeHandler()')
code_block(doc, '''for (let ans of submission.answers) {
  if (ans.question && ans.question.type === 'essay') {
    const points = Number(answersData[`points_${ans._id}`] || 0);
    ans.pointsAchieved = Math.min(points, ans.question.points);
    ans.teacherComment = answersData[`comment_${ans._id}`] || '';
  }
  totalScore += ans.pointsAchieved;
}
submission.gradingStatus = 'fully_graded';
await submission.save();
await markComplete({ ..., evidence: { score: totalScore, maxScore: exam.totalPoints } });
await sendNotification(submission.student, 'Exam Graded', `Score: ${totalScore}/${exam.totalPoints}`, ...);''')
explain_text(doc, 'Chỉ cho phép sửa câu essay (kiểm tra type). Điểm trắc nghiệm đã chấm máy, GV không thể sửa. Clamp Math.min để không cho quá điểm tối đa của câu. Sau save: markComplete cập nhật StudentProgress, sendNotification báo học sinh biết có kết quả.')

divider(doc)

heading(doc, '4.8  services/meeting.service.js — Quản Lý Họp Online', 2)

heading(doc, 'Phần 1 — syncMeetingStatus() (Dòng 12–41)', 3)
meta_label(doc, 'Gọi từ đâu', 'getActiveOrUpcomingMeeting(), runBackgroundStatusSync()')
code_block(doc, '''async function syncMeetingStatus(meeting, io = null) {
  const now = new Date();
  if (meeting.status === 'SCHEDULED' && now >= startTime && now < endTime) {
    meeting.status = 'LIVE';
    statusChanged = true;
  } else if ((LIVE||SCHEDULED) && now >= endTime) {
    meeting.status = 'ENDED';
    statusChanged = true;
  }
  if (statusChanged) {
    await meeting.save();
    io.of('/meeting').to(`classroom:${meeting.classroom}`).emit('meeting:status_changed', { meeting });
  }
}''')
explain_text(doc, 'Sync trạng thái meeting theo đồng hồ thực. Khi status thay đổi: save vào DB và emit socket event → tất cả client đang ở trang đó nhận event và cập nhật UI ngay không cần reload trang. io được inject từ ngoài (dependency injection pattern).')

heading(doc, 'Phần 2 — createMeeting() (Dòng 81–162)', 3)
code_block(doc, '''const roomId = `room_${classroomId}_${crypto.randomBytes(4).toString('hex')}`;
// ...
if (startNow) { parsedStartTime = now; status = 'LIVE'; }
else          { parsedStartTime = new Date(startTime); status = startTime <= now ? 'LIVE' : 'SCHEDULED'; }
// ...
await Notification.insertMany(notifications);  // bulk notify học sinh
io.of('/meeting').to(`classroom:${classroomId}`).emit('meeting:status_changed', { meeting });''')
explain_text(doc, 'roomId: classroomId + 4 bytes random = 8 hex chars → đủ unique để làm room name WebRTC. Nếu startTime đã qua lúc tạo → set LIVE ngay. Notification.insertMany: 1 bulk query cho N học sinh (thay vì N insert riêng). Emit socket event cho trang lớp học đang mở để hiện banner "Cuộc họp đang diễn ra".')

heading(doc, 'Phần 3 — autoEndEmptyMeeting() (Dòng 258–282)', 3)
meta_label(doc, 'Gọi từ đâu', 'index.js Socket.IO disconnect handler, sau setTimeout 4s')
code_block(doc, '''async function autoEndEmptyMeeting(meetingId, io = null) {
  const meeting = await Meeting.findById(meetingId);
  if (!meeting || meeting.status !== 'LIVE') return null;  // guard
  meeting.status = 'ENDED'; meeting.endTime = new Date();
  await meeting.save();
  io.of('/meeting').to(String(meetingId)).emit('meeting_ended_automatically', {...});
}''')
explain_text(doc, 'Được gọi khi participant cuối rời phòng. setTimeout 4s trước khi gọi hàm này (để tránh end ngay khi người cuối disconnect tạm thời rồi reconnect). Guard "if !LIVE": nếu teacher đã end thủ công trong 4s đó → không end lần 2.')

page_break(doc)

# ══════════════════════════════════════════════════════════════════════════════
# CHƯƠNG 5 — CONTROLLERS
# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 5 — CONTROLLERS (Xử Lý HTTP Request)', 1)
explain_text(doc, 'Controller nhận request, validate input, gọi service/model, trả response. Theo pattern Fat Service – Thin Controller: logic nghiệp vụ nằm ở Service, controller chỉ điều phối.')

heading(doc, '5.1  controller/auth/auth.controller.js', 2)

heading(doc, 'Phần 1 — Hàm login (Dòng ~50–90)', 3)
meta_label(doc, 'Route', 'POST /auth/login (qua loginRateLimit: 10 lần/15 phút, skipSuccessfulRequests=true)')
code_block(doc, '''async function login(req, res, next) {
  // ...validate errors...
  const user = await authenticateUser(email, password);
  const { accessToken, refreshToken } = await buildAuthSession(user);
  res.cookie('accessToken', accessToken, {
    httpOnly: true, maxAge: 15*60*1000, sameSite: 'strict'
  });
  res.cookie('refreshToken', refreshToken, {
    httpOnly: true, maxAge: 7*24*60*60*1000, sameSite: 'strict'
  });
  req.session.regenerate(async err => {
    await req.logIn(user, ...);
    res.redirect(redirectPath);
  });
}''')
explain_text(doc, 'httpOnly: true → JavaScript không đọc được cookie → chặn XSS attack đánh cắp token. sameSite: "strict" → cookie không gửi cross-site → chặn CSRF trong nhiều trường hợp. maxAge khác nhau: accessToken 15 phút, refreshToken 7 ngày.')
bullet(doc, 'req.session.regenerate(): tạo session ID MỚI → chống Session Fixation attack (attacker đã biết session ID cũ không dùng được nữa)')
bullet(doc, 'req.logIn(user): Passport serialize userId vào session mới')

heading(doc, 'Phần 2 — Hàm logout', 3)
meta_label(doc, 'Route', 'POST /auth/logout')
code_block(doc, '''async function logout(req, res, next) {
  await revokeRefreshToken(req.user.id);  // clear hash trong DB
  res.clearCookie('accessToken');
  res.clearCookie('refreshToken');
  req.logout(err => { req.session.destroy(...) });
}''')
explain_text(doc, 'revokeRefreshToken() set refreshTokenHash=null trong DB → refresh token cũ không dùng được nữa dù còn trong cookie. clearCookie xóa cookie. req.logout() Passport xóa user khỏi session. req.session.destroy() xóa session khỏi MongoStore.')

divider(doc)

heading(doc, '5.2  controller/student/classroom.controller.js', 2)

heading(doc, 'Phần 1 — joinClassroomHandler (Dòng 30–73)', 3)
meta_label(doc, 'Route', 'POST /student/classrooms/join')
code_block(doc, '''const code = req.body.code.toUpperCase();
const classroom = await Classroom.findOne({ code, isArchived: false });
if (!classroom) { return res.redirect('/student/classrooms?feedback=...' ); }

const existingMember = await ClassroomMember.findOne({ classroom: classroom.id, student: req.user.id });
if (existingMember) { return res.redirect('...?feedback=Bạn đã ở trong lớp này'); }

const member = new ClassroomMember({
  classroom: classroom.id, student: req.user.id,
  status: classroom.approvalRequired ? 'pending' : 'approved',
});
await member.save();''')
explain_text(doc, 'code.toUpperCase() normalize code nhập vào. findOne với isArchived:false để không cho join lớp đã xóa. Kiểm tra trùng lặp trước khi tạo. status: nếu lớp yêu cầu duyệt → "pending", ngược lại → "approved" ngay. Bắt E11000 (race condition 2 click) → flash message thân thiện.')

heading(doc, 'Phần 2 — renderStudentClassroomDetail (Dòng 76–103)', 3)
meta_label(doc, 'Route', 'GET /student/classrooms/:classroomId')
code_block(doc, '''const member = await ClassroomMember.findOne({
  classroom: req.params.classroomId,
  student: req.user.id
}).populate('classroom');

const courseProgress   = await computeCourseProgress(member.classroom, req.user.id);
const courseCompletion = await evaluateClassroomCompletion(member.classroom, req.user.id);
const activeMeeting    = await meetingService.getActiveOrUpcomingMeeting(member.classroom.id, io);

return res.render('student/classrooms/show', {
  membership: member, courseProgress, courseCompletion, activeMeeting
});''')
explain_text(doc, '3 calls sau khi có membership:')
bullet(doc, 'computeCourseProgress(): cây bài học với status LOCKED/COMPLETED/IN_PROGRESS cho sidebar')
bullet(doc, 'evaluateClassroomCompletion(): đánh giá {isComplete, isPassing, met, missing} để hiện badge "Hoàn thành"')
bullet(doc, 'getActiveOrUpcomingMeeting(): cuộc họp đang live hoặc sắp tới để hiển thị banner')

heading(doc, 'Phần 3 — askAiAssistantHandler (Dòng 105–188)', 3)
meta_label(doc, 'Route', 'POST /api/student/classrooms/:id/ai-assistant')
code_block(doc, '''const [lectures, assignments, exams] = await Promise.all([
  Lecture.find({classroom:classroom.id, isPublished:true}).select('title summary').lean(),
  Assignment.find({...}).select('title description').lean(),
  Exam.find({...}).select('title description').lean()
]);
const context = `Bạn là AI Tutor của lớp "${classroom.name}". Giáo trình: ${lectures.map(l => l.title).join(', ')}...`;
const response = await fetch(`https://generativelanguage.googleapis.com/...?key=${apiKey}`, {
  method: 'POST',
  body: JSON.stringify({ contents: [{ parts: [{ text: context + userMessage }] }] })
});''')
explain_text(doc, 'Xây context string nhúng toàn bộ giáo trình (title của lecture/assignment/exam) vào system prompt. Mỗi AI assistant được "grounded" trong context của đúng lớp học → câu trả lời liên quan đến môn học. API key đọc từ DB (SystemSetting) → admin đổi không cần restart server. Fallback mock nếu không có API key.')

divider(doc)

heading(doc, '5.3  controller/student/lecture.controller.js', 2)

heading(doc, 'Phần 1 — groupLecturesByChapter() (Dòng 8–17)', 3)
code_block(doc, '''function groupLecturesByChapter(lectures) {
  return lectures.reduce((groups, lecture) => {
    if (!groups[lecture.chapterTitle]) groups[lecture.chapterTitle] = [];
    groups[lecture.chapterTitle].push(lecture);
    return groups;
  }, {});
}''')
explain_text(doc, 'Hàm helper gom mảng bài giảng phẳng thành object nhóm theo chapterTitle. Ví dụ đầu vào: [{chapterTitle:"Chương 1", title:"Bài 1"}, {chapterTitle:"Chương 1", title:"Bài 2"}, {chapterTitle:"Chương 2", title:"Bài 3"}]. Đầu ra: {"Chương 1": [Bài 1, Bài 2], "Chương 2": [Bài 3]}. Pug template duyệt object này để render sidebar.')

heading(doc, 'Phần 2 — renderStudentLectureDetail() (Dòng 71–126)', 3)
meta_label(doc, 'Route', 'GET /student/classrooms/:cId/lectures/:lId')
code_block(doc, '''const access = await checkItemAccess({
  classroom: membership.classroom,
  studentId: req.user.id,
  itemType: CONTENT_TYPES.LESSON,
  itemId: lecture._id,
});
if (!access.allowed) {
  return res.status(403).render('errors/403', {
    message: 'Complete the previous item in this module before continuing.'
  });
}''')
explain_text(doc, 'Server-side gate ngăn URL bypass: học sinh không thể gõ thẳng URL bài bị khóa. checkItemAccess dùng cùng computeCourseProgress nên kết quả NHẤT QUÁN với sidebar. Sau đó:')
code_block(doc, '''const messages = await ChatMessage.find({ classroom: membership.classroom.id })
  .populate('sender', 'name avatarUrl')
  .sort({ createdAt: -1 })
  .limit(50);
messages.reverse();''')
explain_text(doc, 'Load 50 tin nhắn gần nhất: sort DESC để lấy 50 mới nhất, rồi reverse để hiển thị cũ trước → mới sau (chronological order trong chat panel).')

heading(doc, 'Phần 3 — markLectureComplete() (Dòng 163–202)', 3)
meta_label(doc, 'Route', 'POST /student/classrooms/:cId/lectures/:lId/complete')
code_block(doc, '''await markComplete({
  student: req.user.id,
  classroom: String(membership.classroom._id || membership.classroom),
  itemType: CONTENT_TYPES.LESSON,
  itemId: lecture._id,
  // không có evidence — lecture không có điểm
});
return res.redirect(`/student/classrooms/.../lectures/${lecture._id}`);''')
explain_text(doc, 'Học sinh click nút "Đã học xong" → gọi route POST này. markComplete() ghi StudentProgress. Redirect về trang bài giảng → lần tải lại, sidebar hiện bài này COMPLETED và bài tiếp theo được mở khóa (không cần page logic riêng).')

divider(doc)

heading(doc, '5.4  controller/student/exam.controller.js — Làm Bài Thi', 2)

heading(doc, 'Phần 1 — renderTakeExam() — Mở bài thi (Dòng 110–191)', 3)
meta_label(doc, 'Route', 'GET /student/classrooms/:cId/exams/:eId/take')
code_block(doc, '''// Bước 1: Đếm lượt đã dùng (atomic)
const usedAttempts = await ExamSubmission.countDocuments({
  exam: exam.id, student: req.user.id, status: { $in: ATTEMPT_STATUSES }
});
if (!canStartAttempt(usedAttempts, exam.maxAttempts)) {
  return res.redirect(`.../result`);
}''')
explain_text(doc, 'ATTEMPT_STATUSES = ["submitted","graded","late","auto_submitted"]. in_progress không tính. countDocuments atomic — không race condition. Vượt limit → redirect sang trang kết quả, không mở bài.')
code_block(doc, '''// Bước 2: Tìm hoặc tạo in_progress attempt
let submission = await ExamSubmission.findOne({ exam, student, status: 'in_progress' });
if (!submission) {
  submission = new ExamSubmission({
    exam: exam.id, student: req.user.id, classroom: classroom.id,
    status: 'in_progress', startedAt: new Date(),
    attemptNumber: usedAttempts + 1,
    deadlineAt: computeDeadline(new Date(), exam.duration),
  });
  try { await submission.save(); }
  catch (err) {
    if (err.code === 11000) return res.redirect('.../result');  // race condition
    throw err;
  }
}''')
explain_text(doc, 'Reuse existing in_progress nếu học sinh quay lại (F5, mở tab mới). Nếu chưa có: tạo mới với deadlineAt tính từ NOW. Bắt E11000 cho race condition (2 request concurrent): chỉ 1 tạo được, cái còn lại redirect.')
code_block(doc, '''// Bước 3: Shuffle nếu exam.shuffle = true
if (exam.shuffle) {
  for (let i = questions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [questions[i], questions[j]] = [questions[j], questions[i]];
  }
  questions.forEach(q => {
    for (let i = q.options.length - 1; i > 0; i--) { /* shuffle options */ }
  });
}''')
explain_text(doc, 'Fisher-Yates shuffle algorithm — đảm bảo mọi hoán vị có xác suất bằng nhau (uniform distribution). Xáo trộn cả thứ tự câu hỏi VÀ options trong từng câu. Không lưu order vào DB → mỗi lần mở lại sẽ có order khác nhau.')

heading(doc, 'Phần 2 — submitExamHandler() — Nộp bài (Dòng 193–286)', 3)
meta_label(doc, 'Route', 'POST /student/classrooms/:cId/exams/:eId/submit')
code_block(doc, '''const submission = await ExamSubmission.findOne({
  _id: req.body.submissionId, exam: exam.id, student: req.user.id, status: 'in_progress'
});
if (!submission) return res.status(400).send('No active submission');''')
explain_text(doc, 'Tìm bài theo cả 4 điều kiện: submissionId, examId, studentId, status="in_progress". Nếu thiếu bất kỳ điều kiện nào → 400. Không thể nộp bài của người khác hay nộp 2 lần.')
code_block(doc, '''for (const q of questions) {
  const studentAnswer = req.body[`q_${q.id}`];
  if (q.type === 'multiple_choice' || q.type === 'multiple_answer') {
    const ansArray = Array.isArray(studentAnswer) ? studentAnswer : [studentAnswer];
    const correctOptionIds = q.options.filter(o => o.isCorrect).map(o => o._id.toString());
    // Exact match: đúng TẤT CẢ đáp án, không thừa không thiếu
    if (correctOptionIds.length === ansArray.length &&
        correctOptionIds.every(id => ansArray.includes(id))) {
      isCorrect = true; pointsAchieved = q.points;
    }
  } else if (q.type === 'essay') {
    text = studentAnswer || ''; hasEssay = true;
  }
  totalScore += pointsAchieved;
}''')
explain_text(doc, 'req.body["q_{questionId}"] chứa câu trả lời. Array.isArray check vì multiple_answer gửi mảng, multiple_choice gửi 1 string. Exact match cho multiple_answer: phải chọn đúng TẤT CẢ, không có partial credit. essay: lưu text, đặt hasEssay=true, điểm = 0 (chờ GV).')
code_block(doc, '''const { isLate } = evaluateDeadline(submission.deadlineAt, submittedAt);
submission.answers  = answers;
submission.score    = totalScore;
submission.status   = isLate ? 'late' : 'submitted';
submission.gradingStatus = hasEssay ? 'pending_manual_grade' : 'auto_graded';

// Client-reported violations are intentionally NOT persisted.
// Violations must originate from authenticated socket events on /exam-monitor.

await submission.save();
if (!hasEssay) { await markComplete({ ..., evidence: { score: totalScore, maxScore: exam.totalPoints } }); }''')
explain_text(doc, 'evaluateDeadline dùng SERVER clock. Bài nộp sau deadline+30s → "late" (vẫn chấm). SECURITY NOTE: req.body.violations BỊ BỎ QUA có chủ ý — violations chỉ ghi từ Socket.IO server-side. markComplete chỉ gọi khi không có essay (đã biết điểm cuối). Essay exams: markComplete gọi sau khi GV chấm trong exam.service.js.')

divider(doc)

heading(doc, '5.5  controller/student/submission.controller.js — Nộp Bài Tập', 2)

heading(doc, 'Phần 1 — createSubmissionHandler() (Dòng 59–135)', 3)
meta_label(doc, 'Route', 'POST /student/classrooms/:cId/assignments/:aId/submission')
code_block(doc, '''if (assignment.dueDate && new Date() > new Date(assignment.dueDate) && !assignment.allowLateSubmission) {
  return res.status(403).render('errors/403', { message: 'This assignment is past its due date...' });
}''')
explain_text(doc, 'Kiểm tra deadline server-side. Dù frontend ẩn nút Nộp sau deadline, client có thể tự gửi POST request (Postman, curl...). Server PHẢI kiểm tra độc lập.')
code_block(doc, '''const submission = await Submission.findOne({ assignment: assignment.id, student: req.user.id });
if (submission) {
  // NỘP LẠI: update bài cũ
  submission.textAnswer = req.body.textAnswer || '';
  submission.status = 'submitted'; submission.submittedAt = new Date();
  await submission.save();
} else {
  // NỘP LẦN ĐẦU: tạo mới
  await Submission.create({ assignment, classroom, teacher, student, textAnswer, attachment, status:'submitted' });
}
await markComplete({ ..., itemType: CONTENT_TYPES.ASSIGNMENT, itemId: assignment.id,
  evidence: { maxScore: assignment.totalPoints, submittedAt }  // score chưa có
});''')
explain_text(doc, 'findOne trước khi create để xử lý nộp lại: update bài cũ thay vì create mới → không vi phạm unique index {assignment, student}. markComplete gọi ngay khi nộp: score = null (chưa chấm), maxScore có sẵn. Khi GV chấm: gọi lại markComplete với score mới → update bản ghi cũ.')

divider(doc)

heading(doc, '5.6  controller/teacher/classroom.controller.js', 2)

heading(doc, 'Phần 1 — createClassroomHandler() (Dòng 40–63)', 3)
meta_label(doc, 'Route', 'POST /teacher/classrooms')
code_block(doc, '''const classroom = new Classroom({
  name: req.body.name,
  description: req.body.description || '',
  teacher: req.user.id,
  approvalRequired: req.body.approvalRequired !== 'false',
});
await classroom.save();
// pre-validate hook tự động sinh code
return res.redirect(`/teacher/classrooms/${classroom.id}?feedback=...`);''')
explain_text(doc, 'approvalRequired: req.body.approvalRequired !== "false" — HTML form gửi string "true"/"false", nên phải compare với "false" (không dùng Boolean() vì Boolean("false") = true). Sau classroom.save(), pre-validate hook tự chạy và sinh code ngẫu nhiên — controller không cần làm gì thêm.')

heading(doc, 'Phần 2 — renderGradebook() (Dòng 235–278)', 3)
meta_label(doc, 'Route', 'GET /teacher/classrooms/:classroomId/gradebook')
code_block(doc, '''const members = await ClassroomMember.find({ classroom: classroom.id, status: 'approved' })
  .populate('student', 'name email').sort({ requestedAt: -1 });

const rows = await Promise.all(
  members.map(async m => {
    const studentId = m.student ? String(m.student._id) : null;
    const gradebook = studentId
      ? await computeGradebook({ ...classroom.toObject(), _id: classroom.id }, studentId)
      : { overallPercent: 0, letter: null, byType: {} };
    return { member: m, studentName: m.student.name, overallPercent: gradebook.overallPercent,
             letter: gradebook.letter, byType: gradebook.byType };
  })
);''')
explain_text(doc, 'Promise.all với N học sinh: N queries computeGradebook chạy SONG SONG. Lớp 30 học sinh: 30 queries cùng lúc thay vì tuần tự (30 * latency). classroom.toObject() vì computeGradebook cần plain object (Mongoose document không spread được trực tiếp).')

heading(doc, 'Phần 3 — exportGradebookCsv() (Dòng 280–317)', 3)
meta_label(doc, 'Route', 'GET /teacher/classrooms/:classroomId/gradebook/export.csv')
code_block(doc, '''const fields = ['name', 'email', 'overallPercent', 'letter', 'assignmentsAvg', 'examsAvg'];
const parser = new Parser({ fields });
res.setHeader('Content-Type', 'text/csv');
res.setHeader('Content-Disposition', `attachment; filename="gradebook-${classroom.id}.csv"`);
return res.send(parser.parse(data));''')
explain_text(doc, 'Content-Disposition: "attachment" → browser tự download thay vì hiển thị. json2csv Parser nhận array of objects → CSV string. Không lưu file trên server, stream thẳng từ memory tới client.')

divider(doc)

heading(doc, '5.7  controller/teacher/exam.controller.js', 2)

heading(doc, 'Phần 1 — addQuestionHandler() (Dòng 145–208)', 3)
meta_label(doc, 'Route', 'POST /teacher/classrooms/:cId/exams/:eId/questions')
code_block(doc, '''if (type === 'multiple_choice' || type === 'multiple_answer') {
  const optionTexts   = req.body['optionText[]'] || [];
  const optionCorrects = req.body['optionCorrect[]'] || [];
  const texts   = Array.isArray(optionTexts)   ? optionTexts   : [optionTexts];
  const corrects = Array.isArray(optionCorrects) ? optionCorrects : [optionCorrects];
  options = texts
    .map((text, idx) => ({ text: text.trim(), isCorrect: corrects.includes(idx.toString()) }))
    .filter(opt => opt.text.length > 0);
}
const question = new Question({ exam: exam.id, type, content, options, points, order });
await question.save();  // triggers pre-save hook → auto increment exam.totalPoints''')
explain_text(doc, 'HTML form gửi array bằng field name "optionText[]". Express parse thành mảng HOẶC string nếu chỉ 1 option → ép về Array. isCorrect: form gửi các index của options được tick → corrects.includes(idx.toString()). question.save() trigger Question pre-save hook tự cộng điểm vào exam.')

heading(doc, 'Phần 2 — generateMatrixHandler() (Dòng 230–253)', 3)
meta_label(doc, 'Route', 'POST /teacher/classrooms/:cId/exams/:eId/generate-matrix')
code_block(doc, '''const requirements = [
  { difficulty: 'nhan_biet',   count: Number(num_nhan_biet || 0) },
  { difficulty: 'thong_hieu',  count: Number(num_thong_hieu || 0) },
  { difficulty: 'van_dung',    count: Number(num_van_dung || 0) }
];
const { generateMatrixQuestions } = require('../../services/exam.service');
const generatedCount = await generateMatrixQuestions(req.params.examId, req.user._id, subject, chapter, requirements);''')
explain_text(doc, 'require() inside function (lazy import) để tránh circular dependency tại thời điểm module load. 3 mức độ khó theo chuẩn Bloom/THPT: nhận biết, thông hiểu, vận dụng. Gọi exam.service.js dùng MongoDB $sample để random câu từ QuestionBank.')

divider(doc)

heading(doc, '5.8  controller/teacher/submission.controller.js — Chấm Bài Tập', 2)

heading(doc, 'Phần 1 — gradeSubmissionHandler() (Dòng 84–147)', 3)
meta_label(doc, 'Route', 'POST /teacher/classrooms/:cId/assignments/:aId/submissions/:sId/grade')
code_block(doc, '''const scoreVal = Number(req.body.score);
submission.score = Math.max(0, Math.min(scoreVal, assignment.totalPoints));
submission.teacherComment = req.body.teacherComment || '';
submission.status = 'graded';
submission.gradedAt = new Date();
await submission.save();

await markComplete({
  student: String(submission.student._id || submission.student),
  classroom: String(classroom.id),
  itemType: CONTENT_TYPES.ASSIGNMENT,
  itemId: assignment.id,
  evidence: { score: submission.score, maxScore: assignment.totalPoints, submittedAt: submission.submittedAt },
});''')
explain_text(doc, 'Math.max(0, Math.min(scoreVal, totalPoints)): clamp điểm vào [0, totalPoints] — GV không thể cho điểm âm hoặc vượt quá tối đa. Sau save submission: gọi markComplete() để update StudentProgress với điểm thực tế → gradebook tự động cập nhật ngay không cần query riêng.')

heading(doc, 'Phần 2 — rubricGradeHandler() (Dòng 189–211)', 3)
meta_label(doc, 'Route', 'POST .../grade-rubric')
code_block(doc, '''const gradesMap = {};
for (const [key, value] of Object.entries(req.body)) {
  if (key.startsWith('crit_')) {
    gradesMap[key.slice('crit_'.length)] = value;
  }
}
await gradeWithRubric({ submissionId, assignmentId, teacherId: req.user.id, gradesMap });''')
explain_text(doc, 'Form gửi field tên dạng "crit_{criterionId}". Duyệt req.body, lọc chỉ key bắt đầu "crit_", cắt prefix 5 ký tự để lấy criterionId thuần. Kết quả: {criterionId1: "8", criterionId2: "5"}. Truyền vào gradeWithRubric() để validate và tính tổng.')

divider(doc)

heading(doc, '5.9  controller/admin/classroom.controller.js', 2)
explain_text(doc, 'Đây là file ví dụ mẫu trong yêu cầu. Admin chỉ có quyền xem (read-only), không sửa/xóa lớp học.')

heading(doc, 'Phần 1 — Import và Hằng số (Dòng 1–6)', 3)
code_block(doc, '''const Classroom = require('../../models/Classroom');
const Lecture   = require('../../models/Lecture');
const Exam      = require('../../models/Exam');
const ClassroomMember = require('../../models/ClassroomMember');

const PAGE_SIZE = 20;''')
explain_text(doc, '4 Model MongoDB được import để truy vấn dữ liệu. File này không import Service hay Helper nào, vì đây là màn hình Admin chỉ đọc (read-only), không có business logic phức tạp. PAGE_SIZE = 20: hằng số cố định, mỗi trang hiển thị tối đa 20 lớp.')

heading(doc, 'Phần 2 — Hàm listClassrooms (Dòng 8–37)', 3)
meta_label(doc, 'Gọi từ đâu', 'Route GET /admin/classrooms (và GET /admin/classrooms?q=...&page=2)')
code_block(doc, '''const page = Math.max(1, parseInt(req.query.page) || 1);''')
explain_text(doc, 'Đọc tham số ?page= từ URL. parseInt parse thành số nguyên. || 1 đảm bảo nếu không có ?page= thì mặc định là trang 1. Math.max(1, ...) ngăn người dùng truyền ?page=-5 hoặc ?page=0.')
code_block(doc, '''const query = {};
if (req.query.q) {
  const search = req.query.q.trim();
  query.name = { $regex: search, $options: 'i' };
}''')
explain_text(doc, 'Tính năng tìm kiếm theo tên lớp. Nếu URL có ?q=Python → query MongoDB trở thành { name: { $regex: "Python", $options: "i" } }. $options: "i" là case-insensitive (không phân biệt HOA/thường). Nếu không có ?q= thì query = {} → lấy tất cả.')
code_block(doc, '''const total = await Classroom.countDocuments(query);
const totalPages = Math.ceil(total / PAGE_SIZE);''')
explain_text(doc, 'countDocuments(query) đếm tổng số lớp thỏa điều kiện tìm kiếm (không phải tổng lớp trong DB). Math.ceil làm tròn lên vì 41 lớp ÷ 20 = 2.05 → cần 3 trang, không phải 2.')
code_block(doc, '''const classrooms = await Classroom.find(query)
  .populate('teacher', 'name email')
  .sort({ createdAt: -1 })
  .skip((page - 1) * PAGE_SIZE)
  .limit(PAGE_SIZE);''')
explain_text(doc, 'Lấy đúng 20 lớp của trang hiện tại:')
bullet(doc, '.populate("teacher", "name email") — thay field teacher (ObjectId) thành object {name, email}. Không populate password hay thông tin nhạy cảm')
bullet(doc, '.sort({ createdAt: -1 }) — lớp mới tạo nhất hiện lên trên cùng')
bullet(doc, '.skip((page-1) * PAGE_SIZE) — trang 1 skip 0, trang 2 skip 20, trang 3 skip 40')
bullet(doc, '.limit(PAGE_SIZE) — chỉ lấy tối đa 20 document')

heading(doc, 'Phần 3 — Hàm showClassroom (Dòng 39–62)', 3)
meta_label(doc, 'Gọi từ đâu', 'Route GET /admin/classrooms/:classroomId')
code_block(doc, '''const classroom = await Classroom.findById(req.params.classroomId)
  .populate('teacher', 'name email');
if (!classroom) {
  return res.redirect('/admin/classrooms');
}''')
explain_text(doc, 'Tìm lớp học theo ID trong URL. .populate("teacher") để hiển thị tên giáo viên thay vì ObjectId thô. Nếu không tìm thấy (ID sai hoặc đã xóa) → redirect thẳng về danh sách, không báo 404 (đây là lựa chọn thiết kế của tác giả).')
code_block(doc, '''const [students, lectures, exams] = await Promise.all([
  ClassroomMember.countDocuments({ classroom: classroom.id, status: 'approved' }),
  Lecture.countDocuments({ classroom: classroom.id }),
  Exam.countDocuments({ classroom: classroom.id }),
]);''')
explain_text(doc, 'Chạy 3 query song song (cùng lúc, không phải tuần tự) nhờ Promise.all:')
bullet(doc, 'Query 1: đếm số học sinh đã được duyệt (chỉ status: "approved", loại pending/rejected)')
bullet(doc, 'Query 2: đếm tổng số bài giảng của lớp (kể cả chưa publish)')
bullet(doc, 'Query 3: đếm tổng số bài thi của lớp')
explain_text(doc, 'Dùng Promise.all thay vì 3 await liên tiếp → tiết kiệm ~60% thời gian vì 3 query chạy đồng thời.')
code_block(doc, '''return res.render('admin/classrooms/show', {
  title: classroom.name,
  classroom,
  stats: { students, lectures, exams }
});''')
explain_text(doc, 'Render view views/admin/classrooms/show.pug. Truyền object stats chứa 3 con số đếm, view dùng để hiển thị dạng thẻ thống kê (ví dụ: "32 học sinh | 8 bài giảng | 2 bài thi").')

page_break(doc)

# ══════════════════════════════════════════════════════════════════════════════
# CHƯƠNG 6 — INDEX.JS (Entry Point)
# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 6 — index.js (Entry Point & Socket.IO Namespaces)', 1)
explain_text(doc, 'File khởi động toàn bộ server. Đăng ký middleware theo thứ tự, mount routes, thiết lập 3 Socket.IO namespaces: /exam-monitor, /chat, /meeting.')

heading(doc, 'Phần 1 — Security Middleware Stack', 2)
code_block(doc, '''app.use(helmet());
app.use(xss());
app.use(rateLimit({ windowMs: 15*60*1000, max: 200, message: 'Too many requests' }));
const loginRateLimit = rateLimit({ windowMs: 15*60*1000, max: 10, skipSuccessfulRequests: true });''')
explain_text(doc, 'Thứ tự quan trọng — chạy từ trên xuống dưới:')
bullet(doc, 'helmet(): set security headers (X-Frame-Options ngăn clickjacking, CSP hạn chế script sources, HSTS bắt HTTPS...)')
bullet(doc, 'xss(): sanitize HTML trong req.body — ngăn stored XSS')
bullet(doc, 'rateLimit global: 200 requests/15 phút/IP — ngăn DDoS và scraping')
bullet(doc, 'loginRateLimit: 10 lần/15 phút/IP, skipSuccessfulRequests=true — chỉ đếm failed login → ngăn brute-force password')

heading(doc, 'Phần 2 — Socket.IO /exam-monitor Namespace', 2)
code_block(doc, '''const examMonitor = io.of('/exam-monitor');
examMonitor.use(socketAuthMiddleware);
examMonitor.on('connection', socket => {
  socket.on('cheat-violation', async data => {
    const submission = await ExamSubmission.findOne({
      exam: data.examId, student: socket.userId, status: 'in_progress'
    });
    if (!submission) return;
    if (submission.violations.length < 200) {  // giới hạn unbounded growth
      submission.violations.push({
        type: data.type, time: new Date(),
        details: String(data.details || '').slice(0, 500)  // giới hạn payload
      });
      await submission.save();
    }
    examMonitor.to(data.examId).emit('student-violation', { studentId: socket.userId, violation: ... });
  });
});''')
explain_text(doc, 'socketAuthMiddleware verify JWT hoặc session cookie → socket.userId được authenticate trước khi nhận event. Mọi ghi từ socket đều dùng socket.userId (server-controlled), không tin clientId từ data. .slice(0, 500): giới hạn details để tránh payload lớn. limit 200 violations để tránh array vô hạn trong 1 document. Emit tới room examId → GV monitor nhận realtime.')

heading(doc, 'Phần 3 — Background Job Sync Meeting (Dòng ~cuối file)', 2)
code_block(doc, '''setInterval(() => {
  meetingService.runBackgroundStatusSync(io);
}, 15000);''')
explain_text(doc, 'Background job chạy mỗi 15 giây: quét tất cả meeting SCHEDULED/LIVE, gọi syncMeetingStatus() để so sánh với giờ thực. Nếu startTime đã qua → LIVE. Nếu endTime đã qua → ENDED. Mỗi status change đều emit socket event → UI client tự cập nhật không cần reload.')

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# TỔNG KẾT
# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'TỔNG KẾT — Các Pattern Quan Trọng Cần Nhớ', 1)

heading(doc, 'Pattern 1 — Completion Ledger (StudentProgress là trung tâm)', 2)
code_block(doc, '''// Tất cả đều funneling qua 1 điểm ghi duy nhất:
helper/progress.js::markComplete()
  ← student/lecture.controller.js     (học xong bài giảng)
  ← student/submission.controller.js  (nộp bài tập)
  ← student/exam.controller.js        (nộp bài thi trắc nghiệm)
  ← services/exam.service.js          (GV chấm xong bài thi tự luận)
  ← teacher/submission.controller.js  (GV chấm bài tập)
  ← services/grading.service.js       (GV chấm bằng rubric)''')
explain_text(doc, 'Idempotent + Upsert: gọi 1 lần hay 100 lần đều cho kết quả như nhau. Không có race condition nhờ MongoDB unique index. Toàn bộ gradebook, progress tree, và completion check đều đọc từ StudentProgress này.')

heading(doc, 'Pattern 2 — Compute, Never Store (Không cache trạng thái derived)', 2)
code_block(doc, '''// courseProgress.service.js::computeCourseProgress()
// → Tính LOCKED/COMPLETED/IN_PROGRESS mỗi request, không lưu vào DB
// → Chỉ lưu facts (StudentProgress), tính derived state từ facts

// gradebook.service.js::computeGradebook()
// → Tính điểm mỗi request, không có GradeCache collection
// → Thay đổi điểm → gradebook tự động phản ánh ngay lập tức''')
explain_text(doc, 'Lợi ích: không bao giờ bị stale state, không cần trigger/event để cập nhật derived data. Chấp nhận compute overhead đổi lấy simplicity và correctness.')

heading(doc, 'Pattern 3 — Server-side Security (Không tin client)', 2)
code_block(doc, '''// 1. Deadline enforcement: dùng SERVER clock, không tin client timer
const { isLate } = evaluateDeadline(submission.deadlineAt, new Date());

// 2. Violations: chỉ ghi từ Socket.IO server-side, KHÔNG đọc req.body.violations
//    → học sinh không thể xóa hay giả mạo log vi phạm

// 3. Content locking: checkItemAccess() server-side gate
//    → không thể bypass bằng cách gõ thẳng URL''')
explain_text(doc, 'Security phải enforce ở server, không chỉ ở UI. Frontend là "untrusted territory".')

# ── SAVE ──────────────────────────────────────────────
os.makedirs(os.path.dirname(OUT), exist_ok=True)
doc.save(OUT)
print(f"SUCCESS: {OUT}")
