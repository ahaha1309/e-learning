const fs = require('fs');

let file = fs.readFileSync('views/admin/settings.pug', 'utf8');
const isCrlf = file.includes('\r\n');
file = file.replace(/\r\n/g, '\n');

const certBlock = `          .flex.items-start.justify-between.gap-4.p-6.border-b.border-border
            .space-y-1.pr-6
              p.font-bold.text-sm Chứng chỉ
              p.text-xs.text-muted-foreground Cho phép cấp chứng chỉ hoàn thành.
            label.relative.inline-flex.items-center.cursor-pointer(for='certificateEnabled')
              input#certificateEnabled.peer.sr-only(type='checkbox', name='certificateEnabled', value='true', checked=config.certificateEnabled !== false)
              .w-10.h-6.bg-muted.rounded-full.border.border-input.transition-colors(class='peer-checked_bg-primary peer-checked_border-primary')
              .absolute.left-1.top-1.bg-white.w-4.h-4.rounded-full.transition-transform(class='peer-checked_translate-x-4')
`;

if (file.includes(certBlock)) {
  file = file.replace(certBlock, '');
  if (isCrlf) file = file.replace(/\n/g, '\r\n');
  fs.writeFileSync('views/admin/settings.pug', file, 'utf8');
  console.log('Removed certificate from views/admin/settings.pug');
} else {
  console.log('certBlock not found');
}

