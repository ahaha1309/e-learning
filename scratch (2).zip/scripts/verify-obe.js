const mongoose = require('mongoose');
const Outcome = require('../models/Outcome');
const StudentOutcomeResult = require('../models/StudentOutcomeResult');
const Classroom = require('../models/Classroom');
const Exam = require('../models/Exam');
const Question = require('../models/Question');
const ExamSubmission = require('../models/ExamSubmission');
const User = require('../models/User');
const { calculateOutcomeAttainments } = require('../controller/student/obe.controller');

require('dotenv').config();
const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/e-learning';

mongoose.connect(MONGO_URL).then(async () => {
  console.log('Connected to database successfully.');

  // Find a sample student, classroom, and exam
  const student = await User.findOne({ role: 'student' });
  const classroom = await Classroom.findOne();
  if (!student || !classroom) {
    console.log('No student or classroom found. Seed DB first using: npm run seed');
    await mongoose.disconnect();
    return;
  }

  const exam = await Exam.findOne({ classroom: classroom._id });
  if (!exam) {
    console.log(`No exam found for classroom: ${classroom.name}. Cannot test question mapping.`);
    await mongoose.disconnect();
    return;
  }

  const questions = await Question.find({ exam: exam._id });
  if (questions.length === 0) {
    console.log(`No questions found in exam: ${exam.title}. Please add questions first.`);
    await mongoose.disconnect();
    return;
  }

  console.log(`Testing with student: ${student.name}, Classroom: ${classroom.name}, Exam: ${exam.title}`);

  // 1. Create a sample PLO
  let plo = await Outcome.findOne({ code: 'PLO_TEST' });
  if (!plo) {
    plo = new Outcome({
      code: 'PLO_TEST',
      type: 'PLO',
      description: 'Khả năng áp dụng kiến thức kỹ thuật vào thực tế (PLO Test)'
    });
    await plo.save();
    console.log('Created sample PLO.');
  }

  // 2. Create a sample CLO
  let clo = await Outcome.findOne({ code: 'CLO_TEST', classroom: classroom._id });
  if (!clo) {
    clo = new Outcome({
      code: 'CLO_TEST',
      type: 'CLO',
      description: 'Sinh viên tính toán thành công động năng $W_d = \\frac{1}{2}mv^2$ (CLO Test)',
      classroom: classroom._id,
      mappedPLOs: [{ plo: plo._id, weight: 1.5 }]
    });
    await clo.save();
    console.log('Created sample CLO.');
  }

  // 3. Map first question to the CLO
  const testQuestion = questions[0];
  testQuestion.outcomeMappings = [{ clo: clo._id, weight: 1.0 }];
  await testQuestion.save();
  console.log(`Mapped question "${testQuestion.content}" to CLO_TEST.`);

  // 4. Recreate a clean submission to test 100% attainment
  await ExamSubmission.deleteMany({ exam: exam._id, student: student._id });
  submission = new ExamSubmission({
    exam: exam._id,
    student: student._id,
    classroom: classroom._id,
    status: 'graded',
    answers: [{
      question: testQuestion._id,
      pointsAchieved: testQuestion.points || 1
    }],
    score: testQuestion.points || 1
  });
  await submission.save();
  console.log('Simulated a fresh graded exam submission.');

  // 5. Run aggregation via controller
  console.log('Calculating outcome attainments...');
  const result = await calculateOutcomeAttainments(student._id, classroom._id);
  console.log('Calculation result:', result);

  // 6. Query cached results
  const cachedResults = await StudentOutcomeResult.find({ student: student._id, classroom: classroom._id }).populate('outcome');
  console.log('\n=== Cached OBE Results in DB ===');
  cachedResults.forEach(r => {
    console.log(`Outcome: ${r.outcome.code} (${r.outcome.type}) -> Achieved: ${r.achievedPercent}%, Passed: ${r.isPassed}`);
  });

  await mongoose.disconnect();
  console.log('Disconnected.');
}).catch(err => {
  console.error(err);
});
