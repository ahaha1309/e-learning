"""
Generates 08_Code_Walkthrough_Complete.docx
Covers ALL 11 MAJOR BUSINESS FLOWS of the project with HIGH-DETAIL CODE BLOCKS.
"""
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT_PATH = r"C:\Users\vanha\Downloads\Documentations_DOCX\08_Code_Walkthrough_Complete.docx"

def new_doc():
    doc = Document()
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    return doc

def h(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    if p.runs:
        run = p.runs[0]
        run.font.name = 'Calibri'
        colors = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
                  3: RGBColor(0x1A,0x6A,0x1A), 4: RGBColor(0x66,0x33,0x00)}
        run.font.color.rgb = colors.get(level, RGBColor(0,0,0))
        sizes  = {1: 16, 2: 14, 3: 12, 4: 11}
        run.font.size = Pt(sizes.get(level, 11))
    return p

def code_block(doc, code_text):
    for line in code_text.split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent   = Inches(0.35)
        p.paragraph_format.space_before  = Pt(0)
        p.paragraph_format.space_after   = Pt(0)
        r = p.add_run(line if line.strip() else ' ')
        r.font.name  = 'Courier New'
        r.font.size  = Pt(9)
        r.font.color.rgb = RGBColor(0x17,0x5E,0x24)
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'),   'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'),  'F2F2F2')
        p._p.get_or_add_pPr().append(shd)

def explain_text(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after  = Pt(8)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)
    return p

def divider(doc):
    p = doc.add_paragraph('─' * 90)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after  = Pt(6)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0xAA,0xAA,0xAA)
        r.font.size = Pt(8)

doc = new_doc()

# ── TITLE PAGE ──
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run("08. CODE WALKTHROUGH — TỔNG HỢP TOÀN BỘ NGHIỆP VỤ\nE-Learning LMS – Node.js / Express / MongoDB")
r.font.name = 'Calibri'; r.font.size = Pt(22); r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)
explain_text(doc, "Tài liệu này bao quát TOÀN BỘ CÁC LUỒNG NGHIỆP VỤ (Business Logic) cốt lõi của dự án, trace trực tiếp từ Route tới Controller, Service và Model.")
divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 1: ĐĂNG KÝ (REGISTER)", 1)
explain_text(doc, "Người dùng đăng ký tài khoản và mã hoá mật khẩu.")
h(doc, "Bước 1.1: Controller gọi Service (controller/auth/auth.service.js)", 2)
code_block(doc, '''async function registerUser(userData) {
  const existingUser = await User.findOne({ email: userData.email });
  if (existingUser) throw new AppError(409, 'Email already exists');

  // Teacher đăng ký thì status là pending, cần admin duyệt
  const status = userData.role === 'teacher' ? 'pending' : 'active';
  
  const user = new User({ ...userData, status });
  await user.save(); // Model có pre-save hook tự động bcrypt password
  return user;
}''')
explain_text(doc, "Kiểm tra trùng lặp email. Nếu là giáo viên thì chặn trạng thái 'pending'. Hàm user.save() sẽ tự động kích hoạt Mongoose Middleware (pre-save) bên trong User.js để băm mật khẩu (bcrypt.hash).")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 2: ĐĂNG NHẬP & BẢO MẬT (LOGIN)", 1)
h(doc, "Bước 2.1: Controller xử lý JWT & Cookie (controller/auth/auth.controller.js)", 2)
code_block(doc, '''const { user, accessToken, refreshToken } = await authService.authenticateUser(email, password);

res.cookie('accessToken', accessToken, { httpOnly: true, secure: true, maxAge: 15 * 60 * 1000 });
res.cookie('refreshToken', refreshToken, { httpOnly: true, secure: true, maxAge: 7 * 24 * 60 * 60 * 1000 });

req.session.regenerate(() => {
  req.logIn(user, () => {
    res.redirect(user.role === 'teacher' ? '/teacher' : '/student');
  });
});''')
explain_text(doc, "Cấp cặp Token Access/Refresh và gán vào HttpOnly Cookie để chặn XSS. Regenerate Session ID để chống Session Fixation (Chiếm quyền phiên làm việc).")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 3: QUẢN LÝ LỚP HỌC (CLASSROOM)", 1)
h(doc, "Bước 3.1: Học sinh tham gia lớp bằng mã (controller/student/classroom.controller.js)", 2)
code_block(doc, '''async function joinClassroomHandler(req, res, next) {
  const code = req.body.code.trim().toUpperCase();
  const classroom = await Classroom.findOne({ code, isArchived: false });
  
  if (!classroom) return res.redirect('/student/classrooms/join?feedback=Invalid code');
  
  const status = classroom.approvalRequired ? 'pending' : 'approved';
  await ClassroomMember.create({ classroom: classroom.id, student: req.user.id, status });
}''')
explain_text(doc, "Học sinh nhập mã Code (tự generate ngẫu nhiên 6 ký tự lúc tạo lớp). Căn cứ vào biến approvalRequired của lớp mà duyệt thẳng ('approved') hoặc bắt chờ duyệt ('pending').")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 4: BÀI TẬP & CHẤM ĐIỂM (ASSIGNMENT & GRADING)", 1)
h(doc, "Bước 4.1: Chấm điểm bài nộp bằng Rubric (services/grading.service.js)", 2)
code_block(doc, '''async function gradeWithRubric(assignmentId, submissionId, rubricId, gradesMap) {
  const rubric = await Rubric.findById(rubricId);
  let totalScore = 0;
  const rubricGrades = [];

  for (const criterion of rubric.criteria) {
    const points = gradesMap[criterion._id.toString()] || 0;
    const clampedPoints = Math.min(Math.max(Number(points), 0), criterion.maxPoints);
    totalScore += clampedPoints;
    rubricGrades.push({ criterion: criterion._id, points: clampedPoints });
  }
  
  await Submission.findByIdAndUpdate(submissionId, { score: totalScore, rubricGrades, status: 'graded' });
  return totalScore;
}''')
explain_text(doc, "Teacher nhập điểm theo từng tiêu chí (Criterion) của Rubric. Backend dùng gradesMap để đối chiếu, kẹp (clamp) điểm tránh việc nhập lố (ví dụ tiêu chí tối đa 5 điểm thì không thể nhập 6).")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 5: TIẾN ĐỘ KHÓA HỌC & KHÓA BÀI (PROGRESS ENGINE)", 1)
h(doc, "Bước 5.1: Xây dựng Syllabus Tree (services/courseProgress.service.js)", 2)
code_block(doc, '''const completedRecords = await StudentProgress.find({ classroom: classroomId, student: studentId });
const completedKeys = new Set(completedRecords.map(r => `${r.itemType}:${r.itemId}`));

for (let i = 0; i < allItems.length; i++) {
  const item = allItems[i];
  if (completedKeys.has(`${item.type}:${item.id}`)) {
    item.status = 'COMPLETED';
  } else if (!hasFoundInProgress) {
    item.status = 'IN_PROGRESS';
    hasFoundInProgress = true;
  } else {
    item.status = 'LOCKED';
  }
}''')
explain_text(doc, "Truy vấn lịch sử đọc/làm bài của học sinh. Dùng thuật toán tuần tự (Waterfall) để khoá toàn bộ tài liệu NẰM SAU bài học đầu tiên chưa hoàn thành (hasFoundInProgress).")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 6: THI TRẮC NGHIỆM GIÁM SÁT (PROCTORED EXAM)", 1)
h(doc, "Bước 6.1: Nộp bài và Phạt trễ (controller/student/exam.controller.js)", 2)
code_block(doc, '''const GRACE_PERIOD_MS = 30000; 
const now = new Date();

if (submission.deadlineAt && now.getTime() > submission.deadlineAt.getTime() + GRACE_PERIOD_MS) {
  submission.status = 'late';
} else {
  submission.status = 'submitted';
}

// Bắt gian lận Socket
examMonitor.on('cheat-violation', async (data) => {
  submission.violations.push({ type: data.type, time: new Date() });
  examMonitor.to(submission.exam).emit('student-violation', { studentId: socket.userId, type: data.type });
});''')
explain_text(doc, "Deadline phụ thuộc vào đồng hồ Server, chống việc học sinh đổi múi giờ trên máy tính cá nhân. Việc ghi nhận gian lận (switch tab) thực hiện qua WebSocket theo thời gian thực và đẩy ngay lên màn hình Dashboard của giáo viên đang coi thi.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 7: TÍNH TỔNG KẾT SỔ ĐIỂM (GRADEBOOK)", 1)
h(doc, "Bước 7.1: Tính toán On-the-fly (services/gradebook.service.js)", 2)
code_block(doc, '''function gradeAverage(progresses, weights) {
  const typeAverages = {}; // Ví dụ: EXAM: 85%, ASSIGNMENT: 75%
  let overallPercent = 0;
  let weightUsed = 0;

  for (const [type, data] of Object.entries(typeAverages)) {
    if (weights[type]) {
      overallPercent += data.percent * weights[type];
      weightUsed += weights[type];
    }
  }
  return weightUsed ? (overallPercent / weightUsed) : 0;
}''')
explain_text(doc, "Điểm tổng kết KHÔNG được lưu cứng vào database mà được tính toán lại (compute-on-the-fly) mỗi lần giáo viên mở Sổ Điểm. Hệ số (Weights) do GV tuỳ chỉnh (Ví dụ: Thi 70%, Bài tập 30%) sẽ nhân với trung bình cộng của từng loại.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 8: HỌP TRỰC TUYẾN WEBRTC (ONLINE MEETING)", 1)
h(doc, "Bước 8.1: Socket Signaling (index.js)", 2)
code_block(doc, '''socket.on('join-room', (data) => {
  socket.join(data.meetingId);
  // Nếu là giáo viên thì add thẳng, nếu là học sinh thì bỏ vào waiting room
  if (data.userRole === 'teacher') {
    meetingRooms[data.meetingId].push(socket.id);
  } else {
    waitingRooms[data.meetingId].push(socket.id);
    io.to(teacherSocketId).emit('waiting_students_list', waitingRooms);
  }
});''')
explain_text(doc, "Sử dụng WebRTC để P2P Audio/Video. Socket.IO đóng vai trò Signaling Server để kết nối các Peer. Hỗ trợ tính năng Waiting Room (Phòng chờ) yêu cầu giáo viên duyệt (approve) mới được push vào array meetingRooms.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 9: NHẮN TIN THEO THỜI GIAN THỰC (REAL-TIME CHAT)", 1)
h(doc, "Bước 9.1: Lưu tin nhắn & Broadcast (services/chat.service.js)", 2)
code_block(doc, '''async function saveDirectMessage(sender, recipient, content) {
  const dm = await DirectMessage.create({ sender, recipient, content });
  await dm.populate('sender', 'name avatarUrl');
  
  // Phát tin nhắn cho cả người gửi và người nhận
  chatMonitor.to(`user:${recipient}`).to(`user:${sender}`).emit('receive_direct_message', dm);
  return dm;
}''')
explain_text(doc, "Lưu tin nhắn vào MongoDB, sau đó Emit event 'receive_direct_message' tới room ảo định danh cho user nhận (`user:{recipientId}`). Nhờ đó có thể chat 1-1 mà không cần load lại trang.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 10: TÍCH HỢP TRỢ LÝ AI (GEMINI ASSISTANT)", 1)
h(doc, "Bước 10.1: Gom context và gọi API (controller/student/classroom.controller.js)", 2)
code_block(doc, '''const contextString = `Classroom has ${lectures.length} lessons, ${assignments.length} assignments...`;
const apiKey = (await SystemSetting.findOne({key: 'geminiApiKey'})).value;

const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${apiKey}`, {
  method: 'POST',
  body: JSON.stringify({ contents: [{ parts: [{ text: contextString + "\\n\\nQuestion: " + userMessage }] }] })
});''')
explain_text(doc, "Tính năng độc đáo: Trợ lý AI được cung cấp Context Awareness (biết được lớp học này đang có bao nhiêu bài giảng, bài tập). Lấy key động từ System Settings của Admin và ném vào prompt của Gemini API.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 11: ĐÁNH GIÁ HOÀN THÀNH & CẤP CHỨNG CHỈ (COMPLETION ENGINE)", 1)
h(doc, "Bước 11.1: Rules-based Evaluation (services/completion.service.js)", 2)
code_block(doc, '''function evaluateCompletion(classroom, progressTree, gradePercent) {
  const rules = classroom.completionRules || {};
  let isComplete = true;

  if (rules.requireAllItems && progressTree.completedCount < progressTree.totalCount) {
    isComplete = false;
  }
  if (rules.minOverallPercent && gradePercent < rules.minOverallPercent) {
    isComplete = false;
  }

  return { isComplete, met, missing };
}''')
explain_text(doc, "Rule Engine phân tích việc học sinh có đạt điều kiện qua môn hay không. Nếu `isComplete == true`, Frontend sẽ tự động mở khoá nút 'Tải chứng chỉ' (Certificate) cho học sinh.")

# ── SAVE ──
os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
doc.save(OUT_PATH)
print(f"SUCCESS: {OUT_PATH}")
