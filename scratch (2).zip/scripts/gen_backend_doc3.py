"""
Generates 03_Backend_Code_Explanation_Full_v2.docx
Phong cách: Đọc CODE THỰC TẾ, giải thích từng dòng/cụm, không dùng mô tả chung chung.
"""
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = r"C:\Users\vanha\Downloads\Documentations_DOCX\03_Backend_Code_Explanation_Full_v2.docx"

# ─── HELPERS ──────────────────────────────────────────────────────────────────
def new_doc():
    doc = Document()
    for sec in doc.sections:
        sec.top_margin = Inches(1); sec.bottom_margin = Inches(1)
        sec.left_margin = Inches(1.2); sec.right_margin = Inches(1.2)
    return doc

def h(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    r = p.runs[0] if p.runs else p.add_run(text)
    r.font.name = 'Calibri'
    colors = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
              3: RGBColor(0x1A,0x6A,0x1A), 4: RGBColor(0x33,0x33,0x99)}
    sizes  = {1: 16, 2: 13, 3: 11, 4: 10}
    r.font.color.rgb = colors.get(level, RGBColor(0,0,0))
    r.font.size = Pt(sizes.get(level, 11))
    return p

def para(doc, text, bold=False, italic=False, color=None, size=10.5):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold; r.italic = italic
    r.font.name = 'Calibri'; r.font.size = Pt(size)
    if color: r.font.color.rgb = color
    return p

def code_block(doc, lines):
    """Hiển thị đoạn code màu xanh lá, nền xám."""
    for line in lines.strip().split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.4)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after  = Pt(0)
        r = p.add_run(line if line else ' ')
        r.font.name = 'Courier New'; r.font.size = Pt(9)
        r.font.color.rgb = RGBColor(0x1A,0x6A,0x1A)
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'),'clear'); shd.set(qn('w:color'),'auto')
        shd.set(qn('w:fill'),'F0F4F0')
        p._p.get_or_add_pPr().append(shd)

def explain(doc, code_text, explanation, indent=0.5):
    """Code snippet + mũi tên giải thích."""
    cp = doc.add_paragraph()
    cp.paragraph_format.left_indent = Inches(indent)
    cr = cp.add_run(code_text)
    cr.font.name = 'Courier New'; cr.font.size = Pt(9)
    cr.font.color.rgb = RGBColor(0x00,0x44,0x88)
    shd = OxmlElement('w:shd'); shd.set(qn('w:val'),'clear')
    shd.set(qn('w:color'),'auto'); shd.set(qn('w:fill'),'EEF4FF')
    cp._p.get_or_add_pPr().append(shd)

    ep = doc.add_paragraph()
    ep.paragraph_format.left_indent = Inches(indent + 0.2)
    ep.paragraph_format.space_before = Pt(0)
    ep.paragraph_format.space_after  = Pt(4)
    arr = ep.add_run('→ ')
    arr.font.color.rgb = RGBColor(0xAA,0x00,0x00); arr.bold = True
    er = ep.add_run(explanation)
    er.font.name = 'Calibri'; er.font.size = Pt(10.5)

def bullet(doc, text, level=0):
    p = doc.add_paragraph(text, style='List Bullet')
    p.paragraph_format.left_indent = Inches(0.4 + level * 0.3)
    for r in p.runs: r.font.name = 'Calibri'; r.font.size = Pt(10.5)

def divider(doc):
    doc.add_paragraph("─" * 80)

def note(doc, text):
    p = doc.add_paragraph()
    r = p.add_run(f'⚠ LƯU Ý: {text}')
    r.font.name = 'Calibri'; r.font.size = Pt(10.5)
    r.font.color.rgb = RGBColor(0xCC,0x66,0x00); r.bold = True

# ══════════════════════════════════════════════════════════════════════════════
doc = new_doc()

# TITLE
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run('03. GIẢI THÍCH CODE BACKEND TOÀN BỘ\nE-Learning LMS – Node.js / Express / MongoDB')
r.font.name = 'Calibri'; r.font.size = Pt(20); r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)
para(doc, 'Mỗi cụm code được trích nguyên văn từ file thực tế, kèm giải thích chính xác từng dòng làm gì.', italic=True)
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# PHẦN 1 — MODELS
# ══════════════════════════════════════════════════════════════════════════════
h(doc, 'PHẦN 1 — MODELS (Định nghĩa cấu trúc dữ liệu MongoDB)', 1)
para(doc, 'Mỗi Model tương ứng 1 Collection trong MongoDB. Mongoose Schema định nghĩa các fields, kiểu dữ liệu, ràng buộc và hook tự động.', italic=True)

# ── User ──────────────────────────────────────────────────────────────────────
h(doc, '1.1  models/User.js', 2)
para(doc, 'Collection: users — Lưu tất cả tài khoản (admin / teacher / student).', bold=True)

h(doc, 'Các fields quan trọng:', 3)
explain(doc, "passwordHash: { type: String, select: false, default: null }",
    "'select: false' có nghĩa là khi bạn gọi User.find() hay User.findOne() thì MongoDB sẽ KHÔNG tự động trả về field này. Muốn lấy passwordHash phải chủ động thêm .select(\"+passwordHash\"). Đây là biện pháp bảo mật: không bao giờ vô tình trả hash mật khẩu về frontend.")

explain(doc, "role: { type: String, enum: ['admin', 'teacher', 'student'], default: 'student' }",
    "Chỉ cho phép 3 giá trị. Nếu code cố set role='superuser' → Mongoose throw ValidationError trước khi lưu DB. Default là 'student' vì đó là loại tài khoản phổ biến nhất.")

explain(doc, "status: { default: function() { return this.role === 'teacher' ? 'pending' : 'active' } }",
    "Dùng hàm thay vì giá trị cố định để có thể tham chiếu 'this' (document đang được tạo). Logic: teacher mới đăng ký phải chờ admin duyệt (pending), còn student tự động active luôn.")

explain(doc, "refreshTokenHash: { type: String, select: false, default: null }",
    "KHÔNG lưu refresh token trực tiếp. Lưu SHA-256 hash của nó. Nếu DB bị hack, attacker vẫn không có token thật. Giống cách bcrypt bảo vệ password.")

h(doc, 'Instance Methods (hàm gắn vào từng document):', 3)
explain(doc, "userSchema.methods.setPassword = async function(password) { this.passwordHash = await bcrypt.hash(password, 12); this.passwordChangedAt = new Date(); }",
    "bcrypt.hash(password, 12): salt rounds = 12, tức bcrypt chạy 2^12 = 4096 vòng lặp hash. Càng cao càng chậm → khó brute-force. Sau khi đổi password, cập nhật passwordChangedAt để có thể vô hiệu hóa các JWT cũ.")

explain(doc, "userSchema.methods.comparePassword = function(password) { if (!this.passwordHash) return false; return bcrypt.compare(password, this.passwordHash); }",
    "bcrypt.compare so sánh plaintext password với hash đã lưu. Guard 'if (!this.passwordHash) return false' để xử lý tài khoản OAuth (Google login) — họ không có password, trả false thay vì throw error.")

explain(doc, "userSchema.methods.setRefreshToken = function(token) { this.refreshTokenHash = crypto.createHash('sha256').update(token).digest('hex'); }",
    "Hash refresh token bằng SHA-256 trước khi lưu. Khi validate sau này: hash lại token đến và so sánh với hash trong DB. Không cần giải mã → one-way.")

explain(doc, "userSchema.set('toJSON', { transform(doc, ret) { delete ret.passwordHash; delete ret.refreshTokenHash; return ret; } })",
    "Khi document bị JSON.stringify (ví dụ: res.json(user)), tự động xóa passwordHash và refreshTokenHash khỏi output. An toàn: dù developer quên không lọc, dữ liệu nhạy cảm vẫn không bị lộ.")

# ── Classroom ─────────────────────────────────────────────────────────────────
h(doc, '1.2  models/Classroom.js', 2)
para(doc, 'Collection: classrooms — Lưu thông tin lớp học, cấu hình điểm số và quy tắc hoàn thành.', bold=True)

explain(doc, "function generateClassroomCode() { return crypto.randomBytes(3).toString('hex').toUpperCase(); }",
    "crypto.randomBytes(3) tạo 3 bytes ngẫu nhiên = 6 ký tự hex (mỗi byte = 2 ký tự hex). Ví dụ: 0xA3 F1 2B → 'A3F12B'. toUpperCase() → 'A3F12B'. Đây là mã mời tham gia lớp học.")

explain(doc, "code: { type: String, required: true, unique: true, index: true }",
    "unique: true tạo unique index trong MongoDB, bảo đảm không có 2 lớp nào trùng code. index: true tạo thêm index cho query tìm lớp theo code (Student nhập mã → tìm nhanh O(log n) thay vì O(n)).")

explain(doc, "classroomSchema.pre('validate', function ensureClassroomCode(next) { if (!this.code) { this.code = generateClassroomCode(); } next(); })",
    "Pre-validate hook: chạy TRƯỚC khi Mongoose validate document. Nếu code chưa có (lần đầu tạo), tự động sinh code. Không cần controller gọi generateCode() — Model tự lo. 'next()' bắt buộc phải gọi để tiếp tục pipeline.")

explain(doc, "gradeWeights: [{ itemType: { enum: ['LESSON','QUIZ','ASSIGNMENT','EXAM'] }, weight: { type: Number, min: 0 } }]",
    "Mảng cấu hình trọng số điểm của từng loại nội dung. Ví dụ: [{itemType:'EXAM', weight:70}, {itemType:'ASSIGNMENT', weight:30}] = bài thi chiếm 70%, bài tập 30%. gradebook.service.js đọc mảng này để tính điểm tổng.")

explain(doc, "completionRules: { requireAllItems: {default:false}, minOverallPercent: {default:null}, requiredItemTypes: {default:[]} }",
    "3 quy tắc hoàn thành khóa học (completion.service.js đọc): requireAllItems=true → phải học hết mọi bài. minOverallPercent=70 → phải đạt >=70% điểm. requiredItemTypes=['EXAM'] → phải làm ít nhất 1 bài thi. Mặc định tất cả null/false → không có yêu cầu.")

# ── ClassroomMember ───────────────────────────────────────────────────────────
h(doc, '1.3  models/ClassroomMember.js', 2)
para(doc, 'Collection: classroommembers — Bảng trung gian giữa Student và Classroom (quan hệ nhiều-nhiều).', bold=True)

explain(doc, "status: { enum: ['pending', 'approved', 'rejected', 'left'], default: 'pending' }",
    "pending: học sinh đã nộp đơn xin vào, chờ GV duyệt. approved: được vào lớp. rejected: bị từ chối. left: tự rời lớp. Khi query dữ liệu học sinh trong lớp, luôn filter {status:'approved'} để loại bỏ các trường hợp khác.")

explain(doc, "classroomMemberSchema.index({ classroom: 1, student: 1 }, { unique: true })",
    "Compound unique index: một học sinh chỉ có thể có 1 bản ghi trong 1 lớp. Ngăn race condition: nếu 2 request join cùng lúc, chỉ 1 cái thành công, cái còn lại bị MongoDB ném E11000 duplicate key error.")

# ── Lecture ───────────────────────────────────────────────────────────────────
h(doc, '1.4  models/Lecture.js', 2)
para(doc, 'Collection: lectures — Lưu nội dung bài giảng (text, video link, file PDF...).', bold=True)

explain(doc, "chapterTitle: { type: String, required: true }",
    "Tên chương/module của bài giảng này. courseProgress.service.js dùng field này làm 'module key' để gom bài giảng cùng chương. Ví dụ: 'Chương 1: Giới thiệu Python'.")

explain(doc, "resourceType: { enum: ['pdf', 'ppt', 'video', 'document', 'link', 'text'], default: 'text' }",
    "Loại tài nguyên đính kèm. View Pug dùng giá trị này để render icon phù hợp (PDF icon, video player, link button...). Không ảnh hưởng logic lưu trữ.")

explain(doc, "orderIndex: { type: Number, default: 0 }",
    "Số thứ tự trong chương. Khi query: .sort({chapterTitle:1, orderIndex:1, createdAt:1}). Bài giảng có orderIndex nhỏ hơn hiển thị trước. GV kéo thả để sắp xếp sẽ cập nhật field này.")

explain(doc, "lectureSchema.index({ classroom: 1, chapterTitle: 1, orderIndex: 1 })",
    "Index compound cho đúng pattern query phổ biến nhất. MongoDB có thể dùng index này để sort+filter theo classroom và chapterTitle cùng lúc mà không cần full collection scan.")

# ── Assignment ────────────────────────────────────────────────────────────────
h(doc, '1.5  models/Assignment.js', 2)
para(doc, 'Collection: assignments — Lưu bài tập về nhà do GV tạo.', bold=True)

explain(doc, "allowLateSubmission: { type: Boolean, default: false }",
    "Nếu false: sau dueDate học sinh không nộp được nữa (controller kiểm tra: new Date() > dueDate && !allowLateSubmission → 403). Nếu true: vẫn nộp được, chỉ bị đánh dấu 'nộp muộn'.")

explain(doc, "rubric: { type: Schema.Types.ObjectId, ref: 'Rubric', default: null }",
    "Optional. null = GV chấm điểm tự do (nhập số điểm thủ công). Có giá trị = GV chấm theo rubric (từng tiêu chí có maxPoints riêng). grading.service.js xử lý 2 path này.")

explain(doc, "attachments: [{ fileName, fileUrl: '/uploads/assignments/{filename}', fileType, fileSize, uploadedAt }]",
    "Mảng file đính kèm của GV (đề bài, tài liệu tham khảo). fileUrl lưu đường dẫn tương đối bắt đầu bằng '/uploads/'. Multer middleware xử lý upload và điền filename vào đây.")

explain(doc, "assignmentSchema.index({ classroom: 1, dueDate: 1 })",
    "Index hỗ trợ query lấy bài tập của lớp sắp theo dueDate (ưu tiên deadline gần nhất). Dùng trong trang 'My Assignments' hiển thị bài sắp đến hạn.")

# ── Submission ────────────────────────────────────────────────────────────────
h(doc, '1.6  models/Submission.js', 2)
para(doc, 'Collection: submissions — Lưu bài nộp của học sinh cho mỗi assignment.', bold=True)

explain(doc, "const submissionFileSchema = new Schema({ name, url, mimeType, size }, { _id: false })",
    "_id: false: sub-document này không cần _id riêng vì nó là embedded document trong Submission, không cần tham chiếu độc lập. Tiết kiệm bộ nhớ.")

explain(doc, "textAnswer: { type: String, trim: true, default: '' }",
    "Phần trả lời dạng text (viết tay trong textarea). Học sinh có thể nộp text-only, file-only, hoặc cả hai.")

explain(doc, "status: { enum: ['draft', 'submitted', 'graded', 'returned'], default: 'submitted' }",
    "draft: đang soạn. submitted: đã nộp chờ chấm. graded: GV đã chấm. returned: GV trả lại yêu cầu nộp lại. Logic: default='submitted' vì hệ thống không có tính năng lưu nháp — click Nộp là submitted luôn.")

explain(doc, "rubricGrades: [{ criterion: ObjectId, points: Number, comment: String }]",
    "Chỉ có giá trị khi GV dùng rubric chấm. Mỗi phần tử lưu điểm GV trao cho 1 criterion. submission.score = tổng tất cả criterion.points. Nếu GV chấm thủ công, mảng này rỗng.")

explain(doc, "submissionSchema.index({ assignment: 1, student: 1 }, { unique: true })",
    "Một học sinh chỉ được có 1 bài nộp cho 1 assignment. Nếu học sinh nộp lại, controller dùng findOneAndUpdate (upsert) thay vì tạo mới, tránh vi phạm index này.")

# ── Exam ──────────────────────────────────────────────────────────────────────
h(doc, '1.7  models/Exam.js', 2)
para(doc, 'Collection: exams — Lưu thông tin bài kiểm tra/thi.', bold=True)

explain(doc, "duration: { type: Number, default: 60 } // in minutes, 0 means unlimited",
    "Thời gian làm bài tính bằng phút. 0 = không giới hạn. examIntegrity.service.js dùng field này để tính server-side deadline: deadlineAt = startedAt + duration * 60 * 1000 ms.")

explain(doc, "startTime: { type: Date, default: null }, endTime: { type: Date, default: null }",
    "Khung thời gian mở thi. null = không giới hạn. Có thể đặt: startTime=08:00, endTime=10:00 → bài thi chỉ mở trong 2 tiếng đó. Controller và view kiểm tra để hiển thị 'Chưa mở' / 'Đã đóng'.")

explain(doc, "maxAttempts: { type: Number, default: 1 } // 0 means unlimited",
    "Số lượt thi tối đa. Default=1 (chỉ thi 1 lần). 0 = không giới hạn. examIntegrity.service.js::canStartAttempt(usedAttempts, maxAttempts) kiểm tra trước khi cho mở bài.")

explain(doc, "showResult: { enum: ['none', 'after_submit', 'after_exam_ends'] }",
    "Kiểm soát học sinh thấy kết quả khi nào. 'none': không bao giờ. 'after_submit': thấy ngay sau nộp bài. 'after_exam_ends': phải chờ endTime qua. View result.pug đọc field này để quyết định render hay ẩn.")

explain(doc, "strictMode: Boolean, maxViolations: Number",
    "strictMode=true: bật chế độ giám sát (fullscreen bắt buộc, chặn copy paste). maxViolations: nếu học sinh vi phạm vượt ngưỡng này, Socket.IO server tự động submit bài (auto_submitted). maxViolations=0 = chỉ ghi log, không tự nộp.")

explain(doc, "shuffle: Boolean",
    "Nếu true: khi học sinh mở bài, controller dùng Fisher-Yates algorithm xáo trộn thứ tự câu hỏi VÀ xáo trộn thứ tự các option trong mỗi câu. Mỗi học sinh có thứ tự câu hỏi khác nhau → giảm copy nhau.")

explain(doc, "totalPoints: { type: Number, default: 0 }, questionCount: { type: Number, default: 0 }",
    "2 field denormalized (tính sẵn, không tính lại mỗi lần). Được cập nhật tự động bởi Question model hooks. Mục đích: tránh phải aggregate count + sum mỗi lần hiển thị exam card.")

# ── Question ──────────────────────────────────────────────────────────────────
h(doc, '1.8  models/Question.js', 2)
para(doc, 'Collection: questions — Lưu từng câu hỏi trong bài thi. Có hook tự động cập nhật Exam.', bold=True)

explain(doc, "type: { enum: ['multiple_choice', 'multiple_answer', 'essay'] }",
    "3 loại câu: multiple_choice (1 đáp án đúng), multiple_answer (nhiều đáp án đúng, phải chọn đúng TẤT CẢ), essay (tự luận, chấm tay). Controller chấm tự động cho 2 loại đầu, essay chờ GV.")

explain(doc, "options: [{ text: String, isCorrect: Boolean }]",
    "Mảng các lựa chọn. isCorrect=true đánh dấu đáp án đúng. Khi học sinh nộp bài, controller so sánh các option ID học sinh chọn với option có isCorrect=true. Câu essay: options rỗng.")

explain(doc, "outcomeMappings: [{ clo: ObjectId ref Outcome, weight: Number }]",
    "Ánh xạ câu hỏi với Course Learning Outcomes (CLO). Dùng cho phân tích học tập: câu hỏi này kiểm tra CLO nào, với tỷ trọng bao nhiêu. Tính năng nâng cao, không bắt buộc.")

explain(doc, """questionSchema.pre('save', async function(next) {
  if (this.isNew) {
    await Exam.findByIdAndUpdate(this.exam, { $inc: { questionCount: 1, totalPoints: this.points } });
  }
  next();
})""",
    "Pre-save hook: MỖI KHI thêm câu hỏi mới (isNew=true), tự động tăng exam.questionCount lên 1 và tăng exam.totalPoints thêm đúng số điểm của câu này. $inc là atomic operation của MongoDB. GV không cần manually cộng điểm.")

explain(doc, """questionSchema.post('findOneAndDelete', async function(doc) {
  if (doc) { await Exam.findByIdAndUpdate(doc.exam, { $inc: { questionCount: -1, totalPoints: -doc.points } }); }
})""",
    "Post-delete hook: ngược lại, khi xóa câu hỏi, tự động trừ questionCount và totalPoints của exam. 'post' thay vì 'pre' vì phải có doc (câu hỏi đã xóa) để biết trừ bao nhiêu điểm. Nếu xóa thất bại, hook không chạy — consistent.")

# ── ExamSubmission ────────────────────────────────────────────────────────────
h(doc, '1.9  models/ExamSubmission.js', 2)
para(doc, 'Collection: examsubmissions — Lưu mỗi lần làm bài thi của học sinh (kể cả đang làm dở).', bold=True)

explain(doc, "status: { enum: ['in_progress', 'submitted', 'graded', 'late', 'auto_submitted'] }",
    "in_progress: đang làm (bài thi đang mở). submitted: đã nộp đúng hạn. late: đã nộp nhưng quá deadline (server clock). auto_submitted: hệ thống tự nộp khi hết giờ hoặc quá số violation. graded: GV đã chấm xong câu tự luận.")

explain(doc, "deadlineAt: { type: Date, default: null }",
    "Deadline SERVER-SIDE, tính 1 lần tại thời điểm học sinh bấm 'Bắt đầu thi': deadlineAt = startedAt + exam.duration * 60000. Không phụ thuộc vào đồng hồ client. Khi nộp bài, server so sánh submittedAt với deadlineAt + 30 giây grace period.")

explain(doc, "attemptNumber: { type: Number, default: 1 }",
    "Lần thi thứ mấy. Lần đầu = 1, lần 2 = 2... Kết hợp với unique index {exam, student, attemptNumber} để chặn race condition: 2 request tạo cùng lúc sẽ bị lỗi E11000 ở 1 trong 2.")

explain(doc, "violations: [{ type: String, time: Date, details: String }]",
    "Log gian lận từ Socket.IO. type có thể là: 'blur' (chuyển tab), 'fullscreen_exit', 'copy', 'paste', 'tab_switch'... Chỉ được ghi từ server-side socket event, KHÔNG đọc từ req.body (xem giải thích trong submitExamHandler).")

explain(doc, "gradingStatus: { enum: ['in_progress', 'auto_graded', 'pending_manual_grade', 'fully_graded'] }",
    "Trạng thái chấm điểm. auto_graded: tất cả câu là trắc nghiệm, đã chấm máy. pending_manual_grade: có câu tự luận, chờ GV. fully_graded: GV đã chấm hết câu tự luận.")

h(doc, 'Indexes của ExamSubmission:', 3)
explain(doc, "index({ exam: 1, student: 1, submittedAt: -1 })",
    "Hỗ trợ query: 'lấy tất cả bài nộp của student X trong exam Y, mới nhất trước'. Dùng khi render trang kết quả.")
explain(doc, "index({ exam: 1, student: 1, attemptNumber: 1 }, { unique: true })",
    "Bảo vệ chống race condition: không thể có 2 row cùng (exam, student, attemptNumber). Nếu 2 request concurrent tạo attempt số 1 cùng lúc, MongoDB chỉ chấp nhận 1.")
explain(doc, "index({ exam: 1, status: 1 })",
    "Hỗ trợ GV query: 'tất cả bài in_progress đã quá deadline'. Dùng cho auto-submit sweep job chạy định kỳ.")

# ── StudentProgress ───────────────────────────────────────────────────────────
h(doc, '1.10  models/StudentProgress.js', 2)
para(doc, 'Collection: studentprogresses — Bảng ghi nhận những gì học sinh đã hoàn thành (completion ledger). Đây là collection trung tâm nhất hệ thống.', bold=True)

explain(doc, "itemType: { enum: ['LESSON', 'QUIZ', 'ASSIGNMENT', 'EXAM'] }",
    "Loại nội dung đã hoàn thành. Kết hợp với itemId tạo thành composite identifier cho 1 nội dung cụ thể.")

explain(doc, "score: { type: Number, default: null }, maxScore: { type: Number, default: null }",
    "Null cho bài giảng (LESSON không có điểm). Có giá trị cho ASSIGNMENT/EXAM sau khi chấm. Gradebook đọc score/maxScore để tính % điểm từng item. Bảo đảm: maxScore > 0 mới được tính vào gradebook.")

explain(doc, "studentProgressSchema.index({ classroom:1, student:1, itemType:1, itemId:1 }, { unique:true })",
    "Unique compound index đảm bảo: 1 học sinh chỉ có 1 bản ghi hoàn thành cho mỗi (classroom, item). Đây là lý do helper/progress.js::markComplete() dùng findOneAndUpdate+upsert thay vì create — không lo tạo duplicate.")

explain(doc, "studentProgressSchema.index({ classroom: 1, student: 1 })",
    "2-field prefix index để hỗ trợ query: 'lấy tất cả completion rows của student X trong classroom Y'. Cả courseProgress.service.js và gradebook.service.js đều dùng pattern này.")

# ── Rubric ────────────────────────────────────────────────────────────────────
h(doc, '1.11  models/Rubric.js', 2)
para(doc, 'Collection: rubrics — Template chấm điểm theo tiêu chí, do GV tạo và gán vào Assignment.', bold=True)

explain(doc, "criteria: [rubricCriterionSchema]  // { label, description, maxPoints, scale: [{points, label}] }",
    "Mỗi criterion là 1 tiêu chí chấm. maxPoints là điểm tối đa cho tiêu chí đó. scale là các mức điểm gợi ý để GV click nhanh (ví dụ: [{points:10, label:'Xuất sắc'}, {points:7, label:'Khá'}, {points:4, label:'Trung bình'}]).")

explain(doc, "maxPoints: { type: Number, default: 0 } // denormalized sum",
    "Tổng maxPoints của tất cả criteria. Được sync tự động bởi pre-validate hook. Dùng khi cần biết tổng điểm rubric mà không phải reduce mảng criteria.")

explain(doc, "rubricSchema.pre('validate', function reconcileMaxPoints(next) { this.maxPoints = this.criteria.reduce((sum, c) => sum + c.maxPoints, 0); next(); })",
    "Mỗi lần save rubric, tự tính lại maxPoints = tổng tất cả criteria.maxPoints. Đảm bảo maxPoints không bao giờ sai dù GV thêm/xóa/sửa criteria nhiều lần.")

# ── Notification ──────────────────────────────────────────────────────────────
h(doc, '1.12  models/Notification.js', 2)
para(doc, 'Collection: notifications — Thông báo trong hệ thống (bell icon trên navbar).', bold=True)

explain(doc, "isRead: { type: Boolean, default: false, index: true }",
    "Default false = chưa đọc. middleware/currentUser.js query countDocuments({recipient:userId, isRead:false}) MỖI REQUEST để hiển thị số badge trên navbar. Index trên isRead giúp query này nhanh.")

explain(doc, "notificationSchema.index({ recipient: 1, isRead: 1, createdAt: -1 })",
    "Compound index cho pattern query phổ biến: 'lấy thông báo chưa đọc của user X, mới nhất trước'. Bao gồm đủ cả 3 fields của query và sort → MongoDB dùng được index toàn bộ.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# PHẦN 2 — MIDDLEWARE
# ══════════════════════════════════════════════════════════════════════════════
h(doc, 'PHẦN 2 — MIDDLEWARE (Xử lý trước khi vào Controller)', 1)
para(doc, 'Middleware là các hàm chạy trong pipeline của mỗi HTTP request, theo thứ tự được đăng ký trong index.js.', italic=True)

h(doc, '2.1  middleware/rbac.js — Kiểm tra xác thực và phân quyền', 2)
para(doc, 'File này chứa 2 middleware quan trọng nhất bảo vệ toàn bộ hệ thống:', bold=True)

explain(doc, """function requireAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  if (req.headers.accept?.includes('application/json')) return res.status(401).json({ error: 'Unauthorized' });
  return res.redirect('/auth/login');
}""",
    "req.isAuthenticated() là hàm của Passport.js. Trả true nếu session hợp lệ (user đã đăng nhập). Nếu chưa login: API call → trả JSON 401, page request → redirect trang login.")

explain(doc, """function requireRole(...roles) {
  return function (req, res, next) {
    if (!req.isAuthenticated()) return res.redirect('/auth/login');
    if (!roles.includes(req.user.role)) return res.status(403).render('errors/403', {...});
    return next();
  };
}""",
    "Factory function nhận nhiều role. Ví dụ: requireRole('teacher') tạo middleware chỉ cho teacher qua. requireRole('admin', 'teacher') cho cả admin và teacher. req.user.role được Passport deserialize từ session.")

# ── currentUser ───────────────────────────────────────────────────────────────
h(doc, '2.2  middleware/currentUser.js — Gắn dữ liệu user vào mọi response', 2)
para(doc, 'Chạy trên TOÀN BỘ route, cung cấp biến toàn cục cho tất cả Pug views.', bold=True)

explain(doc, "res.locals.currentUser = authenticated ? req.user : null;",
    "res.locals là object được truyền tự động vào mọi view Pug. Gán vào đây → view có thể dùng currentUser trực tiếp mà không cần controller truyền thêm.")

explain(doc, "res.locals.unreadCount = await Notification.countDocuments({ recipient: req.user.id, isRead: false })",
    "Đếm số notification chưa đọc. Chạy MỌI request của user đã login → hiển thị badge đỏ trên navbar. Có thể tối ưu bằng cache (Redis) nếu traffic lớn.")

explain(doc, "res.locals.unreadChatCount = await DirectMessage.countDocuments({ recipient: req.user.id, isRead: false })",
    "Tương tự, đếm DM chưa đọc để hiển thị badge trên icon chat.")

explain(doc, """if (req.user.role === 'admin') {
  res.locals.pendingCount = await User.countDocuments({ role: 'teacher', status: 'pending' });
}""",
    "Chỉ chạy khi user là admin. Đếm số giáo viên chờ duyệt để hiển thị trong admin sidebar. Không chạy cho teacher/student để không query thừa.")

explain(doc, "const siteNameSetting = await SystemSetting.findOne({ key: 'siteName' });",
    "Đọc tên site từ DB (admin có thể thay đổi trong Settings). res.locals.siteName được render trong <title> và navbar của mọi trang. Nếu không tìm thấy setting → dùng default 'E-Learning LMS'.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# PHẦN 3 — HELPERS
# ══════════════════════════════════════════════════════════════════════════════
h(doc, 'PHẦN 3 — HELPERS (Hàm dùng chung)', 1)

h(doc, '3.1  helper/progress.js — markComplete() [QUAN TRỌNG NHẤT]', 2)
para(doc, 'ĐÂY LÀ ĐIỂM GHI DUY NHẤT vào completion ledger (StudentProgress). Mọi loại nội dung (lecture, assignment, exam) đều gọi hàm này.', bold=True)

explain(doc, """async function markComplete({ student, classroom, itemType, itemId, evidence = {} }) {
  const filter = { classroom, student, itemType, itemId };
  const update = { completedAt: new Date() };""",
    "filter xác định chính xác 1 record: (student X, classroom Y, loại Z, item cụ thể). Nếu record chưa có → tạo mới. Nếu đã có → cập nhật. Đây là pattern upsert.")

explain(doc, """  if (evidence.score !== undefined) update.score = evidence.score;
  if (evidence.maxScore !== undefined) update.maxScore = evidence.maxScore;
  if (evidence.submittedAt !== undefined) update.submittedAt = evidence.submittedAt;""",
    "Chỉ cập nhật evidence fields khi được cung cấp. Lecture gọi markComplete({}) không có evidence → score/maxScore vẫn null (đúng vì lecture không có điểm). Assignment gọi lại khi GV chấm → cập nhật score mà không thay đổi completedAt gốc.")

explain(doc, """  await StudentProgress.findOneAndUpdate(filter, update, { upsert: true, setDefaultsOnInsert: true });
}""",
    "upsert:true = tạo mới nếu chưa có, update nếu đã có. setDefaultsOnInsert = khi tạo mới, áp dụng default values của Schema. Atomic operation của MongoDB: không cần lock, không có race condition.")

h(doc, '3.2  helper/token.js — JWT Token', 2)
explain(doc, """function createAccessToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '15m' });
}""",
    "sub: Subject = user ID. role: được nhúng vào token để middleware RBAC đọc nhanh mà không cần query DB. expiresIn 15m: token ngắn hạn, hết hạn buộc dùng refresh token. Ký bằng JWT_SECRET (HMAC-SHA256).")

explain(doc, """function createRefreshToken(user) {
  return jwt.sign({ sub: user.id, tokenType: 'refresh' }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });
}""",
    "tokenType:'refresh' phân biệt với access token. Ký bằng JWT_REFRESH_SECRET khác. Tồn tại 7 ngày. Được lưu hash trong DB để hỗ trợ revoke (đăng xuất, đổi mật khẩu sẽ clear hash).")

explain(doc, "function hashToken(token) { return crypto.createHash('sha256').update(token).digest('hex'); }",
    "SHA-256 hash của token. Dùng để lưu refreshToken vào DB an toàn. Nếu DB bị dump, attacker chỉ thấy hash, không thể dùng làm refresh token thật.")

h(doc, '3.3  helper/notification.helper.js', 2)
explain(doc, """async function sendNotification(recipientId, title, message, link = '#') {
  try { const notification = await Notification.create({...}); return notification; }
  catch (error) { console.error('Failed to send notification:', error); return null; }
}""",
    "Bắt toàn bộ exception trong try/catch và trả null nếu lỗi thay vì re-throw. Lý do: notification là tính năng phụ — lỗi notification KHÔNG được crash main business logic. Controller dùng Promise.allSettled (không phải Promise.all) để 1 notification lỗi không block toàn bộ.")

explain(doc, """async function sendBulkNotifications(recipientIds, title, message, link) {
  const notifications = recipientIds.map(id => ({ recipient: id, title, message, link }));
  await Notification.insertMany(notifications);
}""",
    "insertMany gửi 1 bulk write command đến MongoDB thay vì N insert riêng lẻ. Cho N học sinh, tiết kiệm N-1 round trips. Hiệu quả hơn nhiều khi lớp có 50-100 học sinh.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# PHẦN 4 — SERVICES
# ══════════════════════════════════════════════════════════════════════════════
h(doc, 'PHẦN 4 — SERVICES (Business Logic)', 1)
para(doc, 'Services chứa toàn bộ logic nghiệp vụ phức tạp. Controllers gọi services, không tự xử lý logic.', italic=True)

# ── auth.service ──────────────────────────────────────────────────────────────
h(doc, '4.1  controller/auth/auth.service.js', 2)
para(doc, 'Xử lý đăng ký, xác thực, token session. Controller auth chỉ parse request rồi ủy quyền cho file này.', bold=True)

explain(doc, """async function registerUser(payload) {
  const email = payload.email.toLowerCase();
  const existingUser = await User.findOne({ email });
  if (existingUser) { const error = new Error('...'); error.statusCode = 409; throw error; }""",
    "Normalize email về lowercase trước khi tìm. Tìm email trùng thủ công thay vì để MongoDB throw duplicate key error — lý do: muốn trả lỗi 409 Conflict với message rõ ràng, không phải lỗi DB thô.")

explain(doc, """  const targetRole = payload.role === 'teacher' ? 'teacher' : 'student';
  const user = new User({ name, email, role: targetRole, status: targetRole === 'teacher' ? 'pending' : 'active' });
  await user.setPassword(payload.password);
  await user.save();""",
    "Whitelist role: chỉ chấp nhận 'teacher', mọi giá trị khác đều thành 'student'. Ngăn user tự đặt role='admin'. Status pending cho teacher (chờ duyệt). setPassword() bcrypt hash rồi gán vào passwordHash.")

explain(doc, """async function authenticateUser(email, password) {
  const user = await User.findOne({ email }).select('+passwordHash +refreshTokenHash');
  if (!user || user.provider !== 'local') { ... throw 401 ... }
  const passwordMatches = await user.comparePassword(password);""",
    ".select('+passwordHash') override 'select:false' trong schema để lấy hash. Kiểm tra provider:'local' vì Google/Facebook users không có password → không nên cho phép đăng nhập bằng password form. Trả cùng 1 lỗi '401 Invalid email or password' cho cả 2 case (user không tồn tại và sai password) → không leak thông tin.")

explain(doc, """async function buildAuthSession(user) {
  const accessToken = createAccessToken(user);
  const refreshToken = createRefreshToken(user);
  user.setRefreshToken(refreshToken);  // lưu hash vào DB
  user.lastLoginAt = new Date();
  await user.save();
  return { user: sanitizeUser(user), accessToken, refreshToken };
}""",
    "Tạo cả 2 token cùng lúc. setRefreshToken() SHA-256 hash refreshToken rồi lưu vào user.refreshTokenHash. Cập nhật lastLoginAt để admin biết user active lần cuối. sanitizeUser() trả chỉ {id, name, email, role, status, provider} — không trả passwordHash.")

explain(doc, """async function rotateRefreshToken(incomingToken) {
  const payload = jwt.verify(incomingToken, process.env.JWT_REFRESH_SECRET);
  const user = await User.findById(payload.sub).select('+refreshTokenHash');
  if (!user || !user.matchesRefreshToken(incomingToken)) { throw 401 }
  return buildAuthSession(user);  // sinh cặp token MỚI
}""",
    "Token Rotation pattern: mỗi lần refresh, vô hiệu hóa refresh token cũ và cấp token mới. user.matchesRefreshToken() hash token đến và so sánh với hash trong DB. Nếu token đã bị dùng/đánh cắp → hash không match → 401. buildAuthSession() tạo token mới và lưu hash mới vào DB.")

explain(doc, """async function upsertOAuthUser(profile, provider) {
  let user = await User.findOne({ $or: [{ provider, providerId }, ...(email ? [{ email }] : [])] });
  if (!user) { user = new User({ name, email, role:'student', provider, providerId, status:'active' }); }
  else { user.provider = provider; user.providerId = providerId; user.avatarUrl = ...; }
  await user.save(); return user;
}""",
    "$or query tìm user theo providerId hoặc email. Nếu user tồn tại với email đó (tài khoản local), link OAuth vào tài khoản đó thay vì tạo mới. Nếu chưa có: tạo user mới với status='active' (OAuth users không cần admin duyệt). role='student' cố định cho OAuth users.")

# ── courseProgress.service ────────────────────────────────────────────────────
h(doc, '4.2  services/courseProgress.service.js — Engine tiến độ học tập [PHỨC TẠP NHẤT]', 2)
para(doc, 'File này là trái tim của hệ thống. Quyết định bài học nào LOCKED, COMPLETED, IN_PROGRESS.', bold=True)

explain(doc, """const ITEM_STATUS = Object.freeze({ COMPLETED:'COMPLETED', IN_PROGRESS:'IN_PROGRESS', NOT_STARTED:'NOT_STARTED', LOCKED:'LOCKED' })""",
    "Object.freeze() ngăn code khác ghi đè giá trị. Thay vì so sánh string 'LOCKED' thủ công (dễ typo), code luôn dùng ITEM_STATUS.LOCKED. Nếu đổi giá trị, chỉ sửa 1 chỗ.")

explain(doc, """async function buildContentItems(classroomId) {
  const [lectures, assignments, exams] = await Promise.all([
    Lecture.find({ classroom: classroomId, isPublished: true }).sort({chapterTitle:1, orderIndex:1, createdAt:1}).lean(),
    Assignment.find({ classroom: classroomId, isPublished: true }).sort({dueDate:1, createdAt:1}).lean(),
    Exam.find({ classroom: classroomId, isPublished: true }).sort({createdAt:1}).lean(),
  ]);""",
    "Promise.all: 3 query chạy SONG SONG, không tuần tự. .lean() trả plain JavaScript object thay vì Mongoose document → nhanh hơn, ít bộ nhớ hơn vì không cần các method của Mongoose.")

explain(doc, """  items.sort((a, b) => {
    if (a.moduleKey !== b.moduleKey) return a.moduleKey.localeCompare(b.moduleKey);
    if (a.order !== b.order) return a.order - b.order;
    return a.createdAt - b.createdAt;
  });""",
    "Sort global: ưu tiên 1) moduleKey (tên chương), 2) orderIndex, 3) thời gian tạo. Kết quả: bài giảng của chương 1 → bài giảng chương 2 → bài tập → bài thi. Thứ tự này được dùng để xác định prerequisite.")

explain(doc, """async function getCompletedItemKeys(classroomId, studentId) {
  const rows = await StudentProgress.find({classroom:classroomId, student:studentId})
    .select('itemType itemId -_id').lean();
  return new Set(rows.map(r => `${r.itemType}:${String(r.itemId)}`));
}""",
    "Dùng Set<string> thay vì mảng để lookup O(1) thay vì O(n). Key format: 'LESSON:64f8a...'. Sau này khi kiểm tra: completedKeys.has('LESSON:64f8a...') cực nhanh.")

explain(doc, """function resolvePrerequisite(item, moduleItems) {
  const position = moduleItems.indexOf(item);
  if (position <= 0) return null;
  for (let i = position - 1; i >= 0; i--) {
    if (moduleItems[i].isRequired) return moduleItems[i];
  }
  return null;
}""",
    "Tìm prerequisite của item: đi ngược từ vị trí hiện tại, tìm item isRequired đầu tiên. Item ở vị trí 0 → không có prerequisite (null). Chỉ xét trong cùng module. isRequired=true cho tất cả item hiện tại (có thể mở rộng optional item sau).")

explain(doc, """function resolveStatus(item, moduleItems, completedKeys, isCurrent) {
  if (completedKeys.has(item.id)) return ITEM_STATUS.COMPLETED;
  const prereq = resolvePrerequisite(item, moduleItems);
  if (prereq && !completedKeys.has(prereq.id)) return ITEM_STATUS.LOCKED;
  return isCurrent ? ITEM_STATUS.IN_PROGRESS : ITEM_STATUS.NOT_STARTED;
}""",
    "Logic 4 bước: 1) Đã hoàn thành → COMPLETED. 2) Có prereq chưa done → LOCKED. 3) Unlocked + là item hiện tại (chưa hoàn thành đầu tiên) → IN_PROGRESS. 4) Còn lại → NOT_STARTED. Pure function, không query DB, test được dễ dàng.")

explain(doc, """async function computeCourseProgress(classroom, studentId) {
  const [items, completedKeys] = await Promise.all([
    buildContentItems(classroomId),
    getCompletedItemKeys(classroomId, studentId),
  ]);""",
    "Chỉ 2 batch queries dù classroom có hàng trăm items: 1 query lấy tất cả content, 1 query lấy tất cả completion. Không N+1. Sau đó xử lý thuần JavaScript trong memory.")

explain(doc, """  const flatChildren = modules.flatMap(m => m.children);
  currentLesson = flatChildren.find(c => c.status === ITEM_STATUS.IN_PROGRESS) || null;
  nextLesson = flatChildren.find(c => c.status === ITEM_STATUS.NOT_STARTED) || null;""",
    "flatMap dẹt mảng 2D (modules > children) thành 1D để tìm kiếm. currentLesson = bài đang học (IN_PROGRESS). nextLesson = bài sắp tới (NOT_STARTED). Dùng để hiển thị 'Tiếp tục học' button trên trang chủ lớp học.")

# ── gradebook.service ─────────────────────────────────────────────────────────
h(doc, '4.3  services/gradebook.service.js — Tính điểm sổ điểm', 2)
para(doc, 'Sổ điểm được TÍNH TOÁN ON-THE-FLY, không lưu trong DB. Mọi thay đổi điểm tự động phản ánh ngay.', bold=True)

explain(doc, """function normalizeWeights(weights) {
  const map = {}; let total = 0;
  for (const w of weights) {
    if (!w || !w.itemType) continue;
    const weight = Number(w.weight);
    if (!Number.isFinite(weight) || weight < 0) continue;
    map[w.itemType] = (map[w.itemType] || 0) + weight;
    total += weight;
  }
  if (total <= 0) return null;
  for (const key of Object.keys(map)) { map[key] = map[key] / total; }
  return map;
}""",
    "Nhận mảng [{itemType, weight}], normalize thành map {itemType: tỷ lệ phần trăm}. Ví dụ: [{EXAM:70, ASSIGNMENT:30}] → {EXAM:0.7, ASSIGNMENT:0.3}. Guard: bỏ qua weight âm hoặc không phải số. Nếu total=0 → return null (không có trọng số, tính trung bình đơn giản).")

explain(doc, """function gradeAverage(scoredItems, normalizedWeights) {
  const byType = {};
  for (const item of scoredItems) {
    if (!(item.maxScore > 0)) continue;  // loại item chưa có maxScore
    if (!byType[item.itemType]) byType[item.itemType] = { sum: 0, count: 0 };
    byType[item.itemType].sum += item.percent;
    byType[item.itemType].count += 1;
  }""",
    "Gom nhóm items theo type, tính tổng % và đếm. Guard '!(item.maxScore > 0)' loại bỏ lecture (maxScore null) và item chưa chấm. Tránh chia cho 0.")

explain(doc, """  if (normalizedWeights) {
    for (const [itemType, w] of Object.entries(normalizedWeights)) {
      if (typeAverages[itemType]) { acc += typeAverages[itemType].percent * w; weightUsed += w; }
    }
    percent = weightUsed > 0 ? acc / weightUsed : unweightedAverage(typeAverages);
  } else { percent = unweightedAverage(typeAverages); }""",
    "Nếu có trọng số: tính weighted average. Nếu student chỉ có bài tập (không có bài thi) nhưng EXAM có weight → weightUsed < 1 → chia cho weightUsed thực tế để tránh under-penalize. Fallback về unweighted nếu không có type nào match trọng số.")

explain(doc, """async function computeGradebook(classroom, studentId) {
  const query = { classroom: classroomId, score: { $ne: null }, maxScore: { $gt: 0 } };
  if (studentId) query.student = studentId;
  const rows = await StudentProgress.find(query).lean();""",
    "Query chỉ lấy rows CÓ ĐIỂM (score not null và maxScore > 0). Lecture rows có score=null → tự động bị loại. Nếu có studentId → 1 học sinh, không có → toàn lớp (hiếm dùng). .lean() vì chỉ đọc dữ liệu.")

# ── examIntegrity.service ─────────────────────────────────────────────────────
h(doc, '4.4  services/examIntegrity.service.js — Kiểm soát thi cử server-side', 2)
para(doc, 'Pure functions không có DB calls → test được mà không cần MongoDB. Controller inject real data.', bold=True)

explain(doc, """function computeDeadline(startedAt, durationMinutes) {
  const start = new Date(startedAt).getTime();
  if (!Number.isFinite(start)) return null;
  const minutes = Number(durationMinutes);
  if (!Number.isFinite(minutes) || minutes <= 0) return null;
  return new Date(start + minutes * 60 * 1000);
}""",
    "Tính deadline = startedAt + duration phút. Guard: nếu startedAt không hợp lệ hoặc duration <= 0 → return null (exam không giới hạn thời gian). Chuyển sang milliseconds để cộng chính xác.")

explain(doc, """const SUBMIT_GRACE_MS = 30 * 1000; // 30 seconds
function evaluateDeadline(deadlineAt, now = new Date()) {
  if (!deadlineAt) return { isLate: false, reason: 'untimed_exam' };
  if (t > deadline + SUBMIT_GRACE_MS) return { isLate: true, reason: 'past_deadline' };
  return { isLate: false, reason: 'within_deadline' };
}""",
    "30 giây grace period để bù trừ: network latency (submit đang bay trên mạng khi timer hết), đồng hồ client lệch nhẹ so với server. Nộp trong 30s sau deadline → vẫn 'submitted'. Sau 30s → 'late'. Bài muộn vẫn được chấm, không mất đáp án.")

explain(doc, """function canStartAttempt(submittedCount, maxAttempts) {
  const max = Number(maxAttempts);
  if (!Number.isFinite(max) || max <= 0) return true;  // unlimited
  return count < max;
}""",
    "maxAttempts=0 hoặc không hợp lệ → unlimited, return true. Ngược lại: số lần đã dùng (chỉ đếm terminal status: submitted/graded/late/auto_submitted) phải nhỏ hơn max. in_progress KHÔNG tính vào count — học sinh đang làm bài không bị chặn.")

# ── completion.service ────────────────────────────────────────────────────────
h(doc, '4.5  services/completion.service.js — Đánh giá hoàn thành khóa học', 2)

explain(doc, """async function checkItemAccess({ classroom, studentId, itemType, itemId }) {
  const tree = await computeCourseProgress(classroom, studentId);
  const key = `${itemType}:${String(itemId)}`;
  for (const module of tree.modules) {
    for (const child of module.children) {
      if (child.id === key) {
        const allowed = child.status !== ITEM_STATUS.LOCKED;
        return { allowed, reason: allowed ? 'ok' : 'prerequisite_incomplete', status: child.status };
      }
    }
  }
  return { allowed: false, reason: 'item_not_published', status: 'UNKNOWN' };
}""",
    "Gate function: kiểm tra học sinh có được truy cập item này không. Dùng cùng computeCourseProgress nên kết quả NHẤT QUÁN với giao diện (sidebar hiện LOCKED = server cũng chặn). Nếu item không có trong tree → unpublished/sai lớp → từ chối với 'item_not_published'.")

explain(doc, """function evaluateCompletion({ completedCount, totalCount, gradePercent, typeCounts, rules }) {
  const met = []; const missing = [];
  // Rule 1: requireAllItems
  if (!requireAllItems) { met.push('no_requireAllItems'); }
  else if (allItemsDone) { met.push('all_items_completed'); }
  else { missing.push(`all_items_completed (${completedCount}/${totalCount})`); }""",
    "Pure function (không DB), kiểm tra từng rule. met[] và missing[] ghi lại chi tiết để debug/hiển thị cho GV biết học sinh còn thiếu gì để hoàn thành. isComplete = missing.length === 0.")

# ── grading.service ───────────────────────────────────────────────────────────
h(doc, '4.6  services/grading.service.js — Chấm điểm theo Rubric', 2)

explain(doc, """function computeRubricTotal(rubric, gradesMap) {
  for (const c of criteria) {
    const raw = Number(map[String(c._id)]);
    const max = Number(c.maxPoints) || 0;
    const awarded = Number.isFinite(raw) ? Math.min(Math.max(raw, 0), max) : 0;
    total += awarded;
  }
  return { total, grades };
}""",
    "Math.min(Math.max(raw, 0), max): clamp điểm vào [0, maxPoints]. GV không thể cho điểm âm hay vượt quá ceiling của criterion. Nếu GV bỏ trống criterion (raw=NaN) → awarded=0. Pure function, dễ unit test.")

explain(doc, """async function gradeWithRubric({ submissionId, assignmentId, teacherId, gradesMap }) {
  const assignment = await Assignment.findOne({ _id: assignmentId, teacher: teacherId });
  if (!assignment || !assignment.rubric) throw new AppError('Assignment has no rubric.', 422);""",
    "Ownership check: findOne với cả assignmentId và teacher:teacherId. Nếu GV khác thử chấm → không tìm thấy → 422. Không cần check permission riêng vì query đã bao gồm điều kiện quyền sở hữu.")

# ── exam.service ──────────────────────────────────────────────────────────────
h(doc, '4.7  services/exam.service.js', 2)

explain(doc, """async function generateMatrixQuestions(examId, teacherId, subject, chapter, requirements) {
  for (const reqConfig of requirements) {
    const matchingQuestions = await QuestionBank.aggregate([
      { $match: { teacher:teacherId, subject, difficulty:reqConfig.difficulty } },
      { $sample: { size: reqConfig.count } }
    ]);""",
    "$sample trong MongoDB Aggregation: lấy ngẫu nhiên N documents thỏa điều kiện. Không cần shuffle trong code. Efficient vì MongoDB tự xử lý random sampling. Mỗi difficulty level (nhan_biet, thong_hieu, van_dung) chạy 1 query riêng.")

explain(doc, """async function gradeSubmission(submissionId, examId, teacherId, answersData) {
  for (let ans of submission.answers) {
    if (ans.question && ans.question.type === 'essay') {
      const points = Number(answersData[`points_${ans._id}`] || 0);
      ans.pointsAchieved = Math.min(points, ans.question.points);
    }
    totalScore += ans.pointsAchieved;
  }
  submission.gradingStatus = GRADING_STATUS.FULLY_GRADED;
  await submission.save();
  await markComplete({...});  // cập nhật ledger với điểm mới
  await sendNotification(submission.student, 'Exam Graded', `Score: ${totalScore}/${exam.totalPoints}`, ...);""",
    "Chỉ cho phép sửa câu essay (kiểm tra type). Điểm trắc nghiệm đã chấm máy, không cho GV sửa. Clamp với Math.min. Sau save: markComplete cập nhật StudentProgress → gradebook tự cập nhật. sendNotification thông báo học sinh biết kết quả.")

# ── meeting.service ───────────────────────────────────────────────────────────
h(doc, '4.8  services/meeting.service.js — Quản lý họp online', 2)

explain(doc, """function syncMeetingStatus(meeting, io) {
  if (meeting.status === 'SCHEDULED' && now >= startTime && now < endTime) { meeting.status = 'LIVE'; }
  else if ((LIVE||SCHEDULED) && now >= endTime) { meeting.status = 'ENDED'; }
  if (statusChanged) {
    await meeting.save();
    io.of('/meeting').to(`classroom:${meeting.classroom}`).emit('meeting:status_changed', {...});
  }
}""",
    "Hàm sync trạng thái meeting theo real time. Khi status thay đổi: save vào DB và emit socket event → tất cả client đang ở trang đó nhận event và cập nhật UI ngay không cần reload. io là Socket.IO server instance.")

explain(doc, """async function createMeeting({ classroomId, teacherId, title, startNow, ... }, io) {
  const roomId = `room_${classroomId}_${crypto.randomBytes(4).toString('hex')}`;
  // ...
  const notifications = approvedMembers.map(member => ({ recipient: member.student, title: ..., message: ... }));
  await Notification.insertMany(notifications);
  io.of('/meeting').to(`classroom:${classroomId}`).emit('meeting:status_changed', { meeting });
}""",
    "roomId là unique string kết hợp classroomId + 4 bytes random = 8 hex chars. Gửi thông báo cho học sinh bằng Notification.insertMany (bulk, 1 query). Emit socket event cho trang lớp học đang mở để hiện banner 'Cuộc họp đang diễn ra'.")

explain(doc, """async function autoEndEmptyMeeting(meetingId, io) {
  const meeting = await Meeting.findById(meetingId);
  if (!meeting || meeting.status !== 'LIVE') return null;
  meeting.status = 'ENDED'; meeting.endTime = new Date();
  await meeting.save();
  io.of('/meeting').to(String(meetingId)).emit('meeting_ended_automatically', {...});
}""",
    "Được gọi khi participant cuối rời phòng (sau setTimeout 4s để tránh end ngay khi người cuối disconnect). Chỉ end nếu vẫn LIVE (guard). Emit tới room cụ thể (meetingId) để notify các client còn lại.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# PHẦN 5 — CONTROLLERS
# ══════════════════════════════════════════════════════════════════════════════
h(doc, 'PHẦN 5 — CONTROLLERS (Xử lý HTTP Request)', 1)
para(doc, 'Controller nhận request, validate, gọi service/model, trả response. Không chứa business logic phức tạp.', italic=True)

# ── auth.controller ───────────────────────────────────────────────────────────
h(doc, '5.1  controller/auth/auth.controller.js — Đăng ký, Đăng nhập, Đăng xuất', 2)

explain(doc, """async function login(req, res, next) {
  const { email, password } = req.body;
  const user = await authenticateUser(email, password);
  const { accessToken, refreshToken } = await buildAuthSession(user);
  res.cookie('accessToken', accessToken, { httpOnly:true, maxAge:15*60*1000, sameSite:'strict' });
  res.cookie('refreshToken', refreshToken, { httpOnly:true, maxAge:7*24*60*60*1000, sameSite:'strict' });
  req.session.regenerate(async err => { await req.logIn(user, ...); res.redirect(...); });
}""",
    "httpOnly:true → JavaScript không đọc được cookie (chặn XSS). sameSite:'strict' → không gửi cookie cross-site (chặn CSRF trong nhiều trường hợp). req.session.regenerate() tạo session ID mới để chống Session Fixation attack. req.logIn() là Passport method, serialize user vào session.")

explain(doc, """async function logout(req, res, next) {
  await revokeRefreshToken(req.user.id);
  res.clearCookie('accessToken'); res.clearCookie('refreshToken');
  req.logout(err => { req.session.destroy(...) });
}""",
    "revokeRefreshToken() clear refreshTokenHash trong DB → token cũ không dùng được nữa dù còn thời hạn. clearCookie xóa cookie. req.logout() Passport xóa user khỏi session. req.session.destroy() xóa session hoàn toàn khỏi MongoStore.")

# ── Student controllers ────────────────────────────────────────────────────────
h(doc, '5.2  controller/student/classroom.controller.js', 2)

explain(doc, """async function renderStudentClassroomDetail(req, res, next) {
  const member = await ClassroomMember.findOne({classroom:req.params.classroomId, student:req.user.id}).populate('classroom');
  const courseProgress = await computeCourseProgress(member.classroom, req.user.id);
  const courseCompletion = await evaluateClassroomCompletion(member.classroom, req.user.id);
  const activeMeeting = await meetingService.getActiveOrUpcomingMeeting(member.classroom.id, io);
  return res.render('student/classrooms/show', { membership:member, courseProgress, courseCompletion, activeMeeting });
}""",
    "4 calls tuần tự (không song song vì courseCompletion phụ thuộc courseProgress về mặt logic nhưng thực ra độc lập). Có thể tối ưu bằng Promise.all(). courseProgress: cây bài học với status. courseCompletion: đánh giá tổng thể {isComplete, isPassing}. activeMeeting: cuộc họp đang diễn ra hoặc sắp tới.")

explain(doc, """async function askAiAssistantHandler(req, res, next) {
  const [lectures, assignments, exams] = await Promise.all([...]);
  const context = `Bạn là AI Tutor... Lớp: ${classroom.name}... Bài giảng: ${lectures.map(l=>l.title)}...`;
  const response = await fetch(`https://generativelanguage.googleapis.com/...?key=${apiKey}`, {
    method:'POST', body: JSON.stringify({ contents: [{ parts: [{text: context + userMessage}] }] })
  });
  const answer = data.candidates[0].content.parts[0].text;
}""",
    "Xây context string nhúng toàn bộ giáo trình vào system prompt. Mỗi AI assistant được 'grounded' trong context của đúng lớp học đó. API key đọc từ DB (SystemSetting) để admin có thể thay đổi mà không cần restart server. Fallback mock nếu không có API key.")

h(doc, '5.3  controller/student/lecture.controller.js', 2)

explain(doc, """async function renderStudentLectureDetail(req, res, next) {
  const access = await checkItemAccess({ classroom:membership.classroom, studentId:req.user.id, itemType:CONTENT_TYPES.LESSON, itemId:lecture._id });
  if (!access.allowed) { return res.status(403).render('errors/403', { message: 'Complete the previous item...' }); }
  const messages = await ChatMessage.find({classroom:membership.classroom.id}).populate('sender','name avatarUrl').sort({createdAt:-1}).limit(50);
  messages.reverse();
  return res.render('student/lectures/show', { lecture, messages, preview: buildPreviewModel(lecture) });
}""",
    "checkItemAccess server-side gate: ngăn URL bypass (học sinh gõ thẳng URL bài bị khóa). ChatMessage load 50 tin nhắn gần nhất: sort DESC để lấy 50 mới nhất rồi reverse để hiển thị cũ trước mới sau. buildPreviewModel tạo metadata cho preview panel (PDF viewer, video embed...).")

explain(doc, """async function markLectureComplete(req, res, next) {
  await markComplete({ student:req.user.id, classroom:String(membership.classroom._id), itemType:CONTENT_TYPES.LESSON, itemId:lecture._id });
  return res.redirect(`/student/classrooms/${membership.classroom._id}/lectures/${lecture._id}`);
}""",
    "Route POST riêng để đánh dấu bài giảng hoàn thành (học sinh bấm nút 'Đã học xong'). Redirect về trang bài giảng sau khi mark. Lần sau tải lại trang, sidebar sẽ hiện bài giảng này là COMPLETED và mở khóa bài tiếp theo.")

h(doc, '5.4  controller/student/exam.controller.js — Làm bài thi', 2)

explain(doc, """async function renderTakeExam(req, res, next) {
  const usedAttempts = await ExamSubmission.countDocuments({ exam:exam.id, student:req.user.id, status:{$in:ATTEMPT_STATUSES} });
  if (!canStartAttempt(usedAttempts, exam.maxAttempts)) { return res.redirect('.../result'); }""",
    "ATTEMPT_STATUSES=['submitted','graded','late','auto_submitted']. Chỉ đếm các lượt đã kết thúc, không đếm in_progress. countDocuments là atomic, không có race condition. Nếu vượt limit → redirect sang trang kết quả, không mở bài.")

explain(doc, """  let submission = await ExamSubmission.findOne({ exam:exam.id, student:req.user.id, status:'in_progress' });
  if (!submission) {
    submission = new ExamSubmission({ ..., attemptNumber: usedAttempts + 1, deadlineAt: computeDeadline(new Date(), exam.duration) });
    try { await submission.save(); }
    catch (err) { if (err.code === 11000) return res.redirect('.../result'); throw err; }
  }""",
    "Reuse existing in_progress submission nếu học sinh quay lại tab (tránh tạo duplicate). Nếu chưa có, tạo mới. deadlineAt tính từ NOW = thời điểm mở bài. Bắt E11000 (unique index violation) cho race condition: 2 request mở bài cùng lúc, chỉ 1 tạo được, cái còn lại redirect.")

explain(doc, """  if (exam.shuffle) {
    for (let i = questions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [questions[i], questions[j]] = [questions[j], questions[i]];
    }
    questions.forEach(q => {
      for (let i = q.options.length - 1; i > 0; i--) { ... }
    });
  }""",
    "Fisher-Yates shuffle algorithm: đảm bảo mọi hoán vị có xác suất bằng nhau. Xáo trộn cả câu hỏi VÀ options trong mỗi câu. Mỗi học sinh thấy thứ tự khác nhau khi tải lại trang (vì shuffle mỗi lần render, không lưu order).")

explain(doc, """async function submitExamHandler(req, res, next) {
  for (const q of questions) {
    const studentAnswer = req.body[`q_${q.id}`];
    if (q.type === 'multiple_choice' || q.type === 'multiple_answer') {
      const ansArray = Array.isArray(studentAnswer) ? studentAnswer : [studentAnswer];
      const correctOptionIds = q.options.filter(o => o.isCorrect).map(o => o._id.toString());
      if (correctOptionIds.length === ansArray.length && correctOptionIds.every(id => ansArray.includes(id))) {
        isCorrect = true; pointsAchieved = q.points;
      }
    }
  }""",
    "req.body['q_{questionId}'] lưu câu trả lời của từng câu. Array.isArray check vì multiple_answer gửi mảng còn multiple_choice gửi 1 string. Exact match: phải chọn đúng TẤT CẢ đáp án đúng, không thừa không thiếu. Không có partial credit cho multiple_answer.")

explain(doc, """  // Client-reported violations are intentionally NOT persisted.
  // Proctoring signals must originate from authenticated socket events on /exam-monitor.
  // Accepting req.body.violations let a student self-report (or drop) their own violation log.
  await submission.save();""",
    "Comment giải thích lý do bảo mật rõ ràng. req.body.violations bị BỎ QUA hoàn toàn. Violations chỉ được lưu từ Socket.IO server-side (examMonitor namespace) nơi server kiểm soát định danh sender. Học sinh không thể xóa hay giả mạo log vi phạm của mình.")

h(doc, '5.5  controller/student/submission.controller.js — Nộp bài tập', 2)

explain(doc, """async function createSubmissionHandler(req, res, next) {
  if (assignment.dueDate && new Date() > new Date(assignment.dueDate) && !assignment.allowLateSubmission) {
    return res.status(403).render('errors/403', { message: 'This assignment is past its due date...' });
  }""",
    "Kiểm tra deadline server-side. Ngay cả khi frontend ẩn nút Nộp sau deadline, client có thể tự gửi POST request. Server phải tự kiểm tra để đảm bảo an toàn.")

explain(doc, """  const attachment = resolveSubmissionAttachment(req.file);
  const submission = await Submission.findOne({ assignment:assignment.id, student:req.user.id });
  if (submission) {
    submission.textAnswer = req.body.textAnswer || '';
    submission.attachment = attachment;
    submission.status = 'submitted';
    await submission.save();
  } else {
    await Submission.create({ assignment, classroom, teacher, student, textAnswer, attachment, status:'submitted' });
  }""",
    "findOne trước khi create: nếu đã nộp rồi thì UPDATE bài nộp cũ (cho phép nộp lại). Nếu chưa nộp thì CREATE mới. Không dùng findOneAndUpdate+upsert ở đây vì cần handle 2 case khác nhau có logic riêng.")

explain(doc, """  await markComplete({ student:req.user.id, classroom:..., itemType:CONTENT_TYPES.ASSIGNMENT, itemId:assignment.id, evidence:{ maxScore:assignment.totalPoints, submittedAt } });""",
    "Ghi completion ngay khi nộp. score KHÔNG có (null) vì chưa chấm. maxScore có để gradebook biết tổng điểm tối đa. Khi GV chấm sau, gradeSubmissionHandler gọi lại markComplete với evidence.score → cập nhật bản ghi cũ, không tạo mới.")

h(doc, '5.6  controller/teacher/classroom.controller.js — Lớp học phía GV', 2)

explain(doc, """async function renderGradebook(req, res, next) {
  const members = await ClassroomMember.find({classroom:classroom.id, status:'approved'}).populate('student','name email');
  const rows = await Promise.all(members.map(async m => {
    const gradebook = await computeGradebook({...classroom.toObject(), _id:classroom.id}, studentId);
    return { member:m, studentName:m.student.name, overallPercent:gradebook.overallPercent, letter:gradebook.letter, byType:gradebook.byType };
  }));
  return res.render('teacher/classrooms/gradebook', { classroom, rows });
}""",
    "Promise.all với N học sinh: chạy song song N queries computeGradebook. Với lớp 30 học sinh: ~30 queries chạy cùng lúc thay vì tuần tự (30x chậm hơn). classroom.toObject() vì computeGradebook cần plain object, không phải Mongoose document.")

explain(doc, """async function exportGradebookCsv(req, res, next) {
  const parser = new Parser({ fields });
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename=\"gradebook-${classroom.id}.csv\"`);
  return res.send(parser.parse(data));
}""",
    "Content-Disposition: attachment → browser tự download thay vì hiển thị. filename suggestion cho browser. json2csv Parser nhận array of objects và fields config, tạo CSV string. Không lưu file trên server, stream thẳng tới client.")

h(doc, '5.7  controller/teacher/exam.controller.js — Thi cử phía GV', 2)

explain(doc, """async function addQuestionHandler(req, res, next) {
  let options = [];
  if (type === 'multiple_choice' || type === 'multiple_answer') {
    const texts = Array.isArray(optionTexts) ? optionTexts : [optionTexts];
    const corrects = Array.isArray(optionCorrects) ? optionCorrects : [optionCorrects];
    options = texts.map((text, idx) => ({ text: text.trim(), isCorrect: corrects.includes(idx.toString()) })).filter(opt => opt.text.length > 0);
  }
  const question = new Question({ exam:exam.id, type, content, options, points, order, isCoding });
  await question.save();  // triggers pre-save hook → auto increment exam.totalPoints
}""",
    "HTML form gửi array bằng field name 'optionText[]'. Express parse thành mảng hoặc string (nếu chỉ 1 giá trị). Ép về Array bằng ternary. isCorrect: form gửi các index được check → corrects.includes(idx.toString()). question.save() trigger Question pre-save hook tự động cộng điểm vào exam.")

explain(doc, """async function generateMatrixHandler(req, res, next) {
  const { subject, chapter, num_nhan_biet, num_thong_hieu, num_van_dung } = req.body;
  const requirements = [
    { difficulty: 'nhan_biet', count: Number(num_nhan_biet || 0) },
    { difficulty: 'thong_hieu', count: Number(num_thong_hieu || 0) },
    { difficulty: 'van_dung', count: Number(num_van_dung || 0) }
  ];
  const { generateMatrixQuestions } = require('../../services/exam.service');
  const generatedCount = await generateMatrixQuestions(req.params.examId, req.user._id, subject, chapter, requirements);
}""",
    "require() inside function (lazy import) để tránh circular dependency khi module load. Tạo requirements array từ form data. Gọi service để random lấy câu từ QuestionBank theo từng level. generatedCount để hiển thị feedback 'Đã tạo X câu'.")

h(doc, '5.8  controller/teacher/submission.controller.js — Chấm bài tập', 2)

explain(doc, """async function gradeSubmissionHandler(req, res, next) {
  const scoreVal = Number(req.body.score);
  submission.score = Math.max(0, Math.min(scoreVal, assignment.totalPoints));
  submission.teacherComment = req.body.teacherComment || '';
  submission.status = 'graded';
  submission.gradedAt = new Date();
  await submission.save();
  await markComplete({ student:..., classroom:..., itemType:CONTENT_TYPES.ASSIGNMENT, itemId:assignment.id,
    evidence: { score: submission.score, maxScore: assignment.totalPoints, submittedAt: submission.submittedAt } });
}""",
    "Math.max(0, Math.min(score, totalPoints)): clamp điểm vào [0, totalPoints], GV không thể cho điểm âm hoặc vượt quá tối đa. Sau save: markComplete cập nhật StudentProgress với score thực tế → gradebook tức thì phản ánh điểm mới.")

explain(doc, """async function rubricGradeHandler(req, res, next) {
  const gradesMap = {};
  for (const [key, value] of Object.entries(req.body)) {
    if (key.startsWith('crit_')) { gradesMap[key.slice('crit_'.length)] = value; }
  }
  await gradeWithRubric({ submissionId, assignmentId, teacherId:req.user.id, gradesMap });
}""",
    "Form gửi field tên dạng 'crit_{criterionId}'. Duyệt req.body, lọc chỉ lấy các key bắt đầu 'crit_', cắt prefix để lấy criterionId. Kết quả: {criterionId1: '8', criterionId2: '5'}. Truyền vào gradeWithRubric() để tính tổng và validate.")

h(doc, '5.9  controller/admin/classroom.controller.js', 2)

explain(doc, """const PAGE_SIZE = 20;
const page = Math.max(1, parseInt(req.query.page) || 1);
query.name = { $regex: search, $options: 'i' };
const total = await Classroom.countDocuments(query);
const totalPages = Math.ceil(total / PAGE_SIZE);
await Classroom.find(query).populate('teacher','name email').sort({createdAt:-1}).skip((page-1)*PAGE_SIZE).limit(PAGE_SIZE);""",
    "PAGE_SIZE cố định 20. page từ query string, Math.max(1,...) ngăn page âm. $regex case-insensitive tìm theo tên lớp. countDocuments đếm tổng để tính số trang. skip+limit là server-side pagination. populate('teacher','name email') thay ObjectId thành tên/email GV.")

explain(doc, """const [students, lectures, exams] = await Promise.all([
  ClassroomMember.countDocuments({ classroom: classroom.id, status: 'approved' }),
  Lecture.countDocuments({ classroom: classroom.id }),
  Exam.countDocuments({ classroom: classroom.id }),
]);
return res.render('admin/classrooms/show', { classroom, stats: { students, lectures, exams } });""",
    "Promise.all: 3 count queries chạy song song. Với N queries tuần tự: 3 * RTT. Song song: 1 * RTT. stats object truyền vào view để hiển thị 3 thẻ thống kê. Admin chỉ xem, không có quyền sửa/xóa lớp.")

h(doc, '5.10  controller/profile/profile.service.js', 2)

explain(doc, """async function changePassword(userId, currentPassword, newPassword) {
  const user = await User.findById(userId).select('+passwordHash');
  if (!user || user.provider !== 'local') { throw Error('Password changes only for local accounts') }
  const passwordMatches = await user.comparePassword(currentPassword);
  if (!passwordMatches) { throw Error('Current password is incorrect') }
  await user.setPassword(newPassword);
  await user.save();
}""",
    ".select('+passwordHash') cần thiết vì schema có 'select:false'. user.provider !== 'local' chặn tài khoản Google/Facebook đổi mật khẩu (họ không có mật khẩu). Bắt buộc nhập mật khẩu cũ (currentPassword) để xác nhận đang là chủ tài khoản — tránh CSRF đổi mật khẩu.")

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# PHẦN 6 — INDEX.JS (Entry Point)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, 'PHẦN 6 — index.js (Entry Point & Socket.IO)', 1)
para(doc, 'File khởi động toàn bộ server, đăng ký middleware, mount routes, và thiết lập WebSocket.', bold=True)

explain(doc, """app.use(helmet()); app.use(xss());
app.use(rateLimit({ windowMs:15*60*1000, max:200, message:'Too many requests' }));
const loginRateLimit = rateLimit({ windowMs:15*60*1000, max:10, skipSuccessfulRequests:true });""",
    "helmet(): set security headers (X-Frame-Options, CSP, HSTS...). xss(): sanitize HTML trong req.body. rateLimit global: 200 requests/15 phút/IP. loginRateLimit: 10 lần/15 phút, skipSuccessfulRequests=true: login thành công không tính vào quota → chỉ đếm failed attempts.")

explain(doc, """const examMonitor = io.of('/exam-monitor');
examMonitor.use(socketAuthMiddleware);
examMonitor.on('connection', socket => {
  socket.on('cheat-violation', async data => {
    const submission = await ExamSubmission.findOne({ exam:data.examId, student:socket.userId, status:'in_progress' });
    submission.violations.push({ type:data.type, time:new Date(), details:String(data.details||'').slice(0,500) });
    await submission.save();
    examMonitor.to(data.examId).emit('student-violation', { studentId:socket.userId, violation: ... });
  });
});""",
    "socketAuthMiddleware verify JWT/session trước khi cho kết nối. Mọi event từ socket có socket.userId đã được authenticate. .slice(0,500): giới hạn details để tránh học sinh gửi payload lớn. Emit tới room examId → GV đang monitor nhận được ngay.")

explain(doc, """setInterval(() => { meetingService.runBackgroundStatusSync(io); }, 15000);""",
    "Background job chạy mỗi 15 giây: quét tất cả meeting SCHEDULED/LIVE, sync trạng thái theo giờ thực. Nếu startTime đã qua → LIVE. Nếu endTime đã qua → ENDED. Emit socket event để cập nhật UI không cần reload.")

# SAVE
os.makedirs(os.path.dirname(OUT), exist_ok=True)
doc.save(OUT)
print(f"SUCCESS: {OUT}")
