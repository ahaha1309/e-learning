# Generates 08_Code_Walkthrough_Final.docx
# Formats exactly according to the user's requested numbering and bullet-point style for all 12 flows.
# Updated with explicit Security/Authorization checks for both Teacher and Student.
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT_PATH = r"C:\Users\vanha\Downloads\Documentations_DOCX\08_Code_Walkthrough_Final_v4.docx"

def new_doc():
    doc = Document()
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    return doc

def h(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    if p.runs:
        run = p.runs[0]
        run.font.name = 'Calibri'
        colors = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
                  3: RGBColor(0x1A,0x6A,0x1A), 4: RGBColor(0x66,0x33,0x00)}
        run.font.color.rgb = colors.get(level, RGBColor(0,0,0))
        sizes  = {1: 16, 2: 14, 3: 12, 4: 11}
        run.font.size = Pt(sizes.get(level, 11))
    return p

def context(doc, text):
    p = doc.add_paragraph()
    r_label = p.add_run("Bối cảnh: ")
    r_label.bold = True
    r_label.font.name = 'Calibri'
    r_label.font.size = Pt(11)
    
    r_text = p.add_run(text)
    r_text.italic = True
    r_text.font.name = 'Calibri'
    r_text.font.size = Pt(11)

def step(doc, number, title, text=""):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(2)
    
    r_num = p.add_run(f"{number}. ")
    r_num.bold = True
    r_num.font.name = 'Calibri'
    r_num.font.size = Pt(11)
    
    r_title = p.add_run(f"{title}: ")
    r_title.bold = True
    r_title.font.name = 'Calibri'
    r_title.font.size = Pt(11)
    
    if text:
        r_text = p.add_run(text)
        r_text.font.name = 'Calibri'
        r_text.font.size = Pt(11)

def bullet(doc, text):
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.left_indent = Inches(0.5)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(11)

def code_block(doc, code_text):
    for line in code_text.split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent   = Inches(0.5)
        p.paragraph_format.space_before  = Pt(0)
        p.paragraph_format.space_after   = Pt(0)
        r = p.add_run(line if line.strip() else ' ')
        r.font.name  = 'Courier New'
        r.font.size  = Pt(9)
        r.font.color.rgb = RGBColor(0x17,0x5E,0x24)
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'),   'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'),  'F2F2F2')
        p._p.get_or_add_pPr().append(shd)
    doc.add_paragraph()

def divider(doc):
    p = doc.add_paragraph('─' * 80)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after  = Pt(12)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0xAA,0xAA,0xAA)
        r.font.size = Pt(8)

doc = new_doc()

# ── TITLE PAGE ──
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run("08. CODE WALKTHROUGH — LUỒNG NGHIỆP VỤ ĐẦY ĐỦ (12 FLOWS)\nE-Learning LMS")
r.font.name = 'Calibri'; r.font.size = Pt(22); r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 1: Học viên nộp bài thi (Standard CRUD Flow)", 1)
context(doc, "Học viên đang ở trang làm bài thi trắc nghiệm. Khi đếm ngược hết giờ hoặc khi họ tự bấm nút 'Nộp bài'. Đây là ví dụ điển hình cho luồng HTTP Request truyền thống.")
step(doc, 1, "Frontend Submit", "Học sinh bấm nút submit trên form HTML (hoặc JavaScript tự động submit form khi hết giờ đếm ngược).")
step(doc, 2, "Router Match (routes/student.exam.routes.js)")
code_block(doc, "router.post('/:examId/submit', requireAuth, requireRole('student'), examController.submitExamHandler);")
bullet(doc, "Router chặn lại bằng 2 middleware auth và role trước khi cho vào Controller.")
step(doc, 3, "Kiểm tra tư cách thành viên lớp học (Bảo mật)")
bullet(doc, "Backend không bao giờ tin tưởng Client. Phải query DB check xem học sinh này có thuộc lớp này không trước khi cho nộp bài.")
code_block(doc, '''const membership = await ClassroomMember.findOne({ 
  classroom: req.params.classroomId, 
  student: req.user.id, 
  status: 'approved' 
});
if (!membership) return res.status(404).send('Classroom not found');''')
step(doc, 4, "Vào Controller & Lấy dữ liệu")
bullet(doc, "Hàm submitExamHandler lấy req.body.answers (object chứa đáp án học sinh gửi lên).")
bullet(doc, "Query lấy toàn bộ câu hỏi của bài thi này: Question.find({ exam: examId }).")
step(doc, 5, "Thuật toán Chấm điểm Khách quan")
code_block(doc, '''let totalScore = 0;
for (let q of correctQuestions) {
    const studentAnswers = req.body[`q_${q._id}`];
    // So sánh mảng đáp án của học sinh với mảng đáp án đúng
    if (studentAnswers && arraysEqual(studentAnswers, q.correctOptions)) {
        totalScore += q.points; // Trả lời đúng, cộng điểm
    }
}''')
step(doc, 6, "Ghi DB", "Tìm record ExamSubmission in_progress, update status thành submitted (hoặc late nếu quá giờ), và lưu score = totalScore.")
step(doc, 7, "Cập nhật Tiến độ lớp học (Sổ cái Ledger)")
bullet(doc, "Code gọi markComplete(...) từ helper/progress.js.")
bullet(doc, "Hàm này sẽ ghi một dòng (hoặc update) vào bảng StudentProgress với itemType = 'EXAM', score = totalScore.")
bullet(doc, "Lệnh này đảm bảo Sổ điểm (Gradebook) sẽ tự động nhận diện được bài thi này để tính trung bình môn.")
step(doc, 8, "Phản hồi", "Gọi res.redirect(`/student/classrooms/${classroomId}/exams/${examId}/result`).")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 2: Đăng nhập & Xác thực (Authentication Flow)", 1)
context(doc, "Học viên nhập Email và Password vào màn hình Login. Luồng này xử lý xác thực và cấp phát phiên làm việc an toàn.")
step(doc, 1, "Frontend Submit", "Người dùng nhập thông tin và POST lên /auth/login.")
step(doc, 2, "Router Match (routes/auth.js)")
code_block(doc, "router.post('/login', loginRateLimit, csrfProtection, loginValidator, authController.login);")
bullet(doc, "loginRateLimit chặn bruteforce (tối đa 10 lần/15 phút).")
bullet(doc, "csrfProtection kiểm tra token _csrf từ form để chặn giả mạo request.")
step(doc, 3, "Vào Service kiểm tra mật khẩu (controller/auth/auth.service.js)")
bullet(doc, "Truy vấn User bằng email: User.findOne({ email }).select('+passwordHash').")
bullet(doc, "Dùng thư viện bcrypt để so sánh mật khẩu mã hoá.")
code_block(doc, '''const isMatch = await bcrypt.compare(password, user.passwordHash);
if (!isMatch) throw new AppError(401, 'Invalid credentials');''')
step(doc, 4, "Cấp phát JWT Token (Access & Refresh)")
bullet(doc, "Sinh accessToken (sống 15 phút) và refreshToken (sống 7 ngày).")
bullet(doc, "Lưu refreshToken vào DB của User để có thể thu hồi (revoke) khi cần.")
step(doc, 5, "Set Cookies (controller/auth/auth.controller.js)")
code_block(doc, '''res.cookie('accessToken', accessToken, { httpOnly: true, secure: true });
res.cookie('refreshToken', refreshToken, { httpOnly: true, secure: true });''')
bullet(doc, "Cờ httpOnly đảm bảo JavaScript phía Client không thể đọc được Token (chống XSS).")
step(doc, 6, "Ngừa Session Fixation và Chuyển hướng")
code_block(doc, '''req.session.regenerate(() => {
    req.logIn(user, () => {
        res.redirect('/student');
    });
});''')
bullet(doc, "req.session.regenerate() lập tức đổi Session ID mới ngay sau khi xác thực thành công.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 3: Đăng ký tài khoản (Register Flow)", 1)
context(doc, "Người dùng mới điền form tạo tài khoản. Xử lý mã hóa mật khẩu và phân quyền.")
step(doc, 1, "Frontend Submit", "Gửi dữ liệu Name, Email, Password, Role lên POST /auth/register.")
step(doc, 2, "Kiểm tra quyền cấu hình hệ thống")
bullet(doc, "Hệ thống truy xuất SystemSetting.findOne({key: 'allowRegistration'}) để kiểm tra xem Admin có đang mở đăng ký hay không.")
step(doc, 3, "Gọi Service (auth.service.js)")
bullet(doc, "Truy vấn DB kiểm tra xem Email đã tồn tại chưa. Nếu có ném lỗi 409 Conflict.")
code_block(doc, '''const existingUser = await User.findOne({ email: userData.email });
if (existingUser) throw new AppError(409, 'Email already exists');''')
step(doc, 4, "Ghi DB và Mã hóa tự động")
bullet(doc, "Với Role là Teacher, ép status = 'pending' để Admin duyệt thủ công.")
bullet(doc, "Hàm save() kích hoạt Mongoose Middleware (pre-save hook) trong User model để tự động bcrypt.hash mật khẩu trước khi lưu vào Mongo.")
step(doc, 5, "Tự động Đăng nhập", "Gọi lại hàm tạo JWT và lưu Cookie HttpOnly như ở luồng Đăng nhập, sau đó redirect.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 4: Học viên tham gia lớp học (Join Classroom)", 1)
context(doc, "Học sinh nhập mã Code gồm 6 ký tự để ghi danh vào lớp. Tuỳ thuộc cài đặt của giáo viên mà học sinh được vào thẳng hoặc chờ duyệt.")
step(doc, 1, "Gửi mã Code (Classroom Controller)")
code_block(doc, "const code = req.body.code.trim().toUpperCase();")
bullet(doc, "Mã code luôn được chuẩn hóa thành in hoa để tra cứu.")
step(doc, 2, "Tra cứu Database")
bullet(doc, "Classroom.findOne({ code, isArchived: false }). Trả về 404 nếu lớp không tồn tại hoặc đã bị lưu trữ.")
step(doc, 3, "Tránh trùng lặp")
bullet(doc, "Kiểm tra ClassroomMember xem học sinh này đã join chưa. Nếu đã có thì không cho join lại.")
step(doc, 4, "Tạo thành viên với Status phụ thuộc thiết lập lớp")
code_block(doc, '''const status = classroom.approvalRequired ? 'pending' : 'approved';
await ClassroomMember.create({ classroom: classroom.id, student: req.user.id, status });''')
step(doc, 5, "Phản hồi", "Báo flash message thành công hoặc 'đang chờ duyệt' dựa vào status.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 5: Đánh giá Tiến độ khoá học (Progress Engine)", 1)
context(doc, "Khi học sinh click vào mục 'Bài giảng' hoặc xem tổng quan lớp, hệ thống tự tính toán xem bài nào được mở (In Progress), bài nào bị khoá (Locked).")
step(doc, 1, "Kích hoạt", "Controller gọi hàm computeCourseProgress(classroomId, studentId).")
step(doc, 2, "Truy vấn dữ liệu song song (courseProgress.service.js)")
bullet(doc, "Sử dụng Promise.all để lấy đồng thời tất cả tài liệu: Lecture, Assignment, Exam.")
code_block(doc, '''const [lectures, assignments, exams] = await Promise.all([
    Lecture.find({ classroom: classroomId, isPublished: true }),
    Assignment.find({ classroom: classroomId, isPublished: true }),
    Exam.find({ classroom: classroomId, isPublished: true })
]);''')
step(doc, 3, "Lấy lịch sử học tập")
bullet(doc, "Đẩy kết quả vào biến Set (Bảng băm) để tra cứu siêu tốc O(1).")
code_block(doc, "const completedKeys = new Set(completedRecords.map(r => `${r.itemType}:${r.itemId}`));")
step(doc, 4, "Thuật toán giải quyết Prerequisite (Chặn mở khoá)")
bullet(doc, "Duyệt qua danh sách tài liệu đã sort từ trên xuống dưới (Waterfall).")
bullet(doc, "Nếu bài học có ID nằm trong completedKeys, đánh dấu trạng thái COMPLETED.")
bullet(doc, "Nếu chưa có, đánh dấu bài ĐẦU TIÊN là IN_PROGRESS. Các bài tiếp theo lập tức bị khoá (LOCKED).")
code_block(doc, '''let hasFoundInProgress = false;
for (const item of allItems) {
    if (completedKeys.has(`${item.type}:${item.id}`)) {
        item.status = 'COMPLETED';
    } else if (!hasFoundInProgress) {
        item.status = 'IN_PROGRESS';
        hasFoundInProgress = true; // Bật chốt chặn
    } else {
        item.status = 'LOCKED';
    }
}''')
step(doc, 5, "Hiển thị", "Trả progressTree về View (Pug). Frontend sẽ render ổ khoá (lock icon) nếu status là LOCKED.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 6: Chấm điểm bài tập bằng Rubric (Grading Flow)", 1)
context(doc, "Giáo viên mở bài làm của học sinh và bắt đầu chấm điểm từng tiêu chí trong bảng Rubric (VD: Nội dung 5đ, Trình bày 3đ, Sáng tạo 2đ).")
step(doc, 1, "Frontend Submit", "Giáo viên POST form với các ô input chứa điểm cho từng tiêu chí: req.body = { 'crit_abc123': 4, 'crit_def456': 2 }")
step(doc, 2, "Xác thực Quyền sở hữu lớp học (Bảo mật)")
bullet(doc, "Phải check xem giáo viên hiện tại có đúng là người tạo ra lớp học này không.")
code_block(doc, '''const classroom = await Classroom.findOne({ _id: req.params.classroomId, teacher: req.user.id });
if (!classroom) return res.status(404).send('Classroom not found or unauthorized');''')
step(doc, 3, "Vào Controller (teacher/submission.controller.js)")
bullet(doc, "Trích xuất req.body thành gradesMap object để dễ tra cứu.")
code_block(doc, "const gradesMap = extractRubricGrades(req.body);")
step(doc, 4, "Thuật toán kẹp điểm (grading.service.js)")
bullet(doc, "Duyệt qua các tiêu chí và dùng Math.min, Math.max để chặn giáo viên nhập số âm hoặc nhập vượt mức tối đa của tiêu chí (maxPoints).")
code_block(doc, '''let totalScore = 0;
for (const criterion of rubric.criteria) {
    const inputPoints = gradesMap[criterion._id.toString()] || 0;
    // Chặn nhập lố điểm (Clamp points)
    const clampedPoints = Math.min(Math.max(Number(inputPoints), 0), criterion.maxPoints);
    totalScore += clampedPoints;
}''')
step(doc, 5, "Ghi DB", "Lưu điểm tổng (totalScore) và mảng chi tiết (rubricGrades) vào bản ghi Submission.")
step(doc, 6, "Cập nhật Sổ Điểm", "Gọi markComplete() để thông báo cho Sổ Điểm biết bài tập này đã có điểm mới.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 7: Giám sát gian lận thi cử (Anti-Cheat Socket Flow)", 1)
context(doc, "Học sinh đang thi và cố tình chuyển tab (Alt-Tab) sang Google để tra cứu đáp án. Hệ thống lập tức bắt được và báo cáo.")
step(doc, 1, "Frontend Event (public/js/anti-cheat.js)")
bullet(doc, "Client Browser lắng nghe sự kiện visibilitychange và blur.")
code_block(doc, '''document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
        recordViolation('visibility_hidden', 'Tab was hidden');
    }
});''')
step(doc, 2, "Gắn Overlay và gửi Socket")
bullet(doc, "Hiển thị overlay đỏ cảnh báo trên màn hình học sinh và Bắn tín hiệu thẳng lên Socket.IO thay vì API HTTP.")
code_block(doc, '''socket.emit('cheat-violation', {
    examId: config.examId,
    violation: { type: 'blur', time: new Date() }
});''')
step(doc, 3, "Server xử lý (Socket Namespace)")
bullet(doc, "Socket nhận event và ghi thẳng violation vào mảng của Document ExamSubmission.")
code_block(doc, '''const submission = await ExamSubmission.findOne({ _id: data.submissionId });
submission.violations.push(data.violation);
await submission.save();''')
step(doc, 4, "Broadcast cho Giáo viên", "Phát ngược (Broadcast) sự kiện này vào Room của bài thi để giáo viên đang xem màn hình Dashboard bắt được tín hiệu nháy đỏ ngay lập tức.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 8: Tính toán Sổ Điểm (Gradebook Compute On-the-fly)", 1)
context(doc, "Mỗi khi giáo viên xem bảng điểm của lớp, điểm số được tính toán tại chỗ thay vì lưu cứng trong DB.")
step(doc, 1, "Truy vấn điểm gốc")
bullet(doc, "Query lấy tất cả các bản ghi StudentProgress của học sinh trong lớp có score != null.")
step(doc, 2, "Xác định Điểm thành phần (Attendance, Midterm, Final)")
bullet(doc, "Tính điểm Chuyên cần (Attendance): Dựa trên số buổi có mặt so với tổng số buổi.")
bullet(doc, "Tính điểm Giữa kỳ (Midterm): Trung bình các bài thi có examType='midterm', hoặc lấy từ điểm do giáo viên nhập tay (manualMidtermScore).")
bullet(doc, "Tính điểm Cuối kỳ (Final): Lấy từ bài thi có examType='final', hoặc điểm do giáo viên nhập tay (manualFinalScore).")
step(doc, 3, "Áp dụng Công thức Đại học Việt Nam (10/30/60)")
bullet(doc, "Áp dụng công thức cố định: totalScore = 0.1 * Chuyên cần + 0.3 * Giữa kỳ + 0.6 * Cuối kỳ.")
code_block(doc, '''let totalScore = null;
if (attendanceScore != null && midtermScore != null && finalScore != null) {
  totalScore = 0.1 * attendanceScore + 0.3 * midtermScore + 0.6 * finalScore;
  totalScore = Math.round(totalScore * 100) / 100;
}''')
step(doc, 4, "Quy đổi ra Hệ 4 và Điểm chữ")
bullet(doc, "Dùng hàm getLetterGrade(totalScore) để tự động quy đổi ra điểm chữ (A, B, C, D, F) và hệ 4 (4.0, 3.0...) theo chuẩn tín chỉ.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 9: Khởi tạo phòng họp WebRTC (Online Meeting)", 1)
context(doc, "Giáo viên tạo phòng họp trực tuyến và học sinh tham gia bằng cách truyền video qua mạng ngang hàng P2P.")
step(doc, 1, "Tham gia Room (Signaling Server)")
bullet(doc, "Học sinh bấm 'Vào phòng'. Socket gửi event join-room lên Server.")
step(doc, 2, "Xác thực Room Join (Socket)")
bullet(doc, "Server xử lý event join-room, kiểm tra quyền User trong lớp học. Nếu là sinh viên thì cho vào Waiting Room, nếu là GV thì duyệt thẳng vào Meeting Room.")
code_block(doc, '''if (data.userRole === 'teacher') {
  meetingRooms[data.meetingId].push(socket.id);
} else {
  waitingRooms[data.meetingId].push(socket.id);
  io.to(teacherSocketId).emit('waiting_students_list', waitingRooms);
}''')
step(doc, 3, "Tạo kết nối ngang hàng P2P")
bullet(doc, "Tạo đối tượng RTCPeerConnection kèm cấu hình STUN Server.")
bullet(doc, "Lấy luồng Camera/Mic từ navigator.mediaDevices.getUserMedia() và nhét vào PC.")
code_block(doc, '''const pc = new RTCPeerConnection(iceServers);
localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));''')
step(doc, 4, "Trao đổi SDP Offer / Answer (Handshake)")
bullet(doc, "Client 1 tạo Offer, gửi lên Node.js (Socket.IO). Node.js forward sang Client 2. Client 2 trả Answer về.")
code_block(doc, '''const offer = await pc.createOffer();
await pc.setLocalDescription(offer);
socket.emit('webrtc_offer', { targetSocketId: socketId, offer });''')
step(doc, 5, "Nhận Media (ontrack)", "Khi kết nối P2P thành công, event ontrack sẽ bắn ra luồng Video của đối phương. Hệ thống gán srcObject vào thẻ HTML.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 10: Nhắn tin nhóm thời gian thực (Real-time Chat)", 1)
context(doc, "Học sinh gửi tin nhắn vào group chat chung của lớp học, không cần tải lại trang.")
step(doc, 1, "Gắn kết Socket Room")
bullet(doc, "Khi vừa mở web, Client gọi event 'join_chat'. Server nhét Client vào room mang mã lớp: socket.join(classroomId).")
step(doc, 2, "Gửi tin nhắn (send_message)")
bullet(doc, "Client gửi event mang nội dung tin nhắn.")
step(doc, 3, "Lưu DB và Broadcast (chat.service.js)")
bullet(doc, "Tạo bản ghi ChatMessage trong MongoDB.")
bullet(doc, "Populate lấy thông tin avatar, tên của người gửi.")
code_block(doc, "chatMonitor.to(classroomId).emit('receive_message', newMsg);")
step(doc, 4, "Render UI (Client)")
bullet(doc, "Sự kiện receive_message tới mọi người trong lớp. Dùng JS thuần document.createElement để nhét bong bóng chat vào màn hình.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 11: Đánh giá Hoàn thành & Cấp chứng chỉ (Completion Engine)", 1)
context(doc, "Hệ thống tự động kiểm tra xem học sinh đã đạt đủ yêu cầu của khóa học hay chưa để mở khóa nút Tải Chứng Chỉ.")
step(doc, 1, "Trigger Evaluation")
bullet(doc, "Được kích hoạt mỗi khi trang chi tiết khoá học tải lên.")
step(doc, 2, "Kiểm tra Rules (completion.service.js)")
bullet(doc, "Load completionRules của lớp (VD: Cần 100% bài giảng và Điểm tổng >= 80%).")
code_block(doc, '''if (rules.requireAllItems && progressTree.completedCount < progressTree.totalCount) {
    isComplete = false;
}
if (rules.minOverallPercent && gradePercent < rules.minOverallPercent) {
    isComplete = false;
}''')
step(doc, 3, "Phản hồi View")
bullet(doc, "Nếu isComplete = true, Pug sẽ dùng điều kiện if để render hiển thị huy hiệu 'Hoàn Thành' và hiện nút Download Certificate.")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "Walkthrough 12: Điểm danh bằng Mã PIN (Attendance Check-in)", 1)
context(doc, "Giáo viên mở phiên điểm danh. Máy chiếu hiển thị mã PIN đổi liên tục mỗi phút. Học sinh dùng điện thoại nhập mã PIN để điểm danh.")
step(doc, 1, "Tạo Phiên Điểm Danh (Teacher)")
bullet(doc, "Xác thực tư cách Giáo viên của lớp: findOne({ _id: classroomId, teacher: req.user.id }).")
bullet(doc, "Server tạo AttendanceSession mới trên DB.")
bullet(doc, "Server lập tức tạo mảng AttendanceRecord có status='absent' cho TOÀN BỘ học sinh trong lớp.")
code_block(doc, '''const records = activeStudents.map(studentId => ({
    session: session.id,
    student: studentId,
    status: 'absent'
}));
await AttendanceRecord.insertMany(records);''')
step(doc, 2, "Học sinh nhập PIN (Student)")
bullet(doc, "Học sinh truy cập trang điểm danh, điền mã PIN thấy trên bảng và bấm Gửi (POST).")
step(doc, 3, "Xác thực Tư cách Học sinh (Bảo mật)")
bullet(doc, "Phải check xem sinh viên này có đang là thành viên chính thức (approved) của lớp không, nếu không chặn ngay.")
code_block(doc, '''const membership = await ClassroomMember.findOne({ 
  classroom: req.params.classroomId,
  student: req.user.id,
  status: 'approved'
});
if (!membership) return res.status(404).send('Classroom not found');''')
step(doc, 4, "Xác thực mã PIN & Hạn chót")
bullet(doc, "Kiểm tra mã code có khớp với currentCode của session không.")
bullet(doc, "Kiểm tra expiresAt của mã PIN xem đã hết hạn chưa (Chống việc sinh viên nhắn tin mã PIN cho bạn ở nhà).")
code_block(doc, '''if (session.currentCode !== code) return res.redirect('/attendance?error=Invalid+Code');
if (new Date() > session.expiresAt) return res.redirect('/attendance?error=Expired');''')
step(doc, 5, "Ghi nhận có mặt (Update Record)")
bullet(doc, "Tìm lại bản ghi 'absent' đã tạo lúc nãy và cập nhật thành 'present'.")
code_block(doc, '''const record = await AttendanceRecord.findOne({ session: session.id, student: req.user.id });
record.status = 'present';
record.time = new Date();
await record.save();''')

# ── SAVE ──
os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
doc.save(OUT_PATH)
print(f"SUCCESS: {OUT_PATH}")
