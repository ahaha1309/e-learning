# Generates 04_Frontend_Code_Explanation_Full.docx
# Covers Frontend Architecture, Pug Templates, and Core Client-Side Scripts.
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT_PATH = r"C:\Users\vanha\Downloads\Documentations_DOCX\04_Frontend_Code_Explanation_Full.docx"

def new_doc():
    doc = Document()
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    return doc

def h(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    if p.runs:
        run = p.runs[0]
        run.font.name = 'Calibri'
        colors = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
                  3: RGBColor(0x1A,0x6A,0x1A), 4: RGBColor(0x66,0x33,0x00)}
        run.font.color.rgb = colors.get(level, RGBColor(0,0,0))
        sizes  = {1: 16, 2: 14, 3: 12, 4: 11}
        run.font.size = Pt(sizes.get(level, 11))
    return p

def code_block(doc, code_text):
    for line in code_text.split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent   = Inches(0.35)
        p.paragraph_format.space_before  = Pt(0)
        p.paragraph_format.space_after   = Pt(0)
        r = p.add_run(line if line.strip() else ' ')
        r.font.name  = 'Courier New'
        r.font.size  = Pt(9)
        r.font.color.rgb = RGBColor(0x17,0x5E,0x24)
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'),   'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'),  'F2F2F2')
        p._p.get_or_add_pPr().append(shd)

def explain_text(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after  = Pt(8)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)
    return p

def divider(doc):
    p = doc.add_paragraph('─' * 90)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after  = Pt(6)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0xAA,0xAA,0xAA)
        r.font.size = Pt(8)

doc = new_doc()

# ── TITLE PAGE ──
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run("04. GIẢI THÍCH CODE FRONTEND TOÀN BỘ\nE-Learning LMS – Pug / TailwindCSS / Vanilla JS")
r.font.name = 'Calibri'; r.font.size = Pt(22); r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)
explain_text(doc, "Tài liệu này phân tích chi tiết tư duy thiết kế kiến trúc Frontend, cấu trúc Layout Pug, và đi sâu vào từng dòng mã nguồn JavaScript phía Client (Browser).")
divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "CHƯƠNG 1: KIẾN TRÚC TEMPLATE PUG & TAILWINDCSS", 1)
explain_text(doc, "Dự án sử dụng mô hình Server-Side Rendering (SSR) bằng Pug Engine, kết hợp với TailwindCSS qua CDN (hoặc PostCSS) để styling nhanh chóng.")

h(doc, "1.1 Cấu trúc Layout Kế Thừa (views/layouts/)", 2)
code_block(doc, '''//- views/layouts/main.pug
doctype html
html(lang="vi", class="light")
  head
    title #{title} | E-Learning LMS
    script(src="https://cdn.tailwindcss.com")
    link(rel="stylesheet", href="/css/custom.css")
    block head
  body(class="bg-slate-50 text-slate-900")
    include ../shared/navbar.pug
    main(class="container mx-auto px-4 py-8")
      block content
    include ../shared/footer.pug
    script(src="/js/modal.js")
    block scripts''')
explain_text(doc, "File main.pug định nghĩa bộ khung HTML chuẩn. Có 3 khu vực thay đổi động (blocks) cho các trang con (views) tiêm code vào: 'block head' (dành cho CSS riêng), 'block content' (nội dung chính), và 'block scripts' (dành cho JS riêng biệt). navbar và footer được tái sử dụng bằng lệnh include.")

h(doc, "1.2 Cách trang con mở rộng Layout (views/student/dashboard.pug)", 2)
code_block(doc, '''extends ../../layouts/main.pug

block content
  div(class="grid grid-cols-1 md:grid-cols-3 gap-6")
    each course in enrolledCourses
      div(class="card hover:shadow-lg transition-all")
        h3(class="text-xl font-bold")= course.name
        p= course.teacher.name''')
explain_text(doc, "Lệnh 'extends' giúp trang dashboard kế thừa khung giao diện. 'each course in enrolledCourses' là vòng lặp xuất mảng dữ liệu được Controller truyền xuống sang mã HTML động. Thay vì viết chuỗi HTML trong Node.js, Pug giúp code sạch và dễ đọc hơn.")

divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "CHƯƠNG 2: HỌP TRỰC TUYẾN WEBRTC (meeting-room.js)", 1)
explain_text(doc, "File phức tạp nhất (hơn 1100 dòng), phụ trách khởi tạo Camera/Mic, kết nối Signaling Server (Socket.IO) và thiết lập mạng ngang hàng (P2P).")

h(doc, "2.1 Lấy luồng Camera & Mic (navigator.mediaDevices)", 2)
code_block(doc, '''try {
  localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  localVideo.srcObject = localStream;
  
  // Tắt mic/cam mặc định khi vừa vào phòng chờ (Lobby)
  localStream.getAudioTracks().forEach((t) => (t.enabled = false));
  localStream.getVideoTracks().forEach((t) => (t.enabled = false));
} catch (err) {
  console.warn('Could not access camera/microphone:', err);
}''')
explain_text(doc, "Dùng API trình duyệt getUserMedia để yêu cầu cấp quyền. Gán stream vào thẻ <video> (srcObject). Mặc định, mute track âm thanh và video bằng cách duyệt mảng getAudioTracks() và set enabled = false, đảm bảo sự riêng tư ở phòng chờ.")

h(doc, "2.2 Khởi tạo PeerConnection (Tạo cầu nối P2P)", 2)
code_block(doc, '''function createPeerConnection(targetSocketId) {
  const pc = new RTCPeerConnection(iceServers); // Dùng STUN servers của Google

  // Thu thập ICE Candidates (địa chỉ IP) và gửi cho người kia qua Socket
  pc.onicecandidate = (event) => {
    if (event.candidate && socket) {
      socket.emit('ice_candidate', { targetSocketId, candidate: event.candidate });
    }
  };

  // Khi nhận được luồng hình ảnh/âm thanh từ người kia
  pc.ontrack = (event) => {
    let stream = event.streams[0];
    if (!stream) stream = new MediaStream([event.track]);
    
    // Gắn vào giao diện DOM
    addOrUpdateRemoteVideoTile(targetSocketId, stream);
  };
  return pc;
}''')
explain_text(doc, "RTCPeerConnection là xương sống của WebRTC. Cần cấu hình iceServers (STUN) để vượt qua NAT/Tường lửa. onicecandidate bắt các địa chỉ IP mạng có thể kết nối được. ontrack được kích hoạt khi kết nối P2P thành công và nhận được khung hình đầu tiên.")

h(doc, "2.3 Luồng SDP Offer / Answer (Signaling)", 2)
code_block(doc, '''// Người mới vào tạo Offer
const offer = await pc.createOffer();
await pc.setLocalDescription(offer);
socket.emit('webrtc_offer', { targetSocketId: socketId, offer });

// Người nhận được Offer tạo Answer
socket.on('webrtc_offer', async ({ senderSocketId, offer }) => {
  const pc = createPeerConnection(senderSocketId);
  await pc.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  socket.emit('webrtc_answer', { targetSocketId: senderSocketId, answer });
});''')
explain_text(doc, "Cơ chế 'Bắt tay' (Handshake): Người gọi (Caller) đóng gói thông tin định dạng video/audio của mình thành Offer. Người nghe (Callee) lưu lại (setRemoteDescription) và trả lời bằng Answer. Sau khi đổi xong SDP và ICE Candidate, 2 máy tính kết nối trực tiếp với nhau.")

h(doc, "2.4 Tính năng Chia sẻ màn hình (Screen Share)", 2)
code_block(doc, '''screenBtn.addEventListener('click', async () => {
  screenStream = await navigator.mediaDevices.getDisplayMedia({ video: { cursor: 'always' } });
  const screenTrack = screenStream.getVideoTracks()[0];

  Object.entries(peerConnections).forEach(async ([socketId, pc]) => {
    // Ép track chia sẻ màn hình vào các kết nối P2P đang có
    pc.addTrack(screenTrack, screenStream);
    
    // Renegotiate: Yêu cầu đối tác thương lượng lại kết nối để nhận track mới
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    socket.emit('webrtc_offer', { targetSocketId: socketId, offer });
  });
});''')
explain_text(doc, "Sử dụng getDisplayMedia() thay vì getUserMedia() để bắt màn hình desktop. Điểm then chốt là quá trình Renegotiation (Tạo Offer mới) để báo cho các Peer khác biết rằng: 'Tôi vừa có thêm một luồng hình ảnh mới, hãy cập nhật lại liên kết'.")

divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "CHƯƠNG 3: BẮT GIAN LẬN THI CỬ (anti-cheat.js)", 1)
explain_text(doc, "Đoạn mã JS nhỏ nhưng cực kỳ quyền lực, chạy ngầm trong giao diện làm bài thi giám sát.")

h(doc, "3.1 Lắng nghe sự kiện hệ thống (Browser APIs)", 2)
code_block(doc, '''window.addEventListener('blur', () => {
  recordViolation('blur', 'Switched tab or window');
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') {
    recordViolation('visibility_hidden', 'Tab was hidden');
  }
});

document.addEventListener('copy', (e) => { e.preventDefault(); recordViolation('copy', 'Attempted to copy'); });
document.addEventListener('contextmenu', (e) => { e.preventDefault(); recordViolation('right_click', 'Attempted to right click'); });''')
explain_text(doc, "Bắt sự kiện: 'blur' (click ra ngoài cửa sổ duyệt web), 'visibilitychange' (chuyển sang tab khác). Sự kiện e.preventDefault() tại copy/paste/contextmenu khiến hành vi chuột phải và Ctrl+C bị vô hiệu hoá hoàn toàn.")

h(doc, "3.2 Ghi nhận vi phạm & Báo cáo Real-time", 2)
code_block(doc, '''function recordViolation(type, details) {
  violations.push({ type, time: new Date().toISOString(), details });
  
  // Hiển thị Overlay cảnh báo học sinh
  violationOverlay.classList.add('visible');
  
  // Gửi trực tiếp lên Server để báo cho Giáo viên
  if (socket) {
    socket.emit('cheat-violation', { examId, studentId, violation: v });
  }

  // Tự động nộp bài nếu vi phạm quá mức
  if (config.maxViolations > 0 && violations.length >= config.maxViolations) {
    setTimeout(() => { examForm.submit(); }, 2500);
  }
}''')
explain_text(doc, "Lưu mảng violations nội bộ. Tự động bắn tín hiệu socket 'cheat-violation' về cho Node.js (sau đó Server sẽ forward sang màn hình giáo viên). Nếu độ dài mảng chạm ngưỡng maxViolations (do GV cấu hình), kích hoạt hàm submit form tự động.")

divider(doc)
doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
h(doc, "CHƯƠNG 4: THAO TÁC DOM VÀ GIAO DIỆN (teams-chat.js & modal.js)", 1)
explain_text(doc, "Các script điều khiển tương tác UI, ẩn/hiện Modal và xử lý Chat real-time không cần tải lại trang.")

h(doc, "4.1 teams-chat.js (Render tin nhắn)", 2)
code_block(doc, '''socket.on('receive_message', (msg) => {
  const isMine = String(msg.sender._id) === String(currentUserId);
  const wrapper = document.createElement('div');
  wrapper.className = `flex gap-3 max-w-[85%] ${isMine ? 'ml-auto flex-row-reverse' : ''}`;
  
  wrapper.innerHTML = `
    <img src="${msg.sender.avatarUrl}" class="w-8 h-8 rounded-full">
    <div class="flex flex-col ${isMine ? 'items-end' : 'items-start'}">
      <span class="text-xs text-slate-500">${msg.sender.name}</span>
      <div class="px-4 py-2 rounded-2xl ${isMine ? 'bg-[#5B5FC7] text-white' : 'bg-white border text-slate-900'}">
        ${msg.content}
      </div>
    </div>
  `;
  chatMessages.appendChild(wrapper);
  scrollToBottom();
});''')
explain_text(doc, "Khi Socket.IO bắt được event 'receive_message', trình duyệt tiến hành render khối HTML trực tiếp bằng document.createElement(). Dùng toán tử ba ngôi để kiểm tra isMine (tin nhắn của mình) để đẩy sang bên phải bằng Tailwind (ml-auto flex-row-reverse) và đổi màu nền, cuối cùng gọi scrollToBottom để tự cuộn xuống cuối.")

h(doc, "4.2 modal.js (Đóng mở Popup)", 2)
code_block(doc, '''document.querySelectorAll('[data-modal-target]').forEach(trigger => {
  trigger.addEventListener('click', (e) => {
    const modalId = trigger.getAttribute('data-modal-target');
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('hidden');
      modal.classList.add('flex', 'animate-fade-in');
    }
  });
});''')
explain_text(doc, "Kiến trúc Event Delegation nhẹ nhàng: Chỉ cần gắn data-modal-target='id_cua_modal' vào HTML Button. Khi click, JS tự động tìm element có ID đó, xoá class 'hidden' và thêm class Tailwind để tạo animation. Không cần viết JS cụ thể cho từng nút.")

# ── SAVE ──
os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
doc.save(OUT_PATH)
print(f"SUCCESS: {OUT_PATH}")
