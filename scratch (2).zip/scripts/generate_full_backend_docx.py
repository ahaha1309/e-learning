import os
import re
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

def add_heading(doc, text, level):
    h = doc.add_heading(text, level=level)
    h.style.font.name = 'Arial'
    if level == 1:
        h.style.font.size = Pt(16)
        h.style.font.color.rgb = RGBColor(0, 51, 102)
    elif level == 2:
        h.style.font.size = Pt(14)
        h.style.font.color.rgb = RGBColor(0, 76, 153)
    elif level == 3:
        h.style.font.size = Pt(12)
        h.style.font.color.rgb = RGBColor(0, 102, 204)
    return h

def add_paragraph(doc, text, bold=False):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    r.font.name = 'Arial'
    r.font.size = Pt(11)
    return p

def extract_functions(filepath):
    functions = []
    dependencies = []
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
        
        req_pattern = re.compile(r'(?:const|let|var)\s+.*?=\s*require\([\'"](.*?)[\'"]\)')
        for match in req_pattern.finditer(content):
            dependencies.append(match.group(1))
            
        func_pattern = re.compile(r'(?:exports\.|const\s+|async\s+function\s+)(\w+)\s*(?:=|)\s*(?:async\s*)?(?:\((.*?)\))?\s*=>?\s*\{?')
        for match in func_pattern.finditer(content):
            func_name = match.group(1)
            params = match.group(2) or ""
            if func_name not in ['require', 'Router', 'Schema', 'model', 'String', 'Number', 'Boolean', 'ObjectId']:
                functions.append((func_name, params))
                
        schema_pattern = re.compile(r'new\s+mongoose\.Schema\(\{([\s\S]*?)\}', re.MULTILINE)
        schemas = []
        for match in schema_pattern.finditer(content):
            schema_body = match.group(1)
            # Find fields
            fields = re.findall(r'(\w+):\s*\{', schema_body)
            if not fields:
                fields = re.findall(r'(\w+):\s*(?:String|Number|Boolean|Date|Array)', schema_body)
            schemas.extend(fields)
            
    return list(set(dependencies)), list(set(functions)), list(set(schemas))

def generate_doc():
    doc = Document()
    add_heading(doc, '03. Giải thích Code Backend (Bản Chi Tiết Toàn Bộ)', 0)
    add_paragraph(doc, 'Đây là bản phân tích ĐẦY ĐỦ toàn bộ source code backend E-Learning. Tài liệu bao gồm kiến trúc, luồng dữ liệu, và phân tích chức năng của TỪNG FILE cụ thể (Models, Controllers, Services).', bold=True)
    
    # 1. ARCHITECTURE
    add_heading(doc, '1. KIẾN TRÚC TỔNG THỂ (ARCHITECTURE)', 1)
    doc.add_paragraph('Backend xây dựng bằng Node.js, Express.js và MongoDB (Mongoose). Mô hình áp dụng là MVC mở rộng (Router -> Middleware -> Controller -> Service -> Model).', style='List Bullet')
    doc.add_paragraph('Fat Service, Thin Controller: Các logic phức tạp (tính điểm, tiến độ, vi phạm thi cử) được đẩy vào Services để tái sử dụng. Controller chỉ parse request, gọi service và trả response.', style='List Bullet')
    doc.add_paragraph('Global Error Handling: Mọi lỗi catch được ở controller được truyền qua next(error) và gom lại xử lý ở index.js.', style='List Bullet')
    doc.add_paragraph('Authentication & Authorization: Sử dụng Passport (Session/Cookie) và RBAC middleware (kiểm tra Role, checkOwnership).', style='List Bullet')

    # 2. FILE BY FILE EXPLANATION
    base_dir = r"c:\Users\vanha\OneDrive\Desktop\e-learning"
    folders = ['models', 'services', 'controller', 'middleware', 'routes']
    
    # Manual deep-dives for core files
    deep_dives = {
        'controller/student/exam.controller.js': 'File CỰC KỲ quan trọng xử lý học sinh làm bài thi.\n- renderTakeExam: Sinh attempt mới, khóa attempt nếu hết lượt, xáo trộn câu hỏi (Fisher-Yates shuffle).\n- submitExamHandler: Chấm điểm tự động câu trắc nghiệm ngay khi nộp. Gọi evaluateDeadline từ examIntegrity.service để chốt giờ server. Gọi markComplete để cập nhật sổ điểm.',
        'services/courseProgress.service.js': 'Xử lý logic tiến độ học tập (Progress Tracking). Hàm computeCourseProgress tải toàn bộ bài học, kiểm tra những bài đã hoàn thành (completedKeys), sau đó tự động KHÓA (LOCKED) các bài tiếp theo nếu học sinh cố tình nhảy cóc (Prevent skipping).',
        'services/gradebook.service.js': 'Xử lý tính điểm trung bình môn theo chuẩn Tín chỉ Đại học Việt Nam. Hàm computeGradebook tự động tổng hợp Điểm Chuyên Cần (10%), Điểm Giữa Kỳ (30%) và Điểm Cuối Kỳ (60%). Hỗ trợ lấy tự động từ bài thi trắc nghiệm hoặc lấy từ điểm do Giáo viên nhập tay (manualMidtermScore, manualFinalScore). Cuối cùng dùng getLetterGrade để quy đổi hệ 4 (A, B, C, D, F).',
        'services/examIntegrity.service.js': 'Xử lý tính toàn vẹn của bài thi (Chống gian lận). Hàm evaluateDeadline so sánh giờ nộp với deadline do Server sinh ra (để chống học sinh hack đồng hồ ở frontend).',
        'middleware/rbac.js': 'Middleware phân quyền. requireAuth kiểm tra login. requireRole kiểm tra role. requireOwnership kiểm tra xem giáo viên có phải là chủ của lớp học / bài thi đó không trước khi cho phép sửa.'
    }

    for folder in folders:
        folder_path = os.path.join(base_dir, folder)
        if not os.path.exists(folder_path):
            continue
            
        add_heading(doc, f'2.{folders.index(folder)+1}. THƯ MỤC: {folder.upper()}', 1)
        add_paragraph(doc, f'Phân tích chi tiết các file trong {folder}/:', bold=True)
        
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.endswith('.js'):
                    filepath = os.path.join(root, file)
                    rel_path = os.path.relpath(filepath, base_dir).replace('\\', '/')
                    add_heading(doc, f'File: {rel_path}', 2)
                    
                    if rel_path in deep_dives:
                        p = doc.add_paragraph()
                        r = p.add_run('PHÂN TÍCH CHUYÊN SÂU (CORE LOGIC):\n')
                        r.bold = True
                        r.font.color.rgb = RGBColor(204, 0, 0)
                        doc.add_paragraph(deep_dives[rel_path])
                    
                    deps, funcs, schemas = extract_functions(filepath)
                    
                    if deps:
                        doc.add_paragraph(f"Dependencies: {', '.join(deps)}")
                        
                    if folder == 'models' and schemas:
                        add_paragraph(doc, 'Database Schema Fields:', bold=True)
                        doc.add_paragraph(', '.join(schemas))
                        doc.add_paragraph('Vai trò: Map với Collection trong MongoDB.')
                        
                    if funcs:
                        add_paragraph(doc, 'Các Hàm/Methods:', bold=True)
                        for fname, fparams in funcs:
                            p = doc.add_paragraph(style='List Bullet')
                            p.add_run(f'{fname}').bold = True
                            if fparams:
                                p.add_run(f'({fparams})')
                            
                            # Simple heuristics
                            if fname.startswith('render') or fname.startswith('get'):
                                p.add_run(' -> Lấy dữ liệu và trả về View / JSON.')
                            elif fname.startswith('create') or fname.startswith('add') or fname.startswith('submit'):
                                p.add_run(' -> Nhận data từ request body, validate, và ghi xuống Database.')
                            elif fname.startswith('update') or fname.startswith('edit'):
                                p.add_run(' -> Cập nhật bản ghi trong Database dựa trên ID.')
                            elif fname.startswith('delete') or fname.startswith('remove'):
                                p.add_run(' -> Xóa bản ghi trong Database.')
                            else:
                                p.add_run(' -> Thực thi nghiệp vụ nội bộ.')

    out_path = r"C:\Users\vanha\Downloads\Documentations_DOCX\03_Backend_Code_Explanation_Full.docx"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    doc.save(out_path)
    print(f"Generated successfully at {out_path}")

if __name__ == '__main__':
    generate_doc()
