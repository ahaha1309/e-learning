/**
 * Script tạo tài liệu Word: Luồng nghiệp vụ hệ thống E-Learning LMS
 * Cấu trúc mỗi chức năng:
 *   1. Mô tả / Ý nghĩa
 *   2. Các bước luồng nghiệp vụ (có đánh số)
 *   3. Code đi kèm với chú thích "// [Bước X] ..."
 */
'use strict';

const {
  Document, Packer, Paragraph, TextRun, HeadingLevel,
  AlignmentType, PageBreak, ShadingType,
} = require('docx');
const fs = require('fs');
const path = require('path');

// ─────────────────────── Helpers ────────────────────────────────
function h1(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 560, after: 280 },
  });
}
function h2(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 400, after: 200 },
  });
}
function h3(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 240, after: 120 },
  });
}
function p(text) {
  return new Paragraph({
    children: [new TextRun({ text, size: 22 })],
    spacing: { after: 120 },
  });
}
function b(text) {
  return new Paragraph({
    children: [new TextRun({ text: '\u2022 ' + text, size: 22 })],
    indent: { left: 360 },
    spacing: { after: 80 },
  });
}

// Nhãn "MÔ TẢ / Ý NGHĨA" màu xanh tím
function sectionMoTa(text) {
  return new Paragraph({
    children: [new TextRun({ text, size: 22, italics: true, color: '374151' })],
    indent: { left: 360 },
    spacing: { after: 160 },
    shading: { type: ShadingType.SOLID, color: 'e0f2fe' },
  });
}

// Nhãn "BƯỚC X" nổi bật
function buocLabel(num, text) {
  return new Paragraph({
    children: [
      new TextRun({ text: '[Bước ' + num + '] ', size: 22, bold: true, color: 'd97706' }),
      new TextRun({ text, size: 22 }),
    ],
    indent: { left: 360 },
    spacing: { after: 80 },
  });
}

// Nhãn loại code
function codeTieuDe(text) {
  return new Paragraph({
    children: [new TextRun({ text: '// Code: ' + text, size: 20, bold: true, color: '1d4ed8' })],
    spacing: { before: 120, after: 40 },
    indent: { left: 360 },
  });
}

// Render code
function code(rawText) {
  return rawText.split('\n').map(line =>
    new Paragraph({
      children: [new TextRun({ text: line || ' ', size: 18, font: 'Courier New', color: '1e293b' })],
      spacing: { before: 0, after: 0 },
      shading: { type: ShadingType.SOLID, color: 'f1f5f9' },
      indent: { left: 360 },
    })
  );
}

function note(text) {
  return new Paragraph({
    children: [new TextRun({ text: 'ℹ File: ' + text, size: 19, italics: true, color: '1e40af' })],
    spacing: { before: 80, after: 160 },
    indent: { left: 360 },
    shading: { type: ShadingType.SOLID, color: 'dbeafe' },
  });
}

function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}

function divider() {
  return new Paragraph({
    children: [new TextRun({ text: '─'.repeat(70), size: 16, color: 'd1d5db' })],
    spacing: { before: 160, after: 160 },
  });
}

const elems = [];

// ════════════════════════════════════════════════════════════════
// TRANG BÌA
// ════════════════════════════════════════════════════════════════
elems.push(
  new Paragraph({
    children: [new TextRun({ text: 'TÀI LIỆU NGHIỆP VỤ HỆ THỐNG', size: 52, bold: true, color: '1e40af' })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 1600, after: 400 },
  }),
  new Paragraph({
    children: [new TextRun({ text: 'E-LEARNING LMS', size: 64, bold: true, color: '1e3a8a' })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 600 },
  }),
  new Paragraph({
    children: [new TextRun({ text: 'Mô tả chức năng · Luồng nghiệp vụ từng bước · Code chi tiết', size: 26, italics: true, color: '6b7280' })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 400 },
  }),
  new Paragraph({
    children: [new TextRun({ text: 'Ngày: ' + new Date().toLocaleDateString('vi-VN'), size: 22, color: '9ca3af' })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  }),
  new Paragraph({
    children: [new TextRun({ text: 'Node.js + Express + MongoDB + Pug + Socket.IO', size: 20, color: 'b0b8c1' })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 1200 },
  }),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 1: TỔNG QUAN
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('1. TỔNG QUAN HỆ THỐNG'),
  sectionMoTa('Hệ thống E-Learning LMS là nền tảng học trực tuyến toàn diện, hỗ trợ 3 vai trò: Admin (quản trị viên), Teacher (giáo viên), Student (học sinh). Mỗi vai trò có giao diện, quyền hạn và luồng nghiệp vụ riêng biệt. Hệ thống tích hợp tính năng real-time (Socket.IO) để giám sát thi và chat lớp học.'),
  h2('Công nghệ sử dụng'),
  b('Backend: Node.js 22 + Express.js (MVC pattern)'),
  b('Database: MongoDB + Mongoose ODM (19 schemas)'),
  b('View Engine: Pug (server-side rendering)'),
  b('Authentication: Passport.js (Local + Google OAuth + Facebook OAuth) + JWT (Access 15 phút + Refresh 7 ngày)'),
  b('Real-time: Socket.IO — 2 namespace: /exam-monitor (giám sát thi), /chat (phòng học)'),
  b('File Upload: Multer (local) + Cloudinary (cloud)'),
  b('Session: express-session + MongoStore (lưu session trong MongoDB)'),
  b('Security: Helmet, CSRF token, Rate Limiting (300 req/15min global, 10 req/15min login), XSS Clean, Mongo Sanitize'),
  h2('Cấu trúc thư mục'),
  ...code(
    'e-learning/\n' +
    '  index.js           <- Entry point: Express app + Socket.IO\n' +
    '  config/            <- DB connection, Passport strategies\n' +
    '  middleware/        <- Auth guards, CSRF, Upload, currentUser\n' +
    '  routes/            <- URL routes (22 file routes)\n' +
    '  controller/\n' +
    '    auth/            <- Đăng ký, đăng nhập, OAuth\n' +
    '    admin/           <- Quản trị (13 controllers)\n' +
    '    teacher/         <- Nghiệp vụ giáo viên (12 controllers)\n' +
    '    student/         <- Nghiệp vụ học sinh (10 controllers)\n' +
    '  models/            <- 19 Mongoose Schemas\n' +
    '  services/          <- Business logic (gradebook, exam, completion)\n' +
    '  helper/            <- Token, notification, progress helper\n' +
    '  views/             <- Pug templates\n' +
    '  public/            <- CSS, JS, images'
  ),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 2: ROLES & PHÂN QUYỀN
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('2. CÁC ROLE VÀ PHÂN QUYỀN'),

  h2('2.1 Admin'),
  sectionMoTa('Quản trị viên hệ thống — có toàn quyền. Đây là vai trò cao nhất, quản lý toàn bộ người dùng, lớp học, nội dung, cài đặt nền tảng và kiểm soát sức khỏe hệ thống.'),
  b('Đăng nhập riêng tại /admin/login (chỉ dùng Passport local, không OAuth)'),
  b('Toàn quyền: User CRUD, Teacher approval, Classroom, Exam, Assignment, Category, Settings, Audit Log'),
  b('Middleware bảo vệ: requireAdminAuth (kiểm tra session + role=admin + status=active)'),

  h2('2.2 Teacher (Giáo viên)'),
  sectionMoTa('Người dạy học. Tạo và quản lý lớp học, bài giảng, bài tập, bài thi trong phạm vi lớp học của mình. Phải được Admin phê duyệt trước khi sử dụng hệ thống.'),
  b('Đăng ký → status = "pending" → chờ Admin duyệt → status = "active" → truy cập /teacher'),
  b('Chỉ thấy và quản lý lớp học, tài nguyên của chính mình'),
  b('Middleware: isAuthenticated + requireRole("teacher") + requireActive (status=active)'),

  h2('2.3 Student (Học sinh)'),
  sectionMoTa('Người học. Tham gia lớp học qua mã code, tiêu thụ nội dung (bài giảng, bài tập, bài thi), tương tác qua thảo luận và điểm danh. Không cần phê duyệt khi đăng ký.'),
  b('Đăng ký → status = "active" ngay (không cần phê duyệt)'),
  b('Tham gia lớp bằng mã code 6 ký tự từ giáo viên'),
  b('Middleware: isAuthenticated + requireRole("student")'),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 3: AUTHENTICATION
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('3. LUỒNG NGHIỆP VỤ — XÁC THỰC (AUTHENTICATION)'),
  note('controller/auth/auth.controller.js | controller/auth/auth.service.js | routes/auth.routes.js'),

  // ── 3.1 ──────────────────────────────────────────────────────
  h2('3.1 Đăng ký tài khoản (Register)'),
  sectionMoTa(
    'MÔ TẢ: Cho phép người dùng tạo tài khoản mới trên hệ thống với vai trò Teacher hoặc Student.\n' +
    'Ý NGHĨA: Teacher khi đăng ký sẽ ở trạng thái "pending" — phải chờ Admin xét duyệt trước khi có thể dạy. Student được kích hoạt ngay. Sau khi đăng ký thành công, hệ thống cấp JWT token và tạo session để người dùng không cần đăng nhập lại.'
  ),
  h3('URL: GET /auth/register (hiển thị form) | POST /auth/register (xử lý đăng ký)'),
  h3('Rate limit: 10 request / 15 phút'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Kiểm tra cài đặt hệ thống — Đọc SystemSetting key="allowRegistration". Nếu = false → từ chối toàn bộ đăng ký (lỗi 403).'),
  buocLabel('2', 'Validate form đầu vào — Dùng express-validator kiểm tra: name, email hợp lệ, password đủ độ dài, role hợp lệ. Nếu lỗi → re-render form với thông báo lỗi (HTTP 422).'),
  buocLabel('3', 'Kiểm tra email trùng lặp — Tìm User theo email (lowercase). Nếu tồn tại → ném lỗi 409 Conflict.'),
  buocLabel('4', 'Tạo User mới — Xác định status theo role: "teacher" → "pending"; còn lại → "active". Hash password với bcrypt (12 rounds).'),
  buocLabel('5', 'Tạo phiên xác thực — buildAuthSession(): sinh JWT Access Token (15 phút) + Refresh Token (7 ngày) → lưu hash của refresh token vào DB.'),
  buocLabel('6', 'Gắn cookie — Set 2 cookie httpOnly: accessToken, refreshToken.'),
  buocLabel('7', 'Tạo session Passport — req.session.regenerate() → req.logIn() → lưu session.role.'),
  buocLabel('8', 'Redirect theo role — Teacher pending → /auth/pending-approval; Teacher active → /teacher; Student → /student.'),
  divider(),
  codeTieuDe('auth.service.js — hàm registerUser() [thực hiện Bước 3 & 4]'),
  ...code(
    'async function registerUser(payload) {\n' +
    '  // [Bước 3] Kiểm tra email tồn tại\n' +
    '  const email = payload.email.toLowerCase();\n' +
    '  const existingUser = await User.findOne({ email });\n' +
    '  if (existingUser) {\n' +
    '    const error = new Error("An account with this email already exists.");\n' +
    '    error.statusCode = 409; // Conflict\n' +
    '    throw error;\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 4] Tạo User mới với status tùy role\n' +
    '  const user = new User({\n' +
    '    name: payload.name,\n' +
    '    email,\n' +
    '    role: payload.role,\n' +
    '    phone: payload.phone || null,\n' +
    '    provider: "local",\n' +
    '    status: payload.role === "teacher" ? "pending" : "active",\n' +
    '  });\n' +
    '  await user.setPassword(payload.password); // bcrypt hash, 12 rounds\n' +
    '  await user.save();\n' +
    '  return user;\n' +
    '}'
  ),
  codeTieuDe('auth.controller.js — hàm register() [Bước 1 → 8 đầy đủ]'),
  ...code(
    'async function register(req, res, next) {\n' +
    '  try {\n' +
    '    // [Bước 1] Kiểm tra allowRegistration setting\n' +
    '    const setting = await SystemSetting.findOne({ key: "allowRegistration" });\n' +
    '    if (setting && setting.value === false)\n' +
    '      return res.status(403).send("Registration is closed.");\n' +
    '\n' +
    '    // [Bước 2] Validate form đầu vào\n' +
    '    const validationMessage = getValidationErrors(req);\n' +
    '    if (validationMessage) {\n' +
    '      return res.status(422).render("auth/register", {\n' +
    '        title: "Create account",\n' +
    '        formData: req.body,\n' +
    '        errorMessage: validationMessage,\n' +
    '      });\n' +
    '    }\n' +
    '\n' +
    '    // [Bước 3 + 4] Tạo user (kiểm tra email, tạo mới)\n' +
    '    const user = await registerUser(req.body);\n' +
    '\n' +
    '    // [Bước 5] Tạo JWT access + refresh token\n' +
    '    const authSession = await buildAuthSession(user);\n' +
    '\n' +
    '    // [Bước 6] Gắn cookie httpOnly\n' +
    '    setAuthCookies(res, authSession);\n' +
    '\n' +
    '    // [Bước 7] Regenerate session Passport\n' +
    '    req.session.regenerate((sessionError) => {\n' +
    '      req.logIn(user, (loginError) => {\n' +
    '        req.session.role = user.role;\n' +
    '        req.session.save(() => {\n' +
    '          // [Bước 8] Redirect theo role / status\n' +
    '          if (user.role === "teacher" && user.status === "pending")\n' +
    '            return res.redirect("/auth/pending-approval");\n' +
    '          if (user.role === "teacher") return res.redirect("/teacher");\n' +
    '          return res.redirect("/student");\n' +
    '        });\n' +
    '      });\n' +
    '    });\n' +
    '  } catch (error) {\n' +
    '    return next(error); // Tới global error handler\n' +
    '  }\n' +
    '}'
  ),

  // ── 3.2 ──────────────────────────────────────────────────────
  h2('3.2 Đăng nhập (Login)'),
  sectionMoTa(
    'MÔ TẢ: Xác thực người dùng đã có tài khoản bằng email + password.\n' +
    'Ý NGHĨA: Sau khi xác thực thành công, hệ thống cấp cặp JWT token (access + refresh) và tạo Passport session. Đây là bước chốt để người dùng có thể truy cập toàn bộ tài nguyên được bảo vệ. Hành động đăng nhập được ghi vào AuditLog để truy vết bảo mật.'
  ),
  h3('URL: GET /auth/login (hiển thị form) | POST /auth/login (xử lý)'),
  h3('Rate limit: 10 request / 15 phút (bảo vệ brute-force)'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Validate form — Kiểm tra email và password có đủ / hợp lệ. Lỗi → re-render form (HTTP 422).'),
  buocLabel('2', 'Tìm và xác thực user — authenticateUser(email, password): tìm user trong DB, so khớp bcrypt hash. Không khớp → lỗi 401.'),
  buocLabel('3', 'Kiểm tra trạng thái tài khoản — status = "rejected" → lỗi 403. status = "pending" (teacher chưa duyệt) → redirect /pending-approval.'),
  buocLabel('4', 'Tạo phiên xác thực — buildAuthSession(): sinh JWT Access Token + Refresh Token, lưu hash vào DB.'),
  buocLabel('5', 'Ghi AuditLog — Lưu: action="USER_LOGIN", userId, ipAddress, userAgent, timestamp.'),
  buocLabel('6', 'Gắn cookie và session — Set httpOnly cookie, regenerate session Passport.'),
  buocLabel('7', 'Redirect theo role — Admin → từ chối (phải dùng /admin/login); Teacher → /teacher/dashboard; Student → /student/dashboard.'),
  divider(),
  codeTieuDe('auth.service.js — hàm authenticateUser() [thực hiện Bước 2 + 3]'),
  ...code(
    'async function authenticateUser(email, password) {\n' +
    '  // [Bước 2] Tìm user, select các field ẩn (select: false)\n' +
    '  const user = await User.findOne({ email: email.toLowerCase() })\n' +
    '    .select("+passwordHash +refreshTokenHash");\n' +
    '\n' +
    '  // [Bước 2] Không tìm thấy hoặc đăng ký bằng OAuth → lỗi\n' +
    '  if (!user || user.provider !== "local") {\n' +
    '    throw Object.assign(\n' +
    '      new Error("Invalid email or password."),\n' +
    '      { statusCode: 401 }\n' +
    '    );\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 2] So khớp bcrypt hash\n' +
    '  const passwordMatches = await user.comparePassword(password);\n' +
    '  if (!passwordMatches) {\n' +
    '    throw Object.assign(\n' +
    '      new Error("Invalid email or password."),\n' +
    '      { statusCode: 401 }\n' +
    '    );\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 3] Kiểm tra trạng thái tài khoản\n' +
    '  if (user.status === "rejected") {\n' +
    '    throw Object.assign(\n' +
    '      new Error("This account has been rejected by an administrator."),\n' +
    '      { statusCode: 403 }\n' +
    '    );\n' +
    '  }\n' +
    '\n' +
    '  return user;\n' +
    '}'
  ),
  codeTieuDe('auth.service.js — hàm buildAuthSession() [thực hiện Bước 4]'),
  ...code(
    'async function buildAuthSession(user) {\n' +
    '  // [Bước 4] Sinh JWT access token (15 phút) và refresh token (7 ngày)\n' +
    '  const accessToken = createAccessToken(user);\n' +
    '  const refreshToken = createRefreshToken(user);\n' +
    '\n' +
    '  // [Bước 4] Lưu hash SHA-256 của refresh token vào DB\n' +
    '  user.setRefreshToken(refreshToken);\n' +
    '  user.lastLoginAt = new Date();\n' +
    '  await user.save();\n' +
    '\n' +
    '  return { user: sanitizeUser(user), accessToken, refreshToken };\n' +
    '}'
  ),

  // ── 3.3 ──────────────────────────────────────────────────────
  h2('3.3 Đăng xuất (Logout)'),
  sectionMoTa(
    'MÔ TẢ: Hủy toàn bộ phiên làm việc của người dùng.\n' +
    'Ý NGHĨA: Đảm bảo an toàn — xóa refresh token khỏi DB (token cũ không thể tái sử dụng dù bị đánh cắp), xóa cookie trình duyệt, và hủy session server-side. Đây là chuẩn bảo mật "token revocation".'
  ),
  h3('URL: POST /auth/logout'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Thu hồi Refresh Token — revokeRefreshToken(userId): xóa refreshTokenHash trong DB → token cũ không còn dùng được.'),
  buocLabel('2', 'Xóa cookie — clearCookie("accessToken") và clearCookie("refreshToken") trên trình duyệt.'),
  buocLabel('3', 'Hủy session — req.session.destroy() → redirect /auth/login.'),
  divider(),
  codeTieuDe('auth.controller.js — hàm logout() [Bước 1 → 3]'),
  ...code(
    'async function logout(req, res, next) {\n' +
    '  try {\n' +
    '    // [Bước 1] Thu hồi refresh token trong DB\n' +
    '    if (req.user?.id) {\n' +
    '      await revokeRefreshToken(req.user.id);\n' +
    '    }\n' +
    '\n' +
    '    // [Bước 2] Xóa cookie trình duyệt\n' +
    '    res.clearCookie("accessToken");\n' +
    '    res.clearCookie("refreshToken");\n' +
    '\n' +
    '    // [Bước 3] Hủy session Passport\n' +
    '    req.session.destroy((error) => {\n' +
    '      if (error) return next(error);\n' +
    '      return res.redirect("/auth/login");\n' +
    '    });\n' +
    '  } catch (error) {\n' +
    '    return next(error);\n' +
    '  }\n' +
    '}'
  ),

  // ── 3.4 ──────────────────────────────────────────────────────
  h2('3.4 OAuth Login (Google / Facebook)'),
  sectionMoTa(
    'MÔ TẢ: Cho phép đăng nhập bằng tài khoản Google hoặc Facebook thay vì email/password.\n' +
    'Ý NGHĨA: Giảm ma sát đăng ký — người dùng không cần nhớ mật khẩu. Nếu email đã tồn tại trên hệ thống (đăng ký local trước đó), tài khoản được liên kết tự động. User OAuth mặc định nhận role = "student".'
  ),
  h3('URL: GET /auth/google → redirect consent screen | GET /auth/google/callback → xử lý'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Redirect OAuth — Passport redirect người dùng đến trang đăng nhập Google/Facebook.'),
  buocLabel('2', 'Google/Facebook callback — Nhận profile (id, email, name, photo) từ provider.'),
  buocLabel('3', 'Upsert User — upsertOAuthUser(): Tìm user theo (provider+providerId) hoặc email. Chưa có → tạo mới role="student", status="active". Đã có → cập nhật providerId, avatarUrl.'),
  buocLabel('4', 'Tạo phiên xác thực — buildAuthSession() → set cookie → session.'),
  buocLabel('5', 'Redirect dashboard — theo role của user.'),
  divider(),
  codeTieuDe('auth.service.js — hàm upsertOAuthUser() [thực hiện Bước 3]'),
  ...code(
    'async function upsertOAuthUser(profile, provider) {\n' +
    '  // [Bước 3] Chuẩn bị thông tin từ profile OAuth\n' +
    '  const email = profile.emails?.[0]?.value?.toLowerCase() || null;\n' +
    '  const name = profile.displayName || "Platform user";\n' +
    '  const avatarUrl = profile.photos?.[0]?.value || null;\n' +
    '\n' +
    '  // [Bước 3] Tìm user theo providerId hoặc email (tránh tạo trùng)\n' +
    '  let user = await User.findOne({\n' +
    '    $or: [\n' +
    '      { provider, providerId: profile.id },\n' +
    '      ...(email ? [{ email }] : []),\n' +
    '    ],\n' +
    '  }).select("+refreshTokenHash");\n' +
    '\n' +
    '  if (!user) {\n' +
    '    // [Bước 3] Chưa có → tạo mới với role=student, status=active\n' +
    '    user = new User({\n' +
    '      name, email: email || (profile.id + "@" + provider + ".local"),\n' +
    '      role: "student", provider, providerId: profile.id,\n' +
    '      avatarUrl, status: "active",\n' +
    '    });\n' +
    '  } else {\n' +
    '    // [Bước 3] Đã có → cập nhật thông tin OAuth, giữ nguyên status\n' +
    '    user.provider = provider;\n' +
    '    user.providerId = profile.id;\n' +
    '    user.avatarUrl = avatarUrl || user.avatarUrl;\n' +
    '    user.status = user.status === "rejected" ? "rejected" : "active";\n' +
    '  }\n' +
    '  await user.save();\n' +
    '  return user;\n' +
    '}'
  ),

  // ── 3.5 ──────────────────────────────────────────────────────
  h2('3.5 Refresh Token'),
  sectionMoTa(
    'MÔ TẢ: Cấp lại Access Token mới khi token cũ hết hạn (15 phút), mà không cần người dùng đăng nhập lại.\n' +
    'Ý NGHĨA: Đây là cơ chế "silent refresh" — client gửi refresh token (7 ngày) để nhận access token mới. Mỗi lần refresh, cặp token mới được cấp (token rotation) và hash cũ trong DB bị ghi đè → không thể tái sử dụng token cũ.'
  ),
  h3('URL: POST /auth/refresh (bỏ qua CSRF)'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Lấy refresh token từ cookie — Đọc req.cookies.refreshToken.'),
  buocLabel('2', 'Verify JWT và khớp hash — rotateRefreshToken(): verify JWT signature → tìm user → so khớp SHA-256 hash với DB. Không khớp → 401.'),
  buocLabel('3', 'Cấp cặp token mới — Sinh access + refresh token mới → ghi hash mới vào DB (token cũ bị vô hiệu hóa).'),
  buocLabel('4', 'Trả JSON — { user, accessToken, refreshToken }. Client cập nhật cookie.'),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 4: ADMIN
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('4. LUỒNG NGHIỆP VỤ — ADMIN'),
  note('controller/admin/ | routes/admin.routes.js | Middleware: requireAdminAuth + attachAdminLocals'),

  // ── 4.1 ──────────────────────────────────────────────────────
  h2('4.1 Đăng nhập Admin'),
  sectionMoTa(
    'MÔ TẢ: Cổng đăng nhập riêng biệt, chỉ dành cho Admin. Không dùng chung với form đăng nhập của giáo viên/học sinh.\n' +
    'Ý NGHĨA: Tách biệt hoàn toàn để tăng bảo mật. Admin chỉ dùng session thuần (không cấp JWT) — thời gian session được giới hạn bởi sessionTimeout trong SystemSettings. Kiểm tra kép: phải có role="admin" VÀ status="active" mới được vào.'
  ),
  h3('URL: GET /admin/login | POST /admin/login'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Kiểm tra đã đăng nhập — Nếu req.user đã là admin → redirect /admin ngay.'),
  buocLabel('2', 'Passport authenticate — passport.authenticate("local"): tìm user theo email, so khớp password.'),
  buocLabel('3', 'Kiểm tra role — role !== "admin" → lỗi 403 "This login is for administrators only".'),
  buocLabel('4', 'Kiểm tra status — status !== "active" → lỗi 403 "Your account is not active".'),
  buocLabel('5', 'Tạo session — req.session.regenerate() → req.logIn(user) → lưu session.role = "admin" → redirect /admin.'),
  divider(),
  codeTieuDe('admin.routes.js — POST /admin/login [Bước 2 → 5]'),
  ...code(
    'router.post("/admin/login", (req, res, next) => {\n' +
    '  // [Bước 2] Passport xác thực local strategy\n' +
    '  passport.authenticate("local", (err, user, info) => {\n' +
    '    if (err) return next(err);\n' +
    '    if (!user) {\n' +
    '      return res.status(422).render("admin/auth/login", {\n' +
    '        errorMessage: info ? info.message : "Invalid credentials.",\n' +
    '      });\n' +
    '    }\n' +
    '\n' +
    '    // [Bước 3] Kiểm tra role\n' +
    '    if (user.role !== "admin") {\n' +
    '      return res.status(403).render("admin/auth/login", {\n' +
    '        errorMessage: "This login is for administrators only.",\n' +
    '      });\n' +
    '    }\n' +
    '\n' +
    '    // [Bước 4] Kiểm tra status\n' +
    '    if (user.status !== "active") {\n' +
    '      return res.status(403).render("admin/auth/login", {\n' +
    '        errorMessage: "Your account is not active.",\n' +
    '      });\n' +
    '    }\n' +
    '\n' +
    '    // [Bước 5] Tạo session và redirect\n' +
    '    req.session.regenerate(() => {\n' +
    '      req.logIn(user, () => {\n' +
    '        req.session.role = user.role;\n' +
    '        req.session.save(() => res.redirect("/admin"));\n' +
    '      });\n' +
    '    });\n' +
    '  })(req, res, next);\n' +
    '});'
  ),

  // ── 4.2 ──────────────────────────────────────────────────────
  h2('4.2 Dashboard Admin'),
  sectionMoTa(
    'MÔ TẢ: Trang tổng quan thời gian thực của toàn bộ nền tảng, gồm số liệu người dùng, nội dung, hoạt động, sức khỏe hệ thống.\n' +
    'Ý NGHĨA: Giúp Admin nhìn toàn cảnh hệ thống trong một màn hình. Tất cả metrics được truy vấn song song (Promise.all) để giảm thời gian tải. Các biểu đồ giúp phát hiện xu hướng (tăng trưởng user, enrollment) và rủi ro (completion thấp, DB lỗi).'
  ),
  h3('URL: GET /admin/dashboard'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Thu thập metrics song song — Promise.all() với 25 queries: tổng user/teacher/student, classrooms, exams, assignments, submissions, discussions, enrollments, chat messages, question bank...'),
  buocLabel('2', 'Tính toán KPI — averageSubmissionScore, averageExamScore, completionRate = (graded/total)*100.'),
  buocLabel('3', 'Xây dựng dữ liệu biểu đồ — User growth (30 ngày), weekly registrations (12 tuần), enrollment trend (6 tháng), role distribution, content distribution.'),
  buocLabel('4', 'Xây dựng module nâng cao — buildPlatformModules(): heatmap 120 ngày, radar 6 chiều, calendar events, attendance rate, upcoming deadlines, recommendations, notifications.'),
  buocLabel('5', 'Kiểm tra DB status — mongooseDbStatus(): lấy version, dataSize, collections, objects count.'),
  buocLabel('6', 'Render dashboard — Truyền toàn bộ dữ liệu vào view admin/dashboard.pug.'),
  divider(),
  codeTieuDe('dashboard.controller.js — Bước 1: thu thập 25 metrics song song'),
  ...code(
    'const [\n' +
    '  totalUsers, totalTeachers, totalStudents, totalAdmins,\n' +
    '  pendingTeachers, activeUsers, totalClassrooms, activeClassrooms,\n' +
    '  totalExams, totalAssignments, totalLectures,\n' +
    '  totalSubmissions, gradedSubmissions, avgScore,\n' +
    '  totalTopics, totalReplies, totalNotifications,\n' +
    '  totalEnrollments, pendingEnrollments, totalChatMessages,\n' +
    '  totalQBEntries, totalExamSubmissions, avgExamScore,\n' +
    '  newUsersToday, newUsersWeek\n' +
    '] = await Promise.all([\n' +
    '  // [Bước 1] Tất cả queries chạy song song — không tuần tự\n' +
    '  User.countDocuments(),\n' +
    '  User.countDocuments({ role: "teacher" }),\n' +
    '  User.countDocuments({ role: "student" }),\n' +
    '  User.countDocuments({ role: "admin" }),\n' +
    '  User.countDocuments({ role: "teacher", status: "pending" }),\n' +
    '  User.countDocuments({ status: "active" }),\n' +
    '  Classroom.countDocuments(),\n' +
    '  Classroom.countDocuments({ isArchived: false }),\n' +
    '  // ... 17 queries còn lại\n' +
    ']);'
  ),
  codeTieuDe('dashboard.controller.js — Bước 4: hàm buildPlatformModules()'),
  ...code(
    'async function buildPlatformModules(ctx) {\n' +
    '  // [Bước 4] Lấy dữ liệu cho heatmap, weekly, monthly, radar...\n' +
    '  const [heatSubs, heatExamSubs, weekSubs, weekExamSubs,\n' +
    '         sessionsHeld, presentCount, monthExams, monthAssign,\n' +
    '         dueExams, dueAssignments, notifications] = await Promise.all([\n' +
    '    Submission.find({ submittedAt: { $gte: heatmapStart } }).select("submittedAt createdAt").lean(),\n' +
    '    ExamSubmission.find({ createdAt: { $gte: heatmapStart } }).select("createdAt").lean(),\n' +
    '    // ... thêm 9 queries\n' +
    '  ]);\n' +
    '\n' +
    '  // [Bước 4] Tính heatmap: 120 ô, mỗi ô là 1 ngày\n' +
    '  const heatMap = {};\n' +
    '  [...heatSubs, ...heatExamSubs].forEach(s => {\n' +
    '    const key = startOfDay(s.submittedAt || s.createdAt).getTime();\n' +
    '    heatMap[key] = (heatMap[key] || 0) + 1;\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 4] Tính radar: 6 chiều sức khỏe nền tảng\n' +
    '  const radar = {\n' +
    '    labels: ["Active Users", "Completion", "Avg Score", "Growth", "Engagement", "System Health"],\n' +
    '    data: [\n' +
    '      Math.min(100, activeUsersRate), // % users active\n' +
    '      Math.min(100, completionRate),  // % submissions graded\n' +
    '      avgScore ? Math.min(100, Math.round(avgScore)) : 0,\n' +
    '      Math.min(100, engagementScore),\n' +
    '      Math.min(100, engagement),\n' +
    '      dbStatus?.status === "connected" ? 100 : 35, // DB health\n' +
    '    ],\n' +
    '  };\n' +
    '  return { heatmap, radar, weekly, monthly, ... };\n' +
    '}'
  ),

  // ── 4.3 ──────────────────────────────────────────────────────
  h2('4.3 Quản lý Người dùng (User Management)'),
  sectionMoTa(
    'MÔ TẢ: Giao diện CRUD đầy đủ để Admin quản lý tất cả tài khoản trên hệ thống.\n' +
    'Ý NGHĨA: Admin có thể tìm kiếm, lọc, tạo mới, chỉnh sửa (đổi role, status, thông tin) và xóa tài khoản bất kỳ. Tính năng lọc + phân trang giúp xử lý số lượng user lớn hiệu quả.'
  ),
  h3('URL: GET /admin/users | GET /admin/users/new | POST /admin/users | GET+POST /admin/users/:userId'),
  h3('Luồng nghiệp vụ — Danh sách users (GET /admin/users):'),
  buocLabel('1', 'Xây dựng query filter — Từ req.query: q (tìm theo name/email bằng $regex case-insensitive), role, status.'),
  buocLabel('2', 'Đếm tổng bản ghi — countDocuments(query) để tính số trang.'),
  buocLabel('3', 'Phân trang và lấy dữ liệu — skip((page-1)*20).limit(20).sort({createdAt: -1}).'),
  buocLabel('4', 'Render danh sách — Truyền users, currentPage, totalPages vào view.'),
  h3('Luồng nghiệp vụ — Tạo user mới (POST /admin/users):'),
  buocLabel('1', 'Validate form — express-validator kiểm tra tất cả fields.'),
  buocLabel('2', 'Kiểm tra email trùng — findOne({ email }).'),
  buocLabel('3', 'Tạo user — new User({...}), gán role và status tùy ý (Admin có đặc quyền).'),
  buocLabel('4', 'Hash password — user.setPassword(password) → bcrypt.'),
  buocLabel('5', 'Lưu và redirect — user.save() → redirect /admin/users.'),
  divider(),
  codeTieuDe('user.controller.js — hàm listUsers() [Bước 1 → 4]'),
  ...code(
    'async function listUsers(req, res, next) {\n' +
    '  const page = Math.max(1, parseInt(req.query.page) || 1);\n' +
    '\n' +
    '  // [Bước 1] Xây dựng query filter từ URL params\n' +
    '  const query = {};\n' +
    '  if (req.query.q) {\n' +
    '    const search = req.query.q.trim();\n' +
    '    // Tìm kiếm theo name hoặc email (không phân biệt hoa thường)\n' +
    '    query.$or = [\n' +
    '      { name: { $regex: search, $options: "i" } },\n' +
    '      { email: { $regex: search, $options: "i" } },\n' +
    '    ];\n' +
    '  }\n' +
    '  if (req.query.role) query.role = req.query.role;\n' +
    '  if (req.query.status) query.status = req.query.status;\n' +
    '\n' +
    '  // [Bước 2] Đếm tổng để tính phân trang\n' +
    '  const total = await User.countDocuments(query);\n' +
    '  const totalPages = Math.ceil(total / 20);\n' +
    '\n' +
    '  // [Bước 3] Lấy trang hiện tại\n' +
    '  const users = await User.find(query)\n' +
    '    .sort({ createdAt: -1 })\n' +
    '    .skip((page - 1) * 20)\n' +
    '    .limit(20);\n' +
    '\n' +
    '  // [Bước 4] Render view\n' +
    '  return res.render("admin/users/index", {\n' +
    '    title: "Users", users, currentPage: page, totalPages,\n' +
    '    query: req.query.q || "",\n' +
    '  });\n' +
    '}'
  ),

  // ── 4.4 ──────────────────────────────────────────────────────
  h2('4.4 Phê duyệt Giáo viên (Teacher Approval)'),
  sectionMoTa(
    'MÔ TẢ: Quy trình xét duyệt tài khoản giáo viên — Admin xem danh sách giáo viên đang chờ, và ra quyết định Approve (chấp thuận) hoặc Reject (từ chối).\n' +
    'Ý NGHĨA: Cơ chế kiểm soát chất lượng giáo viên trước khi họ được phép tạo lớp học và giảng dạy. Sau khi approve → teacher có thể login và sử dụng hệ thống ngay. Sau khi reject → tài khoản bị khóa, không thể đăng nhập.'
  ),
  h3('URL: GET /admin/teachers/pending | POST /admin/teachers/:teacherId/approve | /reject'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Lấy danh sách giáo viên pending — User.find({ role: "teacher", status: "pending" }) → render danh sách.'),
  buocLabel('2a', '[Approve] Tìm teacher theo ID, kiểm tra role="teacher" + status="pending".'),
  buocLabel('2b', '[Approve] Cập nhật teacher.status = "active" → save → redirect với feedback.'),
  buocLabel('3a', '[Reject] Tìm teacher tương tự.'),
  buocLabel('3b', '[Reject] Cập nhật teacher.status = "rejected" → save → redirect với feedback.'),
  divider(),
  codeTieuDe('teacherApproval.service.js — approveTeacher() và rejectTeacher() [Bước 2 + 3]'),
  ...code(
    'async function approveTeacher(teacherId) {\n' +
    '  // [Bước 2a] Tìm giáo viên đang pending, kiểm tra tính hợp lệ\n' +
    '  const teacher = await User.findOne({\n' +
    '    _id: teacherId,\n' +
    '    role: "teacher",\n' +
    '    status: "pending",\n' +
    '  });\n' +
    '  if (!teacher)\n' +
    '    throw new AppError("Teacher not found or already processed.", 404);\n' +
    '\n' +
    '  // [Bước 2b] Kích hoạt tài khoản giáo viên\n' +
    '  teacher.status = "active";\n' +
    '  await teacher.save();\n' +
    '  return teacher;\n' +
    '}\n' +
    '\n' +
    'async function rejectTeacher(teacherId) {\n' +
    '  // [Bước 3a] Tìm giáo viên đang pending\n' +
    '  const teacher = await User.findOne({\n' +
    '    _id: teacherId,\n' +
    '    role: "teacher",\n' +
    '    status: "pending",\n' +
    '  });\n' +
    '  if (!teacher)\n' +
    '    throw new AppError("Teacher not found or already processed.", 404);\n' +
    '\n' +
    '  // [Bước 3b] Từ chối tài khoản — không thể đăng nhập nữa\n' +
    '  teacher.status = "rejected";\n' +
    '  await teacher.save();\n' +
    '  return teacher;\n' +
    '}'
  ),

  // ── 4.5 ──────────────────────────────────────────────────────
  h2('4.5 Quản lý Danh mục (Category CRUD)'),
  sectionMoTa(
    'MÔ TẢ: Admin tạo và quản lý các danh mục phân loại lớp học (ví dụ: Toán, Văn, Lập trình...).\n' +
    'Ý NGHĨA: Danh mục giúp tổ chức lớp học theo chủ đề, hỗ trợ lọc và tìm kiếm. Slug phải duy nhất và được MongoDB index để tra cứu nhanh.'
  ),
  h3('URL: /admin/categories | /new | /:id/edit | /:id/delete'),
  h3('Luồng nghiệp vụ — Tạo danh mục (POST /admin/categories):'),
  buocLabel('1', 'Đọc form — name, slug, description, icon (phosphor icon class).'),
  buocLabel('2', 'Kiểm tra slug trùng — Category.findOne({ slug }). Trùng → lỗi 422 với thông báo.'),
  buocLabel('3', 'Tạo và lưu — Category.create({ name, slug, description, icon }). Bắt lỗi code=11000 (MongoDB duplicate key).'),
  buocLabel('4', 'Redirect với feedback — /admin/categories?feedback=Category+created+successfully.'),
  divider(),
  codeTieuDe('category.controller.js — hàm createCategory() [Bước 1 → 4]'),
  ...code(
    'async function createCategory(req, res, next) {\n' +
    '  // [Bước 1] Đọc dữ liệu từ form\n' +
    '  const { name, slug, description, icon } = req.body;\n' +
    '\n' +
    '  // [Bước 2] Kiểm tra slug không trùng\n' +
    '  const existing = await Category.findOne({ slug });\n' +
    '  if (existing) {\n' +
    '    return res.status(422).render("admin/categories/form", {\n' +
    '      title: "New Category",\n' +
    '      category: req.body,\n' +
    '      errorMessage: "Slug already exists. Please choose another one.",\n' +
    '    });\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 3] Tạo và lưu danh mục\n' +
    '  try {\n' +
    '    await Category.create({ name, slug, description, icon: icon || "ph-folder" });\n' +
    '  } catch (error) {\n' +
    '    if (error.code === 11000) {\n' +
    '      // [Bước 3] MongoDB duplicate key — bắt thêm lần 2 để chắc chắn\n' +
    '      return res.status(422).render("admin/categories/form", {\n' +
    '        errorMessage: "A category with this name or slug already exists.",\n' +
    '      });\n' +
    '    }\n' +
    '    return next(error);\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 4] Redirect với thông báo thành công\n' +
    '  res.redirect("/admin/categories?feedback=Category+created+successfully.");\n' +
    '}'
  ),

  // ── 4.6 ──────────────────────────────────────────────────────
  h2('4.6 Cài đặt Hệ thống (System Settings)'),
  sectionMoTa(
    'MÔ TẢ: Trang cấu hình toàn hệ thống — Admin điều chỉnh hơn 40 tham số ảnh hưởng đến mọi người dùng.\n' +
    'Ý NGHĨA: Cho phép vận hành nền tảng linh hoạt mà không cần sửa code: bật/tắt đăng ký, điều chỉnh giới hạn bảo mật, cấu hình SMTP email, upload logo/favicon, bật/tắt các tính năng (exam proctoring, certificate, discussions). Mỗi setting là 1 document trong collection SystemSetting (key-value pattern).'
  ),
  h3('URL: GET /admin/settings | POST /admin/settings'),
  h3('Luồng nghiệp vụ — Cập nhật settings (POST):'),
  buocLabel('1', 'Đọc form — req.body chứa toàn bộ setting dưới dạng flat key-value.'),
  buocLabel('2', 'Xử lý ảnh — Logo và Favicon: nếu có file upload mới → uploadImageBuffer() lên Cloudinary; không có → giữ URL hiện tại (từ hidden field).'),
  buocLabel('3', 'Xây dựng settingsMap — Map toàn bộ 40+ key với: ép kiểu (bool/number/string), gán giá trị mặc định nếu thiếu.'),
  buocLabel('4', 'Upsert từng setting — Dùng findOneAndUpdate + upsert:true để update hoặc create.'),
  buocLabel('5', 'Redirect với feedback — /admin/settings?feedback=Settings+updated+successfully.'),
  divider(),
  codeTieuDe('setting.controller.js — updateSettingsHandler() [Bước 2 → 4]'),
  ...code(
    'async function updateSettingsHandler(req, res, next) {\n' +
    '  const payload = req.body;\n' +
    '  const bool = (v) => v === "true";\n' +
    '  const num = (v, d) => Number(v) || d;\n' +
    '\n' +
    '  // [Bước 2] Xử lý logo và favicon — upload lên Cloudinary nếu có file mới\n' +
    '  const logoUrlValue = await resolveSettingImage(\n' +
    '    req, "logo", "branding/logo", payload.logoUrl\n' +
    '  );\n' +
    '  const faviconUrlValue = await resolveSettingImage(\n' +
    '    req, "favicon", "branding/favicon", payload.faviconUrl\n' +
    '  );\n' +
    '\n' +
    '  // [Bước 3] Map 40+ settings với ép kiểu và default\n' +
    '  const settingsMap = {\n' +
    '    siteName:           { value: payload.siteName || "E-Learning LMS" },\n' +
    '    allowRegistration:  { value: bool(payload.allowRegistration) },\n' +
    '    maxLoginAttempts:   { value: num(payload.maxLoginAttempts, 5) },\n' +
    '    sessionTimeout:     { value: num(payload.sessionTimeout, 480) },\n' +
    '    enableExamProctoring: { value: bool(payload.enableExamProctoring) },\n' +
    '    logoUrl:            { value: logoUrlValue },\n' +
    '    // ... 35+ settings khác\n' +
    '  };\n' +
    '\n' +
    '  // [Bước 4] Upsert từng setting vào DB\n' +
    '  for (const [key, { value, description }] of Object.entries(settingsMap)) {\n' +
    '    await SystemSetting.findOneAndUpdate(\n' +
    '      { key },\n' +
    '      { value, description },\n' +
    '      { upsert: true } // Tạo mới nếu chưa có\n' +
    '    );\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 5] Redirect với feedback\n' +
    '  return res.redirect("/admin/settings?feedback=Settings+updated+successfully");\n' +
    '}'
  ),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 5: TEACHER
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('5. LUỒNG NGHIỆP VỤ — GIÁO VIÊN (TEACHER)'),
  note('controller/teacher/ | routes/teacher.*.routes.js | Middleware: isAuthenticated + requireRole("teacher") + requireActive'),

  // ── 5.1 ──────────────────────────────────────────────────────
  h2('5.1 Dashboard Giáo viên'),
  sectionMoTa(
    'MÔ TẢ: Trang tổng quan cá nhân của giáo viên — hiển thị các chỉ số về lớp học, tiến độ chấm bài, hành vi học sinh và các deadline sắp tới.\n' +
    'Ý NGHĨA: Giúp giáo viên nắm nhanh toàn bộ tình trạng lớp học trong một màn hình: bao nhiêu bài chưa chấm, ai đang nguy cơ, deadline nào sắp đến. Radar 6 chiều và recommendations hỗ trợ quyết định ưu tiên công việc.'
  ),
  h3('URL: GET /teacher/dashboard'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Lấy danh sách lớp học — Classroom.find({ teacher: req.user.id, isArchived: false }) → lấy classroomIds.'),
  buocLabel('2', 'Thu thập metrics song song — submissionCount cần chấm, totalStudents enrolled, pending submissions (6 gần nhất), graded submissions, attendance sessions.'),
  buocLabel('3', 'Tính analytics — avgScore (aggregate), attendanceRate (present/total*100), submissionRate.'),
  buocLabel('4', 'Tính deadlines — assignments và exams sắp đến trong 7 ngày, đánh dấu "urgent" nếu ≤ 2 ngày.'),
  buocLabel('5', 'Xây dựng báo cáo — weekly (7 ngày), monthly (6 tháng), heatmap (120 ngày), radar (6 chiều).'),
  buocLabel('6', 'Tạo recommendations — quy tắc dựa trên signal: backlog > 5, pending students > 0, avg < 60%, attendance < 75%...'),
  buocLabel('7', 'Render dashboard — truyền toàn bộ dữ liệu vào view.'),
  divider(),
  codeTieuDe('dashboard.controller.js — Bước 2+3: thu thập song song + tính toán'),
  ...code(
    'const classrooms = await Classroom.find({ teacher: teacherId, isArchived: false }).lean();\n' +
    'const classroomIds = classrooms.map(c => c._id);\n' +
    '\n' +
    '// [Bước 2] Truy vấn song song — tránh waterfall\n' +
    'const [submissionCount, totalStudents, pendingSubmissions,\n' +
    '       allClassSubs, allExamSubs, pendingStudents] = await Promise.all([\n' +
    '  Submission.countDocuments({ teacher: teacherId, status: { $ne: "graded" } }),\n' +
    '  ClassroomMember.countDocuments({\n' +
    '    classroom: { $in: classroomIds }, status: "approved"\n' +
    '  }),\n' +
    '  Submission.find({ teacher: teacherId, status: { $ne: "graded" } })\n' +
    '    .populate("student", "name avatarUrl")\n' +
    '    .populate("assignment", "title")\n' +
    '    .sort({ submittedAt: -1 }).limit(6).lean(),\n' +
    '  // ... thêm 3 queries\n' +
    ']);\n' +
    '\n' +
    '// [Bước 3] Tính avgScore bằng aggregate\n' +
    'const avgResult = await Submission.aggregate([\n' +
    '  { $match: { teacher: teacherId, score: { $ne: null } } },\n' +
    '  { $group: { _id: null, avg: { $avg: "$score" }, count: { $sum: 1 } } }\n' +
    ']);\n' +
    'const avgScore = avgResult[0]?.avg || 0;'
  ),

  // ── 5.2 ──────────────────────────────────────────────────────
  h2('5.2 Quản lý Lớp học (Classroom Management)'),
  sectionMoTa(
    'MÔ TẢ: Giáo viên tạo và quản lý lớp học của mình — từ việc tạo lớp, quản lý học sinh xin vào, đến theo dõi tiến trình và xuất bảng điểm.\n' +
    'Ý NGHĨA: Lớp học là đơn vị tổ chức trung tâm của hệ thống — mọi nội dung (bài giảng, bài tập, bài thi) đều gắn với một lớp cụ thể. Cơ chế approvalRequired cho phép lớp mở hoặc lớp có kiểm duyệt thành viên.'
  ),
  h3('URL: GET /teacher/classrooms | POST /teacher/classrooms | /teacher/classrooms/:id/...'),
  h3('Luồng nghiệp vụ — Tạo lớp học:'),
  buocLabel('1', 'Validate form — tên lớp (bắt buộc), mô tả, approvalRequired, category, level.'),
  buocLabel('2', 'Tạo Classroom document — gán teacher = req.user.id. Pre-save hook tự động sinh mã code 6 ký tự unique.'),
  buocLabel('3', 'Lưu vào DB — classroom.save() → redirect đến trang chi tiết lớp.'),
  h3('Luồng nghiệp vụ — Quản lý thành viên:'),
  buocLabel('1', 'Xem danh sách — ClassroomMember.find({ classroom: id }) populate student → phân nhóm pending/approved/rejected.'),
  buocLabel('2', '[Duyệt] POST .../members/:memberId/approve → member.status = "approved", approvedAt = now.'),
  buocLabel('3', '[Từ chối] POST .../members/:memberId/reject → member.status = "rejected".'),
  buocLabel('4', '[Xóa] POST .../members/:memberId/remove → ClassroomMember.findOneAndDelete().'),
  h3('Luồng nghiệp vụ — Gradebook:'),
  buocLabel('1', 'Lấy danh sách members approved.'),
  buocLabel('2', 'computeGradebook(classroom, studentId) cho từng student — tính điểm theo loại (ASSIGNMENT, EXAM), weighted average, letter grade.'),
  buocLabel('3', 'Export CSV — json2csv() → headers Content-Disposition → download file.'),
  divider(),
  codeTieuDe('classroom.controller.js — createClassroomHandler() [Bước 1 → 3]'),
  ...code(
    'async function createClassroomHandler(req, res, next) {\n' +
    '  // [Bước 1] Validate form đầu vào\n' +
    '  const validationMessage = formatValidationErrors(req);\n' +
    '  if (validationMessage) {\n' +
    '    const categories = await Category.find().sort({ name: 1 });\n' +
    '    return res.status(422).render("teacher/classrooms/new", {\n' +
    '      errorMessage: validationMessage,\n' +
    '      formData: req.body,\n' +
    '      categories,\n' +
    '    });\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 2] Tạo Classroom, code được tự sinh bởi pre-save hook\n' +
    '  const classroom = new Classroom({\n' +
    '    name: req.body.name,\n' +
    '    description: req.body.description || "",\n' +
    '    teacher: req.user.id,\n' +
    '    approvalRequired: req.body.approvalRequired !== "false",\n' +
    '    category: req.body.category || null,\n' +
    '    level: req.body.level || "Beginner",\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 3] Lưu vào DB và redirect\n' +
    '  await classroom.save();\n' +
    '  return res.redirect(\n' +
    '    "/teacher/classrooms/" + classroom.id + "?feedback=Classroom+created."\n' +
    '  );\n' +
    '}'
  ),

  // ── 5.3 ──────────────────────────────────────────────────────
  h2('5.3 Quản lý Bài giảng (Lecture Management)'),
  sectionMoTa(
    'MÔ TẢ: Giáo viên tạo và quản lý bài giảng trong từng lớp học — có thể là văn bản (HTML phong phú), video, PDF, tài liệu hoặc link ngoài.\n' +
    'Ý NGHĨA: Bài giảng là đơn vị nội dung học tập cơ bản. Hệ thống hỗ trợ nhiều định dạng để giáo viên linh hoạt trong việc trình bày. Việc đánh orderIndex cho phép giáo viên sắp xếp thứ tự học tập. Khi học sinh xem xong, hệ thống tự động ghi vào StudentProgress ledger.'
  ),
  h3('URL: GET/POST /teacher/classrooms/:id/lectures | .../lectures/:lectureId/show|edit|preview'),
  h3('Luồng nghiệp vụ — Tạo bài giảng (POST):'),
  buocLabel('1', 'Xác minh quyền — Classroom.findOne({ _id: id, teacher: req.user.id }) — không tìm thấy → 404.'),
  buocLabel('2', 'Xác định resource — Nếu có req.file (upload file) → lưu local + xác định resourceType từ mimetype. Nếu không → dùng req.body.resourceUrl và resourceType.'),
  buocLabel('3', 'Tạo Lecture document — new Lecture({...}) với đầy đủ thông tin.'),
  buocLabel('4', 'Lưu và redirect — lecture.save() → redirect danh sách lectures.'),
  h3('Luồng nghiệp vụ — Xem chi tiết (Teacher):'),
  buocLabel('1', 'Load bài giảng và 50 tin nhắn chat gần nhất của phòng học.'),
  buocLabel('2', 'buildPreviewModel() — xây dựng model xem trước (cho split-pane view).'),
  buocLabel('3', 'Render split-pane hub — sidebar chat + nội dung bài giảng.'),
  divider(),
  codeTieuDe('lecture.controller.js — createLectureHandler() [Bước 1 → 4]'),
  ...code(
    'async function createLectureHandler(req, res, next) {\n' +
    '  // [Bước 1] Xác minh lớp học thuộc giáo viên này\n' +
    '  const classroom = await Classroom.findOne({\n' +
    '    _id: req.params.classroomId,\n' +
    '    teacher: req.user.id,\n' +
    '  });\n' +
    '  if (!classroom) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 2] Xác định loại tài nguyên từ file upload hoặc URL\n' +
    '  const resourceUrl = req.file\n' +
    '    ? "/uploads/lectures/" + req.file.filename\n' +
    '    : (req.body.resourceUrl || "");\n' +
    '  const resourceType = req.file\n' +
    '    ? (req.file.mimetype.startsWith("video") ? "video"\n' +
    '       : req.file.mimetype === "application/pdf" ? "pdf" : "document")\n' +
    '    : (req.body.resourceType || "text");\n' +
    '\n' +
    '  // [Bước 3] Tạo Lecture document\n' +
    '  const lecture = new Lecture({\n' +
    '    classroom: classroom.id,\n' +
    '    teacher: req.user.id,\n' +
    '    chapterTitle: req.body.chapterTitle,\n' +
    '    title: req.body.title,\n' +
    '    summary: req.body.summary || "",\n' +
    '    content: req.body.content || "",\n' +
    '    resourceUrl,\n' +
    '    resourceType,\n' +
    '    orderIndex: Number(req.body.orderIndex || 0),\n' +
    '    isPublished: req.body.isPublished !== "false",\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 4] Lưu và redirect\n' +
    '  await lecture.save();\n' +
    '  return res.redirect(\n' +
    '    "/teacher/classrooms/" + classroom.id + "/lectures?feedback=Lecture+created."\n' +
    '  );\n' +
    '}'
  ),

  // ── 5.4 ──────────────────────────────────────────────────────
  h2('5.4 Quản lý Bài tập (Assignment Management)'),
  sectionMoTa(
    'MÔ TẢ: Giáo viên tạo bài tập có deadline và hướng dẫn chi tiết, học sinh nộp bài qua text hoặc file đính kèm.\n' +
    'Ý NGHĨA: Bài tập là cơ chế đánh giá thường xuyên. Khi tạo bài tập, hệ thống tự động gửi notification đến tất cả học sinh enrolled — đảm bảo không ai bỏ lỡ. Deadline enforcement giúp giáo viên quản lý tiến độ.'
  ),
  h3('URL: GET/POST /teacher/classrooms/:id/assignments | .../assignments/:assignmentId'),
  h3('Luồng nghiệp vụ — Tạo bài tập (POST):'),
  buocLabel('1', 'Xác minh quyền — Classroom.findOne({ _id: id, teacher: req.user.id }).'),
  buocLabel('2', 'Validate form — title (bắt buộc), totalPoints, dueDate, isPublished.'),
  buocLabel('3', 'Tạo Assignment document — new Assignment({...}).'),
  buocLabel('4', 'Lưu vào DB — assignment.save().'),
  buocLabel('5', 'Gửi notification — ClassroomMember.find({ classroom, status: "approved" }) → sendNotification() cho từng student. Dùng Promise.allSettled (không fail toàn bộ nếu 1 notification lỗi).'),
  buocLabel('6', 'Redirect — về danh sách assignments.'),
  divider(),
  codeTieuDe('assignment.controller.js — createAssignmentHandler() [Bước 1 → 6]'),
  ...code(
    'async function createAssignmentHandler(req, res, next) {\n' +
    '  // [Bước 1] Xác minh lớp học thuộc giáo viên\n' +
    '  const classroom = await Classroom.findOne({\n' +
    '    _id: req.params.classroomId, teacher: req.user.id\n' +
    '  });\n' +
    '  if (!classroom) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 2] Validate (express-validator đã chạy trong route middleware)\n' +
    '  const validationMessage = formatValidationErrors(req);\n' +
    '  if (validationMessage) { /* re-render form */ }\n' +
    '\n' +
    '  // [Bước 3] Tạo Assignment\n' +
    '  const assignment = new Assignment({\n' +
    '    classroom: classroom.id, teacher: req.user.id,\n' +
    '    title: req.body.title, description: req.body.description || "",\n' +
    '    instructions: req.body.instructions || "",\n' +
    '    totalPoints: Number(req.body.totalPoints || 10),\n' +
    '    dueDate: req.body.dueDate ? new Date(req.body.dueDate) : null,\n' +
    '    isPublished: req.body.isPublished === "true",\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 4] Lưu vào DB\n' +
    '  await assignment.save();\n' +
    '\n' +
    '  // [Bước 5] Gửi notification đến TẤT CẢ students enrolled\n' +
    '  const members = await ClassroomMember.find({\n' +
    '    classroom: classroom.id, status: "approved"\n' +
    '  });\n' +
    '  const notificationPromises = members.map(m =>\n' +
    '    sendNotification(\n' +
    '      m.student,\n' +
    '      "New Assignment",\n' +
    '      "Teacher posted: " + assignment.title,\n' +
    '      "/student/classrooms/" + m.id + "/assignments"\n' +
    '    )\n' +
    '  );\n' +
    '  // allSettled: 1 notification lỗi không làm fail toàn bộ\n' +
    '  await Promise.allSettled(notificationPromises);\n' +
    '\n' +
    '  // [Bước 6] Redirect với feedback\n' +
    '  return res.redirect("...?feedback=Assignment+created.");\n' +
    '}'
  ),

  // ── 5.5 ──────────────────────────────────────────────────────
  h2('5.5 Chấm điểm Bài nộp (Submission Grading)'),
  sectionMoTa(
    'MÔ TẢ: Giáo viên xem, nhận xét và chấm điểm các bài tập đã được học sinh nộp. Hỗ trợ hai chế độ: chấm điểm tự do (nhập số) hoặc chấm theo Rubric (tiêu chí).\n' +
    'Ý NGHĨA: Sau khi chấm, điểm được ghi vào StudentProgress ledger — đây là nguồn dữ liệu duy nhất để tính Gradebook và Course Completion. Đảm bảo nhất quán dữ liệu điểm số xuyên suốt hệ thống.'
  ),
  h3('URL: GET .../assignments/:assignId/submissions | .../submissions/:subId | POST .../submissions/:subId/grade'),
  h3('Luồng nghiệp vụ — Chấm điểm (POST .../grade):'),
  buocLabel('1', 'Xác minh quyền — Classroom.findOne({ teacher }) + Submission.findById với populate student, assignment.'),
  buocLabel('2', 'Cập nhật Submission — score = req.body.score, teacherComment, status = "graded", gradedAt = now.'),
  buocLabel('3', 'Lưu Submission — submission.save().'),
  buocLabel('4', 'Cập nhật Progress Ledger — markComplete({ student, classroom, itemType: ASSIGNMENT, itemId, evidence: { score, maxScore, submittedAt } }).'),
  buocLabel('5', 'Redirect — về danh sách submissions với feedback.'),
  h3('Chế độ Rubric (nếu assignment có rubric):'),
  buocLabel('1', 'Parse điểm từng tiêu chí — req.body["crit_<criterionId>"] cho mỗi criterion.'),
  buocLabel('2', 'gradeWithRubric() — tổng điểm từng criterion, lưu rubricGrades[], tính score tổng.'),
  buocLabel('3', 'markComplete() — giống chế độ thường.'),
  divider(),
  codeTieuDe('submission.controller.js — gradeSubmissionHandler() [Bước 1 → 5]'),
  ...code(
    'async function gradeSubmissionHandler(req, res, next) {\n' +
    '  // [Bước 1] Xác minh quyền và lấy dữ liệu\n' +
    '  const classroom = await Classroom.findOne({\n' +
    '    _id: req.params.classroomId, teacher: req.user.id\n' +
    '  });\n' +
    '  if (!classroom) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  const submission = await Submission.findById(req.params.submissionId)\n' +
    '    .populate("student", "name avatarUrl")\n' +
    '    .populate("assignment");\n' +
    '  if (!submission) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 2] Cập nhật thông tin chấm điểm\n' +
    '  submission.score = Number(req.body.score);\n' +
    '  submission.teacherComment = req.body.teacherComment || "";\n' +
    '  submission.status = "graded";\n' +
    '  submission.gradedAt = new Date();\n' +
    '\n' +
    '  // [Bước 3] Lưu submission vào DB\n' +
    '  await submission.save();\n' +
    '\n' +
    '  // [Bước 4] Cập nhật StudentProgress ledger với điểm thực tế\n' +
    '  // Đây là nguồn sự thật duy nhất — gradebook đọc từ đây\n' +
    '  await markComplete({\n' +
    '    student: String(submission.student._id),\n' +
    '    classroom: String(classroom.id),\n' +
    '    itemType: CONTENT_TYPES.ASSIGNMENT,\n' +
    '    itemId: assignment.id,\n' +
    '    evidence: {\n' +
    '      score: submission.score,\n' +
    '      maxScore: assignment.totalPoints,\n' +
    '      submittedAt: submission.submittedAt,\n' +
    '    },\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 5] Redirect với thông báo\n' +
    '  return res.redirect("...?feedback=Submission+graded.");\n' +
    '}'
  ),

  // ── 5.6 ──────────────────────────────────────────────────────
  h2('5.6 Quản lý Bài thi (Exam Management)'),
  sectionMoTa(
    'MÔ TẢ: Giáo viên tạo bài kiểm tra có thời gian giới hạn, cấu hình câu hỏi (tự nhập hoặc từ ngân hàng câu hỏi), và theo dõi kết quả thi của học sinh.\n' +
    'Ý NGHĨA: Hệ thống hỗ trợ đầy đủ các loại câu hỏi (trắc nghiệm 1 đáp án, nhiều đáp án, tự luận). Tính năng strictMode + Socket.IO cho phép giám sát chống gian lận real-time. Shuffle câu hỏi/đáp án giảm thiểu quay cóp.'
  ),
  h3('URL: /teacher/classrooms/:id/exams | .../exams/:examId/show|edit|questions|submissions|grade|export-csv'),
  h3('Luồng nghiệp vụ — Tạo bài thi (POST):'),
  buocLabel('1', 'Xác minh quyền — Classroom.findOne({ _id, teacher }).'),
  buocLabel('2', 'Tạo Exam document — với đầy đủ cấu hình: duration, maxAttempts, showResult, strictMode, maxViolations, shuffle, startTime, endTime.'),
  buocLabel('3', 'Lưu Exam — exam.save() → redirect trang quản lý câu hỏi.'),
  h3('Luồng nghiệp vụ — Thêm câu hỏi (POST .../questions):'),
  buocLabel('1', 'Parse form — type, content, points. Nếu MCQ/multi_answer: parse optionText[], optionCorrect[].'),
  buocLabel('2', 'Tạo Question document — new Question({ exam, type, content, options, points }).'),
  buocLabel('3', 'Cập nhật exam — exam.totalPoints += points, exam.questionCount++.'),
  buocLabel('4', 'Lưu cả hai — await Promise.all([question.save(), exam.save()]).'),
  h3('Luồng nghiệp vụ — Sinh câu hỏi từ Ma trận (Question Bank):'),
  buocLabel('1', 'POST .../generate-matrix → đọc: subject, chapter, num_nhan_biet, num_thong_hieu, num_van_dung.'),
  buocLabel('2', 'generateMatrixQuestions() — QuestionBank.aggregate: sample ngẫu nhiên đúng số lượng theo độ khó.'),
  buocLabel('3', 'Copy câu hỏi từ bank vào exam — tạo Question mới cho mỗi QBank item.'),
  buocLabel('4', 'Cập nhật exam.totalPoints và exam.questionCount.'),
  divider(),
  codeTieuDe('exam.controller.js — createExamHandler() [Bước 1 → 3]'),
  ...code(
    'async function createExamHandler(req, res, next) {\n' +
    '  // [Bước 1] Xác minh lớp học thuộc giáo viên\n' +
    '  const classroom = await Classroom.findOne({\n' +
    '    _id: req.params.classroomId, teacher: req.user.id\n' +
    '  });\n' +
    '  if (!classroom) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 2] Tạo Exam với đầy đủ cấu hình chống gian lận và thời gian\n' +
    '  const exam = new Exam({\n' +
    '    classroom: classroom.id, teacher: req.user.id,\n' +
    '    title: req.body.title,\n' +
    '    description: req.body.description || "",\n' +
    '    duration: Number(req.body.duration || 60), // phút\n' +
    '    password: req.body.password || "",  // mật khẩu vào phòng thi\n' +
    '    maxAttempts: Number(req.body.maxAttempts || 1),\n' +
    '    showResult: req.body.showResult || "after_submit",\n' +
    '    isPublished: req.body.isPublished === "true",\n' +
    '    strictMode: req.body.strictMode === "true", // bật giam sát\n' +
    '    maxViolations: Number(req.body.maxViolations || 0),\n' +
    '    shuffle: req.body.shuffle === "true",  // xáo trộn câu hỏi\n' +
    '  });\n' +
    '  if (req.body.startTime) exam.startTime = new Date(req.body.startTime);\n' +
    '  if (req.body.endTime)   exam.endTime   = new Date(req.body.endTime);\n' +
    '\n' +
    '  // [Bước 3] Lưu và redirect\n' +
    '  await exam.save();\n' +
    '  return res.redirect(".../" + exam.id + "/questions?feedback=Exam+created.");\n' +
    '}'
  ),
  codeTieuDe('exam.controller.js — addQuestionHandler() [Bước 1 → 4]'),
  ...code(
    'async function addQuestionHandler(req, res, next) {\n' +
    '  const { type, content, points } = req.body;\n' +
    '\n' +
    '  // [Bước 1] Parse options cho MCQ / multiple_answer\n' +
    '  let options = [];\n' +
    '  if (type === "multiple_choice" || type === "multiple_answer") {\n' +
    '    const optionTexts   = req.body["optionText[]"] || [];\n' +
    '    const optionCorrects = req.body["optionCorrect[]"] || [];\n' +
    '    const texts   = Array.isArray(optionTexts)   ? optionTexts   : [optionTexts];\n' +
    '    const corrects = Array.isArray(optionCorrects) ? optionCorrects : [optionCorrects];\n' +
    '    options = texts\n' +
    '      .map((text, idx) => ({\n' +
    '        text: text.trim(),\n' +
    '        isCorrect: corrects.includes(idx.toString()),\n' +
    '      }))\n' +
    '      .filter(opt => opt.text.length > 0);\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 2] Tạo Question document\n' +
    '  const question = new Question({\n' +
    '    exam: exam.id, type, content, options,\n' +
    '    points: Number(points || 1),\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 3+4] Cập nhật tổng điểm exam và lưu song song\n' +
    '  exam.totalPoints = (exam.totalPoints || 0) + Number(points || 1);\n' +
    '  exam.questionCount = (exam.questionCount || 0) + 1;\n' +
    '  await Promise.all([question.save(), exam.save()]);\n' +
    '}'
  ),

  // ── 5.7 ──────────────────────────────────────────────────────
  h2('5.7 Điểm danh (Attendance Management)'),
  sectionMoTa(
    'MÔ TẢ: Giáo viên tạo phiên điểm danh với mã ngắn hạn (60 giây), học sinh nhập mã hoặc quét QR để điểm danh. Giáo viên có thể chỉnh sửa thủ công và xuất báo cáo CSV.\n' +
    'Ý NGHĨA: Mã điểm danh tự hết hạn sau 60 giây và có thể làm mới — tránh học sinh chia sẻ mã cho người vắng mặt. Hệ thống tạo sẵn record "absent" cho tất cả học sinh, giáo viên chỉ cần xem ai đã check-in.'
  ),
  h3('URL: /teacher/classrooms/:id/attendance | .../attendance/:sessionId/live|records|export|close'),
  h3('Luồng nghiệp vụ — Tạo phiên điểm danh (POST):'),
  buocLabel('1', 'Xác minh quyền — Classroom.findOne({ teacher }).'),
  buocLabel('2', 'Tạo AttendanceSession — status = "open", teacher.'),
  buocLabel('3', 'Sinh mã — session.generateNewCode(): mã 6 ký tự random uppercase + expiresAt = now + 60s.'),
  buocLabel('4', 'Lưu session — session.save().'),
  buocLabel('5', 'Tạo records "absent" — lấy danh sách classroom.students → insertMany AttendanceRecord với status = "absent".'),
  buocLabel('6', 'Redirect đến live view — hiển thị mã + QR.'),
  h3('Luồng nghiệp vụ — Làm mới mã (GET API):'),
  buocLabel('1', 'GET /api/.../generate-code → apiGenerateCode(): session.generateNewCode() → session.save().'),
  buocLabel('2', 'Trả JSON { code, expiresAt } → client cập nhật màn hình real-time.'),
  h3('Luồng nghiệp vụ — Đóng phiên (POST):'),
  buocLabel('1', 'closeSession(): AttendanceSession.findOne({ _id, classroom }).'),
  buocLabel('2', 'session.status = "closed" → session.save() → redirect records.'),
  divider(),
  codeTieuDe('attendance.controller.js — createSession() [Bước 1 → 6]'),
  ...code(
    'async function createSession(req, res, next) {\n' +
    '  // [Bước 1] Xác minh quyền\n' +
    '  const classroom = await Classroom.findOne({\n' +
    '    _id: req.params.classroomId, teacher: req.user.id\n' +
    '  });\n' +
    '  if (!classroom) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 2] Tạo AttendanceSession\n' +
    '  const session = new AttendanceSession({\n' +
    '    classroom: classroom.id,\n' +
    '    teacher: req.user.id,\n' +
    '    status: "open",\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 3] Sinh mã 6 ký tự + hết hạn 60 giây\n' +
    '  session.generateNewCode();\n' +
    '\n' +
    '  // [Bước 4] Lưu session\n' +
    '  await session.save();\n' +
    '\n' +
    '  // [Bước 5] Tạo record "absent" cho tất cả students enrolled\n' +
    '  const users = await User.find({ _id: { $in: classroom.students } });\n' +
    '  const records = users.map(user => ({\n' +
    '    session: session.id,\n' +
    '    student: user._id,\n' +
    '    status: "absent",  // mặc định absent, sẽ đổi khi check-in\n' +
    '  }));\n' +
    '  if (records.length > 0) await AttendanceRecord.insertMany(records);\n' +
    '\n' +
    '  // [Bước 6] Redirect đến live view\n' +
    '  return res.redirect(\n' +
    '    "/teacher/classrooms/" + classroom.id + "/attendance/" + session.id + "/live"\n' +
    '  );\n' +
    '}'
  ),

  // ── 5.8 ──────────────────────────────────────────────────────
  h2('5.8 Diễn đàn Thảo luận (Discussion — Teacher)'),
  sectionMoTa(
    'MÔ TẢ: Giáo viên quản lý diễn đàn thảo luận trong lớp học — tạo chủ đề, trả lời, ghim bài và xóa nội dung không phù hợp.\n' +
    'Ý NGHĨA: Diễn đàn tạo không gian tương tác ngoài giờ học. Giáo viên có đặc quyền ghim (pin) chủ đề quan trọng lên đầu danh sách và xóa bất kỳ nội dung vi phạm nào trong lớp mình.'
  ),
  h3('URL: /teacher/classrooms/:id/discussions | .../discussions/:topicId'),
  h3('Chức năng của giáo viên:'),
  buocLabel('1', 'Xem danh sách — DiscussionTopic.find({ classroom }) sort: isPinned DESC, createdAt DESC.'),
  buocLabel('2', 'Tạo topic mới — title + content → DiscussionTopic.create().'),
  buocLabel('3', 'Xem chi tiết + replies — populate author.'),
  buocLabel('4', 'Tạo reply — DiscussionReply.create() → topic.replyCount++.'),
  buocLabel('5', 'Toggle Pin — topic.isPinned = !topic.isPinned → save(). Chỉ giáo viên được phép.'),
  buocLabel('6', 'Xóa topic — DiscussionTopic.findOneAndDelete() + DiscussionReply.deleteMany({ topic }).'),
  buocLabel('7', 'Xóa reply — DiscussionReply.findOneAndDelete() → topic.replyCount--.'),
  divider(),
  codeTieuDe('discussion.controller.js — togglePin() [Bước 5]'),
  ...code(
    'async function togglePin(req, res, next) {\n' +
    '  // [Bước 5] Kiểm tra giáo viên sở hữu lớp\n' +
    '  const classroom = await Classroom.findOne({\n' +
    '    _id: req.params.classroomId, teacher: req.user.id\n' +
    '  });\n' +
    '  if (!classroom) return res.status(404).send("Not found");\n' +
    '\n' +
    '  // [Bước 5] Tìm topic trong lớp\n' +
    '  const topic = await DiscussionTopic.findOne({\n' +
    '    _id: req.params.topicId, classroom: classroom.id\n' +
    '  });\n' +
    '  if (!topic) return res.status(404).send("Topic not found");\n' +
    '\n' +
    '  // [Bước 5] Đảo trạng thái ghim\n' +
    '  topic.isPinned = !topic.isPinned;\n' +
    '  await topic.save();\n' +
    '\n' +
    '  return res.redirect(\n' +
    '    "/teacher/classrooms/" + classroom.id + "/discussions/" + topic.id\n' +
    '  );\n' +
    '}'
  ),

  // ── 5.9 ──────────────────────────────────────────────────────
  h2('5.9 Ngân hàng Câu hỏi (Question Bank)'),
  sectionMoTa(
    'MÔ TẢ: Kho lưu trữ câu hỏi cá nhân của từng giáo viên, được phân loại theo môn học, chương và độ khó. Câu hỏi trong ngân hàng có thể được tái sử dụng để sinh đề thi tự động.\n' +
    'Ý NGHĨA: Thay vì nhập tay từng câu hỏi mỗi khi tạo đề, giáo viên xây dựng ngân hàng câu hỏi một lần và tái sử dụng nhiều lần. Tính năng "sinh đề theo ma trận" (Bloom\'s taxonomy — Nhận biết, Thông hiểu, Vận dụng) đảm bảo đề thi cân bằng độ khó.'
  ),
  h3('URL: GET/POST /teacher/question-banks | .../question-banks/:id/delete'),
  h3('Luồng nghiệp vụ — Thêm câu hỏi:'),
  buocLabel('1', 'Đọc form — subject, chapter, difficulty (nhan_biet/thong_hieu/van_dung), type, content, options, points.'),
  buocLabel('2', 'Parse options — tương tự addQuestionHandler.'),
  buocLabel('3', 'Tạo QuestionBank document — gắn teacher = req.user.id.'),
  buocLabel('4', 'Lưu → redirect với feedback.'),
  h3('Luồng nghiệp vụ — Sinh đề từ ma trận (trong exam management):'),
  buocLabel('1', 'POST .../exams/:examId/generate-matrix: đọc num_nhan_biet, num_thong_hieu, num_van_dung.'),
  buocLabel('2', 'QuestionBank.aggregate(): $sample ngẫu nhiên đúng số lượng theo difficulty.'),
  buocLabel('3', 'Tạo Question cho mỗi bank item, cập nhật exam.totalPoints.'),
  divider(),
  codeTieuDe('questionBank.controller.js — createQuestionHandler() [Bước 1 → 4]'),
  ...code(
    'async function createQuestionHandler(req, res, next) {\n' +
    '  // [Bước 1] Đọc thông tin câu hỏi từ form\n' +
    '  const { subject, chapter, difficulty, type, content, points } = req.body;\n' +
    '\n' +
    '  // [Bước 2] Parse options nếu là trắc nghiệm\n' +
    '  let options = [];\n' +
    '  if (type === "multiple_choice" || type === "multiple_answer") {\n' +
    '    const optionTexts   = req.body["optionText[]"] || [];\n' +
    '    const optionCorrects = req.body["optionCorrect[]"] || [];\n' +
    '    const texts   = Array.isArray(optionTexts)   ? optionTexts   : [optionTexts];\n' +
    '    const corrects = Array.isArray(optionCorrects) ? optionCorrects : [optionCorrects];\n' +
    '    options = texts.map((text, idx) => ({\n' +
    '      text,\n' +
    '      isCorrect: corrects.includes(idx.toString()) || corrects.includes(text),\n' +
    '    }));\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 3] Tạo và gắn vào giáo viên này\n' +
    '  const qb = new QuestionBank({\n' +
    '    teacher: req.user.id, subject, chapter, difficulty,\n' +
    '    type: type || "multiple_choice",\n' +
    '    content, options,\n' +
    '    points: Number(points || 1),\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 4] Lưu và redirect\n' +
    '  await qb.save();\n' +
    '  return res.redirect("/teacher/question-banks?feedback=Question+added+successfully");\n' +
    '}'
  ),

  // ── 5.10 ──────────────────────────────────────────────────────
  h2('5.10 Analytics Lớp học'),
  sectionMoTa(
    'MÔ TẢ: Trang thống kê chuyên sâu cho từng lớp học — số liệu về điểm trung bình, tỉ lệ điểm danh, tỉ lệ nộp bài, phân phối điểm, học sinh xuất sắc và học sinh nguy cơ.\n' +
    'Ý NGHĨA: Cung cấp dữ liệu để giáo viên phát hiện sớm học sinh cần hỗ trợ (atRisk < 50%) và học sinh xuất sắc. Cache 5 phút giảm tải DB cho các lớp đông học sinh.'
  ),
  h3('URL: GET /teacher/classrooms/:id/analytics'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Kiểm tra cache — node-cache TTL 5 phút. Nếu cache hit → render ngay, không truy vấn DB.'),
  buocLabel('2', 'Lấy studentCount — ClassroomMember.countDocuments({ status: "approved" }).'),
  buocLabel('3', 'Tính avgScore — aggregate trên Submission và ExamSubmission, kết hợp weighted average.'),
  buocLabel('4', 'Tính attendanceRate — (presentRecords / sessionsHeld * studentCount) * 100.'),
  buocLabel('5', 'Tính submissionRate — (actualSubmissions / (assignments * students)) * 100.'),
  buocLabel('6', 'Phân phối điểm — ExamSubmission của bài thi gần nhất, chia 5 nhóm (0-20%, 21-40%...).'),
  buocLabel('7', 'Top/AtRisk Students — aggregate ExamSubmission theo student, tính averagePercentage.'),
  buocLabel('8', 'Lưu cache và render — Lưu kết quả vào cache, render view.'),
  divider(),
  codeTieuDe('analytics.controller.js — renderClassroomAnalytics() [Bước 1, 7, 8]'),
  ...code(
    'async function renderClassroomAnalytics(req, res, next) {\n' +
    '  // [Bước 1] Kiểm tra cache trước (TTL 5 phút)\n' +
    '  const cacheKey = "classroom_analytics_" + req.params.classroomId;\n' +
    '  const cached = analyticsCache.get(cacheKey);\n' +
    '  if (cached) return res.render("teacher/analytics/index", cached);\n' +
    '\n' +
    '  // ... [Bước 2 → 6] Tính toán các metrics\n' +
    '\n' +
    '  // [Bước 7] Tính top/atRisk students bằng aggregate pipeline\n' +
    '  const studentStats = await ExamSubmission.aggregate([\n' +
    '    { $match: { exam: { $in: examIds }, gradingStatus: "fully_graded" } },\n' +
    '    { $lookup: { from: "exams", localField: "exam",\n' +
    '                 foreignField: "_id", as: "examData" } },\n' +
    '    { $unwind: "$examData" },\n' +
    '    { $group: {\n' +
    '        _id: "$student",\n' +
    '        totalScore:    { $sum: "$score" },\n' +
    '        totalMaxScore: { $sum: "$examData.totalPoints" },\n' +
    '        examsTaken:    { $sum: 1 },\n' +
    '    }},\n' +
    '    { $project: {\n' +
    '        averagePercentage: {\n' +
    '          $multiply: [{ $divide: ["$totalScore", "$totalMaxScore"] }, 100]\n' +
    '        },\n' +
    '        examsTaken: 1,\n' +
    '    }},\n' +
    '    { $sort: { averagePercentage: -1 } },\n' +
    '  ]);\n' +
    '\n' +
    '  const topStudents   = studentStats.slice(0, 5);\n' +
    '  const atRiskStudents = studentStats.filter(s => s.averagePercentage < 50).slice(0, 5);\n' +
    '\n' +
    '  // [Bước 8] Lưu vào cache và render\n' +
    '  analyticsCache.set(cacheKey, renderData);\n' +
    '  return res.render("teacher/analytics/index", renderData);\n' +
    '}'
  ),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 6: STUDENT
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('6. LUỒNG NGHIỆP VỤ — HỌC SINH (STUDENT)'),
  note('controller/student/ | routes/student.*.routes.js | Middleware: isAuthenticated + requireRole("student")'),

  // ── 6.1 ──────────────────────────────────────────────────────
  h2('6.1 Dashboard Học sinh'),
  sectionMoTa(
    'MÔ TẢ: Trang tổng quan cá nhân của học sinh — hiển thị tiến trình học tập, deadline sắp tới, thành tích và gợi ý cá nhân hóa.\n' +
    'Ý NGHĨA: Giúp học sinh nhìn toàn cảnh tình hình học tập: bao nhiêu lớp đã tham gia, tiến trình mỗi lớp, điểm trung bình, tỉ lệ điểm danh. Hệ thống gamification (XP, Level, Badge, Streak) tạo động lực học tập. Recommendations phát hiện rủi ro sớm (deadline sắp hết, điểm thấp, vắng nhiều).'
  ),
  h3('URL: GET /student/dashboard'),
  h3('Luồng nghiệp vụ:'),
  buocLabel('1', 'Lấy enrollments — ClassroomMember.find({ student, status: "approved" }) populate classroom.'),
  buocLabel('2', 'Thu thập metrics song song — submissionCount, examCount, gradedCount, avgScore.'),
  buocLabel('3', 'Tính tiến trình — StudentProgress ledger: so sánh items completed vs total (lectures + assignments) cho mỗi lớp.'),
  buocLabel('4', 'Tính deadlines — dueAssignments + dueExams >= now, sort, đánh dấu "urgent" nếu ≤ 2 ngày.'),
  buocLabel('5', 'Tính attendanceRate — presentRecords / total sessions.'),
  buocLabel('6', 'Xây dựng báo cáo — weekly (7 ngày), monthly (avg score 6 tháng), heatmap (120 ngày).'),
  buocLabel('7', 'Tính Radar — 6 chiều: Completion, Avg Score, Attendance, Exam Effort, Consistency, Engagement.'),
  buocLabel('8', 'Tính Gamification — XP = sub*50 + exam*75 + graded*25. Level = floor(XP/500)+1. Badges.'),
  buocLabel('9', 'Tạo Recommendations — rules-based: deadline pressure, raise average, improve attendance, join classroom...'),
  buocLabel('10', 'Render dashboard — truyền toàn bộ dữ liệu.'),
  divider(),
  codeTieuDe('dashboard.controller.js — Bước 3: tính tiến trình từ StudentProgress ledger'),
  ...code(
    '// [Bước 3] Lấy progress từ ledger\n' +
    'const progressRows = await StudentProgress.find({\n' +
    '  student: studentId,\n' +
    '  classroom: { $in: classroomIds },\n' +
    '}).lean();\n' +
    '\n' +
    '// Đếm số items đã hoàn thành theo lớp\n' +
    'const doneByClassroom = {};\n' +
    'progressRows.forEach(p => {\n' +
    '  if (p.status === "completed")\n' +
    '    doneByClassroom[p.classroom] = (doneByClassroom[p.classroom] || 0) + 1;\n' +
    '});\n' +
    '\n' +
    '// Đếm tổng lectures và assignments trong mỗi lớp\n' +
    'const [lectureCounts, assignmentCounts] = await Promise.all([\n' +
    '  Lecture.aggregate([\n' +
    '    { $match: { classroom: { $in: classroomIds }, isPublished: { $ne: false } } },\n' +
    '    { $group: { _id: "$classroom", count: { $sum: 1 } } },\n' +
    '  ]),\n' +
    '  Assignment.aggregate([\n' +
    '    { $match: { classroom: { $in: classroomIds } } },\n' +
    '    { $group: { _id: "$classroom", count: { $sum: 1 } } },\n' +
    '  ]),\n' +
    ']);\n' +
    '\n' +
    '// [Bước 3] Tính % tiến trình mỗi lớp\n' +
    'const enrollments = validMemberships.map(m => {\n' +
    '  const totalItems = (lectureMap[m.classroom._id] || 0) + (assignMap[m.classroom._id] || 0);\n' +
    '  const done = doneByClassroom[m.classroom._id] || 0;\n' +
    '  const progress = totalItems > 0\n' +
    '    ? Math.min(100, Math.round((done / totalItems) * 100))\n' +
    '    : 0;\n' +
    '  return { classroom: { ...m.classroom }, progress };\n' +
    '});'
  ),
  codeTieuDe('dashboard.controller.js — Bước 8: Gamification (XP, Level, Badges)'),
  ...code(
    '// [Bước 8] Tính XP từ hành động thực tế\n' +
    'const xpTotal = submissionCount * 50   // 50 XP mỗi bài nộp\n' +
    '             + examCount * 75           // 75 XP mỗi lần thi\n' +
    '             + completedCount * 25;     // 25 XP mỗi bài được chấm\n' +
    '\n' +
    'const xpLevel     = Math.floor(xpTotal / 500) + 1;\n' +
    'const xpIntoLevel = xpTotal % 500;\n' +
    'const xpData = {\n' +
    '  level: xpLevel,\n' +
    '  current: xpTotal,\n' +
    '  toNext: 500,\n' +
    '  progressPct: Math.round((xpIntoLevel / 500) * 100),\n' +
    '  badges: buildBadges(submissionCount, examCount, avgScore, attendanceRate),\n' +
    '};\n' +
    '\n' +
    'function buildBadges(submissionCount, examCount, avgScore, attendanceRate) {\n' +
    '  const badges = [];\n' +
    '  if (submissionCount >= 1)    badges.push({ name: "First Steps",  icon: "ph-footprints" });\n' +
    '  if (examCount >= 3)          badges.push({ name: "Exam Taker",   icon: "ph-exam" });\n' +
    '  if (avgScore >= 90)          badges.push({ name: "Top Scorer",   icon: "ph-star" });\n' +
    '  if (attendanceRate >= 90)    badges.push({ name: "Show Up",      icon: "ph-calendar-check" });\n' +
    '  return badges.slice(0, 4);\n' +
    '}'
  ),

  // ── 6.2 ──────────────────────────────────────────────────────
  h2('6.2 Tham gia Lớp học (Join Classroom)'),
  sectionMoTa(
    'MÔ TẢ: Học sinh nhập mã code 6 ký tự để gửi yêu cầu tham gia lớp học. Tùy cấu hình của giáo viên, học sinh được duyệt tự động hoặc phải chờ.\n' +
    'Ý NGHĨA: Đây là cổng vào lớp học. Code giúp kiểm soát ai được phép vào — chỉ những ai được giáo viên cung cấp code mới xin được. Cơ chế approvalRequired đảm bảo giáo viên kiểm soát thành phần lớp học.'
  ),
  h3('URL: GET /student/classrooms (danh sách) | POST /student/classrooms (tham gia)'),
  h3('Luồng nghiệp vụ — Tham gia lớp:'),
  buocLabel('1', 'Đọc code từ form — code.toUpperCase() (code không phân biệt hoa thường).'),
  buocLabel('2', 'Tìm lớp — Classroom.findOne({ code, isArchived: false }). Không tìm thấy → redirect lỗi.'),
  buocLabel('3', 'Kiểm tra đã là member — ClassroomMember.findOne({ classroom, student }). Đã có → redirect lỗi.'),
  buocLabel('4', 'Tạo ClassroomMember — status tùy approvalRequired: "pending" (chờ duyệt) hoặc "approved" (vào ngay).'),
  buocLabel('5', 'Lưu và redirect — với feedback phù hợp.'),
  h3('Luồng nghiệp vụ — Xem chi tiết lớp:'),
  buocLabel('1', 'ClassroomMember.findOne({ classroom, student }) populate classroom. Không có → 404.'),
  buocLabel('2', 'computeCourseProgress(classroom, studentId) — tính syllabus: chapters, items, lock/unlock, remaining.'),
  buocLabel('3', 'evaluateClassroomCompletion(classroom, studentId) — kiểm tra completionRules → banner hoàn thành.'),
  buocLabel('4', 'Render view với courseProgress và courseCompletion.'),
  divider(),
  codeTieuDe('classroom.controller.js — joinClassroomHandler() [Bước 1 → 5]'),
  ...code(
    'async function joinClassroomHandler(req, res, next) {\n' +
    '  // [Bước 1] Chuẩn hóa code về uppercase\n' +
    '  const code = req.body.code.toUpperCase();\n' +
    '\n' +
    '  // [Bước 2] Tìm lớp theo code, loại bỏ lớp đã archive\n' +
    '  const classroom = await Classroom.findOne({ code, isArchived: false });\n' +
    '  if (!classroom)\n' +
    '    return res.redirect("/student/classrooms?feedback=Classroom+code+not+found.");\n' +
    '\n' +
    '  // [Bước 3] Kiểm tra đã xin vào hoặc đã là thành viên\n' +
    '  const existingMember = await ClassroomMember.findOne({\n' +
    '    classroom: classroom.id, student: req.user.id\n' +
    '  });\n' +
    '  if (existingMember)\n' +
    '    return res.redirect("/student/classrooms?feedback=Already+requested+or+joined.");\n' +
    '\n' +
    '  // [Bước 4] Tạo membership — auto-approve nếu không cần duyệt\n' +
    '  const member = new ClassroomMember({\n' +
    '    classroom: classroom.id,\n' +
    '    student: req.user.id,\n' +
    '    status: classroom.approvalRequired ? "pending" : "approved",\n' +
    '    approvedAt: classroom.approvalRequired ? null : new Date(),\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 5] Lưu và redirect với thông báo phù hợp\n' +
    '  await member.save();\n' +
    '  const msg = classroom.approvalRequired\n' +
    '    ? "Join+request+submitted." : "Joined+classroom+successfully.";\n' +
    '  return res.redirect("/student/classrooms?feedback=" + msg);\n' +
    '}'
  ),

  // ── 6.3 ──────────────────────────────────────────────────────
  h2('6.3 Nộp Bài tập (Assignment Submission)'),
  sectionMoTa(
    'MÔ TẢ: Học sinh nộp bài làm (văn bản và/hoặc file đính kèm) cho một bài tập được giáo viên giao. Có thể nộp lại nhiều lần trước deadline.\n' +
    'Ý NGHĨA: Hỗ trợ upsert — nộp lần đầu là create, nộp lại là update — đảm bảo chỉ có 1 submission mỗi học sinh/bài tập. Sau khi nộp, progress ledger được cập nhật ngay để tiến trình khóa học phản ánh chính xác.'
  ),
  h3('URL: GET .../assignments/:assignId/submission | POST .../submission'),
  h3('Luồng nghiệp vụ — Xem form nộp bài (GET):'),
  buocLabel('1', 'Xác minh membership approved.'),
  buocLabel('2', 'Tìm assignment: isPublished = true, thuộc classroom của học sinh.'),
  buocLabel('3', 'Kiểm tra deadline — dueDate đã qua → 403 "Deadline passed". Chưa qua → hiển thị form.'),
  buocLabel('4', 'Load bài nộp cũ (nếu có) để prefill form — học sinh biết đã nộp rồi.'),
  h3('Luồng nghiệp vụ — Nộp bài (POST):'),
  buocLabel('1', 'Xác minh membership, assignment, deadline — giống GET.'),
  buocLabel('2', 'Validate form — (express-validator trong route).'),
  buocLabel('3', 'Xử lý file đính kèm — resolveSubmissionAttachment(req.file): đường dẫn + metadata.'),
  buocLabel('4', 'Upsert Submission — Tìm submission cũ: có → update; không → create.'),
  buocLabel('5', 'Cập nhật Progress Ledger — markComplete(): ghi hoàn thành assignment vào StudentProgress.'),
  buocLabel('6', 'Redirect — đến trang chi tiết submission với feedback.'),
  divider(),
  codeTieuDe('submission.controller.js — createSubmissionHandler() [Bước 1 → 6]'),
  ...code(
    'async function createSubmissionHandler(req, res, next) {\n' +
    '  // [Bước 1] Xác minh membership approved\n' +
    '  const membership = await ClassroomMember.findOne({\n' +
    '    classroom: req.params.classroomId,\n' +
    '    student: req.user.id,\n' +
    '    status: "approved",\n' +
    '  }).populate("classroom");\n' +
    '  if (!membership) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 1] Tìm assignment phải published và thuộc lớp này\n' +
    '  const assignment = await Assignment.findOne({\n' +
    '    _id: req.params.assignmentId,\n' +
    '    classroom: membership.classroom.id,\n' +
    '    isPublished: true,\n' +
    '  });\n' +
    '  if (!assignment) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 1] Kiểm tra deadline\n' +
    '  if (assignment.dueDate && new Date() > new Date(assignment.dueDate)) {\n' +
    '    return res.status(403).render("errors/403", {\n' +
    '      message: "This assignment is past its due date.",\n' +
    '    });\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 3] Xử lý file đính kèm (Multer upload)\n' +
    '  const attachment = resolveSubmissionAttachment(req.file);\n' +
    '  const submittedAt = new Date();\n' +
    '\n' +
    '  // [Bước 4] Upsert: tìm submission cũ\n' +
    '  const submission = await Submission.findOne({\n' +
    '    assignment: assignment.id, student: req.user.id\n' +
    '  });\n' +
    '  if (submission) {\n' +
    '    // Đã có → cập nhật (nộp lại)\n' +
    '    submission.textAnswer = req.body.textAnswer || "";\n' +
    '    submission.attachment = attachment;\n' +
    '    submission.status = "submitted";\n' +
    '    submission.submittedAt = submittedAt;\n' +
    '    await submission.save();\n' +
    '  } else {\n' +
    '    // Chưa có → tạo mới\n' +
    '    await Submission.create({\n' +
    '      assignment: assignment.id,\n' +
    '      classroom: membership.classroom.id,\n' +
    '      teacher: assignment.teacher,\n' +
    '      student: req.user.id,\n' +
    '      textAnswer: req.body.textAnswer || "",\n' +
    '      attachment, status: "submitted", submittedAt,\n' +
    '    });\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 5] Ghi vào Progress Ledger (score chưa có, sẽ update khi chấm)\n' +
    '  await markComplete({\n' +
    '    student: req.user.id,\n' +
    '    classroom: String(membership.classroom.id),\n' +
    '    itemType: CONTENT_TYPES.ASSIGNMENT,\n' +
    '    itemId: assignment.id,\n' +
    '    evidence: { maxScore: assignment.totalPoints, submittedAt },\n' +
    '  });\n' +
    '\n' +
    '  // [Bước 6] Redirect đến trang xem submission\n' +
    '  return res.redirect(\n' +
    '    ".../" + assignment.id + "/submission?feedback=Submission+saved."\n' +
    '  );\n' +
    '}'
  ),

  // ── 6.4 ──────────────────────────────────────────────────────
  h2('6.4 Làm Bài thi (Take Exam)'),
  sectionMoTa(
    'MÔ TẢ: Học sinh làm bài kiểm tra trực tuyến có thời gian giới hạn. Hệ thống tự động chấm điểm trắc nghiệm ngay khi nộp; câu tự luận do giáo viên chấm thủ công.\n' +
    'Ý NGHĨA: Đây là luồng phức tạp nhất — tích hợp kiểm soát lượt thi (maxAttempts), đếm ngược thời gian (deadlineAt), giám sát chống gian lận qua Socket.IO, xáo trộn câu hỏi, và chấm điểm tự động. Violations chỉ được ghi từ Socket event (không phải từ form) để tránh giả mạo.'
  ),
  h3('URL: GET .../exams/:examId/take | POST .../exams/:examId/submit | GET .../exams/:examId/result'),
  h3('Luồng nghiệp vụ — Bắt đầu làm bài (GET .../take):'),
  buocLabel('1', 'Xác minh membership approved.'),
  buocLabel('2', 'checkItemAccess() — kiểm tra prerequisite (sequential mode). Locked → 403.'),
  buocLabel('3', 'Đếm usedAttempts — countDocuments(status in submitted/graded/late/auto_submitted). Hết lượt → redirect result.'),
  buocLabel('4', 'Tìm in_progress submission — Nếu chưa có: new ExamSubmission({ status: "in_progress", deadlineAt: now + duration }). Bắt lỗi 11000 (duplicate key — race condition).'),
  buocLabel('5', 'Shuffle (nếu bật) — Fisher-Yates trên mảng questions + options mỗi option array.'),
  buocLabel('6', 'Render take view — truyền questions, submission, deadline.'),
  h3('Luồng nghiệp vụ — Nộp bài (POST .../submit):'),
  buocLabel('1', 'Tìm in_progress submission theo submissionId từ hidden form field.'),
  buocLabel('2', 'Parse answers — req.body["q_<questionId>"] cho mỗi question.'),
  buocLabel('3', 'Chấm điểm tự động — MCQ/multi: exact match options → isCorrect, pointsAchieved. Essay → hasEssay = true, để pending.'),
  buocLabel('4', 'Kiểm tra deadline — evaluateDeadline(submission.deadlineAt, now). Muộn → status = "late".'),
  buocLabel('5', 'Lưu submission — status, gradingStatus, answers, score, submittedAt.'),
  buocLabel('6', 'Cập nhật ledger — Nếu không có essay: markComplete(). Redirect result.'),
  divider(),
  codeTieuDe('exam.controller.js — renderTakeExam() [Bước 1 → 6]'),
  ...code(
    'async function renderTakeExam(req, res, next) {\n' +
    '  // [Bước 1] Xác minh membership approved\n' +
    '  const membership = await ClassroomMember.findOne({\n' +
    '    classroom: req.params.classroomId, student: req.user.id, status: "approved"\n' +
    '  }).populate("classroom");\n' +
    '  if (!membership) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 2] Kiểm tra prerequisite\n' +
    '  const access = await checkItemAccess(...);\n' +
    '  if (access.locked) return res.status(403).render("errors/403", ...);\n' +
    '\n' +
    '  // [Bước 3] Đếm số lượt đã dùng\n' +
    '  const usedAttempts = await ExamSubmission.countDocuments({\n' +
    '    exam: exam.id, student: req.user.id,\n' +
    '    status: { $in: ["submitted", "graded", "late", "auto_submitted"] },\n' +
    '  });\n' +
    '  if (!canStartAttempt(usedAttempts, exam.maxAttempts))\n' +
    '    return res.redirect(".../" + exam.id + "/result");\n' +
    '\n' +
    '  // [Bước 4] Tạo hoặc lấy ExamSubmission đang in_progress\n' +
    '  let submission = await ExamSubmission.findOne({\n' +
    '    exam: exam.id, student: req.user.id, status: "in_progress"\n' +
    '  });\n' +
    '  if (!submission) {\n' +
    '    submission = new ExamSubmission({\n' +
    '      exam: exam.id, student: req.user.id,\n' +
    '      classroom: membership.classroom.id,\n' +
    '      status: "in_progress",\n' +
    '      startedAt: new Date(),\n' +
    '      attemptNumber: usedAttempts + 1,\n' +
    '      deadlineAt: computeDeadline(new Date(), exam.duration),\n' +
    '    });\n' +
    '    try {\n' +
    '      await submission.save();\n' +
    '    } catch (err) {\n' +
    '      if (err && err.code === 11000) // Race condition: đã tạo rồi\n' +
    '        return res.redirect(".../" + exam.id + "/result");\n' +
    '      throw err;\n' +
    '    }\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 5] Xáo trộn nếu exam.shuffle = true\n' +
    '  let questions = await Question.find({ exam: exam.id }).sort({ order: 1 });\n' +
    '  if (exam.shuffle) {\n' +
    '    // Fisher-Yates shuffle\n' +
    '    for (let i = questions.length - 1; i > 0; i--) {\n' +
    '      const j = Math.floor(Math.random() * (i + 1));\n' +
    '      [questions[i], questions[j]] = [questions[j], questions[i]];\n' +
    '    }\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 6] Render màn hình làm bài\n' +
    '  return res.render("student/exams/take", {\n' +
    '    exam, questions, submission,\n' +
    '    deadline: submission.deadlineAt,\n' +
    '  });\n' +
    '}'
  ),
  codeTieuDe('exam.controller.js — submitExamHandler() [Bước 1 → 6]'),
  ...code(
    'async function submitExamHandler(req, res, next) {\n' +
    '  const submittedAt = new Date();\n' +
    '\n' +
    '  // [Bước 1] Tìm submission đang in_progress\n' +
    '  const submission = await ExamSubmission.findOne({\n' +
    '    _id: req.body.submissionId,\n' +
    '    exam: exam.id, student: req.user.id,\n' +
    '    status: "in_progress",\n' +
    '  });\n' +
    '  if (!submission) return res.redirect(".../" + exam.id + "/result");\n' +
    '\n' +
    '  // [Bước 2 + 3] Parse và chấm điểm từng câu\n' +
    '  const answers = [];\n' +
    '  let totalScore = 0;\n' +
    '  let hasEssay = false;\n' +
    '  for (const q of questions) {\n' +
    '    const studentAnswer = req.body["q_" + q.id];\n' +
    '    let isCorrect = false, pointsAchieved = 0;\n' +
    '    let selectedOptions = [], text = "";\n' +
    '\n' +
    '    if (q.type === "multiple_choice" || q.type === "multiple_answer") {\n' +
    '      // [Bước 3] Chấm trắc nghiệm: exact match tất cả đáp án đúng\n' +
    '      if (studentAnswer) {\n' +
    '        const ansArray = Array.isArray(studentAnswer) ? studentAnswer : [studentAnswer];\n' +
    '        selectedOptions = ansArray;\n' +
    '        const correctIds = q.options.filter(o => o.isCorrect).map(o => o._id.toString());\n' +
    '        if (correctIds.length === ansArray.length &&\n' +
    '            correctIds.every(id => ansArray.includes(id))) {\n' +
    '          isCorrect = true;\n' +
    '          pointsAchieved = q.points;\n' +
    '        }\n' +
    '      }\n' +
    '    } else if (q.type === "essay") {\n' +
    '      // [Bước 3] Tự luận: lưu text, chờ chấm thủ công\n' +
    '      text = studentAnswer || "";\n' +
    '      hasEssay = true;\n' +
    '    }\n' +
    '    totalScore += pointsAchieved;\n' +
    '    answers.push({ question: q.id, selectedOptions, text, isCorrect, pointsAchieved });\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 4] Kiểm tra có nộp muộn không\n' +
    '  const { isLate } = evaluateDeadline(submission.deadlineAt, submittedAt);\n' +
    '\n' +
    '  // [Bước 5] Cập nhật và lưu submission\n' +
    '  submission.answers = answers;\n' +
    '  submission.score = totalScore;\n' +
    '  submission.submittedAt = submittedAt;\n' +
    '  submission.status = isLate ? "late" : "submitted";\n' +
    '  // gradingStatus: nếu có essay cần chấm tay, còn lại là auto\n' +
    '  submission.gradingStatus = hasEssay ? "pending_manual_grade" : "auto_graded";\n' +
    '  // QUAN TRỌNG: violations không lấy từ req.body\n' +
    '  // — chỉ được ghi qua Socket.IO event "cheat-violation" trên server\n' +
    '  await submission.save();\n' +
    '\n' +
    '  // [Bước 6] Nếu không cần chấm tay → ghi tiến trình, redirect result\n' +
    '  if (!hasEssay) {\n' +
    '    await markComplete({\n' +
    '      student: req.user.id,\n' +
    '      classroom: String(classroom.id),\n' +
    '      itemType: CONTENT_TYPES.EXAM,\n' +
    '      itemId: exam.id,\n' +
    '      evidence: { score: totalScore, maxScore: exam.totalPoints, submittedAt },\n' +
    '    });\n' +
    '  }\n' +
    '  return res.redirect(".../" + exam.id + "/result");\n' +
    '}'
  ),

  // ── 6.5 ──────────────────────────────────────────────────────
  h2('6.5 Điểm danh (Student Check-in)'),
  sectionMoTa(
    'MÔ TẢ: Học sinh nhập mã 6 ký tự (do giáo viên hiển thị trong giờ học) để điểm danh vào một phiên học cụ thể.\n' +
    'Ý NGHĨA: Mã có thời hạn 60 giây và được làm mới liên tục — học sinh phải có mặt thực sự để nhập kịp thời. Hệ thống kiểm tra cả tính hợp lệ của mã và thời hạn, sau đó cập nhật AttendanceRecord từ "absent" sang "present".'
  ),
  h3('URL: GET /student/classrooms/:id/attendance | POST .../attendance/checkin'),
  h3('Luồng nghiệp vụ — Điểm danh (POST .../checkin):'),
  buocLabel('1', 'Xác minh membership approved.'),
  buocLabel('2', 'Tìm phiên đang mở — AttendanceSession.findOne({ classroom, status: "open" }).sort({ createdAt: -1 }) — lấy phiên mới nhất.'),
  buocLabel('3', 'Kiểm tra mã — session.currentCode !== code → lỗi "Invalid Code".'),
  buocLabel('4', 'Kiểm tra thời hạn — new Date() > session.expiresAt → lỗi "Code Expired".'),
  buocLabel('5', 'Upsert AttendanceRecord — Tìm record theo (session, student): có → update status = "present"; không có → create mới.'),
  buocLabel('6', 'Redirect — với feedback "Check-in Successful".'),
  divider(),
  codeTieuDe('attendance.controller.js — submitCheckin() [Bước 1 → 6]'),
  ...code(
    'async function submitCheckin(req, res, next) {\n' +
    '  // [Bước 1] Xác minh học sinh thuộc lớp và đã được duyệt\n' +
    '  const membership = await ClassroomMember.findOne({\n' +
    '    classroom: req.params.classroomId,\n' +
    '    student: req.user.id,\n' +
    '    status: "approved",\n' +
    '  }).populate("classroom");\n' +
    '  if (!membership) return res.status(404).render("errors/404", ...);\n' +
    '\n' +
    '  // [Bước 2] Tìm phiên điểm danh đang mở (mới nhất)\n' +
    '  const session = await AttendanceSession.findOne({\n' +
    '    classroom: membership.classroom.id,\n' +
    '    status: "open",\n' +
    '  }).sort({ createdAt: -1 });\n' +
    '  if (!session)\n' +
    '    return res.redirect("...?error=No+active+attendance+session");\n' +
    '\n' +
    '  const code = (req.body.code || "").trim().toUpperCase();\n' +
    '\n' +
    '  // [Bước 3] So khớp mã điểm danh\n' +
    '  if (session.currentCode !== code)\n' +
    '    return res.redirect("...?error=Invalid+Code");\n' +
    '\n' +
    '  // [Bước 4] Kiểm tra mã chưa hết hạn\n' +
    '  if (new Date() > session.expiresAt)\n' +
    '    return res.redirect("...?error=Code+Expired.+Please+look+for+new+code");\n' +
    '\n' +
    '  // [Bước 5] Upsert AttendanceRecord\n' +
    '  const record = await AttendanceRecord.findOne({\n' +
    '    session: session.id, student: req.user.id\n' +
    '  });\n' +
    '  if (record) {\n' +
    '    if (record.status === "present")\n' +
    '      return res.redirect("...?feedback=Already+checked+in");\n' +
    '    // Đã có record "absent" → đổi sang "present"\n' +
    '    record.status = "present";\n' +
    '    record.time = new Date();\n' +
    '    await record.save();\n' +
    '  } else {\n' +
    '    // Chưa có record (hiếm — insertMany có thể đã tạo) → tạo mới\n' +
    '    await AttendanceRecord.create({\n' +
    '      session: session.id, student: req.user.id,\n' +
    '      status: "present", time: new Date(),\n' +
    '    });\n' +
    '  }\n' +
    '\n' +
    '  // [Bước 6] Redirect thành công\n' +
    '  return res.redirect("...?feedback=Check-in+Successful");\n' +
    '}'
  ),

  // ── 6.6 ──────────────────────────────────────────────────────
  h2('6.6 Diễn đàn Thảo luận (Student Discussion)'),
  sectionMoTa(
    'MÔ TẢ: Học sinh tạo chủ đề thảo luận và trả lời trong phòng học. Có thể xem tất cả thảo luận từ mọi lớp đang học trong một trang duy nhất.\n' +
    'Ý NGHĨA: Tạo không gian học tập tương tác. Học sinh chỉ xóa được nội dung của chính mình (ownership check). Cross-classroom view giúp học sinh không bỏ lỡ thảo luận ở bất kỳ lớp nào.'
  ),
  h3('URL: /student/classrooms/:id/discussions | .../discussions/:topicId | GET /student/discussions (all)'),
  h3('Luồng nghiệp vụ — Tạo topic:'),
  buocLabel('1', 'Xác minh membership approved.'),
  buocLabel('2', 'Validate form — title (bắt buộc), content.'),
  buocLabel('3', 'DiscussionTopic.create({ classroom, author: req.user.id, title, content }) → redirect topic.'),
  h3('Luồng nghiệp vụ — Tạo reply:'),
  buocLabel('1', 'Xác minh membership.'),
  buocLabel('2', 'DiscussionReply.create({ topic, author, content }).'),
  buocLabel('3', 'topic.replyCount++ → topic.save().'),
  h3('Luồng nghiệp vụ — Xóa topic (của mình):'),
  buocLabel('1', 'DiscussionTopic.findOne({ _id, author: req.user.id }) — chỉ tìm topic của học sinh này.'),
  buocLabel('2', 'DiscussionReply.deleteMany({ topic }) → topic.deleteOne().'),
  h3('Cross-classroom view:'),
  buocLabel('1', 'Lấy tất cả classroomIds đang approved của student.'),
  buocLabel('2', 'DiscussionTopic.find({ classroom: { $in: classroomIds } }).populate("classroom").sort(−createdAt).'),
  buocLabel('3', 'Render tất cả topics theo thứ tự mới nhất.'),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 7: REAL-TIME (SOCKET.IO)
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('7. REAL-TIME FEATURES (SOCKET.IO)'),
  note('index.js — Socket.IO được khởi tạo cùng HTTP server, 2 namespace riêng biệt'),

  // ── 7.1 ──────────────────────────────────────────────────────
  h2('7.1 Giám sát Thi chống gian lận (/exam-monitor)'),
  sectionMoTa(
    'MÔ TẢ: Namespace /exam-monitor giúp giáo viên giám sát học sinh đang làm bài thi real-time. Học sinh phát tín hiệu vi phạm (tab switch, copy/paste, thoát fullscreen...) và giáo viên nhận được ngay lập tức.\n' +
    'Ý NGHĨA: Bảo vệ tính toàn vẹn của bài thi trực tuyến. Violations được lưu trực tiếp vào ExamSubmission trong DB qua Socket — không qua form submit để tránh học sinh can thiệp. Giới hạn 200 vi phạm/lần thi để tránh tấn công DoS vào storage.'
  ),
  h3('Events từ Student:'),
  buocLabel('1', '"join-exam" — Student join room theo examId: socket.join(data.examId).'),
  buocLabel('2', '"cheat-violation" — Gửi { examId, studentId, type, details } khi phát hiện hành vi gian lận.'),
  h3('Server xử lý "cheat-violation":'),
  buocLabel('1', 'Validate payload — kiểm tra đủ examId, studentId, type.'),
  buocLabel('2', 'Tìm submission in_progress — ExamSubmission.findOne({ exam, student, status: "in_progress" }).'),
  buocLabel('3', 'Ghi violation — Nếu violations.length < 200: push({ type, time, details.slice(0,500) }) → save().'),
  buocLabel('4', 'Broadcast — examMonitor.to(examId).emit("student-violation", data) → giáo viên nhận.'),
  h3('Events từ Teacher:'),
  buocLabel('1', '"teacher-join" — Giáo viên join room theo examId → nhận "student-violation" real-time.'),
  divider(),
  codeTieuDe('index.js — Socket.IO /exam-monitor handler [Bước 1 → 4]'),
  ...code(
    'const examMonitor = io.of("/exam-monitor");\n' +
    '\n' +
    'examMonitor.on("connection", (socket) => {\n' +
    '  // Học sinh vào phòng thi (join room)\n' +
    '  socket.on("join-exam", (data) => {\n' +
    '    socket.join(data.examId);\n' +
    '  });\n' +
    '\n' +
    '  // Giáo viên vào phòng giám sát\n' +
    '  socket.on("teacher-join", (data) => {\n' +
    '    socket.join(data.examId);\n' +
    '  });\n' +
    '\n' +
    '  socket.on("cheat-violation", async (data) => {\n' +
    '    // [Bước 1] Validate payload\n' +
    '    if (!data || !data.examId || !data.studentId || !data.type) return;\n' +
    '\n' +
    '    try {\n' +
    '      // [Bước 2] Tìm submission đang in_progress\n' +
    '      const submission = await ExamSubmission.findOne({\n' +
    '        exam: data.examId,\n' +
    '        student: data.studentId,\n' +
    '        status: "in_progress",\n' +
    '      });\n' +
    '      if (!submission) return; // Không tìm thấy → bỏ qua\n' +
    '\n' +
    '      // [Bước 3] Lưu violation, giới hạn 200 để tránh DoS vào storage\n' +
    '      if (submission.violations.length < 200) {\n' +
    '        submission.violations.push({\n' +
    '          type: data.type,\n' +
    '          time: new Date(),\n' +
    '          details: data.details ? String(data.details).slice(0, 500) : "",\n' +
    '        });\n' +
    '        await submission.save();\n' +
    '      }\n' +
    '    } catch (err) {\n' +
    '      console.error("Exam violation persist error:", err);\n' +
    '    }\n' +
    '\n' +
    '    // [Bước 4] Broadcast cho giáo viên đang monitor room này\n' +
    '    examMonitor.to(data.examId).emit("student-violation", data);\n' +
    '  });\n' +
    '});'
  ),

  // ── 7.2 ──────────────────────────────────────────────────────
  h2('7.2 Chat Phòng học (/chat)'),
  sectionMoTa(
    'MÔ TẢ: Namespace /chat cho phép học sinh và giáo viên nhắn tin real-time trong phòng học (gắn theo classroomId). Mỗi tin nhắn được lưu vào MongoDB để có lịch sử chat.\n' +
    'Ý NGHĨA: Tạo kênh giao tiếp trực tiếp trong bài giảng — học sinh hỏi câu hỏi ngay khi đang xem video/tài liệu. Tin nhắn được persist nên khi reload trang, lịch sử vẫn còn (50 tin nhắn gần nhất được load khi vào phòng).'
  ),
  h3('Events:'),
  buocLabel('1', '"join_chat" — Join room theo classroomId: socket.join(data.classroomId).'),
  buocLabel('2', '"send_message" — Gửi { classroomId, senderId, content }.'),
  h3('Server xử lý "send_message":'),
  buocLabel('1', 'Lưu tin nhắn — ChatMessage.create({ classroom, sender, content }).'),
  buocLabel('2', 'Populate sender — newMessage.populate("sender", "name avatarUrl").'),
  buocLabel('3', 'Broadcast — chatMonitor.to(classroomId).emit("receive_message", {...}) → tất cả users trong room nhận.'),
  divider(),
  codeTieuDe('index.js — Socket.IO /chat handler [Bước 1 → 3]'),
  ...code(
    'const chatMonitor = io.of("/chat");\n' +
    '\n' +
    'chatMonitor.on("connection", (socket) => {\n' +
    '  // [Bước 1] Học sinh/giáo viên vào phòng chat\n' +
    '  socket.on("join_chat", (data) => {\n' +
    '    socket.join(data.classroomId);\n' +
    '  });\n' +
    '\n' +
    '  socket.on("send_message", async (data) => {\n' +
    '    try {\n' +
    '      // [Bước 1] Lưu tin nhắn vào DB\n' +
    '      const newMessage = await ChatMessage.create({\n' +
    '        classroom: data.classroomId,\n' +
    '        sender: data.senderId,\n' +
    '        content: data.content,\n' +
    '      });\n' +
    '\n' +
    '      // [Bước 2] Populate thông tin người gửi\n' +
    '      const populated = await newMessage.populate("sender", "name avatarUrl");\n' +
    '\n' +
    '      // [Bước 3] Broadcast đến tất cả users trong phòng\n' +
    '      chatMonitor.to(data.classroomId).emit("receive_message", {\n' +
    '        id: populated._id,\n' +
    '        content: populated.content,\n' +
    '        sender: populated.sender,  // { name, avatarUrl }\n' +
    '        createdAt: populated.createdAt,\n' +
    '      });\n' +
    '    } catch (err) {\n' +
    '      console.error("Chat send_message error:", err);\n' +
    '    }\n' +
    '  });\n' +
    '});'
  ),
  pageBreak()
);

// ════════════════════════════════════════════════════════════════
// SECTION 8: DATA MODELS
// ════════════════════════════════════════════════════════════════
elems.push(
  h1('8. MÔ HÌNH DỮ LIỆU (MONGODB SCHEMAS)'),
  sectionMoTa('19 collection MongoDB. Dưới đây là các fields quan trọng và ý nghĩa business của từng model.'),

  h2('8.1 User — Người dùng hệ thống'),
  sectionMoTa('Đây là model trung tâm. Role quyết định màn hình và quyền hạn. Status quyết định có được đăng nhập hay không. Provider phân biệt đăng ký thường và OAuth.'),
  ...code(
    '{\n' +
    '  name: String (required, max 120),\n' +
    '  email: String (unique, lowercase, indexed),\n' +
    '  passwordHash: String (select:false — không trả về mặc định),\n' +
    '  role: enum ["admin","teacher","student"] (default: "student"),\n' +
    '  status: enum ["pending","active","rejected"]\n' +
    '           // Teacher đăng ký -> "pending", còn lại -> "active"\n' +
    '  provider: enum ["local","google","facebook"],\n' +
    '  providerId: String (OAuth user ID từ provider),\n' +
    '  phone, avatarUrl, emailNotifications: Boolean,\n' +
    '  refreshTokenHash: String (select:false — SHA-256 của refresh token),\n' +
    '  passwordChangedAt, lastLoginAt,\n' +
    '  createdAt, updatedAt (auto timestamps)\n' +
    '}\n' +
    '// Methods:\n' +
    '//   setPassword(pw) — bcrypt hash 12 rounds\n' +
    '//   comparePassword(pw) — bcrypt compare\n' +
    '//   setRefreshToken(token) — SHA-256 hash và lưu\n' +
    '//   matchesRefreshToken(token) — verify hash\n' +
    '//   clearRefreshToken() — logout\n' +
    '// Virtual: isApproved -> status === "active"'
  ),

  h2('8.2 Classroom — Lớp học'),
  sectionMoTa('Đơn vị tổ chức chính. Code 6 ký tự là key để học sinh tham gia. approvalRequired điều khiển cơ chế xét duyệt tự động hay thủ công.'),
  ...code(
    '{\n' +
    '  name: String (required),\n' +
    '  description: String,\n' +
    '  teacher: ObjectId -> User (required),\n' +
    '  code: String (unique, 6 ký tự random UPPERCASE, auto-generated bởi pre-save hook),\n' +
    '  approvalRequired: Boolean (default: true),\n' +
    '  isArchived: Boolean (default: false),\n' +
    '  category: ObjectId -> Category,\n' +
    '  level: enum ["Beginner","Intermediate","Advanced"],\n' +
    '  completionRules: Object (điều kiện hoàn thành khóa học),\n' +
    '  createdAt, updatedAt\n' +
    '}'
  ),

  h2('8.3 ClassroomMember — Thành viên lớp học'),
  sectionMoTa('Bảng quan hệ N-N giữa Classroom và User (student). Status quyết định học sinh có thể truy cập nội dung lớp không. Index unique { classroom, student } tránh đăng ký trùng.'),
  ...code(
    '{\n' +
    '  classroom: ObjectId -> Classroom (required),\n' +
    '  student: ObjectId -> User (required),\n' +
    '  status: enum ["pending","approved","rejected"] (default: "pending"),\n' +
    '  requestedAt: Date (khi xin vào),\n' +
    '  approvedAt: Date (khi được duyệt)\n' +
    '  // Index unique: { classroom, student }\n' +
    '}'
  ),

  h2('8.4 Lecture — Bài giảng'),
  sectionMoTa('Đơn vị nội dung học tập. orderIndex và chapterTitle cho phép tổ chức theo chương. resourceType xác định cách render nội dung (video player, PDF viewer, rich text...).'),
  ...code(
    '{\n' +
    '  classroom: ObjectId, teacher: ObjectId,\n' +
    '  chapterTitle: String (nhóm bài giảng theo chương),\n' +
    '  title: String (required),\n' +
    '  summary: String, content: String (HTML rich text),\n' +
    '  resourceUrl: String,\n' +
    '  resourceType: enum ["text","video","pdf","document","link"],\n' +
    '  orderIndex: Number (thứ tự hiển thị),\n' +
    '  isPublished: Boolean (default: true),\n' +
    '  createdAt, updatedAt\n' +
    '}'
  ),

  h2('8.5 Assignment — Bài tập'),
  sectionMoTa('Công việc học sinh cần hoàn thành với deadline. Có thể gắn Rubric để chấm điểm theo tiêu chí.'),
  ...code(
    '{\n' +
    '  classroom: ObjectId, teacher: ObjectId,\n' +
    '  title: String (required), description: String, instructions: String,\n' +
    '  totalPoints: Number (default: 10),\n' +
    '  dueDate: Date (null = không có deadline),\n' +
    '  isPublished: Boolean, allowLateSubmission: Boolean,\n' +
    '  rubric: ObjectId -> Rubric (tùy chọn),\n' +
    '  createdAt, updatedAt\n' +
    '}'
  ),

  h2('8.6 Submission — Bài nộp Assignment'),
  sectionMoTa('Mỗi học sinh có tối đa 1 submission mỗi assignment. Upsert pattern. Score được cập nhật khi giáo viên chấm.'),
  ...code(
    '{\n' +
    '  assignment: ObjectId, classroom: ObjectId, teacher: ObjectId, student: ObjectId,\n' +
    '  textAnswer: String, attachment: { url, filename, mimetype, size },\n' +
    '  status: enum ["submitted","graded","late"],\n' +
    '  score: Number (null trước khi chấm),\n' +
    '  teacherComment: String,\n' +
    '  rubricGrades: [{ criterion: String, points: Number }],\n' +
    '  submittedAt, gradedAt, createdAt, updatedAt\n' +
    '}'
  ),

  h2('8.7 Exam — Bài thi'),
  sectionMoTa('Cấu hình bài thi: thời gian, số lượt, chống gian lận, xáo trộn, cửa sổ thời gian (startTime-endTime). totalPoints và questionCount được cập nhật mỗi khi thêm/xóa câu hỏi.'),
  ...code(
    '{\n' +
    '  classroom: ObjectId, teacher: ObjectId,\n' +
    '  title: String (required), description: String,\n' +
    '  duration: Number (phút, default: 60),\n' +
    '  password: String (mật khẩu vào phòng, tùy chọn),\n' +
    '  maxAttempts: Number (default: 1),\n' +
    '  showResult: enum ["after_submit","always","never"],\n' +
    '  isPublished: Boolean, strictMode: Boolean (bật giam sát),\n' +
    '  maxViolations: Number (ngưỡng vi phạm tối đa),\n' +
    '  shuffle: Boolean (xáo trộn câu hỏi + đáp án),\n' +
    '  startTime: Date, endTime: Date (cửa sổ thời gian thi),\n' +
    '  totalPoints: Number (tổng hợp từ questions),\n' +
    '  questionCount: Number,\n' +
    '  createdAt, updatedAt\n' +
    '}'
  ),

  h2('8.8 Question — Câu hỏi'),
  sectionMoTa('Câu hỏi gắn với Exam. Essay câu hỏi không có options, chờ chấm thủ công.'),
  ...code(
    '{\n' +
    '  exam: ObjectId -> Exam,\n' +
    '  type: enum ["multiple_choice","multiple_answer","essay"],\n' +
    '  content: String (required, nội dung câu hỏi),\n' +
    '  options: [{ text: String, isCorrect: Boolean }],\n' +
    '  points: Number (default: 1), order: Number,\n' +
    '  createdAt, updatedAt\n' +
    '}'
  ),

  h2('8.9 ExamSubmission — Bài nộp Thi'),
  sectionMoTa('Phức tạp nhất — lưu toàn bộ câu trả lời, vi phạm, điểm số và trạng thái chấm. Index unique { exam, student, attemptNumber } đảm bảo mỗi lần thi là duy nhất.'),
  ...code(
    '{\n' +
    '  exam: ObjectId, student: ObjectId, classroom: ObjectId,\n' +
    '  status: enum ["in_progress","submitted","graded","late","auto_submitted"],\n' +
    '  gradingStatus: enum ["pending_manual_grade","auto_graded","fully_graded"],\n' +
    '  answers: [{\n' +
    '    question: ObjectId, selectedOptions: [String], text: String,\n' +
    '    isCorrect: Boolean, pointsAchieved: Number, teacherComment: String\n' +
    '  }],\n' +
    '  score: Number,\n' +
    '  violations: [{ type, time, details }], // tối đa 200 entries\n' +
    '  attemptNumber: Number,\n' +
    '  startedAt, submittedAt, deadlineAt,\n' +
    '  // Index unique: { exam, student, attemptNumber }\n' +
    '}'
  ),

  h2('8.10 AttendanceSession — Phiên điểm danh'),
  sectionMoTa('Mỗi buổi học tạo 1 session. Mã hiện tại (currentCode) tự hết hạn sau 60 giây và được làm mới khi giáo viên bấm refresh.'),
  ...code(
    '{\n' +
    '  classroom: ObjectId, teacher: ObjectId,\n' +
    '  date: Date, status: enum ["open","closed"],\n' +
    '  currentCode: String (6 ký tự random uppercase),\n' +
    '  expiresAt: Date (currentCode hết hạn sau 60 giây)\n' +
    '  // Method: generateNewCode() — sinh mã mới + cập nhật expiresAt\n' +
    '}'
  ),

  h2('8.11 AttendanceRecord — Bản ghi điểm danh cá nhân'),
  sectionMoTa('Mỗi học sinh có 1 record mỗi session. Mặc định "absent" khi session tạo, chuyển "present" khi check-in thành công.'),
  ...code(
    '{\n' +
    '  session: ObjectId -> AttendanceSession,\n' +
    '  student: ObjectId -> User,\n' +
    '  status: enum ["present","absent","late","excused"] (default: "absent"),\n' +
    '  time: Date (thời điểm check-in)\n' +
    '}'
  ),

  h2('8.12 StudentProgress — Sổ tiến trình học tập'),
  sectionMoTa('Ledger (sổ cái) duy nhất theo dõi tiến trình. Mỗi dòng = 1 item (lecture/assignment/exam) cho 1 học sinh. Gradebook và Course Completion đọc từ đây.'),
  ...code(
    '{\n' +
    '  student: ObjectId, classroom: ObjectId,\n' +
    '  itemType: enum ["LECTURE","ASSIGNMENT","EXAM"],\n' +
    '  itemId: ObjectId,\n' +
    '  status: enum ["not_started","in_progress","completed"],\n' +
    '  evidence: { score, maxScore, submittedAt },\n' +
    '  completedAt: Date\n' +
    '  // Index unique: { student, classroom, itemType, itemId }\n' +
    '}'
  ),

  h2('8.13–8.19: Các model phụ trợ'),
  ...code(
    'DiscussionTopic: { classroom, author, title, content, isPinned, replyCount, timestamps }\n' +
    'DiscussionReply: { topic, author, content, timestamps }\n' +
    'QuestionBank:    { teacher, subject, chapter, difficulty, type, content, options, points }\n' +
    'Notification:    { recipient, title, message, link, isRead(default:false), timestamps }\n' +
    'ChatMessage:     { classroom, sender, content, timestamps }\n' +
    'SystemSetting:   { key(unique), value(Mixed), description, updatedAt }\n' +
    'AuditLog:        { action, user, ipAddress, userAgent, createdAt }'
  ),

  pageBreak(),
  new Paragraph({
    children: [new TextRun({ text: '─── Hết tài liệu ───', size: 22, color: '9ca3af', italics: true })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 400 },
  })
);

// ────────────────────────────────────────────────────────────────
// Build document
// ────────────────────────────────────────────────────────────────
async function buildDocument() {
  const doc = new Document({
    styles: {
      default: {
        document: {
          run: { font: 'Times New Roman', size: 22, color: '111827' },
          paragraph: { spacing: { line: 360 } },
        },
      },
    },
    sections: [{ children: elems }],
  });
  const buffer = await Packer.toBuffer(doc);
  const outputPath = path.join(__dirname, '..', 'NGHIEP_VU_HE_THONG_ELEARNING.docx');
  fs.writeFileSync(outputPath, buffer);
  console.log('OK: ' + outputPath);
  console.log('Size: ' + (buffer.length / 1024).toFixed(1) + ' KB');
}

buildDocument().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
