const JSZip = require('jszip');
const fs = require('fs');

async function main() {
  const data = fs.readFileSync('C:/Users/vanha/OneDrive/Desktop/e-learning/Mau trinh bay Slide TTDN.pptx');
  const zip = await JSZip.loadAsync(data);
  const targets = [
    'ppt/slides/slide2.xml',
    'ppt/slides/slide3.xml',
    'ppt/slides/slide4.xml',
    'ppt/slides/slide5.xml',
    'ppt/slides/_rels/slide2.xml.rels',
    'ppt/slideMasters/slideMaster1.xml',
    'ppt/slideMasters/_rels/slideMaster1.xml.rels',
    'ppt/slideLayouts/slideLayout1.xml',
    'ppt/slideLayouts/slideLayout2.xml',
    'ppt/slideLayouts/slideLayout3.xml',
    'ppt/slideLayouts/slideLayout5.xml',
    'ppt/slideLayouts/_rels/slideLayout2.xml.rels',
    'ppt/slideLayouts/_rels/slideLayout5.xml.rels',
    'ppt/theme/theme1.xml',
  ];
  for (const t of targets) {
    const f = zip.file(t);
    if (!f) { console.log('\n######## MISSING:', t); continue; }
    const txt = await f.async('string');
    // pretty print: insert newlines after tags
    const pretty = txt.replace(/></g, '>\n<');
    console.log('\n##########', t, '(', txt.length, 'chars ) ##########\n');
    console.log(pretty);
  }
}
main().catch(e => { console.error(e); process.exit(1); });
