const JSZip = require('jszip');
const fs = require('fs');

(async () => {
  const z = await JSZip.loadAsync(fs.readFileSync('C:/Users/vanha/OneDrive/Desktop/e-learning/báo cáo.docx'));
  const xml = await z.file('word/document.xml').async('string');
  const paras = xml.split('</w:p>');
  const dec = (s) => s.replace(/&/g,'&').replace(/</g,'<').replace(/>/g,'>').replace(/"/g,'"').replace(/'/g,"'");
  const clean = (s) => [...s.matchAll(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)].map(m => m[1]).map(m=>dec(m)).join('');
  let started = false;
  const out = [];
  for (const p of paras) {
    const isToc = /PAGEREF|_Toc235|w:hyperlink/.test(p);
    const styleM = p.match(/<w:pStyle w:val="([^"]*)"/);
    const style = styleM ? styleM[1] : '';
    const isHeading = /Heading/i.test(style) || /Heading|^CHƯƠNG|^MỞ ĐẦU|^KẾT LUẬN|^TÀI LIỆU|HUỚNG|^GIỚI THIỆU/i.test(style);
    const text = clean(p);
    if (!isToc && text.trim()) started = true;
    if (!started) continue;
    if (isToc) continue;
    out.push((isHeading ? ('### [' + style + '] ') : '') + text);
  }
  process.stdout.write(out.join('\n'));
})();
