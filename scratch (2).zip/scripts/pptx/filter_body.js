const fs = require('fs');
const lines = fs.readFileSync('./scripts/pptx/tmp/report_body.txt','utf8').split('\n');
const out = [];
for (let line of lines) {
  // a heading line starts with ###, keep
  if (line.startsWith('### ')) { out.push(line); continue; }
  // strip lines that contain XML tags
  if (/<w:|<a:|<p:|<m:/.test(line)) continue;
  if (!line.trim()) continue;
  out.push(line);
}
fs.writeFileSync('./scripts/pptx/tmp/report_clean.txt', out.join('\n'));
console.log('clean lines:', out.length);
const headings = out.filter(l=>l.startsWith('### '));
console.log('=== HEADINGS ===');
headings.forEach(h=>console.log(h));
