// Pair each image (in document order) with the nearest following paragraph that looks like a caption.
const { JSZip, fs } = require('./gen');
(async () => {
  const z = await JSZip.loadAsync(fs.readFileSync('C:/Users/vanha/OneDrive/Desktop/e-learning/báo cáo.docx'));
  const xml = await z.file('word/document.xml').async('string');
  const rels = await z.file('word/_rels/document.xml.rels').async('string');
  const relMap = {}; [...rels.matchAll(/Id="([^"]*)"[^>]*Target="([^"]*)"/g)].forEach(m => relMap[m[1]] = m[2]);

  // Walk paragraphs in order; for each paragraph, check if it contains a drawing (r:embed) and/or caption text.
  // A caption paragraph usually starts with "Hình" or "Figure" and is short.
  const paras = xml.split('</w:p>');
  const dec = (s) => s.replace(/&/g, '&').replace(/</g, '<').replace(/>/g, '>').replace(/"/g, '"').replace(/&#39;/g, "'");
  const out = [];
  for (let i = 0; i < paras.length; i++) {
    const p = paras[i];
    const embeds = [...p.matchAll(/r:embed="([^"]*)"/g)].map(m => relMap[m[1]] || ('?' + m[1]));
    const texts = [...p.matchAll(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)].map(m => dec(m[1])).join('');
    if (embeds.length) {
      out.push({ img: embeds, caption: '(none - search next paras for caption)' });
      // search next up to 3 paras for a caption-like text
      for (let j = i + 1; j <= Math.min(i + 3, paras.length - 1); j++) {
        const nt = [...paras[j].matchAll(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)].map(m => dec(m[1])).join('');
        if (/^Hình|^Figure|^HINH|^\s*Hình/i.test(nt.trim()) && nt.trim().length < 120) {
          out[out.length - 1].caption = nt.trim();
          break;
        }
      }
    }
  }
  out.forEach((o, i) => console.log(`#${i + 1} IMG ${JSON.stringify(o.img)}  CAPTION: ${o.caption}`));
})();
