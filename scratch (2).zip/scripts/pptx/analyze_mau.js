const JSZip = require('jszip');
const fs = require('fs');
const path = require('path');

async function main() {
  const pptxPath = 'C:/Users/vanha/OneDrive/Desktop/e-learning/Mau trinh bay Slide TTDN.pptx';
  const data = fs.readFileSync(pptxPath);
  const zip = await JSZip.loadAsync(data);
  const files = Object.keys(zip.files).sort();
  console.log('=== PPTX FILE LIST ===');
  files.forEach(f => console.log(f));
  console.log('=== Total:', files.length, '===');
}
main().catch(e => { console.error(e); process.exit(1); });
