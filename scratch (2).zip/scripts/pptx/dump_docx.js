const JSZip = require('jszip');
const fs = require('fs');

async function main() {
  const data = fs.readFileSync('C:/Users/vanha/OneDrive/Desktop/e-learning/báo cáo.docx');
  const zip = await JSZip.loadAsync(data);
  const documentXml = await zip.file('word/document.xml').async('string');

  // Extract all text in <w:t> runs, grouping by paragraph (<w:p>).
  // Split on </w:p> to get paragraphs.
  const paragraphs = documentXml.split('</w:p>');
  let out = [];
  for (const para of paragraphs) {
    // collect all <w:t ...>TEXT</w:t>
    const runs = [...para.matchAll(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)].map(m => m[1]);
    let line = runs.join('');
    line = line.replace(/&/g,'&').replace(/</g,'<').replace(/>/g,'>').replace(/"/g,'"').replace(/'/g,"'");
    // detect heading style
    const styleM = para.match(/<w:pStyle w:val="([^"]*)"[^>]*\/?>/);
    const style = styleM ? styleM[1] : '';
    const hasBreak = /<w:br/.test(para);
    const isHeading = /Heading|^Ti|chuong|^Chương/i.test(style);
    if (line.trim() || hasBreak) {
      out.push((isHeading?('### ['+style+'] '):'')+line);
    }
  }
  console.log(out.join('\n'));

  // List all media images
  const mediaFiles = Object.keys(zip.files).filter(f => f.startsWith('word/media/'));
  console.log('\n\n===== MEDIA IMAGES =====');
  for (const f of mediaFiles) {
    const buf = await zip.file(f).async('nodebuffer');
    console.log(f, '\t', buf.length, 'bytes');
  }
}
main().catch(e => { console.error(e); process.exit(1); });
