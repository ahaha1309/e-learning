// Verify OPC relationship integrity: every r:embed/&r:id resolves in the part's rels.
const G = require('./gen');
const { JSZip, fs, OUT } = G;

async function main() {
  const zip = await JSZip.loadAsync(fs.readFileSync(OUT));
  const issues = [];
  // 1. For each slide: every r:embed must be in slideN.xml.rels, target file must exist.
  const slideFiles = Object.keys(zip.files).filter(f => /^ppt\/slides\/slide\d+\.xml$/.test(f)).sort((a, b) => +a.match(/\d+/)[0] - +b.match(/\d+/)[0]);
  for (const sf of slideFiles) {
    const xml = await zip.file(sf).async('string');
    const relsPath = sf.replace('ppt/slides/', 'ppt/slides/_rels/') + '.rels';
    const relsXml = await zip.file(relsPath).async('string');
    const relIds = {}; [...relsXml.matchAll(/Id="([^"]*)"[^>]*Target="([^"]*)"/g)].forEach(m => relIds[m[1]] = m[2]);
    // r:embed
    for (const m of xml.matchAll(/r:embed="([^"]*)"/g)) {
      const id = m[1];
      if (!relIds[id]) issues.push(`${sf}: r:embed ${id} not in rels`);
    }
    // each rel target file must exist
    for (const [id, target] of Object.entries(relIds)) {
      // normalize relative path
      const baseDir = sf.replace('/slides/', '/slides/').replace(/[^/]+$/, '');
      let abs = target.replace(/^\.\.\//, 'ppt/');
      if (target.startsWith('../media/')) abs = 'ppt/media/' + target.split('/').pop();
      if (target.startsWith('../slideLayouts/')) abs = 'ppt/slideLayouts/' + target.split('/').pop();
      if (!zip.file(abs) && !zip.file(abs.replace(/^\.\.\//, 'ppt/'))) issues.push(`${sf} rels ${id} -> ${target}: target MISSING (${abs})`);
    }
  }
  // 2. presentation.xml sldId r:id must be in presentation.xml.rels pointing to an existing slide
  const pres = await zip.file('ppt/presentation.xml').async('string');
  const presRels = await zip.file('ppt/_rels/presentation.xml.rels').async('string');
  const presRelMap = {}; [...presRels.matchAll(/Id="([^"]*)"[^>]*Type="[^"]*\/(slide|slideLayout|slideMaster|theme|notesMaster)"/g)].forEach(m => presRelMap[m[1]] = m[2]);
  for (const m of pres.matchAll(/<p:sldId[^>]*r:id="([^"]*)"/g)) {
    const id = m[1];
    if (!presRelMap[id]) issues.push(`presentation sldId r:id ${id}: not a slide rel`);
  }
  // sldId count vs slides on disk
  const sldIds = (pres.match(/<p:sldId /g) || []).length;
  if (sldIds !== slideFiles.length) issues.push(`sldIdLst=${sldIds} vs slide files=${slideFiles.length}`);
  // 3. [Content_Types].xml has Override for every slide
  const ct = await zip.file('[Content_Types].xml').async('string');
  for (const sf of slideFiles) {
    if (!ct.includes(`PartName="/${sf}"`)) issues.push(`Content_Types missing Override for ${sf}`);
  }
  // 4. media referenced by rels must exist in zip
  console.log('Integrity issues:', issues.length);
  issues.slice(0, 40).forEach(i => console.log('  -', i));
}
main().catch(e => { console.error(e); process.exit(1); });
