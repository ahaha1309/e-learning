// Dump a readable summary of each slide: title, subtitle, bullet count, text, image pick.
const G = require('./gen');
const { JSZip, fs, OUT } = G;
(async () => {
  const z = await JSZip.loadAsync(fs.readFileSync(OUT));
  for (let i = 1; i <= 21; i++) {
    const xml = await z.file(`ppt/slides/slide${i}.xml`).async('string');
    const rels = await z.file(`ppt/slides/_rels/slide${i}.xml.rels`).async('string');
    // title: first big navy sz=3000 text
    const titles = [...xml.matchAll(/sz="3000"[^>]*><a:solidFill><a:srgbClr val="002060"[\s\S]*?<a:t>([\s\S]*?)<\/a:t>/g)].map(m => m[1]);
    const subs = [...xml.matchAll(/sz="1400"[^>]*<a:latin typeface="Cambria"\/><\/a:rPr><a:t>([\s\S]*?)<\/a:t>/g)].map(m => m[1]);
    // all sz>=2000 body text
    const big = [...xml.matchAll(/sz="(2000|2200|2800|7200|3400|3200|3000)"[\s\S]*?<a:t>([\s\S]*?)<\/a:t>/g)].map(m => m[2]);
    // bullets sz 1800-1900 (body)
    const bullets = [...xml.matchAll(/sz="(1800|1900|1750|1850)"[\s\S]*?<a:t>([\s\S]*?)<\/a:t>/g)].map(m => m[2]);
    // image rId
    const imgs = [...rels.matchAll(/Type="[^"]*image" Target="\.\.\/media\/([^"]*)"/g)].map(m => m[1]);
    console.log(`\n=== SLIDE ${i} ===`);
    console.log('TITLE:', titles[0] || '(cover/special)');
    if (subs[0]) console.log('SUB:', subs[0]);
    console.log('IMG:', imgs.join(', ') || '(none)');
    console.log('BODY bullets (' + bullets.length + '):');
    bullets.forEach(b => console.log('   -', b.slice(0, 90)));
  }
})();
