// Build the 21-slide graduation deck by extending the sample PPTX.
// School logo + footer inherit from the (unchanged) slide master via slideLayouts.
// Run: node scripts/pptx/build.js
const G = require('./gen');
const { JSZip, fs, path, ROOT, SAMPLE, IMG, OUT, cm, esc, nid, imgPx, fitH, run, para, titleShape, accent, bodyShape, pic, box, frame, coverXml, agendaRow, NAVY, RED, GRAY, GRAYLT, WHITE, BG } = G;

// report image picks -> report file (verified against report section content)
const PICKS = {
  ssg_logo: 'image1.png',   // Giới thiệu công ty — logo SSG
  web_home: 'image2.png',   // Giới thiệu công ty — trang chủ website
  flow: 'image3.png',       // Kiến trúc tổng thể — luồng request
  ui_login: 'image11.png',  // OAuth 2.0 — đăng nhập/xác thực
  classroom: 'image13.png', // Classroom Schema — giao diện lớp học
  submission: 'image15.png',// Luồng nộp bài — giao diện nộp bài
  exam: 'image16.png',      // Giao diện làm bài thi
  cheat: 'image17.png',     // Chống gian lận real-time
  qbank: 'image18.png',     // Ngân hàng câu hỏi
  discussion: 'image19.png', // Diễn đàn Thảo luận
  dashboard: 'image21.png', // Dashboard thống kê
  catalog: 'image23.png',    // Catalog khóa học công khai
};

const LAY1 = 'slideLayout1', LAY2 = 'slideLayout2', LAY7 = 'slideLayout7';

// bullets helper: array of {lead,text,lvl,bu,sz,marL,indent} OR strings
function makeBullets(arr, baseSz) {
  return arr.map(o => {
    if (typeof o === 'string') o = { text: o };
    return para({
      head: o.lead, text: o.text, lvl: o.lvl || 0,
      bu: o.bu != null ? o.bu : 'none',
      marL: o.marL != null ? o.marL : cm(0.1),
      indent: o.indent != null ? o.indent : 0,
      sz: o.sz || baseSz || 1800,
      color: o.color,
    });
  }).join('');
}

// a content slide: title+accent + left body + right screenshot
function contentRight(title, sub, bodyParas, pick, cx, imgTop, note) {
  const cyv = fitH(PICKS[pick], cx);
  const noteP = note ? para({ text: note, sz: 1500, i: true, color: GRAYLT, marL: cm(0.1), indent: 0, bu: 'none' }) : '';
  return {
    layout: LAY2,
    pics: [{ pick, x: cm(12.9), y: imgTop, cx, cy: cyv }],
    children: titleShape(title, sub) + accent()
      + bodyShape(bodyParas + noteP, cm(1.0), cm(3.0), cm(11.6), cm(13.6))
      + pic('__R0__', cm(12.9), imgTop, cx, cyv),
  };
}

// a content slide with picture on LEFT (text right)
function contentLeft(title, sub, bodyParas, pick, cx, imgTop) {
  const cyv = fitH(PICKS[pick], cx);
  return {
    layout: LAY2,
    pics: [{ pick, x: cm(1.0), y: imgTop, cx, cy: cyv }],
    children: titleShape(title, sub) + accent()
      + bodyShape(bodyParas, cm(13.6), cm(3.0), cm(11.6), cm(13.6))
      + pic('__R0__', cm(1.0), imgTop, cx, cyv),
  };
}

// KPI strip (3 chips) for results slide
function kpiStrip(items) {
  const cols = items.length;
  const gap = cm(0.4), total = cm(22.6), each = (total - gap * (cols - 1)) / cols;
  let x = cm(1.0); const y = cm(3.0);
  return items.map((it, i) => {
    const bx = box(x, y, each, cm(3.2), NAVY);
    const head = `<a:p><a:pPr algn="ctr"><a:buFont typeface="Arial"/><a:buNone/></a:pPr><a:r><a:rPr lang="vi-VN" sz="2800" b="1" dirty="0"><a:solidFill><a:srgbClr val="${WHITE}"/></a:solidFill><a:latin typeface="Cambria"/></a:rPr><a:t>${esc(it.val)}</a:t></a:r></a:p>`;
    const body = `<a:p><a:pPr algn="ctr"><a:spcBef><a:spcPts val="100"/></a:spcBef><a:buFont typeface="Arial"/><a:buNone/></a:pPr><a:r><a:rPr lang="vi-VN" sz="1300"><a:solidFill><a:srgbClr val="${WHITE}"/></a:solidFill><a:latin typeface="Cambria"/></a:rPr><a:t>${esc(it.label)}</a:t></a:r></a:p>`;
    const txt = `<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="KPI${i}"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${each}" cy="${cm(3.2)}"/></a:xfrm><a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 6000"/></a:avLst></a:prstGeom><a:solidFill><a:srgbClr val="${NAVY}"/></a:solidFill></p:spPr><p:txBody><a:bodyPr anchor="ctr" lIns="0" tIns="0" rIns="0" bIns="0"/><a:lstStyle/>${head}${body}</p:txBody></p:sp>`;
    x += each + gap;
    return txt;
  }).join('');
}

async function main() {
  const zip = await JSZip.loadAsync(fs.readFileSync(SAMPLE));

  // ---- embed chosen report images into ppt/media ----
  const mediaName = {}, usedSrc = new Set(); let mIdx = 100;
  for (const [pick, src] of Object.entries(PICKS)) {
    if (usedSrc.has(src)) { mediaName[pick] = mediaName[Object.entries(PICKS).find(([, v]) => v === src)[0]]; continue; }
    usedSrc.add(src);
    const ext = src.replace(/.*\./, '');
    const m = `rpt${mIdx++}.${ext}`;
    mediaName[pick] = `ppt/media/${m}`;
    zip.file(`ppt/media/${m}`, fs.readFileSync(path.join(IMG, src)));
  }

  // ---- remove the 5 sample slides + rels + stale notes ----
  for (let i = 1; i <= 5; i++) { zip.remove(`ppt/slides/slide${i}.xml`); zip.remove(`ppt/slides/_rels/slide${i}.xml.rels`); }
  zip.remove('ppt/notesSlides/notesSlide1.xml');
  zip.remove('ppt/notesSlides/_rels/notesSlide1.xml.rels');

  const SLIDES = [];

  // ===== 1. COVER =====
  SLIDES.push({
    layout: LAY1, pics: [],
    children: coverXml({
      titleRed: '“XÂY DỰNG HỆ THỐNG QUẢN LÝ',
      titleNavy: 'HỌC TẬP TRỰC TUYẾN (E-LEARNING LMS)”',
      lines: [
        { text: 'Sinh viên thực hiện: Nguyễn Văn Hà', sz: 2000, b: true, color: NAVY },
        { text: 'Ngành: Công nghệ Thông tin  •  Chuyên ngành: Công nghệ Phần mềm', sz: 1600, color: GRAY },
        { text: 'GV hướng dẫn: Ths. Nguyễn Thị Thanh', sz: 1600, color: GRAY },
        { text: 'Công ty Cổ phần Tập đoàn Giải pháp Sao Mai', sz: 1700, b: true, color: NAVY },
        { text: 'Hà Nội, tháng 07/2026', sz: 1500, color: GRAYLT },
      ],
    }),
  });

  // ===== 2. NỘI DUNG TRÌNH BÀY (agenda) =====
  {
    const items = [
      'Giới thiệu doanh nghiệp', 'Giới thiệu đề tài thực tập',
      'Công việc được giao & kết quả đạt được',
      'Tự đánh giá', 'Hướng phát triển lên Đồ án tốt nghiệp', 'Kết luận',
    ];
    const rows = items.map((t, i) => agendaRow(i + 1, t)).join('');
    // two-column layout: split 6 into two columns of 3
    const left = items.slice(0, 3).map((t, i) => agendaRow(i + 1, t)).join('');
    const right = items.slice(3).map((t, i) => agendaRow(i + 4, t)).join('');
    const bodyXml = `<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Agenda"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${cm(2.0)}" y="${cm(3.6)}"/><a:ext cx="${cm(11.5)}" cy="${cm(13.4)}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr wrap="square" anchor="t" lIns="0" tIns="0" rIns="0" bIns="0"><a:normAutofit/></a:bodyPr><a:lstStyle/>${left}</p:txBody></p:sp><p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Agenda2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${cm(15.5)}" y="${cm(3.6)}"/><a:ext cx="${cm(10.6)}" cy="${cm(13.4)}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr wrap="square" anchor="t" lIns="0" tIns="0" rIns="0" bIns="0"><a:normAutofit/></a:bodyPr><a:lstStyle/>${right}</p:txBody></p:sp>`;
    SLIDES.push({ layout: LAY2, pics: [], children: titleShape('NỘI DUNG TRÌNH BÀY', 'Nội dung trình bày chính') + accent() + bodyXml });
  }

  // ===== 3. GIỚI THIỆU DOANH NGHIỆP =====
  SLIDES.push(contentRight(
    'GIỚI THIỆU DOANH NGHIỆP', 'Công ty Cổ phần Tập đoàn Giải pháp Sao Mai',
    makeBullets([
      { lead: 'Tên: ', text: 'CP Tập đoàn Giải pháp Sao Mai (SSG Vietnam)' },
      { lead: 'Lĩnh vực: ', text: 'Xuất khẩu phần mềm • ERP/LMS/CRM • Chuyển đổi số' },
      { lead: 'Kinh nghiệm: ', text: '>20 năm, khách hàng Nhật Bản & Mỹ, dự án lớn' },
      { lead: 'Quy trình: ', text: 'Khảo sát → Lập trình → Kiểm thử → Bàn giao' },
      { lead: 'Vị trí TT: ', text: 'Thực tập sinh Lập trình Web — Sản phẩm E-Learning' },
    ], 1900),
    'web_home', cm(11.5), cm(3.6),
    'Website: ssg-vietnam.com  •  Địa chỉ: Nguyễn Quốc Trị, Yên Hòa, Hà Nội'));

  // ===== 4. GIỚI THIỆU ĐỀ TÀI =====
  SLIDES.push(contentRight(
    'GIỚI THIỆU ĐỀ TÀI', 'Đồ án thực tập — liên quan đến ngành Công nghệ phần mềm',
    makeBullets([
      { lead: 'Đề tài: ', text: 'Xây dựng Hệ thống Quản lý Học tập Trực tuyến (LMS)' },
      { lead: 'Bối cảnh: ', text: 'Chuyển đổi số giáo dục + đào tạo nội bộ doanh nghiệp' },
      { lead: 'Tiếp cận: ', text: 'Server-Side Rendering SSR (Node.js + Express + Pug)' },
      { lead: 'Ngành CNPM: ', text: 'MVC + Service Layer, MongoDB, Socket.IO, bảo mật Web' },
      { lead: 'Mục tiêu: ', text: 'Phân quyền RBAC, thi online, chống gian lận, Gradebook' },
    ], 1900),
    'flow', cm(11.6), cm(8.0),
    'Luồng xử lý một request tiêu chuẩn: Route → Middleware → Controller → Service → Model'));

  // ===== 5. CÔNG VIỆC & KẾT QUẢ — Overview =====
  {
    const b = makeBullets([
      { lead: 'Backend: ', text: 'Node.js + Express, Mongoose schema, controller/service' },
      { lead: 'Frontend: ', text: 'Pug + TailwindCSS cho 3 vai trò Học sinh/Giáo viên/Admin' },
      { lead: 'Real-time: ', text: 'Socket.IO cho chat & giám sát thi cử' },
      { lead: 'Bảo mật: ', text: 'JWT, CSRF, rate-limit, XSS-clean, Mongo sanitize' },
      { lead: 'Kiểm thử: ', text: 'Jest unit test các service quan trọng' },
      { lead: 'DevOps: ', text: 'Docker, PM2, Git/GitHub, commit convention' },
    ], 1750);
    SLIDES.push({ layout: LAY2, pics: [], children: titleShape('CÔNG VIỆC ĐƯỢC GIAO & KẾT QUẢ', 'Tổng quan các nhóm nhiệm vụ đã thực hiện') + accent() + kpiStrip([{ val: '6', label: 'nhóm module' }, { val: '10', label: 'tuần thực tập' }, { val: '3', label: 'vai trò người dùng' }]) + bodyShape(b, cm(1.0), cm(7.0), cm(22.6), cm(9.5)) });
  }

  // ===== 6. Xác thực & phân quyền =====
  SLIDES.push(contentRight(
    'XÁC THỰC & PHÂN QUYỀN', 'Hệ thống định danh đa vai trò (RBAC)',
    makeBullets([
      { lead: 'User model: ', text: 'role admin/teacher/student, status pending/active' },
      { lead: 'JWT 2 lớp: ', text: 'Access token (ngắn) + Refresh token (dài), rotation' },
      { lead: 'HttpOnly Cookie: ', text: 'chống XSS đánh cắp token phía client' },
      { lead: 'OAuth 2.0: ', text: 'đăng nhập Google/Facebook qua Passport.js' },
      { lead: 'CSRF: ', text: 'csurf token cho mọi form, skip an toàn multipart' },
    ], 1800),
    'ui_login', cm(11.6), cm(3.4),
    'select:false cho passwordHash/refreshTokenHash — bảo vệ tầng ODM'));

  // ===== 7. Quản lý lớp học =====
  SLIDES.push(contentRight(
    'QUẢN LÝ LỚP HỌC & DANH MỤC', 'Classroom — đơn vị tổ chức trung tâm',
    makeBullets([
      { lead: 'Classroom: ', text: 'code tự sinh (6 ký tự hex), gradeWeights, completionRules' },
      { lead: 'ClassroomMember: ', text: 'tách collection riêng để mở rộng thành viên' },
      { lead: 'Luồng duyệt: ', text: 'yêu cầu → pending → giáo viên phê duyệt → approved' },
      { lead: 'Catalog: ', text: 'lọc theo cấp độ/danh mục, filter hybrid DB + memory' },
      { lead: 'Seed tự động: ', text: '8 danh mục mặc định + gán lớp theo từ khóa' },
    ], 1800),
    'classroom', cm(11.5), cm(3.6),
    'Unique index {classroom, student} chống trùng lặp yêu cầu'));

  // ===== 8. Bài giảng & Bài tập =====
  SLIDES.push(contentRight(
    'BÀI GIẢNG & BÀI TẬP', 'Module nội dung đào tạo và nộp bài',
    makeBullets([
      { lead: 'Lecture: ', text: 'video/file/link, trạng thái Draft → Published' },
      { lead: 'Upload: ', text: 'Multer → Cloudinary, lưu URL vào resourceUrl' },
      { lead: 'Assignment: ', text: 'dueDate, maxScore, attachmentRequired, late submit' },
      { lead: 'Submission: ', text: 'nộp/cập nhật trong deadline, chặn khi quá hạn' },
      { lead: 'Tự động: ', text: 'thông báo học sinh khi có bài tập / điểm mới' },
    ], 1800),
    'submission', cm(11.5), cm(3.6),
    'Countdown timer + nhãn “Đã quá hạn” đỏ khi qua deadline'));

  // ===== 9. Thi trực tuyến & ngân hàng câu hỏi =====
  SLIDES.push(contentRight(
    'THI TRỰC TUYẾN & NGÂN HÀNG CÂU HỎI', 'Exam schema + Question Bank tái sử dụng',
    makeBullets([
      { lead: 'Exam: ', text: 'duration, maxAttempts, showResult, shuffle, maxViolations' },
      { lead: 'Câu hỏi: ', text: 'trắc nghiệm (auto-chấm) + tự luận (chấm tay)' },
      { lead: 'Auto-save: ', text: 'mỗi 30s qua sendBeacon, chống mất dữ liệu' },
      { lead: 'Question Bank: ', text: 'kho riêng, lọc theo môn/chương/độ khó, compound index' },
      { lead: 'Import CSV: ', text: 'tích hợp TinyMCE, express-validator kiểm tra đầu vào' },
    ], 1750),
    'qbank', cm(11.5), cm(3.6),
    'Tách biệt QuestionBank & Question — xóa đề không mất kho gốc'));

  // ===== 10. Chống gian lận real-time (highlight) =====
  SLIDES.push(contentRight(
    'CHỐNG GIAN LẬN REAL-TIME', 'Điểm kỹ thuật nổi bật của đồ án',
    makeBullets([
      { lead: 'Cách cũ: ', text: 'phát hiện client → HTTP request → sinh viên chặn/sửa' },
      { lead: 'Giải pháp: ', text: 'ghi nhận vi phạm qua WebSocket (Socket.IO)' },
      { lead: 'Sự kiện: ', text: 'visibilitychange (ẩn tab) + blur (mất focus)' },
      { lead: 'An toàn: ', text: 'server không tin studentId; tự tìm submission' },
      { lead: 'Giám sát: ', text: 'broadcast real-time đến giáo viên; auto-submit quá giới hạn' },
    ], 1750),
    'cheat', cm(11.7), cm(3.4),
    'Dữ liệu vi phạm có timestamp — nền tảng cho ML phát hiện gian lận (KLTN)'));

  // ===== 11. Điểm danh, thảo luận, chat =====
  SLIDES.push(contentRight(
    'ĐIỂM DANH • THẢO LUẬN • CHAT', 'Tương tác thời gian thực trong lớp',
    makeBullets([
      { lead: 'Điểm danh: ', text: 'sessionCode + expiresAt, trạng thái present/absent/late' },
      { lead: 'Diễn đàn: ', text: 'topic/reply, ghim & khóa chủ đề, isAnswer' },
      { lead: 'Chat: ', text: 'Socket.IO namespace /chat, mỗi lớp là một room' },
      { lead: 'Lưu trữ: ', text: 'tin nhắn vào MongoDB → xem lịch sử + không mất' },
      { lead: 'Thông báo: ', text: 'badge số chưa đọc qua res.locals middleware' },
    ], 1800),
    'discussion', cm(11.5), cm(3.8)));

  // ===== 12. Gradebook & Chứng chỉ =====
  SLIDES.push(contentRight(
    'SỔ ĐIỂM (GRADEBOOK) & HOÀN THÀNH', 'Tính toán trực tiếp khi đọc — real-time',
    makeBullets([
      { lead: 'Nguồn: ', text: 'StudentProgress — sổ theo dõi tiến độ tập trung' },
      { lead: '5 bước: ', text: 'lọc điểm → quy % → trung bình theo loại → trọng số → xếp loại' },
      { lead: 'Trọng số: ', text: 'gradeWeights chuẩn hóa về 1; fallback trung bình cộng' },
      { lead: 'Hoàn thành: ', text: 'completionRules: 100% bài + điểm sàn + bài bắt buộc' },
      { lead: 'Xuất CSV: ', text: 'json2csv, Content-Disposition attachment filename' },
    ], 1750),
    'submission', cm(11.5), cm(3.6),
    'Certificate model + UI đã sẵn sàng (Phase D) cho tự cấp chứng chỉ'));

  // ===== 13. Admin Dashboard =====
  SLIDES.push(contentRight(
    'ADMIN DASHBOARD', 'Thống kê & quản trị hệ thống',
    makeBullets([
      { lead: 'Thẻ chỉ số: ', text: 'người dùng, giáo viên, học sinh, lớp học (Promise.all)' },
      { lead: 'Line chart: ', text: 'tăng trưởng người dùng 30 ngày, Aggregation Pipeline' },
      { lead: 'Donut: ', text: 'phân bổ vai trò — tái sử dụng biến đã đếm' },
      { lead: 'Render: ', text: 'chartData truyền thẳng vào Pug → Chart.js nội tuyến' },
      { lead: 'Audit Log: ', text: 'ghi mọi hành động Admin + IP, lọc theo thời gian' },
    ], 1750),
    'dashboard', cm(11.5), cm(3.6),
    'No-AJAX render: biểu đồ hiển thị ngay cùng HTML'));

  // ===== 14. Bảo mật & Kiểm thử =====
  SLIDES.push(contentRight(
    'BẢO MẬT & KIỂM THỬ', 'Chuẩn production + Jest unit test',
    makeBullets([
      { lead: 'Helmet: ', text: 'HTTP security headers, CSP tùy chỉnh theo CDN' },
      { lead: 'Rate-limit: ', text: 'auth 10/15p, route thường 100/15p — chống brute force' },
      { lead: 'bcrypt: ', text: 'hash mật khẩu 12 rounds' },
      { lead: 'Test: ', text: 'gradebook, completion, examIntegrity — kw + edge case' },
      { lead: 'Ví dụ test: ', text: '3 ms/2 bài thi +attendance 80% → final 80' },
    ], 1800),
    'exam', cm(11.7), cm(3.8)));

  // ===== 15. KẾT QUẢ ĐẠT ĐƯỢC =====
  SLIDES.push({ layout: LAY2, pics: [],
    children: titleShape('KẾT QUẢ ĐẠT ĐƯỢC', 'Tổng kết 10 tuần thực tập') + accent()
      + kpiStrip([{ val: '10', label: 'tuần phát triển' }, { val: '6+', label: 'module nghiệp vụ' }, { val: '3', label: 'Jest test suites' }])
      + bodyShape(makeBullets([
        { lead: 'Phân quyền RBAC: ', text: '3 vai trò riêng biệt, luồng duyệt học sinh khoa học' },
        { lead: 'Real-time: ', text: 'Socket.IO giám sát thi + chat, ghi nhận từ server' },
        { lead: 'Anti-cheat: ', text: 'bắt gian lận qua WebSocket, không tin client' },
        { lead: 'Prerequisite Gate: ', text: 'ép học tuần tự, chuẩn hóa lộ trình đào tạo' },
        { lead: 'Gradebook: ', text: 'sổ điểm động tính theo thời gian thực' },
      ], 1750), cm(1.0), cm(7.2), cm(22.6), cm(9.0)) });

  // ===== 16. TỰ ĐÁNH GIÁ — Kiến thức & Kỹ năng =====
  SLIDES.push(contentRight(
    'TỰ ĐÁNH GIÁ — Kiến thức & Kỹ năng', 'Lý thuyết đối chiếu thực tiễn',
    makeBullets([
      { lead: 'Web: ', text: 'HTTP/REST hơn CRUD — tích hợp HTTP+WebSocket+DB' },
      { lead: 'CSDL: ', text: 'embedding vs reference, index, Aggregation Pipeline' },
      { lead: 'CNPM: ', text: 'vòng đời, unit test, review, thiết kế schema trước code' },
      { lead: 'Mới học: ', text: 'JWT/OAuth, Socket.IO, Cloudinary, Service Layer' },
      { lead: 'Kỹ năng: ', text: 'đọc code theo luồng, debug có hệ thống, Git, đọc docs' },
    ], 1750),
    'ui_login', cm(11.6), cm(3.8),
    'Kỹ năng ước lượng thời gian — còn cần cải thiện (debug + edge case)'));

  // ===== 17. TỰ ĐÁNH GIÁ — Đáp ứng & Hạn chế =====
  SLIDES.push({ layout: LAY2, pics: [],
    children: titleShape('TỰ ĐÁNH GIÁ — ĐÁP ỨNG & HẠN CHẾ', 'Khả năng đáp ứng công việc') + accent()
      + bodyShape(makeBullets([
        { lead: 'Đáp ứng: ', text: 'hoàn thành đúng hạn, chức năng đúng yêu cầu, không bug nghiêm trọng', color: NAVY },
        { lead: 'Chậm hơn KS: ', text: 'đặc biệt giai đoạn research và xử lý edge case' },
        { lead: 'Tư duy bảo mật: ', text: 'chưa tự nhận ra lỗ hổng (vd. WebSocket /exam-monitor)' },
        { lead: 'Testing: ', text: 'chưa TDD — test viết sau, ít edge case' },
        { lead: 'Performance: ', text: 'chưa chủ động query optimization + pagination' },
      ], 1800), cm(1.0), cm(3.0), cm(22.6), cm(13.6)) });

  // ===== 18. HƯỚNG PHÁT TRIỂN LÊN ĐỒ ÁN TỐT NGHIỆP =====
  SLIDES.push({ layout: LAY2, pics: [],
    children: titleShape('HƯỚNG PHÁT TRIỂN', 'Từ đề tài thực tập → Đồ án tốt nghiệp') + accent()
      + kpiStrip([{ val: 'ML', label: 'phát hiện gian lận' }, { val: 'RecSys', label: 'gợi ý khóa học' }, { val: 'Micro', label: 'services' }])
      + bodyShape(makeBullets([
        { lead: 'Hướng 1: ', text: 'ML phân loại hành vi gian lận từ chuỗi sự kiện có timestamp', color: NAVY },
        { lead: 'Hướng 2: ', text: 'Hệ thống gợi ý khóa học (Collaborative/Content-based)' },
        { lead: 'Hướng 3: ', text: 'Microservices: Auth/Classroom/Exam/Notification riêng biệt' },
        { lead: 'Định hướng: ', text: 'chọn ML phát hiện gian lận thi cử làm Đồ án tốt nghiệp', color: NAVY, b: true },
      ], 1750), cm(1.0), cm(7.2), cm(22.6), cm(9.0)) });

  // ===== 19. KẾT LUẬN =====
  SLIDES.push({ layout: LAY2, pics: [],
    children: titleShape('KẾT LUẬN', 'Tổng kết đồ án & hình thành nghề nghiệp') + accent()
      + bodyShape(makeBullets([
        { lead: 'Sản phẩm: ', text: 'LMS chuẩn doanh nghiệp — RBAC, Anti-cheat, Gradebook, Gate tuần tự' },
        { lead: 'Công nghệ: ', text: 'thành thạo JavaScript/Node.js: Mongoose, Service Layer, JWT Rotation' },
        { lead: 'Bảo mật: ', text: 'HttpOnly Cookies, CSRF, XSS-clean, rate-limit, Helmet' },
        { lead: 'QA: ', text: 'Unit test Jest cho các module tính toán phức tạp' },
        { lead: 'Phát triển: ', text: 'Product thinking, quy trình doanh nghiệp, Git/GitHub' },
      ], 1850), cm(1.0), cm(3.0), cm(22.6), cm(13.6)) });

  // ===== 20. LỜI CẢM ƠN =====
  {
    const sub = [
      { text: 'Ths. Nguyễn Thị Thanh — Giảng viên hướng dẫn', b: true, color: NAVY },
      { text: 'Anh Uông Đức Tùng — Người hướng dẫn tại doanh nghiệp', b: true, color: NAVY },
      { text: 'Các kỹ sư nhóm sản phẩm E-Learning — Công ty SSG Vietnam' },
      { text: 'Gia đình và bạn bè đã luôn đồng hành trong suốt 10 tuần', color: GRAY },
    ];
    const body = sub.map(s => para({ text: '•  ' + s.text, sz: 2000, head: '', color: s.color || GRAY, bu: 'none', marL: cm(0.2), indent: 0, color2: s.color })).join('');
    SLIDES.push({ layout: LAY7, pics: [], children: titleShape('LỜI CẢM ƠN', '') + accent() + bodyShape(body, cm(2.0), cm(5.2), cm(20.6), cm(9.4)) });
  }

  // ===== 21. THANK YOU / Q&A =====
  {
    const c = titleShape('') + accent() +
      `<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Thanks"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="ctrTitle" idx="4294967295"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${cm(2.0)}" y="${cm(5.5)}"/><a:ext cx="${cm(20.0)}" cy="${cm(5.0)}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="ctr"/><a:lstStyle/><a:p><a:pPr algn="ctr"><a:lnSpc><a:spcPct val="110000"/></a:lnSpc></a:pPr><a:r><a:rPr lang="vi-VN" sz="7200" b="1" dirty="0"><a:solidFill><a:srgbClr val="${NAVY}"/></a:solidFill><a:latin typeface="Cambria"/></a:rPr><a:t>THANK YOU!</a:t></a:r></a:p><a:p><a:pPr algn="ctr"><a:spcBef><a:spcPts val="400"/></a:spcBef></a:pPr><a:r><a:rPr lang="vi-VN" sz="2800" b="1" dirty="0"><a:solidFill><a:srgbClr val="${RED}"/></a:solidFill><a:latin typeface="Cambria"/></a:rPr><a:t>${G.esc('Q & A')}</a:t></a:r></a:p><a:p><a:pPr algn="ctr"><a:spcBef><a:spcPts val="600"/></a:spcBef></a:pPr><a:r><a:rPr lang="vi-VN" sz="1800" i="1" dirty="0"><a:solidFill><a:srgbClr val="${GRAY}"/></a:solidFill><a:latin typeface="Cambria"/></a:rPr><a:t>Kính chúc quý thầy cô cùng hội đồng sức khỏe</a:t></a:r></a:p></p:txBody></p:sp>`;
    SLIDES.push({ layout: LAY7, pics: [], children: c });
  }

  console.log('Total slides defined:', SLIDES.length);

  // ============ ASSEMBLE ============
  // assign rIds per slide, write slideN.xml + slideN.xml.rels
  let ridCounter = 1;
  const contentTypesOverrides = [];
  for (let i = 0; i < SLIDES.length; i++) {
    const s = SLIDES[i];
    const n = i + 1;
    // assign rIds
    const rids = [];
    s.pics.forEach((p, idx) => { p.rid = 'rId' + (idx + 2); rids.push({ rid: p.rid, mediaPath: mediaName[p.pick] }); });
    // inject rIds into children (replace __R0__ etc.)
    let childrenXml = s.children;
    s.pics.forEach((p, idx) => { childrenXml = childrenXml.replace('__R' + idx + '__', p.rid); });
    const xml = frame(childrenXml, s.layout);
    zip.file(`ppt/slides/slide${n}.xml`, xml);
    // rels
    let rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/${s.layout}.xml"/>`;
    rids.forEach(rr => { rels += `<Relationship Id="${rr.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${rr.mediaPath.split('/').pop()}"/>`; });
    rels += `</Relationships>`;
    zip.file(`ppt/slides/_rels/slide${n}.xml.rels`, rels);
    contentTypesOverrides.push(`<Override PartName="/ppt/slides/slide${n}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`);
  }

  // fix the stray 'color2' param in para call (no-op) — handled in gen.

  // ---- [Content_Types].xml: replace old slide overrides + Default png/jpg ----
  const ct = await zip.file('[Content_Types].xml').async('string');
  let ct2 = ct.replace(/<Override PartName="\/ppt\/slides\/slide[0-9]+\.xml" ContentType="application\/vnd\.openxmlformats-officedocument\.presentationml\.slide\+xml"\/>/g, '');
  // ensure Defaults for png, jpeg
  if (!/Default Extension="png"/.test(ct2)) ct2 = ct2.replace('<Types ', '<Types ') + ''; // default already present; skip
  // ensure jpeg default
  if (!/Default Extension="jpeg"/.test(ct2)) {
    ct2 = ct2.replace(/(<Default [^>]*\/>)/, (m) => m + '<Default Extension="jpeg" ContentType="image/jpeg"/>');
  }
  ct2 = ct2.replace('</Types>', contentTypesOverrides.join('') + '</Types>');
  zip.file('[Content_Types].xml', ct2);

  // ---- presentation.xml: rebuild sldIdLst ----
  const pres = await zip.file('ppt/presentation.xml').async('string');
  // extract existing sldIdLst element replacement: build new sldId entries (ids can reuse 256..)
  const newSldIds = SLIDES.map((_, i) => `<p:sldId id="${256 + i * 3}" r:id="rId${1000 - i}"/>`).join('');
  const pres2 = pres.replace(/<p:sldIdLst>[\s\S]*?<\/p:sldIdLst>/, `<p:sldIdLst>${newSldIds}</p:sldIdLst>`);
  zip.file('ppt/presentation.xml', pres2);

  // ---- presentation.xml.rels: replace slide relationships ----
  const presRels = await zip.file('ppt/_rels/presentation.xml.rels').async('string');
  // remove old slide relationships (Target slides/slideN.xml) and notesSlide? keep notesMaster
  let pr2 = presRels.replace(/<Relationship Id="rId[0-9]+" Type="[^"]*\/relationships\/slide" Target="slides\/slide[0-9]+\.xml"\/>/g, '');
  // remove commentAuthors/changesInfo refs may remain (harmless). Add our slide rIds matching sldIdLst
  let addRels = '';
  SLIDES.forEach((_, i) => { addRels += `<Relationship Id="rId${1000 - i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i + 1}.xml"/>`; });
  pr2 = pr2.replace('</Relationships>', addRels + '</Relationships>');
  zip.file('ppt/_rels/presentation.xml.rels', pr2);

  // ---- docProps/app.xml: slide count ----
  let app = await zip.file('docProps/app.xml').async('string');
  app = app.replace(/<Slides>[0-9]+<\/Slides>/, `<Slides>${SLIDES.length}</Slides>`);
  zip.file('docProps/app.xml', app);

  // ---- write ----
  const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
  fs.writeFileSync(OUT, buf);
  console.log('WROTE', OUT, (buf.length / 1024).toFixed(0), 'KB  slides=', SLIDES.length);
}

main().catch(e => { console.error(e); process.exit(1); });
