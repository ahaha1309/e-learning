// Validate the produced pptx: re-open, parse each slide XML for obvious issues.
const G = require('./gen');
const { JSZip, fs, OUT } = G;
const parRegex = (xml) => (xml.match(/<a:p>/g) || []).length, brClose = (xml) => (xml.match(/<\/a:p>/g) || []).length;
async function main() {
  const zip = await JSZip.loadAsync(fs.readFileSync(OUT));
  const files = Object.keys(zip.files).filter(f => /^ppt\/slides\/slide\d+\.xml$/.test(f));
  files.sort((a, b) => +a.match(/\d+/)[0] - +b.match(/\d+/)[0]);
  let issues = 0;
  for (const f of files) {
    const xml = await zip.file(f).async('string');
    // basic balance checks
    const openP = (xml.match(/<a:p[ >]/g) || []).length;
    const closeP = (xml.match(/<\/a:p>/g) || []).length;
    const openSp = (xml.match(/<p:sp[ >]/g) || []).length;
    const closeSp = (xml.match(/<\/p:sp>/g) || []).length;
    const openPic = (xml.match(/<p:pic>/g) || []).length;
    const closePic = (xml.match(/<\/p:pic>/g) || []).length;
    const openTx = (xml.match(/<p:txBody>/g) || []).length;
    const closeTx = (xml.match(/<\/p:txBody>/g) || []).length;
    const tag = f.split('/').pop();
    const bad = [];
    const expectedTx = openSp + openPic + (xml.match(/<p:cxnSp[ >]/g) || []).length + (xml.match(/<p:grpSp[ >]/g) || []).length;
    if (openP !== closeP) bad.push(`a:p ${openP}/${closeP}`);
    if (openSp !== closeSp) bad.push(`p:sp ${openSp}/${closeSp}`);
    if (openPic !== closePic) bad.push(`p:pic ${openPic}/${closePic}`);
    if (openTx !== closeTx) bad.push(` txBody ${openTx}/${closeTx}`);
    if (openTx !== openSp) bad.push(`txBody-should=${openSp} has=${openTx}`);
    console.log(tag.padEnd(12), bad.length ? 'ISSUES: ' + bad.join(', ') : 'ok', `len=${xml.length}`);
    if (bad.length) issues++;
  }
  // also verify media present + rels present
  const media = Object.keys(zip.files).filter(f => f.startsWith('ppt/media/rpt'));
  console.log('media files:', media.length, media);
  // verify presentation.xml sldIdLst count
  const pres = await zip.file('ppt/presentation.xml').async('string');
  const sldIds = (pres.match(/<p:sldId /g) || []).length;
  console.log('sldIdLst entries:', sldIds);
  const presRels = await zip.file('ppt/_rels/presentation.xml.rels').async('string');
  const slideRels = (presRels.match(/relationships\/slide"/g) || []).length;
  console.log('presentation slide rels:', slideRels);
  console.log('TOTAL ISSUED SLIDES:', issues);
}
main().catch(e => { console.error(e); process.exit(1); });
