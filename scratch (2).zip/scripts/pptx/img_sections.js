// For each image, find the nearest preceding Heading (the section where it appears).
const { JSZip, fs } = require('./gen');
(async () => {
  const z = await JSZip.loadAsync(fs.readFileSync('C:/Users/vanha/OneDrive/Desktop/e-learning/báo cáo.docx'));
  const xml = await z.file('word/document.xml').async('string');
  const rels = await z.file('word/_rels/document.xml.rels').async('string');
  const relMap = {}; [...rels.matchAll(/Id="([^"]*)"[^>]*Target="([^"]*)"/g)].forEach(m => relMap[m[1]] = m[2]);
  const dec = (s) => s.replace(/&/g, '&').replace(/</g, '<').replace(/>/g, '>').replace(/"/g, '"');

  const paras = xml.split('</w:p>');
  let lastHeading = '(start)';
  const out = [];
  for (let i = 0; i < paras.length; i++) {
    const p = paras[i];
    const styleM = p.match(/<w:pStyle w:val="([^"]*)"/);
    const style = styleM ? styleM[1] : '';
    const txt = [...p.matchAll(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)].map(m => dec(m[1])).join('');
    if (/Heading/i.test(style) && txt.trim()) lastHeading = txt.trim();
    const embeds = [...p.matchAll(/r:embed="([^"]*)"/g)].map(m => relMap[m[1]] || '?');
    if (embeds.length) out.push({ img: embeds, section: lastHeading });
  }
  out.forEach((o, i) => console.log(`#${i + 1} ${JSON.stringify(o.img).padEnd(28)} SECTION: ${o.section}`));
})();
