const JSZip = require('jszip');
const fs = require('fs');

// Extract a readable view of each slide: text runs + shape geometry + image refs + footer.
async function main() {
  const data = fs.readFileSync('C:/Users/vanha/OneDrive/Desktop/e-learning/Mau trinh bay Slide TTDN.pptx');
  const zip = await JSZip.loadAsync(data);

  function parseShape(sp, relsMap) {
    const out = { name: '', type: '', text: [], off: null, ext: null, imgRId: null, geom: null };
    const nv = sp['p:nvSpPr'] || sp['p:nvPicPr'] || sp['p:nvGrpSpPr'] || sp['p:nvCxnSpPr'];
    if (nv) {
      const cNvPr = nv['p:cNvPr'];
      if (cNvPr) out.name = cNvPr['@_name'] || '';
    }
    if (sp['p:nvPicPr']) out.type = 'pic';
    if (sp['p:nvSpPr']) out.type = 'sp';
    const spPr = sp['p:spPr'] || sp['p:picSpPr'] || (sp['p:nvPicPr'] && sp['p:spPr']);
    if (spPr) {
      const xfrm = spPr['a:xfrm'];
      if (xfrm) {
        out.off = { x: xfrm['a:off'] && xfrm['a:off']['@_x'], y: xfrm['a:off'] && xfrm['a:off']['@_y'] };
        out.ext = { cx: xfrm['a:ext'] && xfrm['a:ext']['@_cx'], cy: xfrm['a:ext'] && xfrm['a:ext']['@_cy'] };
      }
      const fill = spPr['a:solidFill'];
      if (fill && fill['a:srgbClr']) out.fill = fill['a:srgbClr']['@_val'];
      const geom = spPr['a:prstGeom'];
      if (geom) out.geom = geom['@_prst'];
    }
    if (out.type === 'pic') {
      const blipFill = sp['p:blipFill'] || (spPr && spPr['a:blipFill']);
      const blip = sp['p:blipFill'] && sp['p:blipFill']['a:blip'];
      if (blip) out.imgRId = blip['@_r:embed'];
    }
    // text
    const txBody = sp['p:txBody'];
    if (txBody && txBody['a:p']) {
      const paras = Array.isArray(txBody['a:p']) ? txBody['a:p'] : [txBody['a:p']];
      for (const p of paras) {
        let line = '';
        const rs = p['a:r'];
        if (rs) {
          const runs = Array.isArray(rs) ? rs : [rs];
          for (const r of runs) {
            const t = r['a:t'];
            if (t) {
              const rPr = r['a:rPr'];
              let sz = rPr && rPr['@_sz'];
              let col = null;
              if (rPr && rPr['a:solidFill'] && rPr['a:solidFill']['a:srgbClr']) col = rPr['a:solidFill']['a:srgbClr']['@_val'];
              line += (col?('['+col+'/'+(sz||'')+'] '):'') + t;
            }
          }
        }
        out.text.push(line);
      }
    }
    return out;
  }

  // We need a proper XML parser. Use fast-xml-parser if available, else fallback.
  let parser;
  try { parser = require('fast-xml-parser'); } catch(e) { parser = null; }

  for (let i = 1; i <= 5; i++) {
    const xml = await zip.file(`ppt/slides/slide${i}.xml`).async('string');
    console.log('\n=========== SLIDE', i, '(raw length', xml.length, ') ===========');
    // Just print compact: lines with text + shape positions
    // Extract <a:t>...</a:t> and nearby <p:sp> blocks naively
    const texts = [...xml.matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)].map(m => m[1]);
    console.log('TEXT RUNS:', JSON.stringify(texts));
    // shape offsets
    const offs = [...xml.matchAll(/<p:nvSpPr>[\s\S]*?<p:cNvPr[^>]*name="([^"]*)"[^>]*>[\s\S]*?<\/p:spPr>[\s\S]*?<a:off x="([^"]*)" y="([^"]*)"[^>]*>[^<]*<a:ext cx="([^"]*)" cy="([^"]*)"/g)];
    // simpler raw extraction
  }
}
main().catch(e => { console.error(e); process.exit(1); });
