// Single-file generator: build 21-slide deck by extending the sample PPTX.
// School logo + footer inherit from the (unchanged) slide master via slideLayouts.
const JSZip = require('jszip');
const fs = require('fs');
const path = require('path');

const ROOT = 'C:/Users/vanha/OneDrive/Desktop/e-learning';
const SAMPLE = ROOT + '/Mau trinh bay Slide TTDN.pptx';
const IMG = ROOT + '/scripts/pptx/tmp/img';
const OUT = ROOT + '/Slide_Thuc_Tap_Do_An.pptx';

const NAVY = '002060', RED = 'C00000', GRAY = '595959', GRAYLT = '808080', WHITE = 'FFFFFF', BG = 'F2F5FB';
const AMP = String.fromCharCode(38); // &
const cm = (c) => Math.round(c * 360000);
const esc = (s) => String(s).split(AMP).join(AMP + 'amp;').replace(/</g, AMP+'lt;').replace(/>/g, AMP+'gt;').replace(/"/g, AMP+'quot;');
let ID = 2000; const nid = () => ++ID; const rid = (i) => 'rId' + i;

// ---- geometry helpers ----
function imgPx(name) {
  const buf = fs.readFileSync(path.join(IMG, name));
  if (buf[0] === 0x89 && buf[1] === 0x50) return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
  let i = 2; while (i < buf.length) {
    if (buf[i] !== 0xFF) { i++; continue; }
    const m = buf[i + 1]; const len = buf.readUInt16BE(i + 2);
    if (m === 0xC0 || m === 0xC2) return { w: buf.readUInt16BE(i + 7), h: buf.readUInt16BE(i + 5) };
    i += 2 + len;
  }
  return { w: 1000, h: 700 };
}
function fitH(name, cx) { const { w, h } = imgPx(name); return Math.round(cx * h / w); }

// a run of text
function run(text, { sz = 2000, b = false, color = GRAY, i = false, font = 'Cambria' } = {}) {
  return `<a:r><a:rPr lang="vi-VN" sz="${sz}"${b ? ' b="1"' : ''}${i ? ' i="1"' : ''} dirty="0"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="${font}"/><a:cs typeface="Times New Roman"/></a:rPr><a:t>${esc(text)}</a:t></a:r>`;
}
// a bullet paragraph; o: {text, lvl, bold, color, bu(none|char X), algn, sz, head(bold lead)}
function para(o = {}) {
  const lvl = o.lvl || 0;
  const sz = o.sz || (lvl === 0 ? 2000 : 1800);
  const col = o.color || GRAY;
  const marL = o.marL != null ? o.marL : (lvl === 0 ? cm(0.5) : cm(1.2));
  const indent = o.indent != null ? o.indent : (lvl === 0 ? -cm(0.5) : -cm(0.45));
  let bu = o.bu === 'none' ? '<a:buFont typeface="Arial"/><a:buNone/>' :
           (o.bu ? `<a:buFont typeface="Arial"/><a:buChar char="${o.bu}"/>` :
           `<a:buFont typeface="Arial"/><a:buChar char="${lvl === 0 ? '\u2022' : '\u2013'}"/>`);
  let runsXml;
  if (o.head) {
    runsXml = run(o.head, { sz, b: true, color: NAVY }) + run(o.text || '', { sz, color: col });
  } else {
    runsXml = run(o.text, { sz, b: !!o.bold, color: col, i: !!o.i });
  }
  const spc = o.tight ? '<a:spcAft><a:spcPts val="300"/></a:spcAft>' : '<a:spcAft><a:spcPts val="500"/></a:spcAft>';
  return `<a:p><a:pPr marL="${marL}" indent="${indent}" algn="${o.algn || 'l'}"><a:lnSpc><a:spcPct val="108000"/></a:lnSpc>${spc}${bu}</a:pPr>${runsXml}</a:p>`;
}

// title shape (content slides)
function titleShape(title, sub) {
  const subPar = sub ? `<a:p><a:pPr algn="l"><a:buFont typeface="Arial"/><a:buNone/></a:pPr><a:r><a:rPr lang="vi-VN" sz="1400" i="1" dirty="0"><a:solidFill><a:srgbClr val="${GRAYLT}"/></a:solidFill><a:latin typeface="Cambria"/></a:rPr><a:t>${esc(sub)}</a:t></a:r></a:p>` : '';
  return `<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${cm(0.8)}" y="${cm(0.45)}"/><a:ext cx="${cm(22.6)}" cy="${sub ? cm(1.9) : cm(1.5)}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr wrap="square" anchor="ctr" lIns="0" tIns="0" rIns="57150" bIns="0"/><a:lstStyle/><a:p><a:pPr algn="l"/><a:r><a:rPr lang="vi-VN" sz="3000" b="1" dirty="0"><a:solidFill><a:srgbClr val="${NAVY}"/></a:solidFill><a:latin typeface="Cambria"/><a:cs typeface="Times New Roman"/></a:rPr><a:t>${esc(title)}</a:t></a:r></a:p>${subPar}</p:txBody></p:sp>`;
}
// accent line under title
function accent() {
  return `<p:cxnSp><p:nvCxnSpPr><p:cNvPr id="${nid()}" name="AccentLine"/><p:cNvCxnSpPr><a:cxnSpLocks/></p:cNvCxnSpPr><p:nvPr/></p:nvCxnSpPr><p:spPr><a:xfrm><a:off x="${cm(0.8)}" y="${cm(2.15)}"/><a:ext cx="${cm(22.6)}" cy="0"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:ln w="22225"><a:solidFill><a:srgbClr val="${NAVY}"/></a:solidFill></a:ln></p:spPr><p:style><a:lnRef idx="1"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="0"><a:schemeClr val="accent1"/></a:effectRef></p:style></p:cxnSp>`;
}
// body box
function bodyShape(parasXml, x, y, w, h) {
  return `<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Content"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr wrap="square" anchor="t" lIns="0" tIns="0" rIns="0" bIns="0"><a:normAutofit/></a:bodyPr><a:lstStyle/>${parasXml}</p:txBody></p:sp>`;
}
// a picture (screenshot) with subtle border
function pic(ridV, x, y, cx, cy) {
  return `<p:pic><p:nvPicPr><p:cNvPr id="${nid()}" name="Picture"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="${ridV}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:ln w="9525"><a:solidFill><a:srgbClr val="BFBFBF"/></a:solidFill></a:ln></p:spPr></p:pic>`;
}
// filled rounded box (KPI / callout)
function box(x, y, w, h, fill, line) {
  return `<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Box"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/></a:xfrm><a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 8000"/></a:avLst></a:prstGeom><a:solidFill><a:srgbClr val="${fill}"/></a:solidFill>${line ? `<a:ln w="12700"><a:solidFill><a:srgbClr val="${line}"/></a:solidFill></a:ln>` : '<a:ln><a:noFill/></a:ln>'}</p:spPr><p:txBody><a:bodyPr/></p:txBody></p:sp>`;
}

// ---- slide frame ----
function frame(children, layout) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree>
<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>
${children}
</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`;
}

// ---- cover slide (layout1, mirrors sample colors/navy+red) ----
function coverXml({ titleRed, titleNavy, lines }) {
  // two centered paragraphs: red lead-in + navy body (or single navy if no navy)
  const T = titleNavy
    ? `<a:p><a:pPr algn="ctr"><a:lnSpc><a:spcPct val="115000"/></a:lnSpc></a:pPr>${run(titleRed, { sz: 3400, b: true, color: RED })}</a:p><a:p><a:pPr algn="ctr"><a:lnSpc><a:spcPct val="115000"/></a:lnSpc></a:pPr>${run(titleNavy, { sz: 3400, b: true, color: NAVY })}</a:p>`
    : `<a:p><a:pPr algn="ctr"><a:lnSpc><a:spcPct val="115000"/></a:lnSpc></a:pPr>${run(titleRed, { sz: 3400, b: true, color: NAVY })}</a:p>`;
  const sub = lines.map((ln) => {
    const sz = ln.sz || 1900, col = ln.color || GRAY, b = !!ln.b;
    return `<a:p><a:pPr algn="ctr"><a:lnSpc><a:spcPct val="140000"/></a:lnSpc><a:spcBef><a:spcPts val="200"/></a:spcBef></a:pPr>${run(ln.text, { sz, b, color: col })}</a:p>`;
  }).join('');
  const c = `<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="TopBar"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cm(33.87)}" cy="${cm(0.5)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="${NAVY}"/></a:solidFill></p:spPr><p:txBody/></p:sp>
<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="BotBar"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="0" y="${cm(18.55)}"/><a:ext cx="${cm(33.87)}" cy="${cm(0.5)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="${NAVY}"/></a:solidFill></p:spPr><p:txBody/></p:sp>
<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="School"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="0" y="${cm(1.0)}"/><a:ext cx="${cm(33.87)}" cy="${cm(2.2)}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="ctr"/><a:lstStyle/><a:p><a:pPr algn="ctr"/><a:r><a:rPr lang="vi-VN" sz="2400" b="1"><a:solidFill><a:srgbClr val="${NAVY}"/></a:solidFill><a:latin typeface="Cambria"/><a:cs typeface="Times New Roman"/></a:rPr><a:t>TRƯỜNG ĐẠI HỌC MỎ - ĐỊA CHẤT</a:t></a:r></a:p><a:p><a:pPr algn="ctr"><a:spcBef><a:spcPts val="60"/></a:spcBef></a:pPr><a:r><a:rPr lang="vi-VN" sz="1500"><a:solidFill><a:srgbClr val="${GRAY}"/></a:solidFill><a:latin typeface="Cambria"/></a:rPr><a:t>BÁO CÁO THỰC TẬP DOANH NGHIỆP</a:t></a:r></a:p></p:txBody></p:sp>
<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="ctrTitle" idx="4294967295"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${cm(3.3)}" y="${cm(4.7)}"/><a:ext cx="${cm(27.2)}" cy="${cm(7.4)}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="ctr" lIns="0" tIns="0" rIns="0" bIns="0"/><a:lstStyle/>${T}</p:txBody></p:sp>
<p:sp><p:nvSpPr><p:cNvPr id="${nid()}" name="Sub"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="subTitle" idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${cm(5.0)}" y="${cm(12.6)}"/><a:ext cx="${cm(23.8)}" cy="${cm(5.3)}"/></a:xfrm></p:spPr><p:txBody><a:bodyPr anchor="ctr" lIns="0" tIns="0" rIns="0" bIns="0"/><a:lstStyle/>${sub}</p:txBody></p:sp>`;
  return c;
}
// ---- agenda row (number + text) ----
function agendaRow(n, text) {
  return `<a:p><a:pPr marL="${cm(0.2)}" indent="0" algn="l"><a:lnSpc><a:spcPct val="140000"/></a:lnSpc><a:spcAft><a:spcPts val="800"/></a:spcAft><a:buFont typeface="Arial"/><a:buNone/></a:pPr>${run(n + '.', { sz: 2200, b: true, color: NAVY })}${run('   ' + text, { sz: 2200, color: GRAY })}</a:p>`;
}

module.exports = { JSZip, fs, path, ROOT, SAMPLE, IMG, OUT, NAVY, RED, GRAY, GRAYLT, WHITE, BG, cm, esc, nid, rid, imgPx, fitH, run, para, titleShape, accent, bodyShape, pic, box, frame, coverXml, agendaRow };
