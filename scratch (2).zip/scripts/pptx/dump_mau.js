const JSZip = require('jszip');
const fs = require('fs');

async function main() {
  const data = fs.readFileSync('C:/Users/vanha/OneDrive/Desktop/e-learning/Mau trinh bay Slide TTDN.pptx');
  const zip = await JSZip.loadAsync(data);
  const targets = [
    'ppt/slides/slide1.xml','ppt/slides/slide2.xml','ppt/slides/slide3.xml',
    'ppt/slides/slide4.xml','ppt/slides/slide5.xml',
    'ppt/slides/_rels/slide1.xml.rels','ppt/slides/_rels/slide2.xml.rels',
    'ppt/slides/_rels/slide3.xml.rels','ppt/slides/_rels/slide4.xml.rels',
    'ppt/slides/_rels/slide5.xml.rels',
    'ppt/slideMasters/slideMaster1.xml','ppt/slideMasters/_rels/slideMaster1.xml.rels',
    'ppt/presentation.xml','ppt/_rels/presentation.xml.rels',
    'ppt/theme/theme1.xml',
    'docProps/app.xml','docProps/core.xml',
  ];
  for (const t of targets) {
    const f = zip.file(t);
    if (!f) { console.log('\n########## MISSING:', t); continue; }
    const txt = await f.async('string');
    console.log('\n##########', t, '(', txt.length, 'chars ) ##########\n');
    console.log(txt);
  }
  // media: print sizes
  const media = zip.file('ppt/media/image1.png');
  if (media) {
    const buf = await media.async('nodebuffer');
    console.log('\n########## media/image1.png size:', buf.length, 'bytes ##########');
  }
}
main().catch(e => { console.error(e); process.exit(1); });
