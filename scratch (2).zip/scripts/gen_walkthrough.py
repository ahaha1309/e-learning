"""
Generates 08_Code_Walkthrough.docx
Reads SOURCE CODE and renders full business-flow walkthroughs.
"""
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT_PATH = r"C:\Users\vanha\Downloads\Documentations_DOCX\08_Code_Walkthrough.docx"

# ─── helpers ───────────────────────────────────────────────────────────────────
def new_doc():
    doc = Document()
    # Margins
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    return doc

def h(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    run = p.runs[0] if p.runs else p.add_run(text)
    run.font.name = 'Calibri'
    colors = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
              3: RGBColor(0x1F,0x68,0xAA), 4: RGBColor(0x33,0x80,0xCC)}
    run.font.color.rgb = colors.get(level, RGBColor(0,0,0))
    sizes  = {1: 16, 2: 14, 3: 12, 4: 11}
    run.font.size = Pt(sizes.get(level, 11))
    return p

def para(doc, text, bold=False, italic=False, color=None, size=11):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold   = bold
    r.italic = italic
    r.font.name = 'Calibri'
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = color
    return p

def code(doc, text):
    """Monospace code block."""
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.4)
    r = p.add_run(text)
    r.font.name = 'Courier New'
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor(0x1A, 0x6A, 0x1A)
    shading = OxmlElement('w:shd')
    shading.set(qn('w:val'), 'clear')
    shading.set(qn('w:color'), 'auto')
    shading.set(qn('w:fill'), 'F0F0F0')
    p._p.get_or_add_pPr().append(shading)
    return p

def bullet(doc, text, level=0):
    p = doc.add_paragraph(text, style='List Bullet')
    p.paragraph_format.left_indent = Inches(0.3 + level * 0.3)
    for r in p.runs:
        r.font.name = 'Calibri'
        r.font.size = Pt(10.5)
    return p

def flow_step(doc, arrow, file_ref, func_ref, desc):
    """One step in a flow chain."""
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.5)
    r1 = p.add_run(f"  {arrow}  ")
    r1.font.color.rgb = RGBColor(0x99,0x00,0x00)
    r1.font.size = Pt(11)
    r1.bold = True
    if file_ref:
        r2 = p.add_run(f"[{file_ref}]  ")
        r2.font.name = 'Courier New'
        r2.font.size = Pt(9.5)
        r2.font.color.rgb = RGBColor(0x00,0x55,0x99)
    if func_ref:
        r3 = p.add_run(f"{func_ref}()")
        r3.font.name = 'Courier New'
        r3.font.size = Pt(9.5)
        r3.bold = True
        r3.font.color.rgb = RGBColor(0x00,0x33,0x66)
    if desc:
        r4 = p.add_run(f"\n        → {desc}")
        r4.font.size = Pt(10)
        r4.font.name = 'Calibri'
    return p

def divider(doc):
    doc.add_paragraph("─" * 80)

def section_intro(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)
    r.italic = True
    r.font.color.rgb = RGBColor(0x55,0x55,0x55)

# ─── document ──────────────────────────────────────────────────────────────────
doc = new_doc()

# ── TITLE PAGE ────────────────────────────────────────────────────────────────
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run("08. CODE WALKTHROUGH\nE-Learning LMS – Node.js / Express / MongoDB")
r.font.name = 'Calibri'
r.font.size = Pt(22)
r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)

para(doc, "Tài liệu này đi bộ qua TỪNG BƯỚC thực thi của mọi business flow quan trọng trong hệ thống, bám sát source code thực tế. Mỗi bước đều ghi rõ File, Function và lý do tồn tại.", italic=True)
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 1 — ĐĂNG KÝ TÀI KHOẢN
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 1 — ĐĂNG KÝ TÀI KHOẢN MỚI (Register)", 1)
section_intro(doc, "User điền form đăng ký → hệ thống tạo account và tự động đăng nhập.")

h(doc, "1.1 Luồng thực thi", 2)
flow_step(doc, "①", None, None, "User mở trình duyệt, truy cập GET /auth/register")
flow_step(doc, "②", "middleware/rbac.js", None, "Hệ thống KHÔNG chặn vì route này PUBLIC (không có requireAuth)")
flow_step(doc, "③", "controller/auth/auth.controller.js", "renderRegister", "Kiểm tra SystemSetting {key:'allowRegistration'}. Nếu value===false → trả 403 Registration Closed. Ngược lại render view auth/register.pug với formData={}, errorMessage=null")
flow_step(doc, "④", None, None, "User điền Name/Email/Password rồi click Submit → POST /auth/register")
flow_step(doc, "⑤", "middleware/csrf.js", "csrfProtection", "Express middleware kiểm tra CSRF token trong body._csrf. Sai token → 403 CSRF error")
flow_step(doc, "⑥", "validate/auth.validate.js", None, "express-validator kiểm tra: name không rỗng, email hợp lệ, password >= 8 ký tự")
flow_step(doc, "⑦", "controller/auth/auth.controller.js", "register", "Gọi getValidationErrors(req). Nếu có lỗi → re-render form với errorMessage. Ngược lại gọi registerUser(req.body)")
flow_step(doc, "⑧", "controller/auth/auth.service.js", "registerUser", "Hash password bằng bcrypt. Tạo User document mới. Nếu email trùng → MongoDB duplicate key error (code 11000) → AppError 409")
flow_step(doc, "⑨", "controller/auth/auth.service.js", "buildAuthSession", "Ký JWT access token (15 phút) và refresh token (7 ngày) bằng jsonwebtoken. Lưu refreshToken vào User.refreshToken trong DB")
flow_step(doc, "⑩", "controller/auth/auth.controller.js", "setAuthCookies", "Set httpOnly cookie: accessToken (maxAge 15min), refreshToken (maxAge 7 ngày)")
flow_step(doc, "⑪", None, "req.session.regenerate", "Bảo vệ session fixation attack: tạo session ID mới, sau đó gọi req.logIn(user) để Passport serialize userId vào session")
flow_step(doc, "⑫", None, None, "Redirect → /student (role=student) hoặc /auth/pending-approval (role=teacher, status=pending)")

h(doc, "1.2 Database được ghi", 2)
bullet(doc, "Collection: users — tạo document mới với các fields: name, email, passwordHash, role, status, refreshToken, createdAt")
bullet(doc, "Collection: sessions — MongoStore tự động lưu session data")
bullet(doc, "Collection: auditlogs — (chỉ ghi ở login, không ghi ở register)")

h(doc, "1.3 Các trường hợp đặc biệt", 2)
bullet(doc, "Email trùng → MongoDB E11000 duplicate key → Controller bắt error.code===11000 → render form với lỗi 'Email already exists'")
bullet(doc, "Registration tắt → SystemSetting.value===false → HTTP 403")
bullet(doc, "Teacher đăng ký → status='pending', redirect /auth/pending-approval → Admin phải duyệt")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 2 — ĐĂNG NHẬP
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 2 — ĐĂNG NHẬP (Login)", 1)
section_intro(doc, "User nhập email/password → hệ thống xác thực, tạo session và cookies.")

h(doc, "2.1 Luồng thực thi", 2)
flow_step(doc, "①", None, None, "User POST /auth/login (qua loginRateLimit: tối đa 10 lần/15 phút, skipSuccessfulRequests=true)")
flow_step(doc, "②", "middleware/csrf.js", "csrfProtection", "Kiểm tra CSRF token")
flow_step(doc, "③", "controller/auth/auth.controller.js", "login", "Gọi getValidationErrors. Nếu lỗi → re-render form")
flow_step(doc, "④", "controller/auth/auth.service.js", "authenticateUser", "User.findOne({email}). Nếu không tìm thấy → AppError(401). Gọi bcrypt.compare(password, user.passwordHash). Sai → AppError(401). Tài khoản status!=='active' → AppError(403)")
flow_step(doc, "⑤", "controller/auth/auth.service.js", "buildAuthSession", "Ký JWT access token + refresh token. Lưu refreshToken vào user.refreshToken")
flow_step(doc, "⑥", "controller/auth/auth.controller.js", "setAuthCookies", "Set cookie accessToken (15min) + refreshToken (7 ngày)")
flow_step(doc, "⑦", None, None, "req.session.regenerate → req.logIn(user) → session.save")
flow_step(doc, "⑧", "models/AuditLog.js", None, "Tạo bản ghi AuditLog {action:'USER_LOGIN', user, ipAddress, userAgent} — async, không block response")
flow_step(doc, "⑨", None, None, "Admin → 403 (dùng /admin/login riêng). Teacher pending → /auth/pending-approval. Teacher active → /teacher. Student → /student")

h(doc, "2.2 Luồng Token Refresh (khi accessToken hết hạn)", 2)
section_intro(doc, "Frontend phát hiện accessToken hết hạn, tự động gọi POST /auth/refresh để lấy token mới.")
flow_step(doc, "①", None, None, "Frontend gọi POST /auth/refresh với cookie refreshToken")
flow_step(doc, "②", "controller/auth/auth.controller.js", "refresh", "Đọc req.cookies.refreshToken")
flow_step(doc, "③", "controller/auth/auth.service.js", "rotateRefreshToken", "Verify JWT refresh token. Tìm User có refreshToken khớp. Ký cặp token mới (Rotation pattern). Lưu refreshToken mới vào DB")
flow_step(doc, "④", None, None, "Trả 200 JSON {user} + set cookie mới. Frontend cập nhật state và retry request ban đầu")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 3 — TẠO LỚP HỌC (Teacher)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 3 — TẠO LỚP HỌC (Teacher Create Classroom)", 1)
section_intro(doc, "Giáo viên điền form tạo lớp → hệ thống tạo Classroom document và sinh mã code ngẫu nhiên.")

h(doc, "3.1 Luồng thực thi", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms")
flow_step(doc, "②", "middleware/rbac.js", "requireRole('teacher')", "Kiểm tra req.user.role === 'teacher'. Sai → 403")
flow_step(doc, "③", "validate/teacher/classroom.validate.js", None, "Kiểm tra name không rỗng, maxLength 200")
flow_step(doc, "④", "controller/teacher/classroom.controller.js", "createClassroomHandler", "Gọi formatValidationErrors. Nếu có lỗi → re-render form")
flow_step(doc, "⑤", "models/Classroom.js", None, "new Classroom({name, description, teacher:req.user.id, approvalRequired}). Schema có pre-save hook tự sinh code 6 ký tự ngẫu nhiên (ví dụ: 'XK9P2A')")
flow_step(doc, "⑥", None, "classroom.save()", "INSERT vào MongoDB collection 'classrooms'")
flow_step(doc, "⑦", None, None, "Redirect /teacher/classrooms/{id}?feedback=Đã tạo thành công")

h(doc, "3.2 Database được ghi", 2)
bullet(doc, "Collection: classrooms — {name, description, code, teacher, approvalRequired, isArchived:false, gradeWeights:[], gradingScale:[], completionRules:{}}")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 4 — HỌC SINH THAM GIA LỚP HỌC
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 4 — HỌC SINH THAM GIA LỚP HỌC (Student Join Classroom)", 1)
section_intro(doc, "Học sinh nhập mã lớp học (code) → hệ thống kiểm tra và tạo ClassroomMember.")

h(doc, "4.1 Luồng thực thi", 2)
flow_step(doc, "①", None, None, "Student POST /student/classrooms/join với body {code: 'XK9P2A'}")
flow_step(doc, "②", "middleware/rbac.js", "requireRole('student')", "Kiểm tra role")
flow_step(doc, "③", "validate/student/classroom.validate.js", None, "Validate code không rỗng, maxLength 10")
flow_step(doc, "④", "controller/student/classroom.controller.js", "joinClassroomHandler", "Chuẩn hóa code.toUpperCase()")
flow_step(doc, "⑤", "models/Classroom.js", None, "Classroom.findOne({code, isArchived:false}). Không tìm thấy → redirect với flash 'Không tìm thấy mã lớp'")
flow_step(doc, "⑥", "models/ClassroomMember.js", None, "ClassroomMember.findOne({classroom, student}) — Kiểm tra trùng lặp. Đã có → redirect 'Bạn đã ở trong lớp này'")
flow_step(doc, "⑦", None, None, "new ClassroomMember({classroom, student:req.user.id, status: classroom.approvalRequired ? 'pending' : 'approved'})")
flow_step(doc, "⑧", None, "member.save()", "INSERT vào 'classroomMembers'. Nếu trùng (race condition) → MongoDB E11000 → bắt error.code===11000 → flash message")
flow_step(doc, "⑨", None, None, "approvalRequired=true → redirect 'Đã gửi yêu cầu'. approvalRequired=false → redirect 'Tham gia thành công'")

h(doc, "4.2 Giáo viên duyệt/từ chối thành viên", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms/{id}/members/{memberId}/approve")
flow_step(doc, "②", "controller/teacher/classroom.controller.js", "approveMemberHandler", "findOne({_id:memberId, classroom}). Kiểm tra GV sở hữu lớp")
flow_step(doc, "③", None, None, "member.status='approved', member.approvedAt=new Date(), member.save()")
flow_step(doc, "④", None, None, "Redirect với feedback 'Student approved'")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 5 — TẠO VÀ XUẤT BẢN BÀI GIẢNG (Teacher)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 5 — TẠO & XUẤT BẢN BÀI GIẢNG (Teacher Create Lecture)", 1)
section_intro(doc, "Giáo viên tạo bài giảng có nội dung rich text (TinyMCE), đặt thứ tự và publish.")

h(doc, "5.1 Luồng thực thi", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms/{id}/lectures")
flow_step(doc, "②", "middleware/rbac.js", "requireRole('teacher')", "Xác thực role")
flow_step(doc, "③", "validate/teacher/lecture.validate.js", None, "Validate title, content, chapterTitle, orderIndex")
flow_step(doc, "④", "controller/teacher/lecture.controller.js", "createLectureHandler", "Kiểm tra GV sở hữu classroom. Parse req.body: title, content (HTML từ TinyMCE), chapterTitle, orderIndex, isPublished, summary")
flow_step(doc, "⑤", "models/Lecture.js", None, "new Lecture({classroom, teacher, title, content, chapterTitle, orderIndex, isPublished, summary})")
flow_step(doc, "⑥", None, "lecture.save()", "INSERT vào 'lectures'")
flow_step(doc, "⑦", None, None, "Redirect /teacher/classrooms/{id}/lectures?feedback=Lecture created")

h(doc, "5.2 Học sinh xem bài giảng + markComplete", 2)
section_intro(doc, "Khi học sinh xem bài giảng, hệ thống tự động ghi nhận hoàn thành vào completion ledger.")
flow_step(doc, "①", None, None, "Student GET /student/classrooms/{cId}/lectures/{lId}")
flow_step(doc, "②", "controller/student/lecture.controller.js", "renderLecture", "Kiểm tra membership {status:'approved'}. Tìm Lecture {isPublished:true}")
flow_step(doc, "③", "services/completion.service.js", "checkItemAccess", "Gọi computeCourseProgress(classroom, studentId) để kiểm tra bài giảng có bị LOCKED không. Nếu LOCKED → trả {allowed:false}")
flow_step(doc, "④", "helper/progress.js", "markComplete", "StudentProgress.findOneAndUpdate({classroom, student, itemType:'LESSON', itemId:lecture.id}, {completedAt:new Date()}, {upsert:true}). Idempotent — xem lại không tạo bản ghi thứ 2")
flow_step(doc, "⑤", None, None, "Render view student/lectures/show.pug với lecture data")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 6 — TẠO VÀ NỘP BÀI TẬP
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 6 — TẠO BÀI TẬP & HỌC SINH NỘP BÀI (Assignment + Submission)", 1)

h(doc, "6.1 Teacher tạo bài tập", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms/{id}/assignments (multipart/form-data)")
flow_step(doc, "②", "controller/teacher/assignment.controller.js", "createAssignmentHandler", "Parse req.body: title, description, instructions, totalPoints, dueDate, isPublished, allowLateSubmission")
flow_step(doc, "③", None, None, "Nếu req.files tồn tại (Multer đã parse): tạo mảng attachments [{fileName, fileUrl:'/uploads/assignments/{filename}', fileType, fileSize}]")
flow_step(doc, "④", "models/Assignment.js", None, "new Assignment({classroom, teacher, title, description, instructions, totalPoints, dueDate, isPublished, allowLateSubmission, attachments}). assignment.save()")
flow_step(doc, "⑤", "helper/notification.helper.js", "sendNotification", "ClassroomMember.find({status:'approved'}) → Với mỗi member: Notification.create({recipient, title:'New Assignment', message, link}). Dùng Promise.allSettled để không block dù 1 notification lỗi")

h(doc, "6.2 Student nộp bài", 2)
flow_step(doc, "①", None, None, "Student POST /student/classrooms/{cId}/assignments/{aId}/submission (multipart)")
flow_step(doc, "②", "validate/student/submission.validate.js", None, "Validate có ít nhất 1 trong: textContent hoặc file đính kèm")
flow_step(doc, "③", "controller/student/submission.controller.js", "submitAssignmentHandler", "Kiểm tra membership approved. Tìm assignment {isPublished:true}")
flow_step(doc, "④", None, None, "Kiểm tra dueDate: new Date() > dueDate && !assignment.allowLateSubmission → trả lỗi 'Deadline đã qua'")
flow_step(doc, "⑤", "models/Submission.js", None, "Submission.findOneAndUpdate({assignment, student}, {textContent, fileUrl, status:'submitted', submittedAt:new Date()}, {upsert:true, new:true}). Nộp lại ghi đè bài cũ")
flow_step(doc, "⑥", "helper/progress.js", "markComplete", "Ghi StudentProgress {itemType:'ASSIGNMENT', score:null, maxScore:null} — score null vì chưa được chấm")

h(doc, "6.3 Teacher chấm điểm bài nộp", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms/{cId}/assignments/{aId}/submissions/{sId}/grade")
flow_step(doc, "②", "controller/teacher/submission.controller.js", "gradeSubmissionHandler", "findOne({submission, assignment}). Parse req.body.score, clamp vào [0, assignment.totalPoints]")
flow_step(doc, "③", None, None, "submission.score=score, submission.teacherComment=comment, submission.status='graded', submission.gradedAt=new Date(). submission.save()")
flow_step(doc, "④", "helper/progress.js", "markComplete", "Cập nhật StudentProgress {score, maxScore:assignment.totalPoints, submittedAt}. Idempotent — cập nhật bản ghi cũ, không tạo mới")
flow_step(doc, "⑤", None, None, "Từ đây gradebook.service.js đọc được điểm mới nhất khi tính toán")

h(doc, "6.4 Teacher chấm điểm bằng Rubric", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms/{cId}/assignments/{aId}/submissions/{sId}/grade-rubric")
flow_step(doc, "②", "controller/teacher/submission.controller.js", "rubricGradeHandler", "Parse req.body: các field dạng 'crit_{criterionId}' → tạo gradesMap = {criterionId: points}")
flow_step(doc, "③", "services/grading.service.js", "gradeWithRubric", "findOne Assignment, Rubric, Submission. Gọi computeRubricTotal(rubric, gradesMap)")
flow_step(doc, "④", "services/grading.service.js", "computeRubricTotal", "Duyệt rubric.criteria, clamp điểm [0, criterion.maxPoints], cộng tổng. Pure function, không DB")
flow_step(doc, "⑤", None, None, "submission.rubricGrades=grades, submission.score=total, status='graded'. submission.save()")
flow_step(doc, "⑥", "helper/progress.js", "markComplete", "Cập nhật StudentProgress {score:total, maxScore:rubric.maxPoints}")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 7 — TIẾN ĐỘ HỌC TẬP & KHÓA BÀI (Course Progress + Locking)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 7 — TIẾN ĐỘ HỌC TẬP & KHÓA BÀI (Course Progress + Content Locking)", 1)
section_intro(doc, "Đây là một trong những business logic phức tạp nhất. Hệ thống tự động khóa các bài học tiếp theo cho đến khi học sinh hoàn thành bài trước đó.")

h(doc, "7.1 Khi nào computeCourseProgress được gọi?", 2)
bullet(doc, "Mỗi lần student xem trang chi tiết lớp học (GET /student/classrooms/{id})")
bullet(doc, "Mỗi lần student truy cập bài giảng/bài tập/bài thi (checkItemAccess gọi nội bộ)")
bullet(doc, "Khi GV xem progress của học sinh trong dashboard")

h(doc, "7.2 Luồng thực thi chi tiết", 2)
flow_step(doc, "①", "controller/student/classroom.controller.js", "renderStudentClassroomDetail", "Tìm ClassroomMember. Gọi computeCourseProgress(member.classroom, req.user.id)")
flow_step(doc, "②", "services/courseProgress.service.js", "computeCourseProgress", "Gọi 2 hàm song song qua Promise.all: buildContentItems(classroomId) và getCompletedItemKeys(classroomId, studentId)")
flow_step(doc, "③", "services/courseProgress.service.js", "buildContentItems", "Chạy 3 query song song (Promise.all): Lecture.find({isPublished:true}), Assignment.find({isPublished:true}), Exam.find({isPublished:true}). Normalize tất cả thành ContentItem DTO. Sort toàn cục theo moduleKey, orderIndex, createdAt")
flow_step(doc, "④", "services/courseProgress.service.js", "getCompletedItemKeys", "StudentProgress.find({classroom, student}).select('itemType itemId'). Trả về Set<string> với key format 'LESSON:id', 'EXAM:id'...")
flow_step(doc, "⑤", "services/courseProgress.service.js", "groupByModule", "Nhóm các ContentItem theo field moduleKey (= chapterTitle của lecture, hoặc 'Bài tập'/'Bài thi' mặc định)")
flow_step(doc, "⑥", "services/courseProgress.service.js", "resolvePrerequisite", "Với mỗi item trong module: tìm item isRequired ngay trước nó trong danh sách đã sort. Item đầu tiên = không có prerequisite")
flow_step(doc, "⑦", "services/courseProgress.service.js", "resolveStatus", "Logic quyết định trạng thái:\n        • completedKeys.has(item.id) → COMPLETED\n        • prereq tồn tại && !completedKeys.has(prereq.id) → LOCKED\n        • Item đầu tiên chưa complete trong module → IN_PROGRESS\n        • Còn lại → NOT_STARTED")
flow_step(doc, "⑧", None, None, "Trả về object đầy đủ: {progressPercent, modules:[{key, children:[{id, title, status, href}]}], currentLesson, nextLesson}")
flow_step(doc, "⑨", "views/student/classrooms/show.pug", None, "Render sidebar menu bên trái với màu sắc khác nhau theo status. LOCKED → icon khóa, không thể click")

h(doc, "7.3 Gate checkItemAccess (Chặn URL direct)", 2)
section_intro(doc, "Học sinh không thể bypass bằng cách nhập thẳng URL của bài học bị khóa.")
flow_step(doc, "①", "controller/student/lecture.controller.js", "renderLecture", "Sau khi tìm thấy lecture, gọi checkItemAccess({classroom, studentId, itemType:'LESSON', itemId})")
flow_step(doc, "②", "services/completion.service.js", "checkItemAccess", "Gọi computeCourseProgress (lại) để lấy cây progress. Tìm item.id trong tree")
flow_step(doc, "③", None, None, "child.status === LOCKED → {allowed:false, reason:'prerequisite_incomplete'}. Controller bắt → res.status(403).render('errors/403')")
flow_step(doc, "④", None, None, "Item không có trong published tree → {allowed:false, reason:'item_not_published'} → 404")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 8 — LÀM BÀI THI (Take Exam – Full Flow)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 8 — LÀM BÀI THI (Take Exam – Full Detail)", 1)
section_intro(doc, "Flow phức tạp nhất trong dự án. Bao gồm: kiểm soát lượt làm, chống gian lận server-side, chấm điểm tự động, và cập nhật completion ledger.")

h(doc, "8.1 Mở bài thi (renderTakeExam)", 2)
flow_step(doc, "①", None, None, "Student GET /student/classrooms/{cId}/exams/{eId}/take")
flow_step(doc, "②", "controller/student/exam.controller.js", "renderTakeExam", "Kiểm tra ClassroomMember {status:'approved'}")
flow_step(doc, "③", None, None, "Tìm Exam {isPublished:true, _id:examId, classroom}")
flow_step(doc, "④", "models/ExamSubmission.js", None, "ExamSubmission.countDocuments({exam, student, status:{$in:['submitted','graded','late','auto_submitted']}}). Đếm số lượt đã dùng (ATOMIC)")
flow_step(doc, "⑤", "services/examIntegrity.service.js", "canStartAttempt", "canStartAttempt(usedAttempts, exam.maxAttempts). maxAttempts=0 → unlimited. usedAttempts >= maxAttempts → false → redirect /result")
flow_step(doc, "⑥", None, None, "ExamSubmission.findOne({exam, student, status:'in_progress'}). Nếu chưa có:")
flow_step(doc, "⑦", "services/examIntegrity.service.js", "computeDeadline", "computeDeadline(new Date(), exam.duration) → startedAt + durationMinutes * 60 * 1000. Nếu duration<=0 → null (không giới hạn thời gian)")
flow_step(doc, "⑧", "models/ExamSubmission.js", None, "new ExamSubmission({exam, student, classroom, status:'in_progress', startedAt:now, attemptNumber:usedAttempts+1, deadlineAt}). submission.save(). Unique index {exam,student,attemptNumber} bảo vệ race condition")
flow_step(doc, "⑨", "models/Question.js", None, "Question.find({exam}).sort({order:1, createdAt:1})")
flow_step(doc, "⑩", None, None, "Nếu exam.shuffle=true: Fisher-Yates shuffle cả questions array và options array của từng câu")
flow_step(doc, "⑪", None, None, "Render student/exams/take.pug với {exam, questions, submission} — Frontend JS hiển thị countdown timer từ submission.deadlineAt")

h(doc, "8.2 Nộp bài thi (submitExamHandler)", 2)
flow_step(doc, "①", None, None, "Student POST /student/classrooms/{cId}/exams/{eId}/submit (khi click Nộp bài hoặc JS auto-submit khi hết giờ)")
flow_step(doc, "②", "controller/student/exam.controller.js", "submitExamHandler", "ExamSubmission.findOne({_id:req.body.submissionId, exam, student, status:'in_progress'}). Không tìm thấy → 400 'No active submission'")
flow_step(doc, "③", None, None, "Question.find({exam:exam.id}) — Lấy đáp án chuẩn")
flow_step(doc, "④", None, None, "Loop qua từng câu hỏi, parse req.body[`q_{question.id}`]:")
flow_step(doc, "   ", None, None, "• multiple_choice/multiple_answer: So sánh ansArray với correctOptionIds. Đúng hoàn toàn (exact match) → pointsAchieved=q.points")
flow_step(doc, "   ", None, None, "• essay: Lưu text vào answers. hasEssay=true. pointsAchieved=0 (chờ GV chấm)")
flow_step(doc, "⑤", "services/examIntegrity.service.js", "evaluateDeadline", "evaluateDeadline(submission.deadlineAt, new Date()) — So sánh SERVER clock với deadline + SUBMIT_GRACE_MS(30s). Nộp muộn → isLate=true (vẫn chấp nhận, status='late')")
flow_step(doc, "⑥", None, None, "submission.answers=answers, submission.score=totalScore, submission.submittedAt=now, submission.status=isLate?'late':'submitted', submission.gradingStatus=hasEssay?'pending_manual_grade':'auto_graded'. submission.save()")
flow_step(doc, "⑦", None, None, "LƯU Ý BẢO MẬT: req.body.violations bị BỎ QUA có chủ ý. Violations chỉ được ghi từ Socket.IO server-side (examMonitor namespace). Học sinh không thể tự sửa log gian lận của mình")
flow_step(doc, "⑧", "helper/progress.js", "markComplete", "Nếu !hasEssay: markComplete({student, classroom, itemType:'EXAM', itemId:exam.id, evidence:{score:totalScore, maxScore:exam.totalPoints, submittedAt}})")
flow_step(doc, "⑨", None, None, "Redirect /student/classrooms/{cId}/exams/{eId}/result")

h(doc, "8.3 Giám sát gian lận qua Socket.IO (/exam-monitor namespace)", 2)
section_intro(doc, "Toàn bộ hệ thống anti-cheat chạy server-side qua WebSocket.")
flow_step(doc, "①", None, None, "Frontend JavaScript phát hiện sự kiện: tab switch, fullscreen exit, copy/paste, window blur → emit socket event 'cheat-violation'")
flow_step(doc, "②", "index.js (examMonitor namespace)", "socket.on('cheat-violation')", "Tìm ExamSubmission {exam, student, status:'in_progress'}. Giới hạn violations.length < 200 để tránh unbounded array growth")
flow_step(doc, "③", None, None, "submission.violations.push({type, time:new Date(), details.slice(0,500)}). submission.save()")
flow_step(doc, "④", None, None, "examMonitor.to(examId).emit('student-violation', {studentId, studentName, violation}) — Broadcast tới phòng thi (nơi GV đang ngồi monitor)")

h(doc, "8.4 Teacher chấm bài thi có câu tự luận", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms/{cId}/exams/{eId}/submissions/{sId}/grade")
flow_step(doc, "②", "controller/teacher/exam.controller.js", "submitGradeHandler", "Gọi gradeSubmission(submissionId, examId, teacherId, req.body)")
flow_step(doc, "③", "services/exam.service.js", "gradeSubmission", "Tìm submission. Parse req.body[`q_{questionId}`] cho từng câu essay. Cập nhật submission.answers[i].pointsAchieved. Tính lại totalScore. submission.gradingStatus='graded'. submission.save()")
flow_step(doc, "④", "helper/progress.js", "markComplete", "markComplete với score mới → StudentProgress được cập nhật → gradebook tự động phản ánh điểm mới")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 9 — SỔ ĐIỂM (Gradebook)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 9 — SỔ ĐIỂM (Gradebook Computation)", 1)
section_intro(doc, "Sổ điểm được TÍNH TOÁN ON-THE-FLY mỗi lần xem, không lưu trong DB. Hệ thống đọc StudentProgress và áp dụng trọng số của GV.")

h(doc, "9.1 GV xem sổ điểm lớp", 2)
flow_step(doc, "①", None, None, "Teacher GET /teacher/classrooms/{id}/gradebook")
flow_step(doc, "②", "controller/teacher/classroom.controller.js", "renderGradebook", "Tìm Classroom (kiểm tra ownership). ClassroomMember.find({status:'approved'}).populate('student')")
flow_step(doc, "③", None, None, "Promise.all(members.map(m => computeGradebook(classroom, m.student._id)))")
flow_step(doc, "④", "services/gradebook.service.js", "computeGradebook", "Query StudentProgress WHERE classroom=id AND student=studentId AND score IS NOT NULL AND maxScore > 0")
flow_step(doc, "⑤", "services/gradebook.service.js", "normalizeWeights", "Đọc classroom.gradeWeights (ví dụ [{itemType:'EXAM', weight:70},{itemType:'ASSIGNMENT', weight:30}]). Normalize thành map {EXAM:0.7, ASSIGNMENT:0.3}")
flow_step(doc, "⑥", "services/gradebook.service.js", "gradeAverage", "Phân nhóm byType: {EXAM:{sum,count}, ASSIGNMENT:{sum,count}}. Tính typeAverages = {EXAM:82.5, ASSIGNMENT:75.0}")
flow_step(doc, "⑦", None, None, "Nếu có normalizedWeights: overallPercent = sum(typeAvg * weight) / weightUsed = 82.5*0.7 + 75.0*0.3 = 80.25")
flow_step(doc, "⑧", "services/gradebook.service.js", "letterFor", "So sánh 80.25 với classroom.gradingScale [{letter:'A',min:90},{letter:'B',min:80}...] → letter='B'")
flow_step(doc, "⑨", None, None, "Trả {overallPercent:80.3, letter:'B', byItem:[...], byType:{EXAM:{percent:82.5,count:2},...}}")
flow_step(doc, "⑩", None, None, "Render teacher/classrooms/gradebook.pug với bảng điểm toàn lớp")

h(doc, "9.2 Export sổ điểm CSV", 2)
flow_step(doc, "①", None, None, "Teacher GET /teacher/classrooms/{id}/gradebook/export.csv")
flow_step(doc, "②", "controller/teacher/classroom.controller.js", "exportGradebookCsv", "Tương tự renderGradebook nhưng dùng json2csv Parser để render CSV string")
flow_step(doc, "③", None, None, "res.setHeader('Content-Disposition', 'attachment; filename=gradebook-{id}.csv'). res.send(csv)")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 10 — HỌP ONLINE (WebRTC Meeting)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 10 — HỌP ONLINE (WebRTC Meeting với Socket.IO)", 1)
section_intro(doc, "Hệ thống họp video tích hợp WebRTC peer-to-peer với phòng chờ (Waiting Room) và điều phối qua Socket.IO /meeting namespace.")

h(doc, "10.1 Teacher tạo phòng họp", 2)
flow_step(doc, "①", None, None, "Teacher POST /teacher/meetings/create (hoặc qua form trang classroom)")
flow_step(doc, "②", "services/meeting.service.js", "createMeeting", "Classroom.findById để validate. Sinh roomId = 'room_{classroomId}_{4bytes hex}' bằng crypto.randomBytes")
flow_step(doc, "③", None, None, "startNow=true → status='LIVE', startTime=now. startNow=false → status='SCHEDULED', parsedStartTime=req.body.startTime")
flow_step(doc, "④", "models/Meeting.js", None, "new Meeting({classroom, teacher, title, startTime, endTime=startTime+duration, status, roomId}). meeting.save()")
flow_step(doc, "⑤", "models/Notification.js", None, "ClassroomMember.find({status:'approved'}) → Notification.insertMany cho tất cả students")
flow_step(doc, "⑥", None, None, "io.of('/meeting').to('classroom:{id}').emit('meeting:status_changed', {meeting}) → Frontend cập nhật live meeting banner")

h(doc, "10.2 Student tham gia phòng họp (WebRTC Signaling)", 2)
flow_step(doc, "①", None, None, "Student click Join Meeting → Frontend connect Socket.IO namespace /meeting")
flow_step(doc, "②", "index.js (meetingMonitor namespace)", "socketAuthMiddleware", "Xác thực qua JWT cookie hoặc session cookie → socket.userId, socket.userRole")
flow_step(doc, "③", None, None, "Frontend emit 'join-room' với {meetingId, userId, userName, userRole, audioActive, videoActive}")
flow_step(doc, "④", "index.js", "socket.on('join-room')", "socket.join(meetingId) — vào room Socket.IO")
flow_step(doc, "   ", None, None, "Teacher → thêm vào meetingRoomsState[meetingId][socket.id]. Emit 'room_users' (danh sách đang họp) và 'waiting_students_list' (phòng chờ)")
flow_step(doc, "   ", None, None, "Student → thêm vào meetingWaitingRoomsState[meetingId][socket.id]. Emit 'waiting_for_approval' về student. Notify Teacher 'waiting_students_list' mới")
flow_step(doc, "⑤", None, None, "Teacher approve: emit 'approve_student_join' {targetSocketId} → Server chuyển student từ waiting sang active. meetingMonitor.to(targetSocketId).emit('join_approved') → Student bắt đầu WebRTC handshake")
flow_step(doc, "⑥", None, None, "WebRTC signaling flow: emit 'webrtc_offer' → server relay → peer emit 'webrtc_answer' → server relay → 'ice_candidate' exchanges → P2P video stream thành lập")

h(doc, "10.3 Background status sync", 2)
flow_step(doc, "①", None, None, "index.js: setInterval(15000) → meetingService.runBackgroundStatusSync(io)")
flow_step(doc, "②", "services/meeting.service.js", "runBackgroundStatusSync", "Meeting.find({status:{$in:['SCHEDULED','LIVE']}}) → Loop gọi syncMeetingStatus(meeting, io)")
flow_step(doc, "③", "services/meeting.service.js", "syncMeetingStatus", "SCHEDULED && now >= startTime && now < endTime → LIVE. LIVE/SCHEDULED && now >= endTime → ENDED. Save và emit socket event")
flow_step(doc, "④", None, None, "autoEndEmptyMeeting: khi participant cuối disconnect, setTimeout 4s → kiểm tra phòng trống → ENDED")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 11 — CHAT (Real-time)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 11 — CHAT REAL-TIME (Socket.IO /chat namespace)", 1)
section_intro(doc, "Hệ thống chat gồm 2 loại: Chat nhóm trong lớp học và Direct Message (DM) 1-1.")

h(doc, "11.1 Chat nhóm lớp học", 2)
flow_step(doc, "①", None, None, "User connect /chat namespace → emit 'join_chat' {classroomId}")
flow_step(doc, "②", "index.js (chatMonitor namespace)", "socket.on('join_chat')", "Kiểm tra ClassroomMember {status:'approved'} hoặc Classroom.teacher=userId. Hợp lệ → socket.join(classroomId)")
flow_step(doc, "③", None, None, "User emit 'send_message' {classroomId, content, fileUrl?}")
flow_step(doc, "④", None, None, "content = String(content).trim().slice(0,1000). Kiểm tra lại quyền truy cập (double-check)")
flow_step(doc, "⑤", "models/ChatMessage.js", None, "ChatMessage.create({classroom, sender, content, fileUrl, fileName, fileType, fileSize}). newMessage.populate('sender','name avatarUrl')")
flow_step(doc, "⑥", None, None, "chatMonitor.to(classroomId).emit('receive_message', {id, content, sender, createdAt}) → Tất cả member trong phòng nhận được")

h(doc, "11.2 Direct Message (DM) 1-1", 2)
flow_step(doc, "①", None, None, "User emit 'join_user_dm_room' → socket.join('user:{userId}')")
flow_step(doc, "②", None, None, "User emit 'send_direct_message' {recipientId, content, fileUrl?}")
flow_step(doc, "③", "services/chat.service.js", "saveDirectMessage", "DirectMessage.create({sender, recipient, content, fileUrl, ...}). Trả DM document đã được populate")
flow_step(doc, "④", None, None, "chatMonitor.to('user:{recipientId}').to('user:{senderId}').emit('receive_direct_message', dm) → Cả 2 phía nhận tin nhắn")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 12 — ĐÁNH GIÁ HOÀN THÀNH KHÓA HỌC & CHỨNG CHỈ
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 12 — ĐÁNH GIÁ HOÀN THÀNH KHÓA HỌC & CẤP CHỨNG CHỈ", 1)
section_intro(doc, "Hệ thống tự động đánh giá xem học sinh đã đủ điều kiện hoàn thành khóa học chưa dựa trên completion rules.")

h(doc, "12.1 evaluateClassroomCompletion", 2)
flow_step(doc, "①", "controller/student/classroom.controller.js", "renderStudentClassroomDetail", "Gọi evaluateClassroomCompletion(classroom, studentId) song song với computeCourseProgress")
flow_step(doc, "②", "services/completion.service.js", "evaluateClassroomCompletion", "Gọi computeCourseProgress để lấy completedCount/totalCount. Gọi computeGradebook để lấy gradePercent")
flow_step(doc, "③", "services/completion.service.js", "evaluateCompletion", "Pure function kiểm tra 3 rules từ classroom.completionRules:\n        • Rule 1: requireAllItems → completedCount >= totalCount\n        • Rule 2: minOverallPercent → gradePercent >= threshold\n        • Rule 3: requiredItemTypes → mỗi loại phải có ít nhất 1 bản ghi hoàn thành")
flow_step(doc, "④", None, None, "Trả {isComplete, isPassing, met:[], missing:[]} → View hiển thị badge 'Hoàn thành' nếu isComplete=true")
flow_step(doc, "⑤", "models/Certificate.js", None, "Nếu isComplete && isPassing → Student có thể xem/download certificate (Certificate model lưu link PDF/image)")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 13 — AI ASSISTANT (Gemini API)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 13 — AI LEARNING ASSISTANT (Gemini API Integration)", 1)
section_intro(doc, "Mỗi lớp học có một AI tutor riêng, được cung cấp context về giáo trình của lớp đó.")

flow_step(doc, "①", None, None, "Student nhập câu hỏi → POST /api/student/classrooms/{id}/ai-assistant {message}")
flow_step(doc, "②", "controller/student/classroom.controller.js", "askAiAssistantHandler", "Kiểm tra membership {status:'approved'}. Lấy userMessage=req.body.message.trim()")
flow_step(doc, "③", None, None, "Promise.all: Lecture.find({isPublished:true}).select('title summary'), Assignment.find, Exam.find → build context string")
flow_step(doc, "④", "models/SystemSetting.js", None, "SystemSetting.findOne({key:'geminiApiKey'}) → Lấy API key từ DB (ưu tiên) hoặc process.env.GEMINI_API_KEY")
flow_step(doc, "⑤", None, None, "fetch POST https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key={apiKey}")
flow_step(doc, "⑥", None, None, "response.candidates[0].content.parts[0].text → Trả JSON {answer}")
flow_step(doc, "⑦", None, None, "Nếu không có apiKey → trả mock response thân thiện với thống kê giáo trình")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 14 — ADMIN MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 14 — ADMIN: QUẢN TRỊ HỆ THỐNG", 1)
section_intro(doc, "Admin có dashboard riêng tại /admin với đăng nhập riêng biệt.")

h(doc, "14.1 Duyệt Teacher", 2)
flow_step(doc, "①", None, None, "Admin POST /admin/teacher-approvals/{id}/approve")
flow_step(doc, "②", "controller/admin/teacherApproval.controller.js", "approveTeacher", "Tìm User {_id, role:'teacher'}. user.status='active'. user.save()")
flow_step(doc, "③", None, None, "Redirect với feedback 'Teacher approved'")

h(doc, "14.2 Cài đặt hệ thống", 2)
flow_step(doc, "①", None, None, "Admin POST /admin/settings")
flow_step(doc, "②", "controller/admin/setting.controller.js", "updateSettings", "Đọc từng setting key từ req.body. SystemSetting.findOneAndUpdate({key}, {value}, {upsert:true}) cho từng key")
flow_step(doc, "③", None, None, "Các setting quan trọng: allowRegistration (bật/tắt đăng ký), geminiApiKey (AI), maintenanceMode, maxFileSize")

h(doc, "14.3 Import học sinh (SIS)", 2)
flow_step(doc, "①", None, None, "Admin upload file CSV qua POST /admin/sis/import")
flow_step(doc, "②", "controller/admin/sis.controller.js", None, "Parse CSV. Với mỗi row: User.findOne({email}) hoặc tạo mới. Gán vào classroom nếu có cột classroomCode")
flow_step(doc, "③", None, None, "Trả summary: {created, updated, errors}")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# FLOW 15 — ĐIỂM DANH (Attendance)
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "FLOW 15 — ĐIỂM DANH (Attendance)", 1)
section_intro(doc, "Giáo viên tạo phiên điểm danh, học sinh check-in. Dữ liệu lưu 2 collection: AttendanceSession và AttendanceRecord.")

flow_step(doc, "①", None, None, "Teacher POST /teacher/classrooms/{id}/attendance/sessions/create → AttendanceSession.create({classroom, date, status:'open'})")
flow_step(doc, "②", None, None, "Teacher phát code/link cho học sinh")
flow_step(doc, "③", None, None, "Student POST /student/classrooms/{id}/attendance/checkin {sessionId}")
flow_step(doc, "④", "controller/student/attendance.controller.js", "checkIn", "Kiểm tra session còn 'open'. AttendanceRecord.create({session, student, checkedInAt:now, status:'present'})")
flow_step(doc, "⑤", None, None, "Teacher đóng session: AttendanceSession.findOneAndUpdate({_id}, {status:'closed'})")
flow_step(doc, "⑥", None, None, "Teacher xem báo cáo: aggregate AttendanceRecord theo session → % present/absent")
divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
# TỔNG KẾT
# ══════════════════════════════════════════════════════════════════════════════
h(doc, "TỔNG KẾT: BẢN ĐỒ DEPENDENCY GIỮA CÁC FLOW", 1)
para(doc, "Sơ đồ cho thấy helper/progress.js::markComplete là trung tâm của toàn bộ hệ thống:", bold=True)
code(doc, """helper/progress.js::markComplete()
  ← submitExamHandler()         [Exam nộp bài]
  ← submitGradeHandler()        [GV chấm bài thi essay]
  ← gradeSubmissionHandler()    [GV chấm bài tập]
  ← rubricGradeHandler()        [GV chấm rubric]
  ← renderLecture()             [HS xem bài giảng]

services/courseProgress.service.js::computeCourseProgress()
  ← renderStudentClassroomDetail()  [trang chủ lớp]
  ← checkItemAccess()               [gate mọi content item]
  ← evaluateClassroomCompletion()   [đánh giá hoàn thành]

services/gradebook.service.js::computeGradebook()
  ← renderGradebook()               [GV xem sổ điểm]
  ← exportGradebookCsv()            [export CSV]
  ← evaluateClassroomCompletion()   [đánh giá hoàn thành]""")

para(doc, "\n")
para(doc, "File quan trọng nhất cần đọc trước:", bold=True)
bullet(doc, "index.js — Entry point, toàn bộ middleware stack và Socket.IO namespaces")
bullet(doc, "helper/progress.js — markComplete(): Điểm ghi dữ liệu duy nhất vào completion ledger")
bullet(doc, "services/courseProgress.service.js — computeCourseProgress(): Logic unlock/lock bài học")
bullet(doc, "services/gradebook.service.js — computeGradebook(): Tính điểm trung bình trọng số")
bullet(doc, "services/examIntegrity.service.js — computeDeadline/evaluateDeadline/canStartAttempt")
bullet(doc, "controller/student/exam.controller.js — submitExamHandler(): Business logic thi cử phức tạp nhất")
bullet(doc, "middleware/rbac.js — requireAuth/requireRole: Bảo vệ mọi route")

# ── SAVE ──────────────────────────────────────────────────────────────────────
os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
doc.save(OUT_PATH)
print(f"SUCCESS: {OUT_PATH}")
