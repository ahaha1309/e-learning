# 03_Backend_Code_Explanation_Full_Part2.docx
# Tiếp tục giải thích chi tiết các Controller còn lại cho Admin, Teacher, Student.
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = r"C:\Users\vanha\Downloads\Documentations_DOCX\03_Backend_Code_Explanation_Full_Part2.docx"

def new_doc():
    doc = Document()
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    return doc

def heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    if p.runs:
        r = p.runs[0]
        r.font.name = 'Calibri'
        clr = {1: RGBColor(0x00,0x33,0x66), 2: RGBColor(0x00,0x55,0x99),
               3: RGBColor(0x1A,0x6A,0x1A), 4: RGBColor(0x66,0x33,0x00)}
        r.font.color.rgb = clr.get(level, RGBColor(0,0,0))
        sz = {1:16, 2:13, 3:11, 4:10}
        r.font.size = Pt(sz.get(level, 11))
    return p

def code_block(doc, code_text):
    for line in code_text.split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent   = Inches(0.35)
        p.paragraph_format.space_before  = Pt(0)
        p.paragraph_format.space_after   = Pt(0)
        r = p.add_run(line if line.strip() else ' ')
        r.font.name  = 'Courier New'
        r.font.size  = Pt(9)
        r.font.color.rgb = RGBColor(0x17,0x5E,0x24)
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'),   'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'),  'F2F2F2')
        p._p.get_or_add_pPr().append(shd)

def explain_text(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after  = Pt(8)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)
    return p

def bullet(doc, text, level=0):
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.left_indent = Inches(0.5 + level*0.3)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after  = Pt(2)
    r = p.add_run(text)
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)

def meta_label(doc, label, value):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after  = Pt(4)
    rb = p.add_run(f'{label}: ')
    rb.bold = True
    rb.font.name = 'Calibri'
    rb.font.size = Pt(10.5)
    rv = p.add_run(value)
    rv.font.name = 'Calibri'
    rv.font.size = Pt(10.5)
    rv.font.color.rgb = RGBColor(0x00,0x55,0x99)

def divider(doc):
    p = doc.add_paragraph('─' * 90)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after  = Pt(6)
    for r in p.runs:
        r.font.color.rgb = RGBColor(0xAA,0xAA,0xAA)
        r.font.size = Pt(8)

def page_break(doc):
    doc.add_page_break()

doc = new_doc()

# ──── TITLE ────────────────────────────────────────────
tp = doc.add_paragraph()
tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run('03. GIẢI THÍCH CODE BACKEND TOÀN BỘ (PHẦN 2)\nE-Learning LMS — Node.js / Express / MongoDB')
r.font.name = 'Calibri'; r.font.size = Pt(20); r.bold = True
r.font.color.rgb = RGBColor(0x00,0x33,0x66)
explain_text(doc, 'Tiếp tục phân tích các file controller còn lại trong hệ thống, tập trung vào Admin, Teacher, và Student.')
divider(doc)
page_break(doc)

# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 7 — CÁC CONTROLLER ADMIN CÒN LẠI', 1)

heading(doc, '7.1 controller/admin/assignment.controller.js', 2)

heading(doc, 'Phần 1 — Hàm listAssignments (Dòng 4–24)', 3)
meta_label(doc, 'Route', 'GET /admin/assignments')
code_block(doc, '''const query = req.query.q;
let filter = {};
if (query) {
  filter.title = { $regex: query, $options: 'i' };
}
const assignments = await Assignment.find(filter)
  .populate('classroom', 'name')
  .populate('teacher', 'name')
  .sort({ createdAt: -1 });''')
explain_text(doc, 'Tìm kiếm bài tập theo title bằng regex không phân biệt chữ hoa/thường ($options: "i"). Populate để lấy tên classroom và teacher từ ObjectId, không lấy toàn bộ document (giảm băng thông). Sort lấy bài mới tạo lên trên cùng.')

heading(doc, 'Phần 2 — Hàm renderAdminEditAssignment (Dòng 50–80)', 3)
meta_label(doc, 'Route', 'GET /admin/assignments/:assignmentId/edit')
code_block(doc, '''const dueDateFormatted = assignment.dueDate ? new Date(assignment.dueDate.getTime() - (assignment.dueDate.getTimezoneOffset() * 60000)).toISOString().slice(0, 16) : '';

return res.render('admin/assignments/edit', {
  ...
  formData: {
    dueDate: dueDateFormatted,
    isPublished: String(assignment.isPublished),
    allowLateSubmission: String(assignment.allowLateSubmission),
  }
});''')
explain_text(doc, 'Format dueDate thành chuẩn "YYYY-MM-DDThh:mm" để hiển thị đúng trong thẻ <input type="datetime-local"> của HTML5. Bù trừ timezone offset của server (getTimezoneOffset) để khi slice(0,16) ra đúng local time. Ép kiểu boolean thành string để render pug template dễ dàng.')

heading(doc, 'Phần 3 — Hàm updateAdminAssignmentHandler (Dòng 82–126)', 3)
meta_label(doc, 'Route', 'POST /admin/assignments/:assignmentId/edit')
code_block(doc, '''assignment.title = req.body.title;
assignment.totalPoints = Number(req.body.totalPoints || 10);
assignment.dueDate = new Date(req.body.dueDate);
assignment.isPublished = req.body.isPublished !== 'false';
assignment.allowLateSubmission = req.body.allowLateSubmission === 'true';''')
explain_text(doc, 'Ép kiểu khi update: totalPoints thành số. isPublished != "false" vì HTML form gửi checkbox/radio dưới dạng string. Nếu giá trị là "false", isPublished = false, ngược lại true.')
code_block(doc, '''if (req.files && req.files.length > 0) {
  req.files.forEach((f) => {
    const ext = path.extname(f.originalname).replace('.', '').toLowerCase();
    assignment.attachments.push({
      fileName: f.originalname,
      fileUrl: `/uploads/assignments/${f.filename}`,
      fileType: ext || 'file',
      fileSize: f.size,
      uploadedAt: new Date(),
    });
  });
}''')
explain_text(doc, 'Hỗ trợ upload nhiều file đính kèm nhờ multer middleware đã bọc trước đó (req.files). push object metadata của file vào mảng attachments trong document. Lưu URL tương đối (/uploads/assignments/...) để dễ migrate/host tĩnh.')

divider(doc)

heading(doc, '7.2 controller/admin/setting.controller.js', 2)

heading(doc, 'Phần 1 — Hàm resolveSettingImage (Dòng 5–16)', 3)
code_block(doc, '''async function resolveSettingImage(req, field, folder, existingValue) {
  const uploadedFile = req.files && Array.isArray(req.files[field]) ? req.files[field][0] : null;
  if (uploadedFile) {
    const secureUrl = await uploadImageBuffer(uploadedFile, folder);
    return secureUrl || existingValue || '';
  }
  return existingValue || '';
}''')
explain_text(doc, 'Logic thông minh xử lý ảnh hệ thống (logo/favicon): Nếu Admin tải ảnh MỚI lên, gọi uploadImageBuffer() lên Cloudinary và lấy URL mới. Nếu không up ảnh mới, trả về URL cũ (được form gửi lên qua thẻ hidden input) để không làm mất ảnh đang dùng.')

heading(doc, 'Phần 2 — Hàm renderSettings (Dòng 18–106)', 3)
meta_label(doc, 'Route', 'GET /admin/settings')
code_block(doc, '''const settings = await SystemSetting.find().sort({ key: 1 });
const config = {};
settings.forEach(s => { config[s.key] = s.value; });

const defaults = {
  siteName: 'E-Learning LMS',
  sessionTimeout: 480,
  maxLoginAttempts: 5,
  // ... hơn 40 setting mặc định
};
for (const [key, val] of Object.entries(defaults)) {
  if (config[key] === undefined || config[key] === null) {
    config[key] = val;
  }
}''')
explain_text(doc, 'Mô hình key-value pattern: Đọc toàn bộ record từ SystemSetting. Chuyển array thành object config = { key1: val1, key2: val2 }. Đổ defaults vào config nếu database chưa có key đó (ví dụ khi mới cài đặt hệ thống).')

heading(doc, 'Phần 3 — Hàm updateSettingsHandler (Dòng 108–225)', 3)
meta_label(doc, 'Route', 'POST /admin/settings')
code_block(doc, '''const bool = (v) => v === 'true';
const num = (v, d) => Number(v) || d;

const settingsMap = {
  siteName: { value: payload.siteName || 'E-Learning LMS', description: 'Global Site Name' },
  allowRegistration: { value: bool(payload.allowRegistration), description: 'Allow new users to register' },
  sessionTimeout: { value: num(payload.sessionTimeout, 480), description: 'Session timeout in minutes' },
  // ... 40 settings
};

for (const [key, { value, description }] of Object.entries(settingsMap)) {
  await SystemSetting.findOneAndUpdate(
    { key },
    { value, description },
    { upsert: true }
  );
}''')
explain_text(doc, 'Các hàm helpers ép kiểu string từ HTML form sang bool và number một cách gọn gàng. settingsMap dùng để gom dữ liệu với description đi kèm. Duyệt map và chạy findOneAndUpdate với tuỳ chọn upsert: true (chưa có thì tạo mới, có rồi thì cập nhật). Chạy tuần tự vòng lặp for..of (không dùng Promise.all vì DB có thể limit rate với 40 upserts cùng lúc).')

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 8 — CÁC CONTROLLER TEACHER CÒN LẠI', 1)

heading(doc, '8.1 controller/teacher/meeting.controller.js', 2)

heading(doc, 'Phần 1 — Hàm createMeetingHandler (Dòng 61–85)', 3)
meta_label(doc, 'Route', 'POST /teacher/classrooms/:cId/meetings')
code_block(doc, '''const { title, date, startTime, duration, startNow } = req.body;
const io = req.app.get('io'); // Lấy instance Socket.io từ Express app

const meeting = await meetingService.createMeeting({
  classroomId: classroom.id,
  teacherId: req.user.id,
  title,
  startTime: startNow ? new Date() : new Date(`${date}T${startTime}`),
  duration: Number(duration),
  startNow: startNow === 'true',
}, io);''')
explain_text(doc, 'Giáo viên lên lịch hoặc khởi động ngay cuộc họp (Zoom/Google Meet thu nhỏ qua WebRTC). req.app.get("io") là kỹ thuật chuẩn để lấy socket.io instance bên trong HTTP Controller. Gọi meetingService tạo phòng và phát event realtime tới học sinh.')

heading(doc, 'Phần 2 — Hàm endMeetingHandler (Dòng 104–121)', 3)
meta_label(doc, 'Route', 'POST /teacher/classrooms/:cId/meetings/:mId/end')
code_block(doc, '''const meeting = await Meeting.findOne({ _id: req.params.meetingId, teacher: req.user.id });
if (!meeting || meeting.status === 'ENDED') {
  return res.redirect(`/teacher/classrooms/${classroom.id}?feedback=Meeting+not+found`);
}

meeting.status = 'ENDED';
meeting.endTime = new Date();
await meeting.save();

const io = req.app.get('io');
io.of('/meeting').to(`classroom:${classroom.id}`).emit('meeting:status_changed', { meeting });
io.of('/meeting').to(String(meeting._id)).emit('meeting_ended_by_teacher', { message: 'The teacher has ended the meeting.' });''')
explain_text(doc, 'Chỉ giáo viên tạo meeting mới được quyền kết thúc. Emit 2 sự kiện: 1 tới namespace /meeting cho room chung "classroom:id" để tất cả học sinh đang xem trang tổng quan biết cuộc họp đã kết thúc (ẩn banner), 2 tới namespace room id riêng của cuộc họp để những ai ĐANG TRONG CUỘC HỌP bị kick ra.')

divider(doc)

# ══════════════════════════════════════════════════════════════════════════════
heading(doc, 'CHƯƠNG 9 — CÁC CONTROLLER STUDENT CÒN LẠI', 1)

heading(doc, '9.1 controller/student/chat.controller.js', 2)

heading(doc, 'Phần 1 — Load tin nhắn cũ (Dòng ~25)', 3)
meta_label(doc, 'Route', 'GET /student/classrooms/:cId/chat/history')
code_block(doc, '''const messages = await ChatMessage.find({ classroom: classroomId })
  .populate('sender', 'name avatarUrl role')
  .sort({ createdAt: -1 })
  .limit(100);

// Client mong đợi mảng tin nhắn mới nhất ở dưới cùng, cũ hơn ở trên cùng
messages.reverse();
return res.json({ messages });''')
explain_text(doc, 'Query: Lấy 100 tin nhắn mới nhất bằng cách sort createdAt: -1 (mới nhất lên đầu). Tuy nhiên, UI chat hiển thị từ trên xuống dưới (cũ -> mới). Do đó phải gọi reverse() sau khi lấy xong kết quả từ DB rồi mới trả về Frontend.')

heading(doc, '9.2 controller/student/profile.controller.js', 2)

heading(doc, 'Phần 1 — Hàm updateProfile (Dòng ~50)', 3)
meta_label(doc, 'Route', 'POST /student/profile/edit')
code_block(doc, '''const user = await User.findById(req.user.id);
user.name = req.body.name || user.name;
user.phone = req.body.phone || user.phone;

if (req.file) {
  const secureUrl = await uploadImageBuffer(req.file, 'avatars');
  user.avatarUrl = secureUrl || user.avatarUrl;
}
await user.save();''')
explain_text(doc, 'Cập nhật avatar sử dụng Cloudinary upload trực tiếp từ buffer (không lưu trên disk server) bằng uploadImageBuffer (multer memory storage). Tránh làm rác ổ cứng server và đồng bộ ảnh nhanh chóng ra CDN.')

# ── SAVE ──────────────────────────────────────────────
os.makedirs(os.path.dirname(OUT), exist_ok=True)
doc.save(OUT)
print(f"SUCCESS: {OUT}")
